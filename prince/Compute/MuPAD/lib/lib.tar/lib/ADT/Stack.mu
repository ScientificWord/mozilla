/*****************************************************************************
  $Id $
  File:		lib/ADT/Stack.mu
  Authors:	Nicolas M. Thi�ry <nthiery@users.sourceforge.net>
  Purpose:	Source code for the domain adt::Stack
  Created:	Tue Jan  6 09:04:13 2004
  License:	LGPL
  Project:	MuPAD-Combinat, http://mupad-combinat.sf.net
*****************************************************************************/

domain adt::Stack

    new := () -> dom::newExtended([args()]);

    printMaxSize := 10;

    newExtended :=
    proc(S, emptyPop = FAIL, emptyTop = FAIL, i = FAIL)
	option escape;
    begin
	if i=FAIL then
	    i := nops(S);
	end_if;
	funcenv
	(()->null(),
	 "Stack",
	 // maprec is workaround for kernel problem: output of
	 // funcenvs switches to Unquoted automatically. :-(
	 table("print" =
	       proc()
		   local entries;
	       begin
		   if nops(S) <= adt::Stack::printMaxSize then
		       entries := S;
		   else
		       entries := [output::asciiArt(["..."]),
				   op(S, nops(S)-9..nops(S))];
		   end_if;
		   subsop(hold(f)
			  (op(misc::maprec(entries,
					   {DOM_STRING} = expr2text,
					   Unsimplified))), 0=dom)
	       end_proc,
	       
	       "expr2text" =
	       (() -> "adt::Stack(".expr2text(op(S)).")"),

	       "nops" =
	       (() -> i),

	       "push" =
	       (value -> (i := i+1; S := append(S, value); value)),

	       "pop" =
	       proc()
		   local popVal;
	       begin
		   if S=[] then
		       if emptyPop = FAIL then
			   FAIL
		       else
			   i:=i-1;
			   emptyPop(i+1)
		       end_if;
		   else
		       i := i-1;
		       popVal := S[nops(S)];
		       delete(S[nops(S)]);
		       popVal
		   end_if;
	       end_proc,

	       "top" =
	       proc(k = 0)
	       begin
		   if nops(S) <= k then
		       emptyTop(i-k)
		   else
		       S[nops(S) - k]:
		   end_if
	       end_proc,

	       "depth"   = (() -> i),

	       "empty"   = (() -> bool(i = 0)),

	       "reverse" = (() -> (S := revert(S); null())),

	       "S"       = (() -> S),

	       "copy"    = prog::bless((() -> dom::newExtended(S, emptyPop, emptyTop, i)),
				       dom)));
    end_proc;

end_domain:
