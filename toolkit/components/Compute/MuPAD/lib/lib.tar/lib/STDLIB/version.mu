// $Date: 2006-09-15 12:56:45 +0200 (Fri, 15 Sep 2006) $ $Author: cube - sort of Anonymous $ $Revision: 40550 $ 

// kg, 09/05/94 

/*++
version -- return current version number of MuPAD

version()

version returns a list with 3 integers: the major version
number, the minor version number and the release number.

Example:
version() returns [1,2,1] for the MuPAD kernel 1.2.1.
++*/

version:= proc() option noDebug;
begin
    if testargs() then
	if args(0) <> 0 then error("wrong no of args") end_if;
    end_if;
    [4, 0, 1]
end_proc:

// end of file 
