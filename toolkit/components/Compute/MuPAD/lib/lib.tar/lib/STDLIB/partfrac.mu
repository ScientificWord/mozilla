// $Date: 2006-05-30 14:30:11 +0200 (Tue, 30 May 2006) $ $Author: walter $ $Revision: 39353 $
/* partfrac(f,x) computes a partial fraction decomposition of f wrt x
   partfrac(f, x, Full) computes the full partial fraction decomposition
   over the complex numbers (undocumented!)
  
  Examples:

>> partfrac((2-3*x+x^3)/(9+3*x-5*x^2+x^3),x);

                       1          19          5        
                   --------- + --------- + -------- + 1
                   4 (x + 1)   4 (x - 3)          2    
                                           (x - 3)     

>> partfrac((x^2+y^2)/(x+x*y),x);

                                         2    
                               x        y     
                             ----- + ---------
                             y + 1   x (y + 1)

>> partfrac(1/(x^2+1),x); 

                                    1   
                                  ------
                                   2    
                                  x  + 1

>> partfrac(1/(x^2+1),x, Full);

                              - 1/2 I   1/2 I
                              ------- + -----
                               x - I    x + I
*/

partfrac :=
proc(f,xx)
  local x,d,i,n,l,rest,m,j,s,p,degd,qr,k,t,u,v,ll;
begin
  if args(0)=0 then
    error("No argument given")
  end_if;

  if f::dom::partfrac <> FAIL then
    return(f::dom::partfrac(args()))
  end_if;
  
  if args(0)<2 then
    if nops( (x:= op(indets(f))) ) <> 1 then
      error("you should supply a variable as second argument")
    end_if
  else
    x:=xx
  end_if;

  if testargs() then
    if traperror((p:=poly(1, [x]))) <> 0 then
      error("illegal indeterminate")
    end_if;
    if args(0) = 3 then
      if args(3) <> Full then
        error("Unknown option")
      end_if
    end_if;
  end_if;

  //----------------------------------
  // Change by Walter: 8.12.05
  // Note that 
  //   numer(f) <> numer(normal(f)) 
  //   denom(f) <> denom(normal(f))
  // We do need to normalize!
  f:= normal(f);
  //----------------------------------

  n:=numer(f);
  d:=denom(f);
  l:=divide(n,d,[x]);
  //-----------------------------------
  // Walter: 30.5.06
  // divide may produce FAIL (e.g., divide(sqrt(1 + 1/x), x, [x])).
  // Return the original input (normalized):
  if l = FAIL then
     return(f);
  end_if;
  //-----------------------------------
  p:=l[1]; // polynomial part
  n:=l[2];
  l:=factor(d);
  // Anpassung an Umstellung Factored::_index (Walter, 29.12.04)
  l:= coerce(l, DOM_LIST):
  if args(0)>=3 then
    ll:=[l[1]];
    for i from 1 to nops(l) div 2 do
      d:=op(l,2*i);
      if degree(d,[x])>1 then
        t:=lcoeff(d,[x]); ll[1]:=ll[1]*t; d:=d/t;
        s:=solve(d,x,Multiple);
        if type(s)=Dom::Multiset then
          for u in [extop(s)] do
            ll:=append(ll,x-u[1],u[2]*l[2*i+1])
          end_for;
          next
        end_if
      end_if;
      ll:=append(ll,d,l[2*i+1])
    end_for;
    l:=ll
  end_if;
  m:=nops(l) div 2;
  s:=0;
  for i from 1 to m do
    d:=op(l,2*i);
    degd:=degree(d,x);
    t:=d^op(l,2*i+1);
    rest:=_mult(op(l,2*j)^op(l,2*j+1)$ j=i+1..m);
    j:=solvelib::pdioe(t,rest,n,x);
    u:=j[1]; v:=j[2]; // j[1]*t+j[2]*rest=n
    n:=j[2];
      // split one component : s:=s+j[2]/t 
    for k from op(l,2*i+1) downto 1 do
      qr:=divide(n,d,[x]);
      s:=s+qr[2]/d^k;
      n:=qr[1];
      if n=0 then
        break
      end_if
    end_for;
    n:=j[1];
  end_for;
  p+s/op(l,1)
end_proc:
