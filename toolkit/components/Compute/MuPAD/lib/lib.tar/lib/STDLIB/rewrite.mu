// $Date: 2006-09-04 17:00:27 +0200 (Mo, 04 Sep 2006) $ $Author: Stefan Wehmeier $ $Revision: 40448 $

// rewrite the expression f to type typ

rewrite :=
proc(f, typ)
begin

  if args(0) <> 2 then
    error("wrong number of arguments")
  end_if;

  if f::dom::rewrite <> FAIL then
    return(f::dom::rewrite( args() ))
  end_if;

  if domtype(typ)= DOM_FUNC_ENV and slot(typ, "rewrite")<>FAIL then
    return(slot(typ, "rewrite")(args()))
  end_if;

  case typ
    of exp do
      eval(subs(f,
               [hold(_power)=
                proc(a, b)
                begin
                  if a=0 or testtype(b, Type::Constant) then
                    a^b
                  else
                    exp(b*ln(a))
                  end_if
                end_proc,
                hold(sin)   = (x -> 1/(2*I)*(exp(x*I)-exp(-x*I))),
                hold(cos)   = (x -> 1/2*(exp(x*I)+exp(-x*I))),
                hold(tan)   = (x -> -I*(exp(x*I)^2-1)/(exp(x*I)^2+1)),
                hold(cot)   = (x -> I*(exp(x*I)^2+1)/(exp(x*I)^2-1)),
                hold(sinh)  = (x -> 1/2*(exp(x)-exp(-x))),
                hold(cosh)  = (x -> 1/2*(exp(x)+exp(-x))),
                hold(tanh)  = (x -> (exp(x)^2-1)/(exp(x)^2+1)),
                hold(coth)  = (x -> (exp(x)^2+1)/(exp(x)^2-1)),
                hold(arcsin)= (x -> -I*ln(I*x+sqrt(1-x^2))),
                hold(arccos)= (x -> -I*ln(x+I*sqrt(1-x^2))),
                hold(arctan)= (x -> I/2*(ln(1-I*x)-ln(1+I*x))),
                hold(arccot) = (x -> I/2*(ln(1-I/x)-ln(1+I/x))),
                hold(arcsinh)= (x -> ln(x+sqrt(x^2+1))),
                hold(arccosh)= (x -> ln(x+sqrt(x^2-1))),
                hold(arctanh)= (x -> 1/2*(ln(1+x)-ln(1-x))),
                hold(arccoth)= (x -> 1/2*(ln(1+1/x)-ln(1-1/x))),
             // 2-argument version of arg is obsolete
             // hold(arg)    = ((x, y) -> -I*ln((x+I*y)/abs(x+I*y)))
                hold(arg)    = (z -> -I*ln(z/abs(z)))
               ]));
      break
    of tan do
      eval(subs(f, [
                hold(sin)  = (x ->  2*tan(x/2)     / (1+tan(x/2)^2) ),
                hold(cos)  = (x -> (1-tan(x/2)^2)  / (1+tan(x/2)^2) ),
                hold(cot)  = (x ->  1/tan(x) ),
             // hold(exp)  = (x -> (1-I*tan(I*x/2))^2
             //                                    / (1+tan(I*x/2)^2) ),
                hold(exp)  = (x -> (I+tan(I*x/2))  / (I-tan(I*x/2)) ),
                hold(sinh) = (x -> -I*2*tan(I*x/2) / (1+tan(I*x/2)^2) ),
                hold(cosh) = (x -> (1-tan(I*x/2)^2)/ (1+tan(I*x/2)^2) ),
                hold(tanh) = (x ->-I*tan(I*x) ),
                hold(coth) = (x -> I/tan(I*x) )
               ]));
      break
    of tanh do
      eval(subs(f, [
                hold(sin)  = (x ->-2*I*tanh(I*x/2) /(1-tanh(I*x/2)^2) ),
                hold(cos)  = (x ->(1+tanh(I*x/2)^2)/(1-tanh(I*x/2)^2) ),
                hold(tan)  = (x ->-I*tanh(I*x) ),
                hold(cot)  = (x -> I/tanh(I*x) ),
             // hold(exp)  = (x -> (1+tanh(x/2))^2 /(1-tanh(x/2)^2) ),
                hold(exp)  = (x -> (1+tanh(x/2))   /(1-tanh(x/2)  ) ),
                hold(sinh) = (x -> 2*tanh(x/2)     /(1-tanh(x/2)^2) ),
                hold(cosh) = (x -> (1+tanh(x/2)^2) /(1-tanh(x/2)^2) ),
                hold(coth) = (x ->  1/tanh(x))
               ]));
      break
    of cot do
      eval(subs(f, [
                hold(sin)  = (x ->   2*cot(x/2)   / (cot(x/2)^2+1) ),
                hold(cos)  = (x -> (cot(x/2)^2-1) / (cot(x/2)^2+1) ),
                hold(tan)  = (x -> 1/cot(x) ),
             // hold(exp)  = (x ->-(1+I*cot(I*x/2))^2/(1+cot(I*x/2)^2) ),
                hold(exp)  = (x -> (cot(I*x/2)-I)   / (cot(I*x/2)+I) ),
                hold(sinh) = (x -> -I*2*cot(I*x/2)  / (1+cot(I*x/2)^2) ),
                hold(cosh) = (x -> (cot(I*x/2)^2-1) / (1+cot(I*x/2)^2) ),
                hold(tanh) = (x ->-I/cot(I*x) ),
                hold(coth) = (x -> I*cot(I*x) )
               ]));
      break
    of coth do
      eval(subs(f, [
                hold(sin)  = (x -> -2*I*coth(I*x/2) /(coth(I*x/2)^2-1) ),
                hold(cos)  = (x -> (1+coth(I*x/2)^2)/(coth(I*x/2)^2-1) ),
                hold(tan)  = (x -> -I/coth(I*x) ),
                hold(cot)  = (x ->  I*coth(I*x) ),
             // hold(exp)  = (x -> (1+coth(x/2))^2 / (coth(x/2)^2-1) ),
                hold(exp)  = (x -> (1+coth(x/2))   / (coth(x/2)  -1) ),
                hold(sinh) = (x ->    2*coth(x/2)  / (coth(x/2)^2-1) ),
                hold(cosh) = (x -> (coth(x/2)^2+1) / (coth(x/2)^2-1) ),
                hold(tanh) = (x -> 1/coth(x) )
               ]));
      break
    of ln do
      eval(subs(f, [
                // formulae 4.4.26-4.4.31 in Abramowitz and Stegun
                hold(arcsin)=(x ->  -I*ln(I*x+sqrt(1-x^2))),
                hold(arccos)=(x ->  -I*ln(x+I*sqrt(1-x^2))),
                hold(arctan)=(x ->   I/2*(ln(1-I*x)-ln(1+I*x))),
                hold(arccot)=(x ->  I/2*(ln(1-I/x) - ln(1+I/x))),
                // formulae 4.6.20-4.6.25 in Abramowitz and Stegun
                hold(arcsinh)=(x -> ln(x+sqrt(x^2+1))),
                hold(arccosh)=(x -> ln(x+sqrt(x^2-1))),
                // both rewriting rules arctanh -> ln are valid
         //     hold(arctanh)=(x -> ln(sqrt(1+x))-ln(sqrt(1-x))),
                hold(arctanh)=(x -> 1/2*( ln(1+x)-ln(1-x))),
                // both rewriting rules arccoth -> ln are valid
         //     hold(arccoth)=(x -> ln(sqrt(1+1/x))-ln(sqrt(1-1/x))),
                hold(arccoth)=(x -> 1/2* (ln(1+1/x)-ln(1-1/x))),
         //  the following does not hold for z=0 !!!
             // 2-argument version of arg is obsolete
             // hold(arg)    = ((x, y) -> -I*ln((x+I*y)/abs(x+I*y))),
                hold(arg)    = (z -> -I*ln(z/abs(z))),
                hold(log)=((b, x) -> ln(x)/ln(b))
               ]));
      break
    of lambertW do
      eval(subs(f, hold(wrightOmega)
                   = (x->lambertW(ceil((Im(x)-PI)/2/PI), exp(x)))));
      break;
    of gamma do
      eval(subs(f, [
                hold(fact) = (n -> gamma(n+1)),
                hold(fact2) = (n -> gamma(n/2 + 1)*2^(((2*n+1 - (-1)^n))/4)
                    * PI^ (((-1)^n - 1)/4)),
                hold(binomial) = ((n,k) -> gamma(n+1)/gamma(k+1)/gamma(n-k+1)),
		hold(beta) = ((x,y) -> gamma(x)*gamma(y)/gamma(x+y))
               ]));
      break
      /*
    of sum do
      eval(subs(f,
		[hold(hypergeom) = hypergeom::asSum]));
      break;
      */
    of fact do
      misc::maprec(f,
                   {"gamma"} =
                   proc(g)
                     local x;
                   begin
                     x:= op(g, 1);
                     if is(x, Type::Integer) = TRUE then
                       fact(x - 1)
                     else
                       g
                     end_if
                   end_proc,
                   {"binomial"} =
                   proc(b)
                     local n, k;
                   begin
                     [n, k]:= [op(b)];
                     fact(n)/fact(k)/fact(n-k)
                   end_proc,
                   {"beta"} =
                   proc(bet)
                     local x, y;
                   begin
                     [x, y]:= [op(bet)];
                     fact(x - 1)*fact(y - 1)/fact(x + y - 1)
                   end_proc,
                   {"fact2"} =
                   proc(fct2)
                     local n;
                   begin
                     n:= op(fct2, 1);
                     if is(n, Type::Even) = TRUE then
                       (n/2)! * 2^(n/2)
                     elif is(n, Type::Odd) = TRUE then
                       n! / ((n-1)/2)! / 2^((n-1)/2)
                     else
                       fact2(n)
                     end_if
                   end_proc
                   );
      break
    of diff do
      // we must map into subexpressions of type "function" to
      // catch subexpressions = D(...)(x1, x2, ...).
      // Do not map into subexpressions of type "D", because
      // D(...) cannot be rewritten into diff if the arguments
      // (x1, x2, ..) are not known
      misc::maprec(f, {"function"} = stdlib::D2diff);
      break
    of D do
      // it suffices to map into subexpressions of type "diff"
      // to rewrite  diff(f(x), x) -> D(f)(x)
      misc::maprec(f, {"diff"} = stdlib::diff2D);
      break
    of sign do
      misc::maprec(f,{"heaviside"}=
                   proc()
                   begin
                     (sign(op(args(1)))+1)/2
                   end_proc,
                   {"abs"}=
                   proc()
                   begin
                     op(args(1), 1)/sign(op(args(1)))
                   end_proc);
      break
    of heaviside do
      misc::maprec(f,{"sign"}=
                   proc()
                   begin
                     2*heaviside(op(args(1)))-1
                   end_proc );
      break
    of piecewise do
      eval(subs(f, [
                hold(sign)=
                proc(x)
                begin
                  if type(x)=piecewise then
                    piecewise([piecewise::extmap(x,_not@_leequal,0), 1],
                               [piecewise::extmap(x,_less,0), -1],
                               [piecewise::extmap(x, _equal, 0), 0],
                               [piecewise::extmap(x, z-> not z in R_),
                                x/sqrt(Re(x)^2+Im(x)^2) ]
                               )
                  else
                    piecewise([x>0, 1],
                               [x<0, -1],
                               [x=0, 0],
                               [not x in R_, x/sqrt(Re(x)^2+Im(x)^2)]
                               )
                  end_if
                end_proc,
                hold(abs)=
                proc(x)
                begin
                  if type(x)=piecewise then
                    piecewise([piecewise::extmap(x,_not@_less,0), x],
                               [piecewise::extmap(x,_leequal,0), -x],
                               [piecewise::extmap(x, z-> not z in R_),
                                sqrt(Re(x)^2+Im(x)^2) ]
                               )
                  else
                    piecewise([x>=0, x],
                               [x<=0, -x],
                               [not x in R_, sqrt(Re(x)^2+Im(x)^2)]
                               )
                  end_if;
                end_proc,
                hold(heaviside)=
                proc(x)
                  begin
                  if type(x)=piecewise then
                    piecewise([piecewise::extmap(x,_not@_leequal,0), 1],
                              [piecewise::extmap(x,_equal, 0), heaviside(0)],
                              [piecewise::extmap(x,_less,0), 0]
                               )
                  else
                    piecewise([x>0, 1],
                              [x=0, heaviside(0)],
                              [x<0, 0]
                               )
                  end_if;
                end_proc,
                hold(max)=
                    proc()
                      local argv, i, j;
                    begin
                      argv:= [args()];
                      assert(not hastype(argv, piecewise));
                      piecewise(
                      [_and(argv[i] >= argv[j] $j=1..args(0)), argv[i]]
                      $i=1..args(0))
                    end_proc,
                hold(min)=
                    proc()
                      local argv, i, j;
                    begin
                    argv:= [args()];
                      assert(not hastype(argv, piecewise));
                      piecewise(
                      [_and(argv[i] <= argv[j] $j=1..args(0)), argv[i]]
                      $i=1..args(0))
                    end_proc
           ]));
      break
    of max do
      misc::maprec(f,
        {"min"} = (ex -> -max(op(map(ex, _negate)))),
        {"abs"} = (ex -> if is(op(ex), Type::Real) = TRUE then
                           max(op(ex), -op(ex))
                         else ex end_if));
      break;
    of min do
      misc::maprec(f,
        {"max"} = (ex -> -min(op(map(ex, _negate)))),
        {"abs"} = (ex -> if is(op(ex), Type::Real) = TRUE then
                           -min(op(ex), -op(ex))
                         else ex end_if));
      break;
    of sincos do
      misc::maprec(f,
                   {"exp"}= proc() begin
                     cos(op(args(1),1)/I)+I*sin(op(args(1),1)/I)
                   end_proc,
                   {"tan"}= proc() begin
                     sin(op(args(1)))/cos(op(args(1)))
                   end_proc,
                   {"cot"}= proc() begin
                     cos(op(args(1)))/sin(op(args(1)))
                   end_proc,
                   {"sinh"}= proc() begin
                     -I*sin(I*op(args(1),1))
                   end_proc,
                   {"cosh"}= proc() begin
                     cos(I*op(args(1),1))
                   end_proc,
                   {"tanh"}= proc() begin
                     -I*sin(I*op(args(1),1))/cos(I*op(args(1),1))
                   end_proc,
                   {"coth"}= proc() begin
                     I*cos(I*op(args(1),1))/sin(I*op(args(1),1))
                   end_proc
                  );
      break
    of sin do
      f:= rewrite(f, sincos);
      f:= misc::maprec(f,
                       {"_power"} =
                       proc(pow)
                         local base, expo, z;
                       begin
                         if type((base:= op(pow, 1))) = "cos" and
                           type((expo:= op(pow, 2))) = DOM_INT then
                           z:= op(base, 1);
                           if expo >= 2 or expo <= -2 then
                             // cos(z)^(2n) = (cos(z)^2)^n
                             //             = (1-sin(z)^2)^n
                             return
                             (base^(expo mod 2) * (1 - sin(z)^2)^(expo div 2))
                           end_if
                       end_if;
                       pow
                       end_proc
                       );
      // replace remaining cos(x) by 1 - 2 * sin(x/2)^2
      eval(subs(f, hold(cos) = (x -> 1 - 2 * sin(x/2)^2) ));
      break
    of cos do
      f:= rewrite(f, sincos);
      f:= misc::maprec(f,
                   {"_power"} =
                   proc(pow)
                     local base, expo, z;
                   begin
                     if type((base:= op(pow, 1))) = "sin" and
                       type((expo:= op(pow, 2))) = DOM_INT then
                       z:= op(base, 1);
                       if expo >= 2 or expo <= -2 then
                         // sin(z)^(2n) = (sin(z)^2)^n
                         //             = (1-cos(z)^2)^n
                         return
                         (base^(expo mod 2) * (1 - cos(z)^2)^(expo div 2))
                       end_if
                     end_if;
                     pow
                   end_proc
                                            );
      eval(f);
      break
    of arcsin do
      eval(subs(f,
                [
                 hold(arccos) = (x -> PI/2 - arcsin(x)),
              // hold(arctan) = (x -> arcsin(x/sqrt(1+x^2))), // this is false
                 hold(arctan) = (x -> signIm(I*x)*(PI/2 - arcsin(1/sqrt(1+x^2)))),
              // hold(arccot) = (x -> PI/2 - arcsin(x/sqrt(1+x^2))) // this is false
                 hold(arccot) = (x -> signIm(I/x)*PI/2 - signIm(I/sqrt(1+x^2))*arcsin(x/sqrt(1+x^2)))
                 ]));
      break
    of arccos do
      eval(subs(f,
                [
                 hold(arcsin) = (x -> PI/2 - arccos(x)),
              // hold(arctan) = (x -> PI/2 - arccos(x/sqrt(1+x^2))),  // this is false
                 hold(arctan) = (x -> signIm(I*x)* arccos(1/sqrt(1+x^2))),
              // hold(arccot) = (x -> arccos(x/sqrt(1+x^2)))  // this is false
                 hold(arccot) = (x -> signIm(I/x)*arccos(sqrt(-x^2)/sqrt(-(1+x^2))))
                 ]
                ));
      break
    of arctan do
      eval(subs(f,
                [
               //hold(arcsin)  = (x -> arctan(x/sqrt(1-x^2))),        // this is false
                 hold(arcsin)  = (x -> 2*arctan(x/(1 + sqrt(1-x^2)))),
                 hold(arccos)  = (x -> PI/2 - 2*arctan(x/(1 + sqrt(1-x^2)))),
               //hold(arccot)  = (x -> PI/2 - arctan(x))              // this is false
		 hold(arccot)  = (x -> arctan(1/x)),                   // OK except for x = 0
		 hold(arctanh) = (x -> -I*arctan(I*x))
                 ]
                ));
      break
    of arccot do
      eval(subs(f,
                [
              // hold(arcsin) = (x -> PI/2 - arccot(x/sqrt(1-x^2))),  // this is false
                 hold(arcsin) = (x -> 2*arccot((1 + sqrt(1-x^2))/x)),
              // hold(arccos) = (x -> arccot(x/sqrt(1-x^2))),         // this is false
                 hold(arccos) = (x -> PI/2 - 2*arccot((1 + sqrt(1-x^2))/x)),
              // hold(arctan) = (x -> PI/2 - arccot(x))               // this is false
                 hold(arctan) = (x -> arccot(1/x))   // OK except for x = 0
                 ]
                ));
      break
    of sinhcosh do
      eval(subs(f, [
                hold(exp) =(x ->  cosh(x) + sinh(x) ),
                hold(tanh)=(x ->    sinh(x)/cosh(x) ),
                hold(coth)=(x ->    cosh(x)/sinh(x) ),
                hold(sin) =(x ->  I*sinh(x/I) ),
                hold(cos) =(x ->    cosh(x/I) ),
                hold(tan) =(x ->  I*sinh(x/I)/cosh(x/I) ),
                hold(cot) =(x -> -I*cosh(x/I)/sinh(x/I) )
                   ]));
      break
    of sinh do
      f:= rewrite(f, sinhcosh);
      f:= misc::maprec(f,
                       {"_power"} =
                       proc(pow)
                         local base, expo, z;
                       begin
                         if type((base:= op(pow, 1))) = "cosh" and
                           type((expo:= op(pow, 2))) = DOM_INT then
                           z:= op(base, 1);
                           if expo >= 2 or expo <= -2 then
                             // cosh(z)^(2n) = (cosh(z)^2)^n
                             //             = (1 + sinh(z)^2)^n
                             return
                             (base^(expo mod 2) * (1 + sinh(z)^2)^(expo div 2))
                           end_if
                       end_if;
                       pow
                       end_proc
                       );
      // cosh(x) = cosh(x/2)^2 + sinh(x/2)^2 = 1 + 2*sinh(x/2)^2
      eval(subs(f, hold(cosh) = (x -> 1 + 2 * sinh(x/2)^2) ));
      break
    of cosh do
      f:= rewrite(f, sinhcosh);
      misc::maprec(f,
                   {"_power"} =
                   proc(pow)
                     local base, expo, z;
                   begin
                     if type((base:= op(pow, 1))) = "sinh" and
                       type((expo:= op(pow, 2))) = DOM_INT then
                       z:= op(base, 1);
                       if expo >= 2 or expo <= -2 then
                         // sinh(z)^(2n) = (sinh(z)^2)^n
                         //             = (-1 + cosh(z)^2)^n
                         return
                         (base^(expo mod 2) * (-1 + cosh(z)^2)^(expo div 2))
                       end_if
                   end_if;
                   pow
                   end_proc
                   );
      break
    of arcsinh do
      eval(subs(f,
                [
                 hold(ln)     = (x -> signIm(I*(x + 1/x))* arcsinh((x-1/x)/2)
                                    + PI*I*signIm(x)*(1 - signIm(I*(x+1/x)))/2),
                 hold(arcsin) = (x -> signIm(I*x)*(PI + 2*I*arcsinh(I/sqrt(2)*sqrt((1 - x^2)^(1/2) + 1)))),
                 hold(arccos) = (x -> (1/2 - signIm(I*x))*PI
                                          - signIm(I*x)*2*I*arcsinh(I/sqrt(2)*sqrt((1 - x^2)^(1/2) + 1))),
                 hold(arctan) = (x -> signIm(I*x)*(PI/2 + I*arcsinh(I/(x^2 + 1)^(1/2)))),
                 hold(arccot) = (x -> signIm(I/x)*(PI/2 + I*arcsinh(I/(1/x^2 + 1)^(1/2)))),
                 hold(arccosh) = (x -> signIm(I*x)*arcsinh(sqrt(x^2 - 1))
                                        + PI*I*signIm(x + sqrt(x^2 -1))*(1 - signIm(I*x))/2),
             //  both of the following formulas for arctanh --> arcsinh are ok
             //  hold(arctanh) = (x -> signIm(x)*(PI/2*I + signIm(x^2 - 1)* arcsinh(1/sqrt(x^2 - 1)))),
                 hold(arctanh) = (x -> signIm(x)*(PI/2*I - arcsinh(I/sqrt(1 - x^2)))),
             //  both of the following formulas for arccoth --> arcsinh are ok
             //  hold(arccoth) = (x -> signIm(1/x)*(PI/2*I + signIm(1/x^2 - 1)* arcsinh(1/sqrt(1/x^2 - 1)))),
                 hold(arccoth) = (x -> signIm(1/x)*(PI/2*I - arcsinh(I/sqrt(1 - 1/x^2))))
                ]
                ));
      break
    of arccosh do
      eval(subs(f,
                [hold(ln)     = (x -> signIm(I*(x - 1/x))* arccosh(1/2*(x + 1/x))
                                    + PI*I/2* (1 - sqrt(x)*sqrt(1/x))*(1 - signIm(I*(x-1/x)))),
                 hold(arcsin) = (x -> I*signIm(x)*arccosh(sqrt(1 - x^2))),
                 hold(arccos) = (x -> I*signIm(sqrt(1 - x^2))*arccosh(x)
                                    + (1 - sqrt(x+1)*sqrt(1/(x+1)))*PI),
                 hold(arctan) = (x -> signIm(I*x)*PI/2 - I*signIm(1/x)*arccosh(sqrt(x^2/(x^2 + 1)))),
                 hold(arccot) = (x -> signIm(I/x)*PI/2 - I*signIm(x)*arccosh(sqrt(1/(x^2 + 1)))),

                 hold(arcsinh) = (x -> signIm(I*x)*arccosh(sqrt(x^2 + 1))),
                 hold(arctanh) = (x -> signIm(x)*I*PI/2
                                     + signIm(I/x) * arccosh(sqrt(x^2/(x^2 - 1)))),
                 hold(arccoth) = (x -> signIm(1/x)*I*PI/2
                                     + signIm(I*x) * arccosh(sqrt(1/(1 - x^2))))
                 ]
                ));
      break
    of arctanh do
      eval(subs(f,
                [hold(ln)     = (x ->  2*arctanh((x-1)/(x+1))
                                     + PI*I*(1 - sqrt(x+1)*sqrt(1/(x + 1)))
                                ),       // OK except for x = -1
                 hold(arcsin) = (x -> -2*I*arctanh((I*x + (1-x^2)^(1/2) - 1)/
                                                   (I*x + (1-x^2)^(1/2) + 1))
                                ),       // OK except for x = I
                 hold(arccos) = (x -> PI/2 + 2*I*arctanh((I*x + (1-x^2)^(1/2) - 1)/
                                                         (I*x + (1-x^2)^(1/2) + 1))
                                ),       // OK except for x = I
                 hold(arctan) = (x -> -I*arctanh(I*x)),  // OK except for x = +- 1 , +-I
                 hold(arccot) = (x -> -I*arctanh(I/x)),  // OK except for x = +- 1 , +-I
              // both the following rules arcsinh -> arctanh are OK:
              // hold(arcsinh) = (x -> arctanh(sqrt(1 + x^2)/x) - PI/2*I*signIm(conjugate(x))):
                 hold(arcsinh) = (x -> 2*arctanh((x - 1 + (x^2 + 1)^(1/2))/
                                                 (x + 1 + (x^2 + 1)^(1/2)))) ,
                 hold(arccosh) = (x -> 2*arctanh((x - 1 + (x^2 - 1)^(1/2))/
                                                 (x + 1 + (x^2 - 1)^(1/2)))) ,
                 hold(arccoth) = (x -> arctanh(1/x))  // OK except for x = 0
                ]
                ));
      break
    of arccoth do
      eval(subs(f,
                [hold(ln)     = (x ->  2*arccoth((x+1)/(x-1))
                                     + PI*I*(1 - sqrt(x+1)*sqrt(1/(x + 1)))
                                ),       // OK except for x = 1
                 hold(arcsin) = (x -> -2*I*arccoth((I*x + (1-x^2)^(1/2) + 1)/
                                                   (I*x + (1-x^2)^(1/2) - 1))
                                ),       // OK except for x = 0
                 hold(arccos) = (x -> PI/2 + 2*I*arccoth((I*x + (1-x^2)^(1/2) + 1)/
                                                         (I*x + (1-x^2)^(1/2) - 1))
                                ),       // OK except for x = 0
                 hold(arctan) = (x -> I*arccoth(I/x)),  // OK except for x = +- 1 , +-I
                 hold(arccot) = (x -> I*arccoth(I*x)),  // OK except for x = +- 1 , +-I
              // both the following rules arcsinh -> arccoth are OK:
              // hold(arcsinh) = (x -> arccoth(1/sqrt(1 + x^2)/x) - PI/2*I*signIm(conjugate(1/x))):
                 hold(arcsinh) = (x -> 2*arccoth((x + 1 + (x^2 + 1)^(1/2))/
                                                 (x - 1 + (x^2 + 1)^(1/2)))) ,
                 hold(arccosh) = (x -> 2*arccoth((x + 1 + (x^2 - 1)^(1/2))/
                                                 (x - 1 + (x^2 - 1)^(1/2)))) ,
                 hold(arctanh) = (x -> arccoth(1/x))  // OK except for x = 0
                 ]
                ));
      break
    of andor do
      misc::maprec(f,
                   {"_implies"} = (x -> not op(x,1) or op(x,2)),
                   {"_equiv"}   = (x -> op(x,1) and op(x,2) or
                                   (not op(x,1) and not op(x,2))),
                   {"_xor"}     = (x -> (op(x,1) or op(x,2)) and
                                   not (op(x,1) and op(x,2) ))
                   );
      break
    of Re do
      eval(subs(f, hold(Im) = (x -> (x - Re(x))/I )));
      break
    of Im do
      eval(subs(f, hold(Re) = (x -> (x - Im(x)))));
      break
    otherwise
      error("Unknown target type in rewrite")
  end_case;
  /* eval is not mapped through matrices so we have to do this here */
  f := %;
  if hastype( f, Dom::Matrix() ) then
    f := misc::maprec( f, { Dom::Matrix() }=proc( X ) begin map( X, eval ); end_proc, Unsimplified );
  end_if;
  f;
end_proc:

//--------------------------------------------------
// utilities for rewrite target 'diff'
//--------------------------------------------------
/*
  Rewrite D(..)(x1, x2, ..) to diff(..., x1, x2, ...)
  if x1, x2, .. are distinct identifiers/indexed identifiers.

  If x1, x2, are not identifiers, then rewriting to D to diff
  would be possible. However, diff would reconvert to D automatically.

  If any of the identifier x1, x2,... occurs twice,
  D cannot be rewritten.
  E.g., D([1], f)(x1, x1) = diff(f(x1, x1), x1) - D([2], f)(x1, x1).

  The following is implemented:

  D(f)(x) -> diff(f(x),x)
  D(D(f))(x) -> diff(f(x),x,x)
  D([1],f)(x) -> diff(f(x),x)
  D([1,2],f)(x,y) -> diff(f(x,y),x,y)
  D(f)(x,y) -> error
*/
stdlib::D2diff:=
proc(x)
  local i, f, nlist, varlist;
begin
  if type(op(x, 0)) <> "D" then
     return(x);
  end_if;

  if nops(x)=1 and
     contains({DOM_IDENT, "_index"}, type(op(x,1))) and
     nops(op(x,0))=1
     then // x = D(f)(X)
          return(stdlib::recursiveD2diff(op(x, 0..1)))
  elif
     map({op(x)},type) minus {DOM_IDENT, "_index"} = {} then
    // D(...)(X, Y, ...)
    if nops(x) <> nops({op(x)}) then
       // some of the variables occur twic, e.g.,
       // D([1], f)(x, y, x). This cannot be
       // rewritten as a diff-expression:
       // diff(f(x, y, x), x) <> D([1], f)(x, y, x) !
       if nops(op(x, 0)) = 1 and nops(x) > 1 then
            // x = D(f)(X, Y, ..)
            error("univariate derivative ".expr2text(op(x, 0)).
                  " called with ".expr2text(nops(x)). " arguments (".expr2text(op(x)).")")
       end_if;
       return(x);
    end_if;
    if nops(op(x,0))=2 then
      // x = D([n1, n2,...], f)(X, Y, ...)
      // nlist = op(x, [0, 1]) = [n1, n2, ...]
      // op(x, [0, 2]) = f
      nlist:= op(x,[0,1]); // list of indices
      varlist:= [op(x, nlist[i]) $ i =1..nops(nlist)]:
      if has(varlist, FAIL) then
         error("derivative with respect to a non-existing ".
               "argument requested");
      end_if;
      diff(subsop(x, 0 = op(x,[0,2])), op(varlist));
    elif
      nops(op(x,0))=1 and op(x,[0,0])=hold(D)
      then
         // x = D(f)(X1,X2,...,X.N) -> diff(f(X1,X2,...), X1)+diff(...,X2)+...
         if nops(x) > 1 then
            error("univariate derivative ".expr2text(op(x, 0)).
                  " called with ".expr2text(nops(x)). " arguments (".expr2text(op(x)).")")
         end_if;
         // x = D(f)(X) -> diff(f(X), X)
         // op(x, [0, 1]) = f
         f:= op(x, [0, 1]);
         diff(f(op(x, 1)), op(x, 1));
    else x
    end_if
  else // x = D(..)(expr1, expr2, ...)
       // where at least one of the expressions
       // is not an identifier. In this case,
       // it is not possible to rewrite the
       // D-expression as a diff-expression.
       x
  end_if
end_proc :

// rewrite  D(D(..(D(f))..))(X) -> diff(f(X), X, .., X)
stdlib::recursiveD2diff:= proc()
begin
  if type(args(1))="D" and nops(args(1))=1 then
     //args() = D(D(..(D(f))..)), X
     diff(stdlib::recursiveD2diff(op(args(1),1),args(2)),args(2))
  else
    // stopping criterion for the recursive call:
    // recursiveD2diff(f, X) = f(X)
    args(1)(args(2))
  end_if
end_proc :

//--------------------------------------------------
// utilities for rewrite target 'D'
//--------------------------------------------------

// stdlib::diff2D: convert diffs in an expression into D's
//
// Applying the multivariate chain rule:
// diff(function(y1, y2, ...), x1, x2, x3, ...))
// -->
// diff(  diff(function(y1,y2,..),x1), x2, x3, ...)
// -->
// diff(  D([1], function)(y1, y2, ...) * diff(y1, x1)
//      + D([2], function)(y1, y2, ...) * diff(y2, x1)
//      + ...,
//      x2, x3, ...)
//
// and the diff's are converted into D's recursively

stdlib::diff2D := proc(f)
  local g, function, y, x1, otherVariables, i, mydiff;
begin
   if not has(f, diff) then
     return(f);
   end_if;
   case type(f)
   of "_plus" do
   of "_mult" do
   of "_power" do
      // step recursively into expressions
      return(map(f, stdlib::diff2D))
   of "diff" do

      // apply multivariate chain rule and proceed recursively
      // f= diff(function(y1, y2, ...), x1, x2, ...)
      //         ^^^^^^^^^^^^^^^^^^^^^
      //                 g

      g:= op(f, 1):

      if domtype(g) <> DOM_EXPR then
         return(f);
      end_if;

      //------------------------------------------------
      // Warning: diff(x, x[i]) remains symbolically.
      // Warning: diff(x+y, x[i]) remains symbolically.
      // Warning: diff(x[i], x) remains symbolically.
      // Bugs in diff?
      // In these cases, nothing can be done.
      // The following is a crude workaround:
      case type(g)
      of "_index" do // takes care of symbolic diff(x[i], x)
      of "_plus" do  // takes care of symbolic diff(x+y, x[i])
      of "_mult" do  // takes care of symbolic diff(x*y, x[i])
      of "_power" do // takes care of symbolic diff(x^y, x[i])
         return(f);
      end_case;

      //------------------------------------------------
      // Warning: diff(x[i], x[i]) remains symbolically.
      // The following is a crude workaround:
      // mydiff becomes obsolete, when diff is changed s.th.
      // diff(x[i], x) = 0
      // diff(x, x[i]) = 0
      // diff(x[i], x[j]) = 0
      mydiff:= proc(f, x)
      begin
        if f = x then 1
        elif not has(f, x) then 0
        else diff(f, x)
        end_if;
      end_proc:

      // now, do rewrite!
      function := op(g, 0);
      y := [op(g)];  // = [y1, y2, ..]
      x1 := op(f, 2);
      otherVariables := op(f, 3..nops(f));
      if nops(y) = 1 then
           return(stdlib::diff2D(
             diff(
                _plus( D(function)(op(y)) *
                       stdlib::diff2D(mydiff(y[i], x1))
                       $ i = 1..nops(y)
                     ),
             otherVariables)))
      else return(stdlib::diff2D(
             diff(
                _plus( D([i], function)(op(y)) *
                       stdlib::diff2D(mydiff(y[i], x1))
                       $ i = 1..nops(y)
                     ),
             otherVariables)))
      end_if;
   end_case;
   // default: do nothing
   f
end_proc:
