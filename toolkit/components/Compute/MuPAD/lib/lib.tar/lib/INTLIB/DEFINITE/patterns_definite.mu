defint_patterns:=[
    [1/(x^2+1)^2, PI/8+1/4, [u=0, v=1]],
    [x^2/(x^2+1)^2, PI/8-1/4, [u=0, v=1]],

   // [1/(a*x+b), ln(1+a/b)/a, [u=0, v=1, a>0, b>0]],
   // [1/(x^2+a), (ln(sqrt(-a)-1)-ln(sqrt(-a)+1))/2/sqrt(-a), [u=0, v=1, a<-1]],

    [1/(a*x^2+b), arctan(sqrt(a/b))/sqrt(a*b), [u=0, v=1, a>0, b>0]],
    [x/(a*x^2+b), ln(1+a/b)/2/a, [u=0, v=1, a>0, b>0]],

    [1/(a+x)/(b+x^2), PI*a/2/sqrt(b)/(a^2+b)+ln(sqrt(b)/a)/(a^2+b), [u=0, v=infinity, a>0, b>0]],
    [1/(a+x^2)/(b+x^2)/(c+x^2), PI/2/sqrt(c)/(a-b)*(1/(b+sqrt(b)*sqrt(c))-1/a*(sqrt(a)*sqrt(c))), [u=0, v=infinity]],
    [x^2/(a+x^2)/(b+x^2)/(c+x^2), PI/2/(sqrt(a)+sqrt(b))/(sqrt(b)+sqrt(c))/(sqrt(c)+sqrt(a)), [u=0, v=infinity]],

    [1/sqrt(a+b*x^2), ln(sqrt(1+b/a)+sqrt(b/a))/sqrt(b), [u=0, v=1, a>0, b>0]],
    [x/sqrt(a+b*x^2), ln(sqrt(a+b)-sqrt(a))/b, [u=0, v=1, a>0, a+b>0]],
    [1/sqrt(x^2-1)/(a+b*x), 2/sqrt(a^2-b^2)*arctan(sqrt((a-b)/(a+b))), [u=1, v=infinity, b>0, a>b]],

    [(1-x^a)^b, PI/a/sin(PI/a), [u=0, v=1, a>1, a*b=-1]],

    [sqrt(a+b*x^2), sqrt(a+b)/2 + (ln(sqrt(a+b)+sqrt(b)) - ln(a)/2)*a/2/sqrt(b), [u=0, v=1, a>0, b>0]],

    // Dwight, Tables of integrals and other mathematical data
    [x^a*(1-x^b)^c, beta(c+1,(a+1)/b)/b, [u=0, v=1, Re(a)>-1, b>0, Re(c)>-1]], // 855.42

    [x^a/(b+x), PI*b^a/sin((a+1)*PI), [u=0, v=infinity, Re(a)<0, Re(a)>-1, not b<=0]],  // 856.04
    [1/(1+x^a), PI/a/sin(PI/a), [u=0, v=infinity, Re(a)>1]], // 856.05
    [x^a*(1+x)^b, beta(a+1,-1-a-b), [u=0, v=infinity, Re(a)>-1, Re(a+b)<-1]],  // 856.11
    [1/(x^2+a)/(x^2+b), PI/2/(a*sqrt(b)+b*sqrt(a)), [u=0, v=infinity, not a<=0, not b<=0]], // 856.31

    [sqrt(1-x)/(a*x-1), -2/a*(1-sqrt((1-a)/a)*arctan(sqrt(a/(1-a)))), [u=0, v=1, a>0, a<1]],
    [1/sqrt(1-x)/(a*x-1), -2/sqrt(a*(1-a))*arctan(a/(1-a)), [u=0, v=1, a>0, a<1]],

    [(-ln(x))^a, gamma(a+1), [u=0, v=1, Re(a)>-1]], // 863.01
    [x^a*ln(x), -1/(a+1)^2, [u=0, v=1, Re(a)>-1]],  // 863.02
    [ln(x)/(x^2-1), PI^2/8, [u=0, v=1]], // 863.31
    [x*ln(x)/(x^2-1), PI^2/24, [u=0, v=1]], // 863.32
    [x^2*ln(x)/(x^2-1), PI^2/8-1, [u=0, v=1]],  // 863.33
    [ln(x)/(x^2+1), -CATALAN, [u=0, v=1]],  // 863.34
    [ln(x)/(x^2+1)^2, -ln(2), [u=0, v=1]],  // 863.35
    [ln(x)/sqrt(1-x^2), -PI/2*ln(2), [u=0, v=1]], // 863.41
    [x*ln(x)/sqrt(1-x^2), ln(2)-1, [u=0, v=1]], // 863.42
    [x^2*ln(x)/sqrt(1-x^2), PI/8*(1-2*ln(2)), [u=0, v=1]],
    [ln(x)*sqrt(1-x^2), -PI/4*(ln(2)+1/2), [u=0, v=1]], // 863.43
    [(1-x^a)*(1-x^b)/ln(x), ln((a+b+1)/(a+1)/(b+1)), [u=0, v=1, a>-1, b>-1, a+b>-1]], // 863.54
    [x^n*ln(1-x), blockTransparent(-Sum::sum_fn(i -> 1/i, 1..(n+1))/(n+1)), [u=0, v=1, n>=0]], // 863.73
    [ln(1-x)/(1+x^2), PI/8*ln(2)-CATALAN, [u=0, v=1]],  // 864.01
    [ln(1+x)/(1+x^2), PI/8*ln(2), [u=0, v=1]],  // 864.02
    [arctanh(x)/(1+x^2), CATALAN/2, [u=0, v=1]],
    [ln(1+x^2)/(1+x^2), PI/2*ln(2)-CATALAN, [u=0, v=1]],  // 864.04
    [ln(1-x^a)/x, -PI^2/6/a, [u=0, v=1, Re(a)>0]],  // 864.21
    [ln(1+x^a)/x, PI^2/12/a, [u=0, v=1, Re(a)>0]],  // 864.22
    [arctanh(x^a)/x, PI^2/8/a, [u=0, v=1, Re(a)>0]],
    [ln(1-x)/sqrt(1-x^2), -2*CATALAN-PI/2*ln(2), [u=0, v=1]], // 864.31
    [ln(1+x)/sqrt(1-x^2), 2*CATALAN-PI/2*ln(2), [u=0, v=1]],  // 864.32
    [arctanh(x)/sqrt(1-x^2), 2*CATALAN, [u=0, v=1]],
    [ln(x)/(x^2-1), PI^2/4, [u=0, v=infinity]],  // 864.53
    [ln(x)/(x^2+a), PI/4/sqrt(a)*ln(a), [u=0, v=infinity, a>0]], // 864.54
    [ln(1+x)/(1+x^2), PI/4*ln(2)+CATALAN, [u=0, v=infinity]],  // 864.61

    [ln(1+exp(-x)), PI^2/12, [u=0, v=infinity]],  // 865.81
    [ln(1-exp(-x)), PI^2/6, [u=0, v=infinity]], // 865.82

    [ln(x)*exp(a*x), (ln(-a)+EULER)/a, [u=0, v=infinity, Re(a)<0]], // 865.901
    [ln(x)/exp(a*x), -(ln(a)+EULER)/a, [u=0, v=infinity, Re(a)>0]],
    [x*ln(x)*exp(a*x), -(ln(-a)-1+EULER)/a^2, [u=0, v=infinity, Re(a)<0]], // 865.902
    [x*ln(x)/exp(a*x), -(ln(a)-1+EULER)/a^2, [u=0, v=infinity, Re(a)>0]],
    [x^2*ln(x)*exp(a*x), (ln(-a)-3/2+EULER)*2/a^3, [u=0, v=infinity, Re(a)<0]], // 865.903
    [x^2*ln(x)/exp(a*x), -(ln(a)-3/2+EULER)*2/a^3, [u=0, v=infinity, Re(a)>0]],
    [ln(x)*exp(a*x)/sqrt(x), sqrt(-PI/a)*(ln(-a)+ln(4)+EULER), [u=0, v=infinity, Re(a)<0]], // 865.904
    [ln(x)/exp(a*x)/sqrt(x), sqrt(PI/a)*(ln(a)+ln(4)+EULER), [u=0, v=infinity, Re(a)>0]], 
  
    // Gr�bner & Hofreiter, Integraltafel, 2. Teil
    [1/(a*x^2+b*x+c), (arctan((a+b/2)/sqrt(a*c-b^2/4))-arctan(b/sqrt(4*a*c-b^2)))/sqrt(a*c-b^2/4), [u=0, v=1, 4*a*c>b^2]], // 131.2a
    [1/(a+b*sqrt(x)), 2/b-2*a/b^2*ln(1+b/a), [u=0, v=1, a*(a+b)>0]],  // 211.1b
    [1/(a*x^2+b*x+c)/sqrt(x), PI/sqrt(2*c*(sqrt(a*c)+b)), [a>0, b>0, a*c>b^2, u=0, v=infinity]],  // 211.6a
    [1/(a*x^2+b*x+c)*sqrt(x), PI/sqrt(2*a*(sqrt(a*c)+b)), [a>0, b>0, a*c>b^2, u=0, v=infinity]],  // 211.6b
    [1/(a*x+b)/sqrt(x), PI/sqrt(a*b), [u=0, v=infinity, a>0, b>0]],  // 211.7
    [(-(x+c)*(x+d))^a, (v-u)^(2*a+1)/(2*a+1)!*gamma(a+1)^2, [c=-u, d=-v, blockTransparent(testtype(2*a, Dom::Integer))]], // 212.3
    [1/sqrt(x^2+a), ln(1+sqrt(2)), [u=0, v^2=a]], // 214.1b
    [x/sqrt(x^2+a), v*(sqrt(2)-1), [u=0, v^2=a]], // 214.1c
    [x^2/sqrt(x^2+a), v^2/2*(sqrt(2)-ln(1+sqrt(2))), [u=0, v^2=a]], // 214.1d
    [1/x/sqrt(x^2+a), PI/2/a, [u>0, v=infinity, a=-u^2]], // 215.2c
    [1/sqrt(a-x^2)/(x^2+c), PI/2/sqrt(c)/sqrt(c+a), [u=0, v^2=a, a>0, c>0]], // 216.8a
    [x/sqrt(a-x^2)/(x^2+c), 1/sqrt(a+c)*ln((sqrt(a)+sqrt(a+c))/sqrt(c)), [u=0, v^2=a, a>0, c>0]], // 216.8b
    [1/sqrt(a-x^2)/(x^2+c), -PI/2/sqrt(-c)/sqrt(-c-a), [u=0, v^2=a, a>0, -c>a]], // 216.9a
    [x/sqrt(a-x^2)/(x^2+c), -arcsin(sqrt(-a/c))/sqrt(-a-c), [u=0, v^2=a, a>0, -c>a]],  // 216.9b

    [x^n/(exp(a*x)-1), abs(bernoulli(n+1))/2/(n+1)*(2*PI/a)^(n+1), [u=0, v=infinity, a>0, n>0, n mod 2=1]],  // 313.9a
    [x^n/(exp(a*x)+1), (2^n-1)/(n+1)*abs(bernoulli(n+1))*(PI/a)^(n+1), [u=0, v=infinity, a>0, n>0, n mod 2=1]],  // 313.10a
    [x^a*exp(x^2)^b, gamma((a+1)/2)/(-b)^((a+1)/2)/2, [u=0, v=infinity, a>-1, b<0]],  // 314.2

    [ln(a*x^2+b)/(c*x^2+d), PI/sqrt(c*d)*ln((sqrt(a*d)+sqrt(b*c))/sqrt(c)), [u=0, v=infinity, a>0, b>0, c>0, d>0]],  // 325.18
    [ln(1+a*x^2)/sqrt(1-x^2), PI*ln((1+sqrt(1+a))/2), [u=0, v=1, a>=-1]], // 325.21b
 
    [ln(a*x), ln(a)-1, [u=0, v=1, a>0]],

    [arcsin(x), PI/2-1, [u=0, v=1]],
    [arccos(x), 1, [u=0, v=1]],

    [tan(x+a*I), PI*I, [u=0, v=infinity, Re(a)>0]],

    [arccot(x)^2, PI*ln(2), [u=0, v=infinity]],

    [x^a*ln(x)^b, gamma(b+1)/(-a-1)^(b+1), [u=1, v=infinity, a<-1, b>-1]],

    // Bronstein, Taschenbuch der Mathematik (1.1.3.4)
    [x^a*exp(b*x^2), gamma((a+1)/2)/2/(-b)^((a+1)/2), [Re(a)>-1, Re(b)<0, u=0, v=infinity]],
    [x^a/exp(b*x^2), gamma((a+1)/2)/2/b^((a+1)/2), [Re(a)>-1, Re(b)>0, u=0, v=infinity]],

    [cos(a*x)*exp(b*x^2), sqrt(-PI/b)/2*exp(a^2/4/b), [b<0, u=0, v=infinity]],
    [cos(a*x)/exp(b*x^2), sqrt(PI/b)/2*exp(-a^2/4/b), [b>0, u=0, v=infinity]],

    [sin(x)*exp(a*x)/x, arccot(-a), [a<0, u=0, v=infinity]],
    [sin(x)/exp(a*x)/x, arccot(a), [a>0, u=0, v=infinity]],

    // FIXME: pattern for ln(x)^n*exp(-x^2) ???
    [ln(x)*exp(-x^2), -sqrt(PI)/4*(EULER+ln(4)), [u=0, v=infinity]],
    [ln(x)/exp(x^2), -sqrt(PI)/4*(EULER+ln(4)), [u=0, v=infinity]],
    [ln(x)^2*exp(-x^2), sqrt(PI)/8*((EULER+ln(4))^2+PI^2/2), [u=0, v=infinity]],
    [ln(x)^2/exp(x^2), sqrt(PI)/8*((EULER+ln(4))^2+PI^2/2), [u=0, v=infinity]],

    [sin(a*x)/x, PI/2, [a>0, u=0, v=infinity]],
    [sin(a*x)/x, -PI/2, [a<0, u=0, v=infinity]],
  // only as principal value?
//    [tan(a*x)/x, PI/2, [a>0, u=0, v=infinity]],
//    [tan(a*x)/x, -PI/2, [a<0, u=0, v=infinity]],
    [(cos(a*x)-cos(b*x))/x, ln(b/a), [u=0, v=infinity]],

    // TODO: sin(x)*cos(a*x)/x

    [sin(x)/sqrt(x), sqrt(PI/2), [u=0, v=infinity]],
    [x*sin(b*x)/(x^2+a), PI/2*exp(-sqrt(a)*b), [a>0, b>0, u=0, v=infinity]],
    [x*sin(b*x)/(x^2+a), -PI/2*exp(sqrt(a)*b), [a>0, b<0, u=0, v=infinity]],
    
    [cos(a*x)/(x^2+1), PI/2*exp(-a), [a>0, u=0, v=infinity]],
    [cos(a*x)/(x^2+1), PI/2*exp(a), [a<0, u=0, v=infinity]],
    [sin(a*x)^2/x^2, PI/2*abs(a), [a in R_, u=0, v=infinity]],

    [1/sqrt(1+a*x^2), arcsin(sqrt(-a))/sqrt(-a), [not a<=-1, u=0, v=1]],
    [x/sqrt(1-x^2)/sqrt(1+a*x^2), 1/4/sqrt(-a)*arctanh(sqrt(-a)), [not a<=-1, u=0, v=1]],

    [ln(x)/(x-1), PI^2/6, [u=0, v=1]],
    [ln(x)/(x+1), -PI^2/12, [u=0, v=1]],

    // dauert lange bis es gefunden wird, da int zun�chst die Summe im Z�hler zerlegt
    [(x^a-1)*(x^b-1)/(x-1)/ln(x), -ln(gamma(a+1)*gamma(b+1)/gamma(a+b+1)), [a>-1, b>-1, a+b>-1, u=0, v=1]],

    [ln(1/x)^a, gamma(a+1), [a>-1, u=0, v=1]],

    [x*ln(sin(x)), -PI^2*ln(2)/2, [u=0, v=PI]],
    [sin(x)/x*ln(x), -PI/2*EULER, [u=0, v=infinity]],
    [sin(x)/x*ln(x)^2, PI/2*EULER^2+PI^3/24, [u=0, v=infinity]],

    [ln(a+b*cos(x)), PI*ln((a+sqrt(a^2-b^2))/2), [a>=b or a>=-b, u=0, v=PI]],

    [ln(x/sqrt(1-x^2))/sqrt(1-x^2), 0, [u=0, v=1]],  // int(ln(tan(x)), x=0..PI/2)
    [ln(1+tan(x)), PI/8*ln(2), [u=0, v=PI/4]],

    // Gradshteyn, Table of Integrals, Series and Products
    [ln(1+a*x)*x/sqrt(1-x^2), -1+PI/2/a+sqrt(1-a^2)/a*(arcsin(a)-PI/2), [not a<-1, u=0, v=1]],  // 4.292.4
    [arctanh(a*x)*x/sqrt(1-x^2), PI/2/a*(1-sqrt(1-a^2)), [not a<-1, not a>1, u=0, v=1]],
    [ln(1+a*x)/x/sqrt(1-x^2), PI^2/8-arccos(a)^2/2, [not a<-1, u=0, v=1]],  // 4.292.5
    [arctanh(a*x)/x/sqrt(1-x^2), PI^2/4-PI/2*arccos(a), [not a<-1, not a>1, u=0, v=1]],

    // integral representations of special functions
    [exp(-x^2)/x*sin(a*x), erf(a/2)*PI/2, [a in R_, u=0, v=infinity]],

    [exp(a*x)/x, Ei(-a), [Re(a)<0, u=1, v=infinity]],

    // keep this as long as indefinite integration cannot handle it:
    [(cos(x)-1)/x, Ci(v)-ln(v)-EULER, [u=0]],

    [1/sqrt(1+a*x^2)/sqrt(1-x^2), ellipticF(arcsin(v), -a), [u=0, v>=-1, v<=1]],
    [sqrt(1+a*x^2)/sqrt(1-x^2), ellipticE(arcsin(v), -a), [u=0, v>=-1, v<=1]],
    [1/sqrt(1+a*x^2)/(b+c*x^2)/sqrt(1-x^2), ellipticPi(-c/b, arcsin(v), -a)/b, [u=0, v>=-1, v<=1]],

    [x^a*(x+d)^b*exp(c*x), gamma(a+1)*kummerU(a+1,a+b+2,-c*d)*d^(a+b+1), [Re(a)>-1, Re(c)<0, d>0, u=0, v=infinity]],
    [x^a*(x+d)^b/exp(c*x), gamma(a+1)*kummerU(a+1,a+b+2,c*d)*d^(a+b+1), [Re(a)>-1, Re(c)>0, d>0, u=0, v=infinity]],

    [x^n/(exp(x)+a), -polylog(n+1,-a)*gamma(n+1)/a, [not a<=-1, u=0, v=infinity]],

    [x^a*(1-x)^b*exp(c*x), hypergeom([a+1],[a+b+2],c)*beta(a+1,b+1), [Re(a)>-1, Re(b)>-1, u=0, v=1]],

    [x^a/(exp(x)+1), zeta(a+1)*gamma(a+1)*(1-2^(-a)), [Re(a)>-1, u=0, v=infinity]],
    [x^a/(exp(x)-1), zeta(a+1)*gamma(a+1), [Re(a)>0, u=0, v=infinity]],

    // integral representations for CATALAN
    [x*exp(x/2)/(exp(x)+1), 4*CATALAN, [u=0, v=infinity]],
    [x/cosh(x), 2*CATALAN, [u=0, v=infinity]],
    [arctan(x)/x, CATALAN, [u=0, v=1]],
    [ellipticK(x)/sqrt(x), 4*CATALAN, [u=0, v=1]],
    [ellipticK(x^2), 2*CATALAN, [u=0, v=1]],
    [ellipticE(x^2), CATALAN+1/2, [u=0, v=1]],
    [arctan(x)^2, PI^2/16+PI/4*ln(2)-CATALAN, [u=0, v=1]],

    // integral representations for EULER
    [ln(-ln(x)), -EULER, [u=0, v=1]],
    [ln(ln(1/x)), -EULER, [u=0, v=1]],

    // integrals involving special functions
    [besselJ(a,x), 1, [Re(a)>0, u=0, v=infinity]],
    [besselJ(a,x)^2/x, 1/2/a, [Re(a)>0, u=0, v=infinity]],
    [besselY(a,x), -tan(a*PI/2), [Re(a)<1, Re(a)>-1, u=0, v=infinity]],

    [ellipticK(a*x^2)*x/sqrt(1-x^2), (PI^2/4-PI/2*arccos(sqrt(a)))/sqrt(a), [u=0, v=1]],

    // misc patterns
    [1/sqrt(a/x+b), PI*a/(-b)^(3/2)/2, [b<0, u=0, v*b=-a]],

    null()
]:

