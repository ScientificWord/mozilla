// $Id: abs.mu 35455 2005-12-06 10:40:39Z ccr $

// definite integration involving abs(something real)
// this works only if there are only a finite number
// of places where the arguments of abs are zero

intlib::defInt_abs :=
proc(f, x, a, b, options)
  local indices, exs, critpts, res, i, j,
	t, subex, rnd;
begin
  if {domtype(float(a)), domtype(float(b))} <> {DOM_FLOAT} then
    return(FAIL);
  end_if;
  
  save x;
  // extract all expressions appearing as arguments
  // of abs and involving x
  indices := select(map([prog::find(f, hold(abs))],
			l -> l[1..-2]),
		    l -> has(op(f, l.[1]), x));

  exs := {op(map(indices, l->op(f, l.[1])))};
  
  // use solve to try and find the critical points
  // where these expressions are integers
  critpts := {};
  for i in exs do
  // ensure there are no (hidden?) complex numbers
    if is(i, Type::Real) <> TRUE or
       traperror((t := solve(i, x))) <> 0 or
       domtype(t) <> DOM_SET then
      return(intlib::defInt_abs2(args()));
    end_if;
    critpts := critpts union t;
  end_for;
  
  // to reach subexpressions first
  indices := prog::sort(indices, -nops);
  
  // critical points in numerical order
  if map(critpts, domtype@float) <> {DOM_FLOAT} then
    return(FAIL);
  end_if;
  critpts := prog::sort([op(critpts union {a, b})], float);
  
  // between each two of these, the abs() are replaceable
  // by + or -.  we try to compute which one
  res := 0;
  rnd := frandom(129876);
  for i from 1 to nops(critpts) - 1 do
    assume(critpts[i]<x<critpts[i+1]);
    t := f;
    for j in indices do
      subex := Simplify(op(f, j));
      t := subsop(t, j=subex);
    end_for;
    res := res + intlib::defInt(t, x=critpts[i]..critpts[i+1], options);
  end_for;
  res;
end_proc:

intlib::defInt_abs2 :=
proc(f, x, a, b, options)
  local res;
begin
  save x;
  assume(a<x<b);
  res := FAIL;
  if traperror((res := expr(rectform(f))),
		MaxSteps=intlib::simplifyMaxSteps) = 0 and
     expr(res) <> f then
    return(intlib::defInt(res,x=a..b, options));
  end;
  FAIL;
end:
