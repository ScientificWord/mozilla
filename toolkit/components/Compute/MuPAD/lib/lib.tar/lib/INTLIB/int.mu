// $Date: 2006-05-16 14:38:22 +0200 (Tue, 16 May 2006) $ $Author: ccr $ $Revision: 39044 $ 

/*--
intlib::int(f,x) - computes the antiderivative of the function f(x) with
                   respect to the variable x.
--*/

intlib::int:=
  proc(f :Type::Arithmetical, x :DOM_IDENT, options=table() : DOM_TABLE)
    local prop,C,F;
    save _X; //necessary to make assumption on integration variable
  begin
    //if testargs() then f:=eval(f) end_if;
    C:=solvelib::getIdent(Any, indets(f, All) union {_X});
    if property::hasprop(_X) then 
      //assume(C,prop1)  // does'nt work due to an error in assume
      zip([C],[getprop(_X)],assume);
    end_if;
    delete _X;
    if property::hasprop(x) then
      prop:=getprop(x);
      if prop=Type::Complex then
        //assume(_X,prop) // does'nt work due to an error in assume
        zip([_X],[Type::Complex],assume);        
      elif not(property::Fail((prop:=prop and Type::Real))) then
        if prop=Type::Zero then
          prop:=Type::Complex;
          if intlib::printWarningsFlag then
            warning("Cannot integrate when ".strprint(NoNL, x).
                    " has property ".strprint(NoNL, getprop(x)).".\n".
                    "While integrating, we will assume ".strprint(NoNL, x).
                    " has property ".strprint(NoNL, prop).".");
          end_if;
        elif is(x,Type::Rational)=TRUE then
          prop:=Type::Real;
          if intlib::printWarningsFlag then
            warning("Cannot integrate when ".strprint(NoNL, x).
                    " has property ".strprint(NoNL, getprop(x)).".\n".
                    "While integrating, we will assume ".strprint(NoNL, x).
                    " has property ".strprint(NoNL, prop).".");
          end_if;
        end_if;
        //assume(_X,prop) // does'nt work due to an error in assume
        zip([_X],[prop],assume);
      elif intlib::printWarningsFlag then
        warning("Cannot assume ".strprint(NoNL, x).
               " is a real variable,\n"."since that would be inconsistent to ".
                "user given properties")
      end_if
    else
      assume(_X,Type::Real)
    end_if;
    if x<>_X then f:=subs(f,[_X=C,x=_X]) end_if;
    F:=subs(intlib::int_intern(f, _X, options),[_X=x,C=_X]);
    unassume(C);
    F    
  end_proc:


intlib::int_intern:=
proc(_F_,_x_,options=table())
  local integral,Float,_f_,F0, tmp, res, dummy, f_t, method;
  save intlibDepthLevel, //make counter secure for error or exception handling
  MAXEFFORT;
begin
  F0:=_F_;
  res := 0;
  
  if intlibDepthLevel = hold(intlibDepthLevel) then
    sysassign(intlib::tries,{});
    sysassign(intlibDepthLevel,0):
  end_if;
  sysassign(intlibDepthLevel,intlibDepthLevel+1);
  
  _F_ := misc::maprec(_F_, {DOM_POLY} = expr);
  
  // First, transform each floating point number to its
  // rational approximation
  _f_:=misc::maprec(_F_,
                    {DOM_FLOAT,DOM_COMPLEX}=
                    (x -> numeric::rationalize(x,Minimize)) );
  Float:=(if _f_ <> _F_ then float else id end_if)@(x->combine(x, exp));
  
  if has(_f_,arg) then
    _f_:=eval(subs(_f_,hold(arg)=(z->-I*ln(z/abs(z)))));
  end_if;

  if has(_f_,log) then
    _f_:=eval(subs(_f_,hold(log)=((b,x) -> ln(x)/ln(b))));
  end_if;

  // dirac must not reach some of the functions below
  if has(_f_, hold(dirac)) then 
     tmp:= intlib::diracInt(_f_, _x_, options):
     if tmp <> FAIL then
        return(Float(tmp));
     else
        return(hold(int)(args()));
     end_if;
  end_if;

  if testtype(_f_, Type::RatExpr(_x_, Type::IndepOf(_x_))) then
    // short circuit: rational functions are handled completely
    // by Risch, but the result returned there may not be in the
    // form desired.
    userinfo(2,"rational expression, trying Risch integration");
    integral := intlib::rational(_f_, _x_, options);
    if integral=FAIL then
      if stdlib::hasmsign(F0) then
        integral := -hold(int)(-F0, _x_);
      else
        integral := hold(int)(F0,_x_);
      end_if;
    end_if;
      
    return(Float(integral))
  end_if;

  // since not every of the following methods will really consume time,
  // giving one fifth of the effort to each should be ok

  MAXEFFORT:= MAXEFFORT/5;
  
  for method in
      [// look for user-defined patterns
       ["checking user patterns", intlib::lookup_user],
       // test if integrand contains special functions that can be treated
       ["looking for special functions", intlib::specialFunctionInt],
       // test for patterns with known good substitutions
       // (and for hyperelliptic integrals)
       ["looking for known good substitutions", intlib::trafoLookup],
       // treat elliptic integrals
       ["looking for elliptic integrals", intlib::elliptic],
       // lookup method
       ["trying lookup method", intlib::lookup],
       // Risch Integration
       ["trying Risch integration", intlib::rischInt],
       // using linearity of integration
       ["try to integrate term by term", intlib::termByTerm],
       // special handling of rational function in trig. terms
       ["looking for rational function in trig. terms", intlib::ratSinCos],
       ["looking for rational function of linear sqrt", intlib::ratOfTwoSqrt]
      ] do
    userinfo(2, method[1]);
    integral:=(method[2])(_f_,_x_,options);
    if integral<>FAIL then
      if testtype(integral, "_plus") then
        [f_t, integral, dummy] := split(integral, testtype, "int");
      elif testtype(integral, "int") and op(integral, 2) = _x_ then
        f_t := integral;
        integral := 0;
      else
        f_t := 0;
      end;
      if iszero(f_t) then
        return(Float(res + intlib::expandExp(integral)));
      elif op(f_t, 0)=hold(int) and op(f_t, 2)=_x_ then
        res := res + intlib::expandExp(integral);
        _f_ := op(f_t, 1);
      end;
    end_if;
  end_for;
  
  if iszero(_f_) then
    // can't really hapen, can it?
    return(Float(res));
  else
    if stdlib::hasmsign(_f_) then
      Float(res)-hold(int)(Float(-_f_), _x_)
    else
      Float(res)+hold(int)(Float(_f_),_x_)
    end_if;
  end_if;
end_proc:

intlib::tries:={}:

intlib::expandExp:=
  proc(f)
  begin
    if has({f},exp) then
      misc::maprec(f,{"exp"}=proc() begin expand(exp(op(args()))) end_proc )
    else
      f
    end_if;
  end_proc:




/* if both the lookup method and Risch algorithm failed,
  and if the function is a sum, it can be that some
  terms can be integrated by the lookup method and some
  other by Risch algorithm, like for example int(diff(g(x),x)+x+2,x) */
intlib::termByTerm :=
proc(f,x, options)
  local f0, e, i, r, r2;
  save MAXEFFORT;
begin
  f0:=f;
  if type(f)="_mult" and contains(map({op(f)},type),"_plus") then
    f := [op(f)];
    // find the first sum in the operands, expand
    for i from 1 to nops(f) do
      if type(f[i]) = "_plus" then
        e := f[i];
        delete f[i];
        f := `*`(op(f));
        f := map(e, `*`, f);
        break;
      end_if;
    end_for;
   end_if;
  if type(f)="_plus" then
    r:=0;
    r2 := 0;
    MAXEFFORT:= MAXEFFORT/nops(f);
    for e in [op(f)] do
      i:=intlib::int(e,x, options);
      if hastype(i,"int") then
        r2 := r2+e;
      else
        r:=r+i
      end_if
    end_for;
    if iszero(r2) then
      return(r);
    elif iszero(r) then
      return(FAIL);
    else
      return(r+hold(int)(r2, x));
    end_if;
  end_if;
  FAIL
end_proc:

/* for integrands involving sin and cos, as a last resort try using
   combine(..., sincos) and if that leads to no change, try using
   the standard tangent substitutions */

intlib::ratSinCos :=
proc(f, x)
  local f2, t, integral;
begin
  if not has(f, {hold(sin), hold(cos)}) then
    return(FAIL);
  end;
  if has(f, `#t`) then
    t := genident("tmp") = `#t`;
    f := subs(f, op(t, 2) = op(t, 1), Unsimplified);
  else
    t := null();
  end_if;
  
  if not testtype(subs(f, sin(x)=`#t`, cos(x)=`#t`),
                  Type::RatExpr(`#t`, Type::IndepOf(`#t`))) then
    // the things below still *might* help in some cases,
    // but usually take very long without yielding a result
    return(FAIL);
  end_if;
  
  // to avoid cases where the `#t` cancel:
  if not testtype(subs(f, sin(x)=`#t`, cos(x)=2*`#t`),
                  Type::RatExpr(`#t`, Type::IndepOf(`#t`))) then
    // the things below still *might* help in some cases,
    // but usually take very long without yielding a result
    return(FAIL);
  end_if;
  
  // will still run into trouble.  Oh well, needs Type::RatExpr
  // for two vars to stop that.
  
  f2 := combine(f, sincos);
  if f2 <> f then
    userinfo(2, "trying to integrate after combining sin/cos terms");
    integral := intlib::int_intern(f2, x);
    if not hastype(integral, "int") then
      return(integral);
    end_if;
  end_if;

  f := expand(f);
  
  f2 := subsex(f, [sin(x)^2=`#t`^2/(`#t`^2+1),
                   cos(x)^2=1/(`#t`^2+1),
                   sin(x)*cos(x)=`#t`/(`#t`^2+1),
                   tan(x)=`#t`]);
  if not has(f2, x) and
     (testtype(f2, Type::RatExpr(`#t`, Type::IndepOf(`#t`))) or
      Simplify::defaultValuation(f2) < 2*Simplify::defaultValuation(f))
     then
    userinfo(2,"try to substitute t=tan(".expr2text(x).")");
    integral := intlib::int(f2/(`#t`^2+1), `#t`);
    if not hastype(integral, "int") then
      return(subs(integral, `#t`=tan(x), t));
    end_if;
  end_if;
  
  f2 := subsex(f/sin(x), [sin(x)^2=1-`#t`^2,
                          cos(x)=`#t`]);
  if not has(f2, x) and
     (testtype(f2, Type::RatExpr(`#t`, Type::IndepOf(`#t`))) or
      Simplify::defaultValuation(f2) < 2*Simplify::defaultValuation(f))
    then
    userinfo(2,"try to substitute t=cos(".expr2text(x).")");
    integral := intlib::int(f2, `#t`);
    if not hastype(integral, "int") then
      return(-subs(integral, `#t`=cos(x), t));
    end_if;
  end_if;
  
  f2 := subsex(f/cos(x), [sin(x)=`#t`,
                          cos(x)^2=1-`#t`^2]);
  if not has(f2, x) and
     (testtype(f2, Type::RatExpr(`#t`, Type::IndepOf(`#t`))) or
      Simplify::defaultValuation(f2) < 2*Simplify::defaultValuation(f))
    then
    integral := intlib::int(f2, `#t`);
    userinfo(2,"try to substitute t=sin(".expr2text(x).")");
    if not hastype(integral, "int") then
      return(subs(integral, `#t`=sin(x), t));
    end_if;
  end_if;
  
  f2 := eval(subsex(f, [sin(x)=2*`#t`/(1+`#t`^2),
                        cos(x)=(1-`#t`^2)/(1+`#t`^2),
                        tan(x)=2*`#t`/(1-`#t`^2),
                        cot(x)=(1-`#t`^2)/2/`#t`,
                        tan(x/2)=`#t`]));
  if not has(f2, x) and
     (testtype(f2, Type::RatExpr(`#t`, Type::IndepOf(`#t`))) or
      Simplify::defaultValuation(f2) < 2*Simplify::defaultValuation(f))
    then
    userinfo(2,"try to substitute t=tan(".expr2text(x)."/2)");
    integral := intlib::int(2*f2/(1+`#t`^2), `#t`);
    if not hastype(integral, "int") then
      return(subs(integral, `#t`=tan(x/2), t));
    end_if;
  end_if;
  
  FAIL;
end_proc:
