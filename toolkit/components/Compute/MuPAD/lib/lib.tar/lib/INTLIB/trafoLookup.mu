// $Id: trafoLookup.mu 37535 2006-03-08 15:33:20Z ccr $

// intlib::trafoLookup -- examine integrand for frutiful transformation patterns

intlib::trafoLookup :=
proc(f, x)
  local power_pos, t, n, ft, sub, res, dummy,
	a, b, c, d, e, integral, num, den, i, ok, l;
begin
  // rational expressions should not make it to here,
  // but are reasonably quick to check:
  if testtype(f, Type::RatExpr(x, type::IndepOf(x))) then
    return(intlib::rational(f, x));
  end_if;
  
  // some dummy var not in f:
  t := solvelib::getIdent(Any, indets(f, All) union {x});
  
  res := 0;
  
  // find fractional powers
  power_pos := map({prog::find(f, hold(_power))}, l -> l[1..-2]);
  power_pos := select(power_pos,
		      p -> has(op(f,p), x));
  power_pos := select(power_pos,
		      p -> not testtype(op(f, p.[2]), DOM_INT));
  
  // do some exist and are all of these identical?
  // TODO: (x+sqrt(a*x+b))/sqrt(a*x+b) -- negative powers
  l := map(power_pos, pos -> op(f, pos));
  if nops(l) = 1 then
    n := 1/op(f, op(power_pos, 1).[2]);
    
    // this is not really integration by substitution,
    // but since we have all the information already ...
    if n = -2 and nops(power_pos)=1 and
       nops(op(power_pos,1)) = 1 and
       op(f, 0) = hold(_mult) then
      // a/(b*sqrt(c)), a, b, c polynomials, b and c squarefree
      //  --> intlib::hint (hyperelliptic integrals)
      c := op(f, op(power_pos, 1).[1]);
      ft := subsop(f, op(power_pos, 1)=1);
      if testtype(ft, Type::RatExpr(x, Type::IndepOf(x))) then
        a := poly(numer(ft), [x]);
        b := poly(denom(ft), [x]);
	
        // care for squarefree
        ok := TRUE;
        c := poly(c, [x]);
        if c <> FAIL and not x in indets(poly2list(c)) then
          d := [op(polylib::sqrfree(c))];
          if _lazy_and((d[i]<4)$i=3..nops(d) step 2) then
            c := poly(d[1], [x]);
            for i from 2 to nops(d)-1 step 2 do
              case d[i+1]
                of 1 do
                  c := c*d[i];
                  break;
                of 2 do
                  b := b*d[i];
                  break;
                otherwise
                  ok := FALSE;
              end_case
            end_for;
            
            d := gcd(a, b);
            a := a/d;
            b := b/d;
            if ok and degree(c) > 1 and
              degree(c) mod 2 = 1 and
              degree(gcd(b, b')) = 0 and
              degree(gcd(a, b)) = 0 and
              degree(gcd(b, c)) = 0 and
              degree(gcd(c, c')) = 0 and
              indets(poly2list(a)) = {} and
              indets(poly2list(b)) = {} and
              indets(poly2list(c)) = {} then
              userinfo(2, "detected hyperelliptic integral");
              integral := FAIL;
              traperror((integral := intlib::hyperint(expr(a), expr(b),
                                                      expr(c), x)));
              if integral <> FAIL then
		if testtype(integral, "_plus") then
		  [ft, res, dummy] := split(integral, testtype, "int");
		else
		  [ft, res] := [0, integral];
		end;
		if iszero(ft) then
		  return(res);
		end;
		// ensure that the remaining integral is one w.r.t.
		// the same variable.  Should always be the case.
		if op(ft, 0) = hold(int) and
		   op(ft, 2) <> x then
		  res := 0;
		else
		  f := op(ft, 1);
		end;
              end_if;
            end_if;
          end_if;
        end_if;
      end_if;
    end_if;

    if testtype(n, DOM_INT) then
      sub := poly(op(f, op(power_pos, 1).[1]), [x]);
      if sub <> FAIL and
	 not(x in indets(sub)) then
      
	// rational function of x and (a*x+b)^(1/n)?
	if degree(sub) = 1 then
	  a := lcoeff(sub);
	  b := coeff(sub, 0);
          // Gr�bner/Hofreiter, 211.1a
	  // int(R(x, (a*x+b)^(1/n)), x) =
	  //  int(R((t^n-b)/a, t)*n/a*t^(n-1), t) | t = (a*x+b)^(1/n)
	  if traperror((ft := subs(subsop(f, op(map(power_pos, p -> p=t))),
				   x = (t^n-b)/a)*n/a*t^(n-1))) = 0 then
	    if testtype(ft, Type::RatExpr(t, Type::IndepOf({t,x}))) then
	      userinfo(2, "detected integrand of the form Rat(x, (a*x+b)^(1/n))");
	      integral := intlib::rational(ft, t);
	      if integral <> FAIL then
		return(res + evalAt(integral, t = (a*x+b)^(1/n)));
	      end_if;
	    end_if;
	  end_if;
	elif FALSE /* the formulas are buggy, sorry */
	     and degree(sub) = 2 then
	  // rational function of x and (a*x^2+b*x+c)^(1/2)?
	  // --> G&H 231.1a
	  a := coeff(sub, 2);
	  b := coeff(sub, 1);
	  c := coeff(sub, 0);
	  
	  ft := subsop(f, op(map(power_pos, p -> p=x)));
	  if testtype(ft, Type::RatExpr(x, Type::IndepOf(x))) then
	    userinfo(2, "detected integrand of the form Rat(x, sqrt(a*x^2+b*x+c))");
	    // look for some special cases first, for simpler results:
	    if FALSE and iszero(b) then
	      if traperror((ft := -subs(subsop(f,
					       op(map(power_pos,
						      p -> p = sqrt(c/a)*(t^2+1)/(t^2-1)))),
					x = 2*sqrt(c/a)*t/(t^2-1))
				* 2 * sqrt(c/a)*(t^2+1)/(t^2-1)^2)) = 0 then
		assert(testtype(ft, Type::RatExpr(t, Type::IndepOf({t,x}))));
		integral := intlib::rational(ft, t);
		if integral <> FAIL then
		  return(res + subs(integral, t = (sqrt(x^2+c/a)+sqrt(c/a))/x));
		end_if;
	      end_if;
	    else
	      // d is alpha in G&H, e is beta
	      if traperror((d := ceil(-(b-sqrt(b^2-a*c))/(a))+1)) <> 0 then
		d := 42;
	      end_if;
	      e := sqrt(a*d^2+2*b*d+c);
	      
	      if traperror((ft := subs(subsop(f, op(map(power_pos,
							p -> p = (a*e*t^2-2*(a*d+b)*t+e)/(a*t^2-1)))),
				       x = (-(a*d+2*b)*t^2+2*e*t-d)/(a*t^2-1))
				* (-2*a*e*t^2+4*(a*d+b)*t-2*e)/(a*t^2-1)^2)) = 0 then
		assert(testtype(ft, Type::RatExpr(t, Type::IndepOf({t,x}))));
		integral := intlib::rational(ft, t);
		if integral <> FAIL then
		  return(res + subs(integral, t = (x-d)/(sqrt(a*x^2+b*x+c)-e)));
		end_if;
	      end_if;
	    end_if;
	  end_if;
	end_if;
      end_if;
    
      if sub=FAIL then
	// radicand not polynomial.
	// rational?
	sub := op(f, op(power_pos, 1).[1]);
	if testtype(sub, Type::RatExpr(x, Type::IndepOf(x))) then
	  num := poly(numer(sub), [x]);
	  den := poly(denom(sub), [x]);
	  
	  if num <> FAIL and degree(num) = 1 and
	     den <> FAIL and degree(den) = 1 then
	    // substitution GH 213.1
	    a := lcoeff(num);
	    b := coeff(num, 0);
	    c := lcoeff(den);
	    d := coeff(den, 0);
	    if traperror((ft := subs(subsop(f, op(map(power_pos, p -> p=(a/c)^(1/n)*t))),
				     x = (-a*d*t^n+b*c)/(a*c*(t^n-1)))
			      *n*(a*d-b*c)/(a*c)*t^(n-1)/(t^n-1)^2)) = 0 then
	      
	      if testtype(ft, Type::RatExpr(t, Type::IndepOf({t,x}))) then
		userinfo(2, "detected integrand of the form Rat(x, ((a*x+b)/(c*x+d))^(1/n)");
		integral := intlib::rational(ft, t);
		if integral <> FAIL then
		  return(res +
			 subs(integral,
			      t^n = c/a*(a*x+b)/(c*x+d),
			      t = (c/a*(a*x+b)/(c*x+d))^(1/n)));
		end_if;
	      end_if;
	    end_if;
	  end_if;
	end_if;
      end_if;
    end_if; // n integer
  end_if;
  if iszero(res) then
    FAIL;
  else
    res + hold(int)(f,x);
  end;
end_proc:

// separated from the above, because it must be done
// *after* pattern matching and Risch integration failed.
// TODO TODO TODO TODO TODO TODO TODO TODO TODO
intlib::ratOfTwoSqrt :=
proc(f, x)
  local power_pos, t, n, ft,
	a, b, c, d, integral, l,
	alp, bet, gam;
begin
  // some dummy var not in f:
  t := solvelib::getIdent(Any, indets(f, All) union {x});
  
  // find fractional powers
  power_pos := map({prog::find(f, hold(_power))}, l -> l[1..-2]);
  power_pos := select(power_pos,
		      p -> has(op(f,p), x));
  power_pos := select(power_pos,
		      p -> not testtype(op(f, p.[2]), DOM_INT));
  // do some exist and how many are different?
  l := map(power_pos, pos -> op(f, pos));
 
  if nops(map(l, op, 1)) = 2 then
    // Rat(x, sqrt(a*x+b), sqrt(c*x+d)) --> G&H, 221.1
    // TODO: Avoid this step if possible.
    // E.g. int(sqrt(x)+sqrt(x+1), x) should return
    // 2/3*x^(3/2) + 2/3*sqrt(x+1)^3/2, not use the
    // following, extremely lengthy way.
    // This probably means moving this part after the
    // matcher and after Risch integration.
    n := map(l, op, 2);
    if n = {1/2} or n = {1/2, -1/2} or n = {-1/2} then
      a := op(l, [1,1]);
      c := op(l, [2,1]);
      if testtype(a, Type::PolyExpr(x)) and degree(a, x) = 1 and
	 testtype(c, Type::PolyExpr(x)) and degree(c, x) = 1 then
	b := coeff(a, x, 0); a := coeff(a, x, 1);
	d := coeff(c, x, 0); c := coeff(c, x, 1);
	if not testtype(d, Type::Real) or is(d >= 0) then
	  alp := 0;
	else
	  alp := -d/c;
	end_if;
	bet := sqrt(a*alp+b);
	gam := sqrt(c*alp+d);
	if traperror((ft := subs(f,
				 sqrt(a*x+b)=(-bet*c*t^2+2*gam*a*t-bet*a)/(c*t^2-a),
				 sqrt(c*x+d)=(gam*c*t^2-2*bet*c*t+gam*a)/(c*t^2-a),
				 1/sqrt(a*x+b)=1/((-bet*c*t^2+2*gam*a*t-bet*a)/(c*t^2-a)),
				 1/sqrt(c*x+d)=1/((gam*c*t^2-2*bet*c*t+gam*a)/(c*t^2-a)),
				 x=alp-4*bet*gam*t/(c*t^2-a)
				   +(4*(2*alp*a*c+a*d+b*c)*t^2-8*bet*gam*a*t)/(c*t^2-a)^2))) = 0 then
	  if testtype(ft, Type::RatExpr(t, Type::IndepOf({t,x}))) then
	    userinfo(2, "detected integrand of the form R(x, sqrt(a*x+b), sqrt(c*x+d))");
	    integral := intlib::int(ft*
				    (4*bet*gam*c^2*t^4
				     -8*(2*alp*a*c+a*d+b*c)*c*t^3
				     +24*bet*gam*a*c*t^2
				     -8*(2*alp*a*c+a*d+b*c)*a*t
				     +4*bet*gam*a^2)/
				    (c*t^2-a)^3, t);
	    if integral <> FAIL then
	      return(Simplify(subs(integral,
				   t=(sqrt(a*x+b)-bet)/(sqrt(c*x+d)-gam))));
	    end_if;
	  end_if;
	end_if;
      end_if;
    end_if;
  end_if;
  FAIL;
end_proc:
