// $Date: 2002-12-06 16:37:06 +0100 (Fri, 06 Dec 2002) $ $Author: stefanw $ $Revision: 21231 $ 
/*++
intlib::simplify(f,x) - simplifies the expression f over the variable x and 
returns the simplified expression if possible or f otherwise.
++*/
intlib::simplify:=
proc(f,x)
  local opt,i; 
  save _global_n,_global_k,_global_k_sub,_global_k_ident,_global_k_diff,
  _global_k_deg,_global_k_alg,_global_Q,_global_Q_sub;
  begin
    delete _global_n,_global_k,_global_k_sub,_global_k_ident,_global_k_diff,
    _global_k_deg,_global_k_alg,_global_Q,_global_Q_sub;
// test of input and options
    if testargs() then
      if args(0)<>2 then
        error("wrong no of arguments");
      end_if;
      if (domtype(f)<>DOM_LIST or nops(f)<1 or
          (map({op(f)},domtype) minus
           {DOM_EXPR,DOM_IDENT,DOM_INT,DOM_RAT,DOM_COMPLEX}) <> {}) and
        not(contains({DOM_EXPR,DOM_IDENT,DOM_INT,DOM_RAT,DOM_COMPLEX},
                     domtype(f)))
        or not(testtype(x,DOM_IDENT)) then
        error("Illegal argument");
      end_if;
    end_if;
  opt:=hold(Exp);
  _global_n:=1; _global_k:=[x];
  _global_k_sub:=[x];
  _global_k_ident:=[genident()];
  _global_k_diff:=[1];
  _global_k_deg:=[0];
  _global_k_alg:=[0];
  _global_Q:=[];
  _global_Q_sub:=[];
  f:=intlib::subst(f,opt);
  repeat
    i:= intlib::tower(f)
  until i<>FALSE end_repeat;
  f:=i;
  if f=FAIL then return(procname(args())); end_if;
  f:= subs(f,_global_k_sub[_global_n-i]=_global_k[_global_n-i]
           $ i=0.._global_n-2,
           _global_Q_sub[nops(_global_Q)-i]=_global_Q[nops(_global_Q)-i]
           $ i=0..nops(_global_Q)-1);
  normal(f);
end_proc:
