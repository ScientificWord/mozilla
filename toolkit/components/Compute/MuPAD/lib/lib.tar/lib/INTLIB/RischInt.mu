// $Date: 2005-12-05 16:08:51 +0100 (Mon, 05 Dec 2005) $ $Author: ccr $ $Revision: 35432 $ 

/*++ ---------------- RischInt.mu ---------------------

Author: Winfried Fakler,  University of Paderborn
Date Created: 12 December 1998
Last Update : 13 November 2000


Description:
This file contains the toplevel functions for symbolic integration of
elementary functions. Currently, it is only implemented for transcendental
functions.
This function is mainly a cut - copy - paste implementation extracted from
int.mu due to Ralf Kraume and Paul Zimmermann.
							  
Functions: 

 - used Parameter:
    ++ f   :DOM_EXPR
    ++ x   :DOM_IDENT				  
    ++ f    = elementary function
    ++ x    = indeterminate of f					  

 - intlib::rischInt(f, x <, Unsimplified>)
    ++ returns an elementary antiderivative of f wrt. x or FAIL.
    ++ Currently, only the transcendental case is implemented.
    ++ If option Unsimplified is given, the complex integral is returned.
    
See:
 
Examples:
>> intlib::rischInt(x*sin(x^2-1),x);
					      
++*/

 intlib::rischInt :=
  proc(f :Type::Arithmetical,x :DOM_IDENT,o=" ")
    local opt,i,integral,tosubs,hassincos,hasI,
          vl,sl,bl,hl,e, const1, const2, REC;
    save  _global_n,
          _global_k,_global_k_sub,_global_k_ident,_global_k_diff,
          _global_k_deg,_global_k_alg,
          _global_Q,_global_Q_sub,
          _global_n0,
          _global_k0,_global_k_sub0,_global_k_ident0,_global_k_diff0,
          _global_k_deg0,_global_k_alg0,
          _global_Q0,_global_Q_sub0;
  begin
    //if testargs() then f:=eval(f) end_if;
    delete _global_n0,
    _global_k0,_global_k_sub0,_global_k_ident0,_global_k_diff0,
    _global_k_deg0,_global_k_alg0,
    _global_Q0,_global_Q_sub0;
    vl:=((indets(f) minus indets(x)) union {hold(_global_k)})
         intersect {_global_n,
                    _global_k,_global_k_sub,_global_k_ident,_global_k_diff,
                    _global_k_deg,_global_k_alg,
                    _global_Q,_global_Q_sub,
                    _global_n0,
                    _global_k0,_global_k_sub0,_global_k_ident0,
                    _global_k_diff0,_global_k_deg0,_global_k_alg0,
                    _global_Q0,_global_Q_sub0};
    hl:=vl intersect {_global_n0,
                      _global_k0,_global_k_sub0,_global_k_ident0,
                      _global_k_diff0,_global_k_deg0,_global_k_alg0,
                      _global_Q0,_global_Q_sub0};
    vl:=vl minus hl;
    if iszero(nops(vl)) then sl:=[]: bl:=[]
    else sl:=[op(map(vl, e->e=_concat(e,0)))]; 
    end_if;
    if nops(hl)<>0 then
      hl:=[op(map(hl, e->e=genident()))];
      sl:=hl.sl 
    end_if;
    bl:=[op(map(sl,e->op(e,2)=op(e,1)))];
    properties(op(e,2),properties(op(e,1))) $ e in sl ;
    delete _global_n,
           _global_k,_global_k_sub,_global_k_ident,_global_k_diff,
           _global_k_deg,_global_k_alg,
           _global_Q,_global_Q_sub;
    f:=eval(subs(f,sl));
    x:=eval(subs(x,sl));
    opt:=hold(Exp);
    // the following two lines are used to simplify the result afterwards
    hassincos:=has(f,{sin,cos,tan});
    hasI:=has(f,I);
    // initialize tower of extension fields of _f_ over rational numbers
    _global_n:=1; _global_k:=[x];
    _global_k_sub:=[x]; _global_k_ident:=[genident()]; _global_k_diff:=[1];
    _global_k_deg:=[0]; _global_k_alg:=[0];
    _global_Q:=[]; _global_Q_sub:=[];
    // substitution and construction of the field extensions over the 
    // rational numbers 

    ////////////////////////////////////////////////////////////////////
    //
    // problem: also constant terms are rewritten by uncontrolled simplification
    // example: int(x^2*arccos(n), x)
    // try to rewrite only terms, that depends on the integration variable
    const1 := table();
    const2 := table();
    // replace every constant term by a new generated constant
    REC := proc(X)
             local ident;
           begin
             if not contains(indets(X), x) then
               // the expression is independend of integration variable
               if testtype(X, Type::Real) then // return numbers
                 X
               elif contains(const2, X) then   // return the same identifier for equal expressions
                 const2[X]
               else                            // generate a new free identifier
                 ident := genident("C");       // and save the corresponding subexpression
                 const1[ident] := X;
                 const2[X] := ident;
               end_if
             elif X = x then                   // return the variable itself
               X
             elif op(X, 0) <> FAIL and nops(X) > 1 then 
               // do not replace f(x, x) by f(C1, C2) !
               X
             else                              // go into the expression
               map(X, REC)
             end_if
           end_proc;

    f := REC(f);

    if hassincos then f:=combine(f,sincos) end_if; // produces a simpler tower
    //f:=intlib::subst(f,opt);
    f:=rewrite(rewrite(f,ln),exp);  // did not work for f=sqrt(_global_k(x))
    if has(f,exp) then f:=combine(expand(f),exp) end_if;

    // replace every new generated constant by the former constant term
    f := subs(f, {op(const1)});
    // end of simplification
    ////////////////////////////////////////////////////////////////////
    userinfo(2,"after substitution, integrand is",f);

    // -----------------------------------------------
    // Winfried, what are you doing here?
    // Waiting for a time out by the calling procedure?
    // No: tower has side effects: it writes into 
    //     global (?!) tables _global_Q, _global_Q_sub
    // -----------------------------------------------
    repeat i:=intlib::tower(f) until i<>FALSE end_repeat;
    // -----------------------------------------------
    
    if i=FAIL then
      userinfo(1,"construction of tower extension failed");
      return(FAIL)
    end_if;
    userinfo(2,"field extension of rational numbers",_global_Q,_global_Q_sub);
    userinfo(2,"tower extension of functions",_global_k,_global_k_sub,_global_k_alg);
    userinfo(2,"after field extensions, integrand is",i);
    // determine integral 
    integral:=intlib::intt(i,_global_n);
    // back substitution 
    tosubs:=[_global_k_sub[_global_n-i]$ i=0.._global_n-2,
             _global_Q_sub[nops(_global_Q)-i]$ i=0..nops(_global_Q)-1];
    while has(integral,tosubs) do
      // take care with eval here, for example in int(1/(x^2+k^2),x) !!! 
      if traperror
        ((integral:=
          subs(integral,
               _global_k_sub[_global_n-i]=_global_k[_global_n-i]
               $ i=0.._global_n-2,
               _global_Q_sub[nops(_global_Q)-i]=_global_Q[nops(_global_Q)-i]
               $ i=0..nops(_global_Q)-1,
               hold(_global_k)=hold(_intlib_k),
               hold(_global_n)=hold(_intlib_n),
               hold(i)=hold(_intlib_i));
          )) <> 0 then
        userinfo(1,"something is wrong, probably there is an undetected ".
               "algebraic relation between some functions of the integrand.".
                "\nPerhaps rewriting the integrand e.g. with ".
                "'rewrite(integrand,tan)' will help.");
        integral:=FAIL;
      end_if;
    end_while;
    // for unknown reasons, eval(integral) may produce an error here
    // so we use another traperror :-(
    if traperror((integral:=eval(subs(integral,
                                      hold(_intlib_k)=hold(_global_k),
                                      hold(_intlib_n)=hold(_global_n),
                                      hold(_intlib_i)=hold(i)))
                  )) <> 0 then
      return(FAIL)
    end_if;
    userinfo(2,"after substitution, integral is",integral);
    if integral = FAIL then
      return(FAIL)
    end_if;

    // try to simplify integral
    if o<>Unsimplified then

      // Simplify RootOf - expressions: this may be possible now
      // because of the substitutions
      integral:= misc::maprec(integral,
                              {RootOf} =
                              (rof -> solve(op(rof, 1), op(rof, 2))));
                              
      
      if hasI=FALSE and has(integral,I) then
        userinfo(2,"try to compute real part of integral");
        integral:=intlib::simplifyComplexIntegral(integral, x,
                                                  if intlib::hasLnExp(f) then
                                                    hold(Unique)
                                                  end_if)
      end_if;
      if hassincos then
        // the following line needs too much time e.g. for
        // combine(expand(cos(10*x)))
        // integral:=combine(expand(intlib::to_sincos(integral,x)),sincos)
	traperror((integral:=simplify(integral)),
		  MaxSteps = intlib::simplifyMaxSteps);
      end_if;
    end_if;
    delete _global_n,_global_k,_global_k_sub,_global_k_ident,_global_k_diff,
           _global_k_deg,_global_k_alg,_global_Q,_global_Q_sub;
    integral:=eval(subs(integral,bl));
    map(hl,e->(unassume(op(e,2)); e));
    
    integral
  end_proc:

/*
f:=sin(t)^2*(cos(t)*(-1) + cos(t)^2*3 + sin(t)^2*3)*(cos(t)*(-6) + cos(t)^2*9\
 + sin(t)^2*9 + 1)^(-2);

*/
