// $Date: 2006-05-18 10:53:51 +0200 (Thu, 18 May 2006) $ $Author: ccr $ $Revision: 39100 $ 

/* intlib::lookup1(e) returns FAIL or a primitive, the main variable is _X.

  It is possible to define an "int" attribute for a given function.
  It works as follows: int(F(g(x)),x) calls the "int" attribute of F
  with the arguments F(g(x)) and x. The "int" attribute should return
  either the integral of FAIL.
*/

alias(indep(a,x)=_pattern(hold(a),not has,x)): /* NOTE: same alias is
                                                  defined in intdef.mu */

prog::init(matchlib::_remainders_to_vars):

// for remembering already tested integrands
intlib::lookupTries:={}:

intlib::lookup :=
proc(f :Type::Arithmetical,
     x=hold(_X) :DOM_IDENT,
     options = table(),
     lookAt = FAIL)
  save _X;
  local C, F, noX, dummy, FSA;
begin
  //if testargs() then f:=eval(f) end_if; // in case someone makes nonsense
  
  C:=solvelib::getIdent(Any, indets(f, All) union {_X});
  save C;
  if property::hasprop(_X) then 
    //assume(C,prop1)  // doesn't work due to an error in assume
    zip([C],[getprop(_X)],assume);
  end_if;
  if x <> _X then
    delete _X;
    if property::hasprop(x) then
      //assume(_X,prop) // doesn't work due to an error in assume
      zip([_X],[getprop(x)],assume);
    end_if;
    if x<>_X then f:=eval(subs(f,[_X=C,x=_X])) end_if;
  elif _X <> hold(_X) then
    delete _X;
  end_if;
//  remove independent factors 
  if type(f)="_mult" then
    [f, noX, dummy] := split([op(f)], has, _X);
    assert(dummy = []);
    f := _mult(op(f));
    noX := _mult(op(noX));
  else
    noX := 1;
  end_if;
  
  F := FAIL;

  if intlib::userpatternsFSA <> FAIL then
    F := matchlib::addpatterns::handle_results
       (matchlib::evalFSA(f, intlib::userpatternsFSA));
  end_if;

   if F = FAIL then
      if options["UseNewLookup"] <> FALSE and
         intlib::patternFSA <> FAIL
        and calledFromWithinDSolve <> TRUE 
        then
        if lookAt = FAIL then
          lookAt := [];
          for FSA in [op(intlib::patternFSA)] do
            if op(FSA, 1) in {Default, RatExpr} or
               hastype(f, op(FSA, 1)) then
              lookAt := lookAt.[op(FSA, 1)];
            end_if;
          end_for;
        end_if;

        F := _concat([],
                     op(map(intlib::patternFSA[FSA],
                            fsa -> matchlib::evalFSA(f, fsa))) $ FSA in lookAt);
	F := matchlib::addpatterns::handle_results(F);
     else // old lookup
       F:=intlib::lookup_intern(f);
     end_if;
  end_if;
   
  if F<>FAIL then 
    F:=subs(noX * F, [_X=x,C=_X]);
    if domtype(F) = piecewise then
      // remove brnaches for x=ln(x) etc.
      F := piecewise::mapConditions(F, intlib::removeZeroSet, x);
      if domtype(F) = piecewise then
	F := piecewise::fillCases(F, freeze(int)(f, x, intlib::printOptions(options)))
      elif F=undefined then
	F := FAIL;
      end;
    end;
  end_if;
  F
end_proc:

intlib::lookup_user := proc(f, x, opt=table())
begin intlib::lookup(f, x, opt, []) end:

// remove branches only valid for discrete values of x
intlib::removeZeroSet :=
proc(cond, x)
begin
  case type(cond)
    of "_and" do
    of "_or" do
    of "_xor" do
    of "_not" do
      return(map(cond, intlib::removeZeroSet, x));
    of "_equal" do
      if has(cond, x) then
	return(FALSE);
      end;
  end_case;
  return(cond);
end_proc:

// lookup involving substitution may cause intlib::intfn(f(g(x)), g(x)):
intlib::intfn :=
proc(ex, x)
  local t;
begin
  t := solvelib::getIdent(Any, indets(ex, All));
  subs(int(subsex(ex, x=t), t), t=x);
end:

// f'(x) -> f(x)
intlib::stripdiff :=
proc(ex, x)
  local vars, fx, i;
begin
  assert(type(ex)="diff");
  fx := op(ex, 1);
  vars := [op(ex, 2..nops(ex))];
  i := contains(vars, x);
  // error means no match
  if i = 0 then error("x not found"); end_if;
  delete vars[i];
  diff(fx, op(vars));
end_proc:

// D([7], f)(a, b, c, d, e, f, x, g) -> f(a, b, c, d, e, f, x, g)
// D([2], f)(a, g(x)) * g'(x) -> f(a, g(x))
intlib::stripD :=
proc(ex, gprimex, x)
  local f, gx, ind, i, const;
begin
  assert(type(op(ex, 0)) = "D");
  if nops(op(ex, 0)) = 1 then
    ind := [1];
    f := op(op(ex, 0));
  else
    [ind, f] := [op(op(ex, 0))];
  end_if;
  gx := select([op(ex)], has, x);
  
  // error means no match
  if nops(gx) <> 1 then
    error("mismatch");
  end_if;
  
  gx := op(gx);
  
  i := contains(ind, contains([op(ex)], gx));
  
  if i = 0 then error("wrong partial diff."); end_if;
  
  if not has(gx, x) or
     has((const := normal(diff(gx, x)/gprimex)), x) then
    error("no match");
  end_if;
  
  delete ind[i];
  subsop(ex, 0 = D(ind, f))/const;
end_proc:

// try int(f(x), x), but if that returns hold(int)(...),
// return FAIL.
intlib::tryint :=
proc()
  local ret;
begin
  ret := int(args());
  if hastype(ret, "int") then
    return(FAIL);
  end_if;
  ret;
end_proc:

// sums and products w.r.t. a to-be-generated ident:
intlib::sum :=
proc(a, r)
   local i;
begin
   i := solvelib::getIdent(Z_, indets(a, All) union indets(r, All));
   sum(a(i), i=r);
end_proc:

intlib::product :=
proc(a, r)
   local i;
begin
   i := solvelib::getIdent(Z_, indets(a, All) union indets(r, All));
   product(a(i), i=r);
end_proc:


// _X is the integration variable 
intlib::lookup_intern:=
  proc(_f_)
    local hl,sl,bl,vl,integral,e;
    save a,b,xx,p,q,c,g,m,d,f,
         a0,b0,xx0,p0,q0,c0,g0,m0,d0,f0;
  begin
    delete a0,b0,xx0,p0,q0,c0,g0,m0,d0,f0;
    vl:=(indets(_f_) minus indets(_X))
         intersect {a,b,xx,p,q,c,g,m,d,f,
                    a0,b0,xx0,p0,q0,c0,g0,m0,d0,f0};
    hl:=vl intersect {a0,b0,xx0,p0,q0,c0,g0,m0,d0,f0};
    vl:=vl minus hl;
    if iszero(nops(vl)) then sl:=[]: bl:=[]
    else sl:=[op(map(vl, e->e=_concat(e,0)))]; 
    end_if;
    if nops(hl)<>0 then
      hl:=[op(map(hl, e->e=genident()))];
      sl:=hl.sl 
    end_if;
    bl:=[op(map(sl,e->op(e,2)=op(e,1)))];
    properties(op(e,2),properties(op(e,1))) $ e in sl ;
    delete a,b,xx,p,q,c,g,m,d,f;
    _f_:=eval(subs(_f_,sl));

    if type(_f_)="_mult" then
      integral := intlib::lookup2(select(_f_,has,_X));
      if integral <> FAIL and integral <> NIL then
        integral:=select(_f_, proc() begin not has(args(1),_X) end_proc) *
                  integral;
      end_if
    else
      integral:=intlib::lookup2(_f_);
    end_if;
  
    delete a,b,xx,p,q,c,g,m,d,f;
    if type(integral)="int" then // to avoid infinite loops
      integral:= hold(int)(op(eval(subs([op(integral)],bl))));
    else
      integral:=eval(subs(integral,bl));
    end_if;
    map(hl,e->(unassume(op(e,2))));
    if integral=NIL
    then FAIL
    else integral
    end_if
  end_proc:
    

    
// _X is the integration variable 
intlib::lookup1 := proc(f) begin
   // remove independent factors 
   if type(f)="_mult" then
      select(f, proc() begin not has(args(1),_X) end_proc) *
      intlib::lookup2(select(f,has,_X))
   else intlib::lookup2(f)
   end_if
end_proc: 


// functions 'xx' for which intlib::lookupxx exists
intlib::Functions:={"arcsin","arcsinh","arccos","arccosh","arctan","besselJ",
                    "cos","exp","ln","sin","tan"}:


// if f is a product, all factors depend on _X 
intlib::lookup2 := proc(_f_)
  local intg,dg,i,gg,aa,l;
  save a,b,xx,p,q,c,g,m,d,f;
begin
   l := map([op(intlib::lookup2,11)], properties):
   delete a,b,xx,p,q,c,g,m,d,f;      
   zip([op(intlib::lookup2,11)], l, properties);
   if not has(_f_,_X) then return(_f_*_X) end_if;

   // to avoid loops
   if not contains(intlib::lookupTries,_f_) then
     sysassign(intlib::lookupTries,intlib::lookupTries union {_f_});
   else
     return(FAIL)
   end_if;
        //---------------------------------------------------------
        // Thilo 23.7.2002: Added the avoidance of NIL within loop.
        //---------------------------------------------------------
   for gg in select(misc::subExpressions(_f_,intlib::Functions),has,_X) do
      i:=slot(intlib,"lookup".type(gg))(_f_);
      if i<>FAIL and i<>NIL then return(i) end_if
   end_for;
///   _f_:=misc::maprec(_f_,{"_power"}=proc() begin
///                             if type(op(args(1),1))="_power" and
///                                   type(op(args(1),[1,2]))=DOM_INT and
///                                type(op(args(1),2))=DOM_RAT then
///                                     op(args(1),[1,1])^(op(args(1),[1,2])*
///                                                     op(args(1),2)) 
///                                else args(1) end_if end_proc);
   // first do pattern matching 
   case type(_f_)
   of "_power" do
      if op(_f_,2)=1/2 then return((
         if testtype(op(_f_,1),Type::PolyExpr(_X)) then
            intlib::looksqrt(1,op(_f_,1),_X)
         elif intlib::matchassign(op(_f_,1),_X/(indep(a,_X)-_X^3)) then
            2/3*arcsin(_X^(3/2)/a^(1/2))
         elif intlib::matchassign(op(_f_,1),(indep(a,_X)+_X)/(indep(a,_X)-_X))
         then (_X-a)*_f_+a*arctan(_X*_f_/(a+_X))
         else FAIL end_if))
      elif op(_f_,2)=-1/2 then return((
         if testtype(op(_f_,1),Type::PolyExpr(_X)) then
            intlib::looksqrt2(1,op(_f_,1),_X)
         else FAIL end_if))
      elif op(_f_,2)=3/2 and testtype(op(_f_,1),Type::PolyExpr(_X)) then
         return(intlib::looksqrt(op(_f_,1),op(_f_,1),_X))
      elif op(_f_,2)=-1 and intlib::matchassign(op(_f_,1),indep(b,_X)*_X^2+
        indep(b,_X)*_X+indep(a,_X)) then
                (4*a*b-b^2)^(1/2); return(2*arctan(b*(2*_X+1)/%)/%)
      end_if; break
     of "_mult" do
      for gg in _f_ do
         if gg=_X then next // to avoid infinite loops 
         elif contains({"function","exp"},type(gg)) and nops(gg)=1 then
            // try to recognize int(aa*F(f(x))*diff(f(x),x),x) = aa*int(F(u),u)
            if not has((aa:=_f_/gg/diff(op(gg),_X)),_X) then
               intlib::int(subsop(gg,1=_X),_X);
               return((if type(%)<>"int" then return(aa*subs(%,_X=op(gg))) 
                else FAIL end_if))
            end_if
         elif type(gg)="diff" then
            // int aa(gg) D(gg) dx = int aa(t) dt 
               if nops(gg)=2 then intg:=op(gg,1) 
               else intg:=subsop(gg,nops(gg)=null())
               end_if;
               if op(gg,nops(gg))=_X and not has((aa:=subs(_f_/gg,intg=xx)),_X)
               then return(subs(intlib::int(aa,xx),xx=intg))
               end_if
         elif iszero((dg:=diff(gg,_X))) then //return(gg*intlib::int(f/gg,_X))
         elif not has((aa:=_f_/dg),_X) then return(aa*gg)
         elif hastype(dg, "diff") then
           // we must not replace gg by xx, because evaluating would turn
           // dg into zero
           userinfo(100, "Derivative of ".expr2text(gg).
                    " could not be computed");
         elif not has((aa:=normal(eval(subs(aa,gg=xx)))),_X) then
           aa:= intlib::int(aa, xx);
           // only proceed if integration was successful
           if not hastype(aa, "int") then
             return(subs(aa,xx=gg))
           end_if;
         end_if
      end_for;
      // transform sqrt(a/b)*(c/d) into normal form sqrt(a*b)*(c/d/b) 
      if intlib::matchassign(_f_,_pattern(p)*_pattern(q)^(1/2)) then
         p*(expand(numer(q)*denom(q)))^(1/2)/denom(q);
         if _f_<>% then return(intlib::lookup2(%)) end_if
      end_if;
      // case g(x)*sqrt(a+c*x+b*x^2) 
      if intlib::matchassign(_f_,sqrt(indep(a,_X)+indep(c,_X)*_X+indep(b,_X)
        *_X^2)*_pattern(hold(g))) then
        // ccr: inserted branch on 19.07.02, to fix bug Nr. 514/521
        if iszero(b)
          and intlib::matchassign(g,
                                  1/(_X-indep(p,_X))^indep(q,_X))
          and testtype(q, Type::PosInt) then
          if q = 1 then
            if is(c*p+a>0) = TRUE then
              return(2*sqrt(c*_X+a)-sqrt(c*p+a)*
                     ln(genident("C")*(sqrt(c*_X+a)+sqrt(c*p+a))/
                        (sqrt(c*_X+a)-sqrt(c*p+a))));
            elif is(c*p+a<0) = TRUE then
              // This condition is not listed in Gr�bner's table,
              // but seems to be necessary:
              if is(c*_X+a>0) = TRUE then
                return(2*sqrt(c*_X+a)+2*sqrt(-c*p-a)*
                       arctan(sqrt((-c*p-a)/(c*_X+a))));
              end_if;
            end_if;
// Here, I'll have to check which further conditions
// muyst be satisfied... (ccr, 19.7.02)
//          else
//            assert(q>1 and testtype(q, Type::PosInt));
//            case is(c*p+a>0)
//              of TRUE do
//                return(-2*sqrt(c)/(2*q-3)/(_X-p)^(q-2/3));
//                break;
//              of FALSE do
//                return(c*(c*x+a)^(3/2)
//                       +_plus((_mult(((2*q-5)-2*i)$i=0..gg-2)
//                               /2^(gg-1)/_mult((q-1-i)$i=0..gg-1)
//                               *(-c/(c*p+a))^gg/(x-p)^(q-gg))$gg=1..q-1)
//                       + ((-1)^p*_mult((2*i-1)$i=0..q-2)/2^(q-1)/(q-1)!
//                          *(c/(c*p+a))^(q-1)
//                          *(2*sqrt(c*_X+a)-sqrt(c*p+a)
//                            * ln(genident("C")
//                                 *(sqrt(c*_X+a)+sqrt(c*p+a))
//                                 /(sqrt(c*_X+a)-sqrt(c*p+a))))));
//                break;
//            end_case;
          end_if;
        end_if;
          
        p:=(a+c*_X+b*_X^2)^(1/2);
         return(
           (if testtype(g,Type::PolyExpr(_X)) then 
              intlib::looksqrt(g,a+c*_X+b*_X^2,_X)
            // case x^m*sqrt(a+b*x) 
            elif b=0 and 
                 intlib::matchassign(g,_X^_pattern(hold(m),is,Type::NonNegInt))
               then 2/c^(m+1)*p*hold(sum)(
                     (-a)^(m-i)*(a+c*_X)^(1+i)*binomial(m,i)/(3+2*i),i=0..m )
            // case x^m*sqrt(c*x-x^2) 
            elif a=0 and b=-1 and 
                 intlib::matchassign(g,_X^_pattern(hold(m),is,Type::NonNegInt))
               then a:=c/2; 
                a^(m+2)*arcsin((_X-a)/a)*binomial(2*m+1,m)/(m+2)/2^m
                +p*(_X^(m+1)/(m+2)-sum(2^(i-m)*a^(m+1-i)*_X^i*binomial(2*m+1,m)
                /(m+2)/binomial(2*i+1,i)/(i+1),i=0..m))
            elif c<>0 then FAIL
            elif g=1/_X then p-a^(1/2)*arctanh(a^(1/2)/p)
            elif g=1/_X^2 then -p^3/a/_X+b*_X*p/a+b^(1/2)*ln(b^(1/2)*_X+p)
            elif g=1/_X^3 then
              -p^3/a/_X^2/2+b/a/2*(p-a^(1/2)*arctanh(a^(1/2)/p))
            elif not has((c:=_X^2-1/g),_X) 
               then // g=1/(x^2-c) 
                 if type(c)="_power" and op(c,2)=2 
                  then c:=op(c,1) else c:=c^(1/2)
                 end_if;
                 p:=c+_X; q:=_X-c; gg:=(b*c^2+a)^(1/2);
                 d:=(b*p^2-2*b*c*p+b*c^2+a)^(1/2);
                 m:=(b*q^2+2*b*c*q+b*c^2+a)^(1/2);
                 i:=b^(1/2);
                 m/2/c+i/2*ln(i*_X+m)-gg/2/c*arctanh((b*c^2+a+b*c*q)/gg/m)
                 -d/2/c+i/2*ln(i*_X+d)+gg/2/c*arctanh((b*c^2+a-b*c*p)/gg/d)
            else FAIL end_if))
      // case g(x)/sqrt(a+d*x+b*x^2) 
      elif intlib::matchassign(_f_,_pattern(hold(g))/(indep(b,_X)*_X^2
                               +indep(d,_X)*_X+indep(a,_X))^(1/2)) 
         then p:=(a+d*_X+b*_X^2)^(1/2);
           return(
             (if testtype(g,Type::PolyExpr(_X)) 
                then intlib::looksqrt2(g,a+d*_X+b*_X^2,_X)
              elif g=1/_X 
                 then if a=0 then -2*p/d/_X 
                      else -arctanh((a+d*_X/2)/p/a^(1/2))/a^(1/2) end_if
              elif b=0 and intlib::matchassign(g,
                              (indep(c,_X)+_X*indep(b,_X))^indep(m,_X)) 
                 then 
                   if m=-1 then -2*arctan((-b)^(1/2)*p/(-d*c+a*b)^(1/2))
                        /(a*b-d*c)^(1/2)/(-b)^(1/2)
                   elif is(m,Type::NonNegInt)=TRUE then
                     // `#i` instead of i, so
                     // assume(s, Type::PosInt):
                     // int((t-x)^(s-1)/sqrt(x), x)
                     // works
                       2*p*fact(m)^2/d/fact(1+2*m)*hold(sum)((4*c
                       -4*a*b/d)^(m-`#i`)*(c+b*_X)^`#i`*binomial(2*`#i`,`#i`),`#i`=0..m)
                     else FAIL end_if
              elif d=0 and (not has((c:=1/g+_X^2),_X) or 
                   not has((c:=1/g-_X^2),_X))
                 then 
                   if type(c)="_power" and op(c,2)=2 then 
                        gg:=op(c,1) 
                   else gg:=c^(1/2) 
                   end_if;
                   if iszero(c) then 
                        -1/_f_/_X^3/a
                   else
                     d:=(b*c+a)^(1/2); 
                     // --------------------------------------------------
                     // Walter 21.2.02: I fixed the branch below
                     // --------------------------------------------------
                     if d=0 and c = 1/g + _X^2 then
                        // int( 1/(c - _X^2)/ sqrt(b*_X^2 - b*c), _X)
                        _X*sqrt(b*(_X^2 - c))/b/c/(_X^2 - c);
                     elif d=0 and c = 1/g - _X^2 then
                        // int( 1/(c + _X^2)/ sqrt(b*_X^2 - b*c), _X)
                        if is(b < 0) = TRUE then
                             1/sqrt(2)/c/sqrt(-b)*arctan( sqrt(2)*_X*sqrt(-b)/(b*(_X^2 - c))^(1/2));
                        else 1/sqrt(2)/c/sqrt(b)* arctanh(sqrt(2)*_X*sqrt(b) /(-b*(c -_X^2))^(1/2));
                        end_if;
                     // --------------------------------------------------
                     // Walter 21.2.02: I fixed the branch above, but I did
                     // not fix the branch below. It seems to be wrong:
                     //    float(int(1/(2 + z^2)/sqrt(z^2 - 1), z=2..3)); --> 0.1225138585
                     // numeric::int(1/(2 + z^2)/sqrt(z^2 - 1), z=2..3);  --> 0.05652767424
                     // --------------------------------------------------
                     else
                       // This is Paul's (?) original code:
                       // This formula seems to be wrong!!
                       p:=_X+gg;
                       q:=_X-gg;
                       //arctanh((b*c+a+b*gg*q)/d/(b*q^2+2*b*gg*q+b*c+a)^(1/2));
                       //(%-subs(%,q=-p))/2/d/gg;
                       (
                          arctanh((b*c+a+b*gg*q)/d/(b*q^2+2*b*gg*q+b*c+a)^(1/2))
                         -arctanh((b*c+a-b*gg*p)/d/(b*p^2-2*b*gg*p+b*c+a)^(1/2))
                       )/2/d/gg;
                       if c=1/gg+_X^2 then 
                             % 
                       else -% 
                       end_if;
                     end_if;
                   end_if;
              elif a=0 and b=-1 
                 then
                   if intlib::matchassign(g,
                                _X^_pattern(hold(m),is,Type::NonNegInt))
                     then a:=d/2; 
                       binomial(2*m,m)*(a/2)^m*(arcsin(_X/a-1)-p*sum((2/a)^i
                       *_X^(i-1)/binomial(2*i,i)/i,i=1..m))
                   elif intlib::matchassign(g,1/_X^_pattern(hold(m),
                                            is,Type::PosInt))
                      then a:=d/2; 
                        -p*sum((a/2)^(i-m)*_X^(-1-i)*binomial(2*i,i)
                        /binomial(2*m,m)/m,i=0..m-1)
                   else FAIL end_if
              else FAIL end_if))
      // case 1/x/sqrt(c+a*x^m) 
      elif intlib::matchassign(_f_,(indep(a,_X)*_X^indep(m,_X)-indep(c,_X))
                               ^(-1/2)/_X) 
         then return(2*arctan((a*_X^m-c)^(1/2)/c^(1/2))/m/c^(1/2))
      // case x^2*(a+b*x^2)^(3/2) 
      elif intlib::matchassign(_f_,_X^2*(indep(a,_X)+indep(b,_X)
                               *_X^2)^(3/2)) 
         then p:=(a+b*_X^2)^(1/2);
         return(_X*p/b*(p^4/6-a*p^2/24-a^2/16)-a^3*ln(b^(1/2)*_X+p)/b^(3/2)/16)
      // case x^2/(a+b*x^2)^(3/2) 
      elif intlib::matchassign(_f_,_pattern(hold(g))
                                /(indep(a,_X)+indep(b,_X)*_X^2)^(3/2)) 
         then p:=(a+b*_X^2)^(1/2); 
          return(
           (if g=_X^2 then -_X/b/p+ln(b^(1/2)*_X+p)/b^(3/2)
            elif g=1/_X then 1/a/p-arctanh(a^(1/2)/p)/a^(3/2)
            elif g=1/_X^3 then
              -1/a/_X^2/p/2-3/2*b/a*(1/a/p-arctanh(a^(1/2)/p)/a^(3/2))
            else FAIL end_if))
      // try Bertrand's algorithm for hyperelliptic functions
      elif (gg:=intlib::match1(_f_,
             _pattern(p,Type::PolyExpr(_X,Type::Rational))/
                        _pattern(q,Type::PolyExpr(_X,Type::Rational))/
                         sqrt(_pattern(f,Type::PolyExpr(_X,Type::Rational))))
           )<>FAIL 
         then
           userinfo(1,"recognized hyperelliptic integral");
           // check the conditions 
           p:=subs(p,gg); q:=subs(q,gg); f:=subs(f,gg);
           if degree(f,_X) mod 2 = 1 and gcd(q,f,_X)=1 and gcd(p,q,_X)=1
              and gcd(f,diff(f,_X),_X)=1 and gcd(q,diff(q,_X),_X)=1 
             then //intlib::hyperint(p,q,f,_X);
               //if not has(%, int) then return(%) end_if
             return(intlib::hyperint(p,q,f,_X))
           end_if
      end_if;
      break
   of "diff" do
      if op(_f_,2)=_X then
         return(
          (if nops(_f_)=2 then op(_f_,1) else subsop(_f_,2=null()) end_if))
      end_if
   otherwise // try to use "int" attributes 
      gg:=op(_f_,0);
      if type(gg)="D" then
         if nops(gg)=1 then gg:=D([1],op(gg)) end_if;
         for a from 1 to nops(op(gg,1)) do
            if op(_f_,op(gg,[1,a]))=_X 
               and not has(subsop([op(_f_)],op(gg,[1,a])=NIL),_X)
            then return(D(subsop(op(gg,1),a=null()),op(gg,2))(op(_f_)))
            end_if
         end_for
      elif type(eval(gg))=DOM_FUNC_ENV then
         gg:=slot(eval(gg),"int");
         if gg<>FAIL then
            gg:=gg(_f_,_X);
            if gg<>FAIL then return(gg) end_if
         end_if 
      end_if; break
   end_case;
   // tries to map on sums 
   /* call intlib::lookup here to ensure that the factors
     independent of _X are removed */
   if type(_f_)="_plus" then
     map(_f_,intlib::lookup_intern)
   else
     FAIL
   end_if
end_proc:

intlib::lookup2(_X) := 1/2*_X^2:
intlib::lookup2(hold(abs(_X))) := hold(_X*abs(_X)/2):
intlib::lookup2(1/sqrt(1-_X^2)) := hold(arcsin(_X)):
intlib::lookup2(1/sqrt(_X^2-1)) := hold(arccosh(_X)):
intlib::lookup2(sign(_X)) := hold(_X*sign(_X)):
intlib::lookup2((1-_X^2)^(1/2)):=1/2*_X*(1-_X^2)^(1/2)+1/2*arcsin(_X):
intlib::lookup2(1/_X/sqrt(_X^2-1)):=hold(-arctan(1/sqrt(_X^2-1))):
intlib::lookup2(1/sqrt(_X^2+1)):=arcsinh(_X):
intlib::lookup2(1/_X^3/sqrt(_X^2+1)):=
                        -sqrt(_X^2+1)/2/_X^2+arctanh(sqrt(_X^2+1))/2:
intlib::lookup2(1/_X^3/sqrt(_X^2-1)):=
                        hold(sqrt(_X^2-1)/2/_X^2-arctan(1/sqrt(_X^2-1))/2):
intlib::lookup2(1/_X^3/(1-_X^2)^(1/2)):=
                        -(1-_X^2)^(1/2)/2/_X^2-arctanh(1/(1-_X^2)^(1/2))/2:
intlib::lookup2((1+_X^2)/(1-_X^2)/(1+_X^4)^(1/2)):=
                        ln((2^(1/2)*_X+(1+_X^4)^(1/2))/(1-_X^2))/2^(1/2):
intlib::lookup2((1-_X^2)/(1+_X^2)/(1+_X^4)^(1/2)):=
                        hold(arctan(2^(1/2)*_X/(1+_X^4)^(1/2))/2^(1/2)):
intlib::lookup2(1/(_X*(-1/2) + (_X^2-4)^(1/2)*1/2)):=
             _X^2*(-1/4) + _X*(_X^2-4)^(1/2)*(-1/4) + ln(_X + (_X^2-4)^(1/2)):
intlib::lookup2(1/(_X*(-1/2) + (_X^2-4)^(1/2)*(-1/2))):=
             -1/4*_X^2+1/4*_X*(_X^2-4)^(1/2)-ln(_X+(_X^2-4)^(1/2)):
intlib::lookup2((_X^2-1)^(1/2)/(_X^2*2-2)):=1/2*ln(_X+(_X^2-1)^(1/2)):
intlib::lookup2((_X^2-1)^(1/2)/(-_X^2*2+2)):=-1/2*ln(_X+(_X^2-1)^(1/2)):
        
