proc()
save FSA;
begin
  read("INTLIB".stdlib::PathSep."DEFINITE".stdlib::PathSep."patternFSA.mb", Plain);
  intlib::definite::patternFSA:=FSA;
end():

