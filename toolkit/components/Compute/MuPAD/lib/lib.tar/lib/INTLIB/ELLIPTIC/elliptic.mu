/* helper functions for expressing elliptic integrals by special functions */

intlib::elliptic:=proc(f,x,options)
local powops,i,j,polys,result;
begin
  // get rid of the assumption x in R_
  save x;
  eval(hold(_delete)(x));

  powops:=select([prog::find(f,"_power",Type)], o->not testtype(op(op(f,o),2), DOM_INT));
  if nops(powops)=0 then
    return(FAIL);
  end_if;
  
  polys:=[];
 
  // replace all square roots by `#Y`(j)
  for i in powops do
    if not testtype(op(op(f,i),2), DOM_RAT) then
      return(FAIL);
    end_if;

    if not testtype(op(op(f,i),2)*2, DOM_INT) then
      return(FAIL);
    end_if;

    if not testtype(op(op(f,i),1), Type::PolyExpr([x], Type::IndepOf({x, `#Y`}))) then
      return(FAIL);
    end_if;

    j:=contains(polys, op(op(f,i),1));
    if j=0 then
      polys:=polys . [op(op(f,i),1)];
      j:=nops(polys);
    end_if;
    
    f:=subsop(f, i.[1]=`#Y`(j), i.[2]=op(op(f,i),2)*2, Unsimplified);
  end_for;

  f:=eval(f);

  // make sure that f is rational
  if not intlib::elliptic::testrat(f,x) then
    return(FAIL);
  end_if;
   
  result:=intlib::elliptic::ellrec(f,x,polys,[],options);

  // see if we actually did some useful work
  if type(result)="int" then
    return(FAIL);
  end_if;

  if _lazy_and(type(result)="_plus", map(op(result), o->type(o)="int")) then
    return(FAIL);
  end_if;

  return(result);
end_proc:


intlib::elliptic:=funcenv(intlib::elliptic):


// test whether f is rational in x and `#Y`(j)
intlib::elliptic::testrat:=proc(f,x)
begin
  case type(f)
    of "_plus" do
    of "_mult" do
      return(_lazy_and(map(op(f), intlib::elliptic::testrat, x)));
    of "_power" do
      if not testtype(op(f,2), DOM_INT) and has(op(f,1),{x,`#Y`}) then
        return(FALSE);
      end_if;
      return(intlib::elliptic::testrat(op(f,1),x));
    of "function" do
      return(bool(op(f,0)=`#Y`) or not has(f,{x,`#Y`}));
    otherwise
      return(bool(f=x) or not has(f,{x,`#Y`}));
  end_case;
end_proc:


// recursively split f into normalized forms
intlib::elliptic::ellrec:=proc(f,x,splitpolys,radpolys,options)
local tmp,a,b;
begin
  if iszero(f) then
    return(0);
  end_if;

  if nops(splitpolys)>0 then
    tmp:=intlib::elliptic::splitrat(subs(f,`#Y`(nops(splitpolys))=`#YY`), `#YY`, splitpolys[-1]);
    
    return(
      intlib::elliptic::ellrec(tmp[1],x,splitpolys[1..-2],radpolys.[splitpolys[-1]],options) +
      intlib::elliptic::ellrec(tmp[2],x,splitpolys[1..-2],radpolys,options));
  end_if;

  // Now f is a rational function in x.
  // Objective: integrate f/sqrt(radpolys[1])/sqrt(radpolys[2])...

  if nops(radpolys)=0 then
    // pure rational function
    return(intlib::rational(f,x,options));
  end_if;

  radpolys:=sort(radpolys, (p,q)->degree(p,[x])>degree(q,[x]));

  if iszero(1-x^2-radpolys[1]) then
    if nops(radpolys)=2 and degree(radpolys[2],x)=1 then
      a:=coeff(radpolys[2],x,1);
      b:=coeff(radpolys[2],x,0);
      
      // FIXME: case b<0 is wrong
      if iszero(a-b) then
        return(hold(int)(f/(1+x)/sqrt(1-x)/sqrt(b),x));
      elif iszero(a+b) then
        return(hold(int)(f/(1-x)/sqrt(1+x)/sqrt(b),x));
      end_if;
      
      return(intlib::elliptic::ell3c(f,x,a,b));
    end_if;
  end_if;

  if nops(radpolys)=1 and degree(radpolys[1],x)=2 and coeff(radpolys[1],x,1)=0 then
    // special case: circular integral
    a:=coeff(radpolys[1],x,2);
    b:=coeff(radpolys[1],x,0);

    // FIXME: make this a piecewise
    if is(a<0)=TRUE and is(b>0)=TRUE then
      return(intlib::circular(f,x,-b/a)/sqrt(-a));
    elif is(a>0)=TRUE and is(b>0)=TRUE then
      return(intlib::hyperbolic(f,x,b/a)/sqrt(a));
    end_if;
  end_if;

  return(hold(int)(f/_mult(op(map(radpolys,sqrt))), x, intlib::printOptions(options)));
end_proc:


// split a rational function R(x,X) with X^2=X2 into R1(x)/X+R2(x)
intlib::elliptic::splitrat:=proc(r,X,X2)
local n,d,red;
begin
  // reduction polynomial
  red:=poly(X^2-X2, [X]);
  
  r:=normal(r);
  n:=divide(poly(numer(r), [X]), red, Rem);
  d:=divide(poly(denom(r), [X]), red, Rem);

  n:=divide(n*poly(coeff(d,1)*X-coeff(d,0), [X]), red, Rem);
  d:=coeff(d,1)^2*X2-coeff(d,0)^2;

  return([normal(coeff(n,1)*X2/d), normal(coeff(n,0)/d)]);
end_proc:


// int(sum(c[k]^(k-1), k=1..nops(c)) / sqrt(_X_) / sqrt(1-_X_) / sqrt(1-m*_X_), _X_)
intlib::elliptic::ell3:=proc(c,z,m)
local k,tmp;
begin
  k:=nops(c);
  // padding
  if k=1 then
    c:=c . [0];
  end_if;

  tmp:=0;

  // reduce case k>2 to k=2
  // G&H 243.4a
  while k>2 do
    tmp:=tmp + c[k]*2/(2*k-3)/m*z^(k-3);
    c[k-1]:=c[k-1] + c[k]*(2*k-4)/(2*k-3)*(m+1)/m;
    c[k-2]:=c[k-2] - c[k]*(2*k-5)/(2*k-3)/m;
    k:=k-1;
  end_while;

  tmp:=expand(tmp) * sqrt(z) * sqrt(1-z) * sqrt(1-m*z);
  z:=arcsin(sqrt(z));
  return(tmp + 2*(c[1]+c[2]/m)*ellipticF(z, m) - 2*c[2]/m*ellipticE(z, m));
end_proc;


// int(sum(c[j]^(j-1), j=1..nops(c)) / sqrt(_X_) / sqrt(1-_X_) / sqrt(1-m*_X_) / (1-n*_X_)^k, _X_)
intlib::elliptic::ell3pi:=proc(c,z,m,n,k)
local i,j,tmp,result;
begin
  // TODO: special cases
  if iszero(n-1) or iszero(n-m) then
    return(FAIL);
  end_if;

  // padding
  while nops(c)<k+4 do
    c:=c.[0];
  end_while;
  
  // first switch from base {_X_^j} to base {(1-n*_X_)^j}
  i:=nops(c);
  while i>1 do
    tmp:=c[i] / (-n)^(i-1);
    
    c[i]:=tmp;
    for j from 1 to i-1 do
      c[j]:=c[j] - tmp*binomial(i-1,j-1)*(-n)^(j-1);
    end_for;
    
    i:=i-1;
  end_while;

  // reduce case k>1 to k=1
  // G&H 241.9a
  result:=0;
  
  while k>1 do
    tmp:=c[1]/2/(k-1)/(1-n)/(m-n);

    result:=result + tmp/(1-n*z)^(k-1);
    c[2]:=c[2] + tmp*(2*k-3)*(n^2-2*m*n-2*n+3*m);
    c[3]:=c[3] - tmp*(2*k-4)*(-m*n-n+3*m);
    c[4]:=c[4] + tmp*(2*k-5)*m;
    
    c:=c[2..nops(c)];
    k:=k-1;
  end_while;

  // now switch back to base {_X_^j}
  for i from k+1 to nops(c) do
    tmp:=c[i];

    c[i]:=tmp*(-n)^(i-k-1);
    for j from k+1 to i-1 do
      c[j]:=c[j] + tmp*binomial(i-k-1,j-k-1)*(-n)^(j-k-1);
    end_for;
  end_for;

  return(
    result*2*n^2*sqrt(z)*sqrt(1-z)*sqrt(1-m*z) + 
    c[1]*2*ellipticPi(n,arcsin(sqrt(z)),m) + 
    intlib::elliptic::ell3(c[2..nops(c)],z,m));
end_proc;


// int(p/sqrt(a*_X+b)/sqrt(1-_X^2), _X), abs(a)<b
intlib::elliptic::ell3a:=
proc(p,x,a,b)
  local j: DOM_INT;
begin
  p:=poly(subs(p, x=2*x-1), [x]);
  p:=[coeff(p,j) $ j=0..degree(p)];
  
  return(intlib::elliptic::ell3(p, (x+1)/2, 2*a/(a-b)) / sqrt(b-a));
end_proc:


// int(p/sqrt(a*_X+b)/(c*_X+d)^k/sqrt(1-_X^2), _X), abs(a)<b
intlib::elliptic::ell3b:=
proc(p,x,a,b,c,d,k)
  local j: DOM_INT;
begin
  p:=poly(subs(p, x=2*x-1), [x]);
  p:=[coeff(p,j) $ j=0..degree(p)];
  
  return(intlib::elliptic::ell3pi(p, (x+1)/2, 2*a/(a-b), 2*c/(c-d), k) / (d-c)^k / sqrt(b-a));
end_proc:


// int(r/sqrt(a*_X+b)/sqrt(1-_X^2), _X), abs(a)<b, r rational in x
intlib::elliptic::ell3c:=
proc(r,x,a,b)
  local result,p,s,t,k;
begin
  // the most likely reason for ell3c to fail is that partfrac
  // cannot decompose denom(r) into linear factors
  r:=partfrac(r,x,Full);
  
  if type(r)="_plus" then
    p:=select(r, testtype, Type::PolyExpr([x], Type::IndepOf(x)));
    r:=select([op(r)], not testtype, Type::PolyExpr([x], Type::IndepOf(x)));
  elif testtype(r, Type::PolyExpr([x], Type::IndepOf(x))) then
    p:=r;
    r:=[];
  else
    p:=0;
    r:=[r];
  end_if;

  // all of the following could be done a lot more efficient

  result:=intlib::elliptic::ell3a(p,x,a,b);

  for s in r do
    t:=denom(s);
    if type(t)="_power" then
      k:=op(t,2);
      t:=op(t,1);

      assert(k>1);
    else
      k:=1;
    end_if;

    assert(has(t,x));

    if degree(t,x)>1 then
      return(FAIL);
    end_if;

    result:=result + intlib::elliptic::ell3b(numer(s),x,a,b,coeff(t,x,1),coeff(t,x,0),k);
  end_for;

  return(result);
end_proc:


