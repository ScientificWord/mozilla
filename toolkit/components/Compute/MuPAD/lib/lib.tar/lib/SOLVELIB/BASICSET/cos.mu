solvelib::BasicSet::cos := solvelib::BasicSet::spfun(cos):
solvelib::BasicSet::cos(C_) := C_ :
solvelib::BasicSet::cos(R_) := Dom::Interval([-1, 1]):
