
solvelib::BasicSet::sin := solvelib::BasicSet::spfun(sin):

solvelib::BasicSet::sin(C_) := C_:
solvelib::BasicSet::sin(R_) := Dom::Interval([-1, 1]):
