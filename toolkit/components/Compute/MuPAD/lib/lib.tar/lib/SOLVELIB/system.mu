/* */
/* $Date: 2006-06-19 17:17:24 +0200 (Mon, 19 Jun 2006) $ $Author: stefanw $ $Revision: 39678 $ */
/* */
/* zimmerma, 14/12/95 */

/*--
	solvelib::solve_sys
--*/

// Sys - set or list of equations
// Unk - set or list of unknowns



alias(C_N(unk) = solvelib::cartesianPower(C_, nops(unk))):

solvelib::solve_sys :=
proc(Sys: Type::Union(DOM_LIST, DOM_SET), Unk: DOM_LIST)
  local
  sys:DOM_LIST,
  newsys, /* j, newsys2, */ eq,i,R, pw,
  unk: DOM_LIST,
  newunk: DOM_LIST, otherunk: DOM_LIST, dummy: DOM_LIST,
  newunkpos, otherunkpos,
  options: DOM_TABLE,
  originalOptions: DOM_TABLE,
  eqtypes, ring,
  makeExpression: DOM_PROC,
  check: DOM_PROC,
  toSplit: DOM_LIST, // or-conditions where each operand leads to a separate
                     // system
  ineqs: DOM_LIST, // list of constraints that must *not* hold TRUE
  leqs: DOM_LIST,  // inequalities of type "_less" or "_leequal"
  newIndices: DOM_LIST,
  solutions, sol;
  
begin

/********************************
  local methods
********************************/


  
  // makeExpression - turns any legal input (equation, polynomial, ...)
  // into a (sequence of) expression(s) and adjusts the coefficient domain at
  // the same time
  makeExpression:=
  proc(equation)
    local ring;
  begin
    case type(equation)
      of "_unequal" do
        ineqs:= ineqs.[op(equation, 1) - op(equation, 2)];
        null();
        break
      of "_not" do
        ineqs:= ineqs.[op(equation, 1)];
        null();
        break
      of "_in" do
        equation:= expand(equation);
        if type(equation) <> "_in" then
          makeExpression(equation)
        else
          equation
        end_if;
        break
      of "_less" do
      of "_leequal" do
        leqs:= leqs.[equation];
        null();
        break
      of "_equal" do
        return(makeExpression(op(equation,1)-op(equation,2)))
      of "_or" do
      // split the system into several systems, one for each operand
        equation:= select(equation, x -> is(x) <> FALSE);
        if type(equation) <> "_or" then
          return(makeExpression(equation))
        end_if;
        toSplit:= toSplit.[equation];
        null();
        break
      of "_mult" do
        equation:= select([op(equation)], x -> is(x=0) <> FALSE);
        if nops(equation) = 0 then
          return(1)
        elif nops(equation) = 1 then
          return(makeExpression(op(equation, 1)))
        end_if;
        // split the system into several systems, one for each operand
        toSplit:= toSplit.[_or(op(equation, i) = 0 $i=1..nops(equation))];
        null();
        break
      of "exp" do
        // unsatisfiable, since exp has no zeroes
        return(1)
      of "_and" do
        map(op(equation), makeExpression);
        break
      of DOM_POLY do
        ring:= op(equation, 3);
        if has(ring, IntMod) then
          ring:= Dom::IntegerMod(op(ring,1))
        end_if;
        if R=hold(Expr) then
          R:=ring
        else
          // try to understand equation
          // as a polynomial over the previously chosen ring
          equation:= poly(equation, R);
          if equation = FAIL then
            error("Coefficient ring of polynomial does not ".
                  "match previously chosen domain for solving".
                               " or other coefficient ring");
          end_if;
        end_if;
        expr(equation);
        break
      otherwise
        equation
    end_case
  end_proc;


  
  // m a i n 



  // argument checking and conversion
  
  // force sys to be a list
  sys:=[op(Sys)];

  if {op(Unk)} intersect Type::ConstantIdents <> {} then
    error("Invalid variable (mathematical constant was given)")
  elif nops(Unk) = 0 then
    error("Need variable(s) to solve for")
  end_if;
  unk:=[op(Unk)];
  
  options:= originalOptions:= solvelib::getOptions(args(3..args(0)));

  if options["IgnoreSpecialCases"] then
    pw:= solvelib::ignoreSpecialCases
  else
    pw:= piecewise
  end_if;

  // The case VectorFormat = FALSE has been caught in the main program
  // of solve
  options["VectorFormat"] := TRUE;
  
  
 

  // handling of floats
  if stdlib::hasfloat(sys) then
    sys:=numeric::rationalize(sys);
    solvelib::solve_sys(sys, Unk, options);
    return(misc::maprec(%, {solvelib::VectorImageSet, Dom::ImageSet,
                            DOM_INT, DOM_RAT, DOM_COMPLEX, DOM_IDENT}= float))
  end_if;

  R:= options["Domain"];
  // convert all equations and polys to expressions
  // as a side effect, separate inequalities
  ineqs:= [];
  leqs:= [];
  toSplit:= [];
  sys:=map(sys, makeExpression);
  options["Domain"]:= R;
  
  if nops(toSplit) > 0 then
    eq:= toSplit[1];
    delete toSplit[1];
    return(
           _union(solvelib::solve_sys(sys.ineqs.leqs.toSplit.[op(eq, i)],
                                      Unk, options)
                  $i=1..nops(eq))
           )
  end_if;




  // try overloading
  eqtypes:= map(sys, domtype);
  eqtypes:= select(eqtypes, c -> (slot(c, "solve_sys")<>FAIL));
  if nops(eqtypes) > 0 then
    userinfo(50, "System solver has been overloaded");
    if leqs <> [] then
      error("Cannot solve systems with inequalities over domains")
    end_if;
    ring:= eqtypes[1];
    sys:= map(sys, ring::convert);
    ineqs:= map(ineqs, ring::convert);
    if has([sys, ineqs], FAIL) then
      error("Could not convert all of the equations")
    end_if;
    if ineqs <> [] then
      return(ring::solve_sys(sys, Unk, options) minus
             ring::solve_sys(ineqs, Unk, options))
    else
      return(ring::solve_sys(sys, Unk, options))
    end_if;
  end_if;


  if R <> hold(Expr) then
    if leqs <> [] then
      error("Cannot solve systems with inequalities over domains")
    end_if;
    if ineqs <> [] then
      return(solvelib::domsolve(sys, Unk, options) minus
             solvelib::domsolve(ineqs, Unk, options))
    else
      return(solvelib::domsolve(sys, Unk, options))
    end_if
  end_if;

  // toDo: single objects overload solve - intersect solutions
  // with solution to the rest of the system  
  
  if options["Multiple"]=TRUE then
    error("Option multiple is not allowed in the system solver")
  end_if;


  userinfo(3, "System solver called for ".expr2text(sys)." in unknowns ".
	expr2text(Unk));
  userinfo(10, "Options are ".expr2text(options));
    

  // unsatisfiable equations?
  if contains(map(sys, is, Type::Zero), FALSE) > 0 then
    return({})
  end_if;

  // handle inequalities
  if nops(ineqs) > 0 then
    if nops(sys) = 0 and nops(leqs) > 0 then
      if nops(ineqs) > 0 then
        return(solvelib::solve_minus(solvelib::ineqsys(leqs, Unk),
                                     solve(ineqs, unk, options) ))
      else
        return(solvelib::ineqsys(leqs, Unk))
      end_if
    end_if;
    // we can only handle a few cases of mixed systems, unfortunately
    solutions := solvelib::solve_sys(sys, unk, options);
    if solutions = {} then
       return({})
    end_if;
    // to improve: check solutions instead of solving exceptions ?!
    solutions:= solvelib::solve_minus(solutions, solve(ineqs, unk, options));
    if nops(leqs) > 0 then
      return(solvelib::solve_intersect(solvelib::ineqsys(leqs, Unk), solutions))
    else
      return(solutions)
    end_if
  end_if;
  // handle inequalities of type _leequal and _less
  if leqs <> [] then
    return(solvelib::ineqsys(leqs, Unk) intersect
    solvelib::solve_sys(sys, unk, options))
  end_if;

  
  // remove zero equations
  sys:= select(sys, _not@iszero);

  // no equations left?
  if nops(sys)=0 then
    return(C_N(unk))
  end_if;



   if nops(Unk)=1 then
    // only one unknown, use the equation solver
     R:= [FAIL $ nops(sys)];
     for i from 1 to nops(sys) do
      R[i]:=solve(op(sys, i), op(Unk, 1), options);
      if type(R[i]) = "solve" then
        return(hold(solve)(Sys, Unk, solvelib::nonDefaultOptions(originalOptions)))
      end_if
     end_for;  
     return(solvelib::numberSetToVectorSet(solvelib::solve_intersect(op(R))))
   end_if;

  
  
  // substitute unknowns that are not identifiers
  // substitute all indexed identifiers, including free parameters
  eq:= select({op(unk)}, not testtype, DOM_IDENT) union
       select(solvelib::indets(sys, {"_index"}), x -> type(x) <> DOM_IDENT);
  eq:= [op(eq)];
  if eq<>[] then
    eq:= [(op(eq,i) = genident()) $i=1..nops(eq)];
    newsys:= solvelib::solve_sys(subs(sys, eq), subs(Unk, eq), options);
    subs(newsys, (op(eq,[i,2])=op(eq,[i,1])) $i=1..nops(eq));
    return(%)
  end_if;




  // at this point, our system sys contains no more objects that
  // overload solve, or inequalities, or objects of type _not
  // however, there may still be non-expandable objects of type _in

  if select(sys, proc(eq)
                   begin
                     testtype(eq, Type::Arithmetical) <> TRUE and
                     type(eq) <> "_in"
                 end_proc)
    <> [] then
    error("Systems contains equation of unknown type")
  end_if;

  // we have to do the following things:
  // - split products and powers
 //  - solve _in - expressions

  if contains(map({op(sys)}, type), "_in") then
    return(hold(solve)(sys, unk))
  end_if;
  


  // first, we expand sums (e.g. sum(a+x[i], i=...))
  sys:= misc::maprec(sys, {"sum"} = expand);

  
  // remove powers

  sys:= map(sys, proc(eq)
                 begin
                   if type(eq)<>"_power" then
                     eq
                   elif testtype(op(eq,2), Type::Constant)<>TRUE then
                     eq
                   elif is(op(eq, 2)>0) then
                     op(eq, 1)
                   else
                     // negative exponent: unsolvable
                     FAIL
                   end_if
                 end_proc
                   );
  if contains(sys, FAIL)>0 then
    return({})
  end_if;
  

  
  
  // handle linear systems
  // parameters are handled via ShowAssumptions, over Expr only


  if (newsys:= solvelib::solve_islinear(sys, unk, options)) <> FALSE then
    /* solve returns a set of solutions
       whereas linsolve always returns one solution */
    assert(R = hold(Expr));
    i:= numeric::linsolve(newsys, unk, hold(Symbolic),
                          hold(ShowAssumptions));
  
    return(solvelib::completeLinearSolution(i, newsys, unk, options))

  end_if;


/*
   // risky change, switched off for the moment

  // handle linear equations in more complicated systems

  for i from 1 to nops(sys) do
    for j from 1 to nops(unk) do
      if ((eq:= Type::Linear(op(sys, i), [unk[j]]))) <> FALSE
        and not iszero(eq[1])
        then
        // sys[i] is eq[1]*unk[j] + eq[2] = 0
        newsys:= sys; delete newsys[i];
        newunk:= unk; delete newunk[j];
        // solve sys[i] for unk[j], and substitute into the remaining system
        // newsys, to be solved for the remaining unknowns newunk
        // solutions of the original system are:
        // all values of newunk that make both eq[1] and eq[2] equal zero,
        // together with any value of unk[j], as far as they also satisfy 
        // the remaining system newsys
        // *and*
        // all values of newunk that make eq[1] nonzero, such that
        // unk[j] -> -eq[2]/eq[1] may be substituted, as far as they satisfy
        // the remaining system after that substitution


        // solve case eq[1] = eq[2] = 0 first
        // solutions:= solvelib::solve_sys([eq[1], eq[2]], newunk, options);

     
        
        return
        (
         solvelib::solve_sys(newsys.eq, unk, options)
      /*   solvelib::selectIndices
         (
          solvelib::free2Bound
          (
           (solutions
            intersect
            solvelib::solve_sys(newsys, newunk, options)
            ),
           [unk[j]]
           ),
          [$1..j-1, nops(newunk)+1, $j..nops(newunk)]
          )
       */
          union
            (if traperror((newsys2:= subs(newsys, unk[j] = -eq[2]/eq[1]))) <> 0
               then {}
             else  
               solvelib::substituteBySet
               (
                matrix(subsop(unk, j= -eq[2]/eq[1])),
                newunk,
                solvelib::solve_minus
                (
            solvelib::solve_sys
            (newsys2, newunk, options),
            solvelib::solve_sys
            ([eq[1]], newunk, options)
            )
           )
             end_if
             )
         );               
      end_if;

    end_for
  end_for;
*/

  
   // handle algebraic systems (*do* handle parameters in a special way)

  if (newsys:= solvelib::solve_isalgebraic({op(sys)}, unk)) <> FALSE then
    solutions:=  solvelib::solve_algebraic(op(newsys, 1), unk, NIL, options);
    // select correct solutions, depending on op(newsys, 2)
    return(solvelib::solve_minus(solutions,
           solvelib::solve_algebraic({op(newsys, 2)}, unk, NIL, options)))
  end_if;
  

  // try to make the system into a polynomial system
  // by additional substitutions

  
  newsys:= map(sys, numer);
  // toDo: check whether solutions are zeroes of the denominator
  newsys:= solvelib::makeSystem({op(newsys)}, unk);
  // now newsys is a sequence equations, non-algebraic, vars, conditions
  if nops(op(newsys, 2)) = 0 then
    // no non-algebraic equations
    sol:= solve(op(newsys, 1),
               op(newsys, 3),
               options);

    // find out the positions of the old variables    
    newIndices:= [contains(op(newsys, 3), op(unk, i) ) $i=1..nops(unk)];
    assert(contains(newIndices, 0) = 0);
    sol:= solvelib::selectIndices(sol, newIndices);
    // check solutions
    check:=
    proc(S)
      local checked, pws, nonpws, dummy;
    begin
      case type(S)
        of piecewise do
          return(piecewise::extmap(S, check))
        of DOM_SET do
          checked:=
          map(S,
              proc(v)
                local cond;
              begin
                if traperror((
                cond:= subs(sys, unk[i] = v[i]
                            $i=1..nops(unk))
                              )) <> 0 then
                  // evaluation fails -> "solution" does not belong
                  // to scope of definition
                  return({})
                end_if;
                cond:= _and(op(map(cond, _equal, 0)));
                pw(
                   [cond, {v}],
                   [not cond, {}]
                   )
              end_proc);

          [pws, nonpws, dummy]:= split(checked, x -> type(x) = piecewise);
          assert(dummy = {});
          nonpws:= _union(op(nonpws));
          // to avoid gigantic running times
          if nops(pws) >= 4 then
            pws:= map(pws, piecewise::expression, 1);
            if not options["NoWarning"] then
              warning("possibly spurious solutions; could not check")
            end_if
          end_if;
          pws:= _union(op(pws));
          return(nonpws union pws)
      end_case;
      // default (not quite correct)
      if not options["NoWarning"] then
        warning("possibly spurious solutions")
      end_if;
      S
    end_proc:
    return(check(sol))
  end_if;


  // test whether the system is polynomial in at least some of the
  // variables; if yes, solve at least for them
   [newunk, otherunk, dummy]:= split(unk,
                  proc(x)
                  begin
                    not has(indets(sys, PolyExpr) minus {x}, x)
                  end_proc
                  );
  // now newunk is a list consisting of all "good" unknowns
  // select those equations that contain only "good" unknowns,
  // and solve for them
  if nops(newunk) > 0 then
    newsys:= select(sys, equ -> indets(equ) intersect {op(unk)}
                    minus {op(newunk)} = {});
    solutions:= solvelib::solve_sys(newsys, newunk, options);
    if type(solutions) = DOM_SET then
      // solver returned set - of - lists format
      if solutions = {} then
        return({})
      end_if;
      assert(map(solutions, type) = {matrix} );

      otherunkpos:= map(unk, x-> contains(otherunk, x));
      newunkpos:= map(unk, x-> contains(newunk, x));
        // for each solution (given as a list), append the
        // solutions for the non-polynomial vars
      solutions:= _union(op(map(solutions,
          proc(v)
            local nsys;
          begin
            nsys:= eval(subs(sys, newunk[i] = v[i] $i=1..nops(newunk)));
            solvelib::cartesianProduct({v},
            solvelib::solve_sys(nsys, otherunk, options))
          end_proc
         )));
      return(solvelib::selectIndices(solutions, [(if newunkpos[i] <> 0 then
                                           newunkpos[i]
                                         else  
                                           otherunkpos[i] + nops(newunk)
                                          end_if)
                                          $i=1..nops(unk)
                                           ] ))
      
      // else fall through
    end_if;
  else // nops(newunk) = 0
    userinfo(50, "System is not polynomial in any of the unknowns")
  end_if;

  userinfo(1,"Could not solve the non-algebraic system");
  hold(solve)(sys,Unk)
 
end_proc:

/* end of file */

