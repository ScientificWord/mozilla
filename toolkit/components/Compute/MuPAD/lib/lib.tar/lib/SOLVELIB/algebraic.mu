/* */
/* $Date: 2006-01-11 14:46:55 +0100 (Wed, 11 Jan 2006) $ $Author: stefanw $ $Revision: 36253 $ */
/* */
/* zimmerma, 14/12/95 */


// Methods for solving algebraic systems

// the function solvelib::algebraic (former interface function in 1.4)
// has been removed




/*--
	solvelib::solve_algebraic(sys, unk, dm, options) solves the algebraic
	system 'sys' with respect to the unknowns 'unk' over the
	coefficient field 'dm'.

	If 'unk' is a list, then it gives the elimination order.
--*/

solvelib::solve_algebraic:=
proc(syss, unkk, domm) 
  local g, gb, reord, sys, unk, dm, options, storeLeadingCoeffs, 
  lcoefflist: DOM_LIST, linear, lc, i, inds,
  indepSets, 
  monic, cond, dimen,
  solveIrreducibleFactor: DOM_PROC;
  
begin

  lcoefflist:= [];
  
  // procedure storeLeadingCoeffs
  storeLeadingCoeffs:=
  proc(f, o)
    local l;
  begin
    l:= lcoeff(f, o);
    if testtype(expr(l), Type::Constant) <> TRUE then
      lcoefflist:= append(lcoefflist, l)
    end_if;
    multcoeffs(f, 1/l)
  end_proc;


  
  sys:= syss;
  unk:= unkk;
  if args(0) >= 3 then
    dm:= domm
  else
    dm:= NIL
  end_if;
  options:= solvelib::getOptions(args(4..args(0)));
  if type(unk) = DOM_SET then
    unk:= [op(unk)];
    reord:= Reorder
  else
    reord:= null()
  end_if;
  userinfo(3, "Entering solver for algebraic systems");
  if dm= NIL then
    if map(sys, testtype, Type::PolyExpr(unk, Type::Rational)) = {TRUE}
      then
      dm:=Expr;
      monic:= groebner::primpart
    else
      dm:=Dom::ExpressionField(normal, iszero@normal);
      monic:= storeLeadingCoeffs
    end_if
  else
    monic:= f -> multcoeffs(f, _invert(lcoeff(f)))
  end_if;
  
  sys:= map([op(sys)], poly, unk, dm);
  /* first compute a basis wrt DegInvLexOrder */
  gb:=groebner::gbasis(sys, DegInvLexOrder, reord, hold(Monic) = monic);
  /* then transform it in a LexOrder basis (the Grobner walk) */
  g:=groebner::gbasis(gb, LexOrder, reord, hold(Monic)= monic );
  g:=groebner::factor(g, reord);


  solveIrreducibleFactor:=
  proc(g, unkOrig)
    local gb, unk;
  begin
    unk:= unkOrig;
               
    if nops(g) = 1 and degree(g[1])=0 then
      if iszero(g[1]) then
        userinfo(20, "Zero equation: everything is a solution");
        g:= solvelib::cartesianPower(C_, nops(unk))
      else
        g:= {} /* no solution */
      end_if;
      indepSets:= {};
      
    else
      
      // it may be that the order of unknowns has to be exchanged
      indepSets:= groebner::stronglyIndependentSets(g);
      userinfo(10, "Independent sets are :".expr2text(indepSets[3]));
      dimen:= indepSets[1];
      indepSets:= indepSets[2];
      // the number of indep. var. should equal the dimension of the variety
      assert(dimen = nops(indepSets));
      // now indepSets is a set x1, x2, ..., xn of variables,
      // such that the solutions to the system can be expressed as
      // [x1 = ..., x2 = ..., ..., xn = ...]
      
      unk:= split(unk, v -> not contains(indepSets, v));
      assert(unk[3] = []);

      if nops(unk[2])= 0 then
        userinfo(10, "Zero-dimensional system")
      else
        dm:=Dom::ExpressionField(normal, iszero@normal);
        monic:= storeLeadingCoeffs;
        g:= map(g, poly, unk[1], dm);
        // the grobner basis has to be re-computed, and the order of variables
        // must not be changed
        reord:= null();
        lcoefflist:= [];
        g:=groebner::gbasis(g, LexOrder, hold(Monic)= monic );
      end_if;
      
  
      userinfo(2,"Groebner basis is",map(g, expr));
      userinfo(2,"Groebner basis is valid if the following leading coefficients ".
    "are all nonzero:".expr2text(lcoefflist));
  
    
  
      g:=groebner::triangular_set(g);
      unk:= unk[1];

      g:=_union(op(map(g, solvelib::allvals, unk, unkOrig, options)));
    end_if;

    assert(testtype(g, Type::Set));
    
    if nops(lcoefflist) = 0 or options["IgnoreSpecialCases"] then
      // toDo: add positions to free2Bound
      g:= solvelib::free2Bound(g, [op(indepSets)]);
      unk:= unk.[op(indepSets)];
      return(solvelib::selectIndices
             (g, [contains(unk, unkk[i]) $i=1..nops(unkk)] ))
    else
      lcoefflist:= map(lcoefflist, expr);
      cond:= _and(op(map(lcoefflist, _unequal, 0)));
      // search for degree 1 leading coefficient:
      // if it exists, we also solve the special case
      linear:= FAIL;
      for lc in lcoefflist do
        inds:= indets(lc);
        for i in inds do
          if testtype(lc, Type::PolyExpr([i])) and
            degree(lc, [i]) = 1 then
            linear:= [lc, i];
            break
          end_if
        end_for;
        if linear <> FAIL then break; end_if
      end_for;
    
    
      if linear <> FAIL then
        gb:= poly(linear[1], [linear[2]]);
      return(solvelib::free2Bound
             (
              piecewise([cond, g],
                [linear[1] = 0,
                 solve(subs(syss,
                            linear[2] = -coeff(gb, 0) / coeff(gb, 1)),
                       unk, options)] ),
             [op(indepSets)]))
    end_if;
    
    // if nothing helps, accept also higher degree polynomials

    for lc in lcoefflist do
      inds:= indets(lc);
      for i in inds do
        if testtype(lc, Type::PolyExpr([i])) then
          linear:= [lc, i];
          break
        end_if
      end_for;
      if linear <> FAIL then break; end_if
    end_for;

    // attach the condition ,,leading coeff = 0'' as
    // additional equation to the polynomial system, and start over
    if linear <> FAIL then
      return(solvelib::free2Bound
             (
              piecewise([cond, g],
                        [not cond, solvelib::bound2Free
                         (solvelib::solve_algebraic
                          (syss union {linear[1]}, unk.[i], dm, options), nops(unk)+1, i)]),
             [op(indepSets)]))
    else  
      // only non-polynomial leading coefficients
      solvelib::free2Bound(piecewise([cond, g]), [op(indepSets)])
    end_if
      end_if
             end_proc;

  _union(op(map(g, solveIrreducibleFactor, unk)))
end_proc:


/*--
solvelib::allvals(g, unk, unk2, options)

g - a list of polynomials, in triangular form
unk - set of unknowns
unk2 - set of variables that should not be replaced
options - table of options, as returned by solvelib::getOptions()

returns an expression of the form unk in set


--*/

solvelib::allvals :=
proc(g: Type::ListOf(DOM_POLY),
     unk: Type::ListOf(DOM_IDENT),
     unk2: Type::ListOf(DOM_IDENT), 
     options: DOM_TABLE)
  local sol,
  i, j, r,
  freeInd: DOM_SET,
  toSubs,
  backSubstitute: DOM_PROC;
  
begin

  // local methods

  // backSubstitute
  backSubstitute:=
  proc(solution)
    local
    backSubs: DOM_PROC,
    subsvec: DOM_PROC;
  begin

    // local method subsvec
    // replace any occurence of elements of vars
    subsvec:=
    proc(v: matrix)
    begin
      v:= [op(v)];
      while has(v, {op(unk)}) do
        // no eq. should be of the form x=f(x)
        assert(zip(v, unk, has) = [FALSE $nops(v)]);
        v:= eval(subs(v, unk[i] = v[i] $i=1..nops(unk)))
      end_while;
      matrix(v)
    end_proc;
    
    // local method backSubs  
    backSubs:=
    proc(S)
      local i: DOM_INT;
    begin
      case type(S)
        of piecewise do
          return(_union
                 (
                  solve(piecewise::condition(S, i), unk, VectorFormat)
                  intersect
                  backSubs(piecewise::expression(S, i))
                  $i=1..nops(S)
                  ))
        of "_union" do
          return(map(S, backSubs))
        of DOM_SET do
          return(map(S, subsvec))
        of solvelib::VectorImageSet do
          S:= S::dom::avoidAliasProblem(S, {op(unk2)});
          return(extsubsop(S, 1 = subsvec(expr(S))))
      end_case;
      S
      
    end_proc;
    
    backSubs(solution)
  end_proc; // backSubstitute

  /////////////////////////////////////////
  //  main program of solvelib::allvals  //
  /////////////////////////////////////////
  
  // if the ideal is <1>, there is no solution
  if nops(g) = 1 and degree(g[1]) = 0 then
    return({})
  end_if;

  freeInd:= indets(map(g, expr));
  
  // strange but true: the only zero-dimensional vector is ...
  sol:= {matrix(0, 1, [])};
  
  for i from nops(unk) downto 1 do

    // add the constraints imposed by the last equation

    // if we have already solved for the last variable appearing in that
    // equation,  go on
    repeat
      r:= g[nops(g)];
      delete g[nops(g)]
    until not has (op(r,1), {op(unk, 1..i-1)}) end_repeat;

    // we know that the system is zero-dimensional:
    // this is why we have extracted the independent sets before
    // thus, unk[i] must really show up
    assert(has(op(r, 1), unk[i]));

    j:= solvelib::solve_poly(poly(op(r,1),[unk[i]]), unk[i], options);
    userinfo(5, "Solving polynomial ".expr2text(op(r,1))." gives ".
             expr2text(j));
    
    // we have to the component j in front of each solution

    sol:= solvelib::cartesianProduct(j, sol);
    sol:= solvelib::avoidAliasProblem(sol, {op(unk2)} union freeInd);

    
    userinfo(5, "Solutions so far are ".expr2text(sol));


  end_for; // i from nops(unk) downto 1

 
  
 

  r:= {op(unk2)} union freeInd; // forbidden idents

  toSubs:= indets(sol) minus r minus
    indets(map(g, op, 2))
    minus Type::ConstantIdents;

  r:= {op(solvelib::getMultipleIdent(C_, nops(toSubs), r))};
  
  [toSubs, r]:= map([toSubs, r], _minus, toSubs intersect r);
    
  sol:= eval(subs(sol, zip([op(toSubs)], [op(r)], _equal)));
  
  if options["BackSubstitution"] then
    backSubstitute(sol)
  else  
    sol
  end_if
end_proc:

/* end of file */

