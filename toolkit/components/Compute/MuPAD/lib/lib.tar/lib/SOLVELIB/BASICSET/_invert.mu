
solvelib::BasicSet::_invert := solvelib::BasicSet::spfun(_invert):

solvelib::BasicSet::_invert(C):=C minus {0}:
solvelib::BasicSet::_invert(R):=R minus {0}:
solvelib::BasicSet::_invert(Q):=Q minus {0}:
// no special value for Z_
