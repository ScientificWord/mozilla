// $Date: 2005-05-02 16:16:58 +0200 (Mon, 02 May 2005) $ $Author: stefanw $ $Revision: 31090 $

/* solvelib::getElement(S)

   returns *one* element of S

   returns FAIL if no element could be found


*/


solvelib::getElement:=
proc(S)
  local i:DOM_INT, result;

begin
  if S::dom::getElement <> FAIL then
    return(S::dom::getElement(S))
  end_if;

  case type(S)
    of DOM_SET do
      if nops(S)=0 then
        FAIL
      else
        op(S,1)
      end_if;
      break
    of "_union" do
      i:=1;
      repeat
        result:=solvelib::getElement(op(S,i));
        i:=i+1
      until i>nops(S) or result<>FAIL end_repeat;
      return(result)
    // of "_intersect" do: don't know ...
    of "Union" do
      // there can be no general heuristic
      result:= solvelib::getElement(op(S, 3));
      if result = FAIL then
        FAIL
      else
        solvelib::getElement(op(S, 1) | op(S, 2) =  result)
      end_if;
      break
    otherwise
      FAIL
  end_case
end_proc:



