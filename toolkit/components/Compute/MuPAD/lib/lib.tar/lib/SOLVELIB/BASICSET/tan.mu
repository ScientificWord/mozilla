


solvelib::BasicSet::tan := solvelib::BasicSet::spfun(tan):
solvelib::BasicSet::tan(R):=R:
