

solvelib::BasicSet::arcsin := solvelib::BasicSet::spfun(arcsin):

solvelib::BasicSet::arcsin(R_):=
Dom::Interval([-PI/2, PI/2])
                union PI/2 - I * Dom::Interval(0, infinity)
                union -PI/2 + I* Dom::Interval(0, infinity):


