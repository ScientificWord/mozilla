/* $Date: 2006-01-26 09:40:49 +0100 (Thu, 26 Jan 2006) $ $Author: tonner $ $Revision: 36534 $ */

/* solvelib::Union

   

   Given a set1 whose elements contain a parameter x or several parameters from a list l
   and a set2, return the set of all objects that can
   be obtained by substituting x in some element of set1
   by some element of set2

*/

alias(BOUND = 20):

solvelib::Union:=
proc(set1, x, set2)
local i, j, l, S, imgsets,
  UnionOverVectorset: DOM_PROC;
save MAXEFFORT;
  
begin

  // local method UnionOverVectorset
  /*  set1 - any set
         l - list
      set2 - set of vectors, matching the length of l
  */

  UnionOverVectorset:=
  proc(set1, l: DOM_LIST, set2)
    local v, inds, indices;
  begin
    if set1 = {} then
      return({})
    end_if;

    // multiple equal entries in l -> probably name conflict
    assert(nops(l) = nops({op(l)}));


    // leave out components which set1 does not depend on
    inds:= freeIndets(set1);
    indices:= select([$1..nops(l)], i -> contains(inds, l[i]));
    if nops(indices) < nops(l) then
      l:= map(indices, i -> l[i]);
      set2:= solvelib::selectIndices(set2, indices)
    end_if;
    
    case type(set2)
      of DOM_SET do
        if map(set2, nops) <> {nops(l)} then
          error("second argument contains vector of wrong dimension")
        end_if;
        return(_union(eval(subs(set1, zip(l,i, _equal))) $i in set2))
      of solvelib::cartesianPower do
        if type(set1) = DOM_SET then
          return(_union(solvelib::VectorImageSet
                        (v, l, [set2::dom::base(set2) $nops(l)])
                        $v in set1
                        ))
        end_if;
    end_case;
    hold(solvelib::Union)(set1, l, set2)
  end_proc;

  /**********************************
  // main program of solvelib::Union
  **********************************/
  
  if domtype(x) = DOM_LIST then
    if nops(x) = 1 then
      x:= op(x, 1);
      set2:= solvelib::vectorSetToNumberSet(set2)
    else
      return(UnionOverVectorset(set1, x, set2))
    end_if
  end_if;

  if not contains(indets(set1), x) and solvelib::isEmpty(set2) = FALSE then
    return(set1)
  end_if;  


  if type(set2) = Dom::Multiset then
    if type(set1) = Dom::Multiset then
      return
      (
      Dom::Multiset::convert
      (
       [[eval(subs(op(set1, i)[1], x = op(set2, j)[1])),
         op(set1,i)[2]*op(set2, j)[2]] $i=1..nops(set1) $j=1..nops(set2)]
       )
       )
    end_if;
    set2:= coerce(set2, DOM_SET)
  end_if;
  
  if type(set2) = DOM_SET then
    if type(set1) = DOM_SET or nops(set2) <= BOUND then
      return(_union(eval(subs(set1, x = i)) $i in set2))
    else
      return(procname(args()))
    end_if
  end_if;
  
  if type(set2)=piecewise then
     // do case analysis w.r.t. parameter set
    /* if has(set2, x) then 
      error("Index set of Union must not depend on index variable")
    end_if; */
    return(piecewise::extmap(set2, z-> solvelib::Union(set1, x, z)))
  end_if;
  
  // try overloading
  if set1::dom::Union <> FAIL then
    return(set1::dom::Union(args()))
  end_if;
  
  case type(set1)
    of DOM_SET do
      l:=[];
      imgsets:=[];
      for i from 1 to nops(set1) do
        S:=solvelib::substituteBySet(op(set1,i), x, set2);
        if type(S) = Dom::ImageSet then
          imgsets := append(imgsets, S)
        else
          l:= append(l, S)
        end_if;
      end_for;
      l:= _union(op(l));
      case nops(imgsets)
        of 0 do
          return(l)
        of 1 do
          return(l union op(imgsets, 1))
        otherwise
          // avoid computing a union of ImageSets
          return(_union(l, op(imgsets)))
      end_case
    of "solve" do
    of RootOf do
      return(procname(args()))
    of "_union" do
    of "_intersect" do
      MAXEFFORT:= MAXEFFORT/nops(set1);
      return(map(set1, solvelib::Union, x, set2))
    of "_minus" do
      return(procname(args()))
    otherwise
      // error("unknown set type ".expr2text(type(set1)))
      return(procname(args()))
  end_case
 end_proc:

solvelib::Union:= funcenv(solvelib::Union):


solvelib::Union::type := "Union":
solvelib::Union::info := "solvelib::Union --- union of a system of sets":
solvelib::Union::print:= "solvelib::Union":

solvelib::Union::Content := proc(Out, data)
                     begin
                       Out::Capply(Out::CUnion,
                                   Out(extop(data, 1)),
                                   Out(extop(data, 2)),
                                   Out(extop(data, 3)));
                     end_proc:



unalias(BOUND):

