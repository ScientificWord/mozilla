// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ #

// NegInt -- expression to test for negative integers

Type::NegInt:=
    new(property::NRange,
	"NegInt",
	proc(t,x) 
	  name Type::NegInt;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if domtype(x) = DOM_INT then
		return(bool(x < 0))
	    end_if;
	    FAIL
	end_proc,
	FALSE, FALSE,
	["NegInt", property::Null]):
