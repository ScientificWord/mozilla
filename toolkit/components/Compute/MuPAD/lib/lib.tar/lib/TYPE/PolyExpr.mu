// $Date: 2004-07-21 15:49:19 +0200 (Wed, 21 Jul 2004) $  $Author: stefanw $  $Revision: 28161 $ 

/*++
PolyExpr -- returns type expression to test polynomial expressions

PolyExpr(x [,T])
PolyExpr(l [,T])

x - unknown
l - list of unknowns
T - coefficient type (default is 'Type::AnyType')

The type expression created returns TRUE if an expression is a polynomial
expression with unknown 'x' or unknows 'l' and coefficients of type 'T'.
++*/

Type::PolyExprTestProc:=
proc(t,x)
  local i;
begin
  if args(0) <> 2 then
    return(FALSE)
  end_if;
    
  case type(x)
    of "_plus" do
    of "_mult" do
      for i in op(x) do
        if not Type::PolyExprTestProc(t, i) then
          return(FALSE)
        end_if
      end_for;
      return(TRUE):
    of "_power" do
      i:= op(x,2);
      if domtype(i) = DOM_INT then
        if i > 0 then
          return(Type::PolyExprTestProc(t, op(x,1)))
        end_if
      end_if;
      break;
  end_case;

  case traperror((x:= poly(x, t[1])))
    of 1005 do
      // illegal argument[poly]
      return(FALSE)
    of 0 do
      break
    otherwise
      // do not catch other errors
      lasterror()
  end_case;
  if domtype(x) <> DOM_POLY then
    return(FALSE)
  end_if;
  x:= [ coeff(x) ];
  if has(x, t[1]) then
    return(FALSE)
  end_if;
  if nops(t) = 1 then
    TRUE
  else
    testtype(x, Type::ListOf(t[2]))
  end_if
end_proc:


Type::PolyExpr:=
proc(x,T)
  local p;
begin
  if testargs() then
    case args(0)
      of 1 do break;
      of 2 do
        if Type::isSeqType(T) then
          error("can't test for sequences")
        end_if;
        break;
      otherwise
        error("wrong no of args");
    end_case;
    if domtype(x) = DOM_LIST then
      if traperror((p:= poly(1,x))) <> 0 then
        error("illegal indeterminate")
      end_if
    elif traperror((p:= poly(1,[x]))) <> 0 then
      error("illegal indeterminate")
    end_if;
    if p = FAIL then
      error("illegal indeterminate")
    end_if;
  end_if;

  new(Type,
      "PolyExpr",
      Type::PolyExprTestProc,
      [(if domtype(x) = DOM_LIST then x else [x] end_if),
       (if args(0) = 2 then T else null() end_if)
       ],
      FALSE)
end_proc:

// end of file 
