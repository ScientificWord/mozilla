// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ #

//
// Property -- type to identify properties
//

Type::Property:=
    new(Type,
	"Property",
	proc(t, x)
	  name Type::Property;
	  option noDebug;
        begin
          if domtype(x) = DOM_EXPR then
            bool(_lazy_and(op(map([op(x)], testtype, Type::Property))) = TRUE)
          else
            contains(x::dom, "prop")
          end_if
	end_proc,
	FALSE, FALSE):

