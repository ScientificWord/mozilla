// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $

// Irrational -- expression to test for irrationals

Type::Irrational:=
    new(property::NRange,
	"Irrational",
	proc(t,x) 
	  name Type::Irrational;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    //if domtype(x) = DOM_FLOAT then
		//TRUE
	    //else
		FAIL
	    //end_if;
	end_proc,
	FALSE, FALSE,
	["Real", "Rational"]):
