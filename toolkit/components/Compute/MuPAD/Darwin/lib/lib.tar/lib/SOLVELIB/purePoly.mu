
/*

solvelib::purePolynomial(l, r, x)

solves a polynomial l + r for x where l = f(x)^n for some integer n,
and r is independent of x

*/


solvelib::purePolynomial:=
proc(l: "_power", r, x: DOM_IDENT, options: DOM_TABLE)
  local j: DOM_INT;
begin

  assert(type(op(l, 2)) = DOM_INT);
  assert(not has(r, x));

  if options["Real"] then
    if op(l, 2) mod 2 = 0 then
      return(piecewise([r <= 0,
                        solvelib::solve_eq(op(l, 1) - (-r)^(1/op(l, 2)), x,
                                           options)
                        union
                        solvelib::solve_eq(op(l, 1) + (-r)^(1/op(l, 2)), x,
                                           options) ],
                       [r > 0, {}]
                       ))
    else
      // odd power: solution is unique
      return(solvelib::solve_eq(op(l, 1) - surd(-r, op(l, 2)), x,
                                           options))
    end_if
  end_if;

  
  if testtype(r, Type::Real) = TRUE then
    // start with the real solution
    r:= -r;
    // now we have to solve x^op(l,2)=r
    // we have to use simplify here and in the following,
    // since we want e.g. that 8^(1/3) becomes 2
    if r>=0 then
      simplify(r^(1/op(l,2)))
    else
      assert(r<0);
      if op(l,2) mod 2 = 1 then
        - simplify(abs(r)^(1/op(l,2)))
      else
        // no particular solution is real
        assert(op(l,2) mod 2 = 0);
        exp(PI*I/op(l,2))*simplify(abs(r)^(1/(op(l,2))))
      end_if
    end_if;
    return(_union
           (solvelib::solve_eq(op(l,1)- % *
                               exp(2*PI*I*j/op(l,2)), x, options)
            $ j=0..op(l,2)-1))
  else
       
    // try to factor r
    r:= [op(factor(-r))];
    // now if r=u*f1^a1*...*fk^ak, our solution is obtained
    // by dividing each exponent a_i
    r[1]:= r[1]^(1/op(l, 2));
    for j from 3 to nops(r) step 2 do
      r[j]:= r[j]/op(l, 2)
    end_for;
    // obtain special solution
    r:= r[1] * _mult(r[2*j]^r[2*j+1] $j=1..nops(r) div 2);
    if testtype(r, Type::AlgebraicConstant) then
      return(_union
             (solvelib::solve_eq
              (op(l,1)- expr(rectform(
                                      r *
                                      exp(2*PI*I*j/op(l,2)))),
               x, options)
              $ j=0..op(l,2)-1))
    else
      return(_union
             (solvelib::solve_eq(op(l,1)- r *
                                 exp(2*PI*I*j/op(l,2)),
                                 x, options)
              $ j=0..op(l,2)-1))
    end_if
  end_if
end_proc:


