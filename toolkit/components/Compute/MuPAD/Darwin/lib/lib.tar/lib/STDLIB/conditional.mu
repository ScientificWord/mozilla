// conditional - the domain of conditionally defined objects

// an object of type conditional has as many operands as branches
// each operand is a list [condition, expression]

// the value of the conditional defined function is the first expression
// the condition of which is satisfied
// the expression may be any object
// ----------------------------------------------------------------------

conditional:= newDomain("conditional"):
conditional::create_dom:= hold(conditional):
conditional::info:= "conditional -- the domain of conditionally defined functions":
conditional::interface:={
                       hold(branch),
                       hold(condition),
                       hold(expression),
                       hold(numberOfBranches)
                         }:

//------------------------------------------------------------------------------------------
conditional::new:=
proc()
  option hold;
  local result, br, cond, i;
begin
  // convert each argument to branch
  result:=[]; // list of all branches created so far

  for i from 1 to args(0) do
    if traperror((br:= context(args(i)))) <> 0 then
      next
    end_if;
    if testargs() then
      if type(br) <> DOM_LIST then
        error("Illegal argument ".expr2text(args(i)))
      end_if;
    end_if;
        
    if traperror((cond:=bool(br[1]))) = 0 then
      if cond then
        return(br[2])
      end_if
    else // cannot evaluate to boolean
      result:= result.[br]
    end_if
  end_for;
  
  if nops(result) = 0 then
    return(undefined)
  else
    return(new(conditional, op(result)))
  end_if;
end_proc:


conditional::convert:=
proc(pw)
begin
  case domtype(pw)
    of conditional do
      return(pw)
    of piecewise do
      return(new(conditional, op(pw)))
  end_case;
  pw
end_proc:


//------------------------------------------------------------------------------------------
conditional::convert_to:=
proc(x:conditional, T:DOM_DOMAIN)
begin
  case T
    of conditional do
      return(x)
    of piecewise do
      return(piecewise(extop(x)))
    of DOM_LIST do
      return([extop(x)])
    otherwise
      FAIL
  end_case
end_proc:
      
//------------------------------------------------------------------------------------------
conditional::testtype:=
proc(x, T)
  local i;
begin
  if T=conditional then
    return(TRUE)
  end_if;

  // test whether every object is of the correct type
  for i from 1 to extnops(x) do
    if testtype(conditional::expression(x, i), T) = FALSE then
      return(FALSE)
    end_if
  end_for;
  TRUE
end_proc:

//------------------------------------------------------------------------------------------
conditional::branch:=
proc(pw:conditional, n:Type::PosInt)
begin
  if n > extnops(pw) then
    FAIL
  else
    extop(pw, n)
  end_if
end_proc:

//------------------------------------------------------------------------------------------
conditional::numberOfBranches:= extnops:

//------------------------------------------------------------------------------------------
conditional::condition:=
proc(pw:conditional, n:DOM_INT)
// returns the n-th condition 
begin
  (extop(pw,n))[1]
end_proc:

//------------------------------------------------------------------------------------------
conditional::expression:=
proc(pw:conditional, n:DOM_INT)
// returns the expression that is valid if the n-th condition holds 
begin
  (extop(pw,n))[2]
end_proc:

//------------------------------------------------------------------------------------------
conditional::setBranch:=
proc(pw: conditional, n: DOM_INT, br: DOM_LIST)
begin
  if n < 1 or n > extnops(pw) then
    error("Index out of range: no such branch")
  end_if;
  extsubsop(pw, n = br)
end_proc:

//------------------------------------------------------------------------------------------
conditional::evaluate:=
proc(pw)
  local i, result, cond;
begin
  result:=null();
  for i from 1 to extnops(pw) do
    if traperror((cond:= bool(eval(conditional::condition(pw,i))))) = 0 then
      if cond then
        return(eval(conditional::expression(pw, i)))
      end_if;
    else 
      result:=result, eval(extop(pw, i))
    end_if;
  end_for;
  if nops(result)=0 then
    return(undefined)
  else  
    new(conditional, result)
  end_if
end_proc:

//------------------------------------------------------------------------------------------
conditional::subs:=
proc(pw:conditional)
  local argv;
begin
  argv:= args(2..args(0));
  conditional::new
  (
   op(
      map([extop(pw)],
          proc(l)
            local newl;
          begin
            if traperror((newl:= subs(l, argv))) = 0 then
              newl
            else
              null()
            end_if
          end_proc
          )
      )
   )
end_proc:


conditional::unapply:=
proc(pw /* ,var1, ...,vark */)
  local listform, Args, i;
  
begin
  listform:= extop(pw);
  if args(0) = 1 then
    Args:= [ op(indets(pw)) ]
  else
    Args:= [ args(2..args(0)) ]
  end_if;

  if Args = [] then
    subsop(proc() option arrow; begin end, 4=hold(conditional)(listform),
           Unsimplified)
  else
    subsop(proc() option arrow; begin end, 1=op(Args),
           4=hold(conditional)
           (subs(listform, [ Args[i]=DOM_VAR(0,1+i) $ i=1..nops(Args) ],
                  Unsimplified)))
  end_if
end_proc:

// conditional::borders(pw, x, range)
// find the set of all "borders"" of a conditional object within
// the given range,
// that is, the set of those x such that in every neighbourhood of x,
// there are numbers falling into two different branches of x
// the conditions of pw must only depend on x!                                          

conditional::borders:=
proc(pw, x, range)
  local branchBorders: DOM_PROC;
begin
  if testargs() then
    if indets([extop(pw)]) minus {x} minus Type::ConstantIdents <> {} then
      error("too many symbols in conditional object")
    end_if
  end_if;
  
  branchBorders:=
  proc(cond): DOM_SET
    local i;
  begin
    case type(cond)
      of "_equal" do
        return(numeric::solve(cond, x = range))
      of "_leequal" do
      of "_less" do
        return(numeric::solve(subsop(cond, 0 = hold(_equal)), x = range))
      of "_and" do
      of "_or" do
        return(_union(branchBorders(op(cond, i)) $i=1..nops(cond)))
      of "_not" do
        return(branchBorders(op(cond, 1)))
    end_case;
    // default:
    {}
  end_proc;
  
  _union(branchBorders(op(extop(pw, i),1)) $i=1..extnops(pw))
end_proc:




//------------------------------------------------------------------------------------------
conditional::PWif := funcenv(hold(slot)(conditional, "PWif"),
                           builtin(1100, 100, " if ", "conditional::PWif")):
//------------------------------------------------------------------------------------------
conditional::print := 
proc(pw)
  local i, nargs;
begin
  if PRETTYPRINT=FALSE then
    hold(conditional)([conditional::condition(pw,i),
                     conditional::expression(pw, i)] $i=1..extnops(pw))
  else
    nargs := extnops(pw);
    hold(conditional)(subsop(conditional::PWif
                           (hold(dummy),
                            conditional::condition(pw, i)),
                           1 = conditional::expression(pw, i),
                           Unsimplified)
                    $i = 1..nargs)
  end_if
end_proc:

//------------------------------------------------------------------------------------------
conditional::TeX :=
proc(pw)
  local i;
begin
  "\\left\\{\n\\begin{array}{ccl}\n".
  _concat((generate::TeX(conditional::expression(pw,i))." & \\text{if} & ".
          generate::TeX(conditional::condition(pw, i))."\\\\\n") $i=1..extnops(pw)).
  "\\end{array}\n\\right."
end_proc:

//------------------------------------------------------------------------------------------
// Typesetting output of conditional
conditional::Content := 
proc(Out, pw)
  local i;
begin
  Out::Cconditional(
              Out::Cpiece(Out(conditional::expression(pw, i)), Out(conditional::condition(pw, i)))
                         $ i = 1..extnops(pw)
                 )
end_proc:
