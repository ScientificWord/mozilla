// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $  $Revision: 8304 $ 

sign := slot(sign,"diff",proc(ausdruck,ableit)
begin
	2 * dirac(op(ausdruck,1)) * diff(op(ausdruck,1),ableit)
end_proc):

// end of file 
