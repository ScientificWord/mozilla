intlib::oscillate := proc(f,a,b,nofun,maxno)
    local N,h,xinit,increasing,osc,y,y1,x;
begin
    for N from nofun to 10*nofun step nofun do
        h := (b-a)/(N+1);
        xinit := a+h;
        if f(xinit) < f(xinit+h) and f(xinit+h) < f(xinit+2*h) then
            increasing := TRUE; break
        elif f(xinit+h) < f(xinit) and f(xinit+2*h) < f(xinit+h) then
            increasing := FALSE; break
        end_if
    end_for;
    if 10*nofun < N then 
      return(FAIL)
    end_if;
    osc := 0;
    while xinit < b and osc <= maxno do
        if increasing then
            y := f(xinit);
            y1 := y; x := xinit+h;
            while x <= b and y1 <= y do
                y1 := y; y := f(x); x := x+h;
            end_while;
            xinit := x;
            osc := osc+1;
            increasing := FALSE
        else
            y := f(xinit);
            y1 := y; x := xinit+h;
            while x <= b and y <= y1 do
                y1 := y; y := f(x); x := x+h;
            end_while;
            xinit := x;
            osc := osc+1;
            increasing := TRUE
        end_if
    end_while;
    osc
end_proc:
