
// arctan::simplify

/*
    does the following to arctan(z):

    if the sign of Re(z) is known, rewrite each
    arctan(z) in terms of arctan(1/z) provided that 1/z is "simpler" than z


*/


arctan::simplify:=
proc(a: "arctan")
  local inverseIsSimpler: DOM_PROC,
  z, mtch;

begin

  inverseIsSimpler:=
  proc(x)
    local y;
  begin

    case domtype(x)
      of DOM_INT do
        return(FALSE)
      of DOM_RAT do
        return(bool(abs(x) < 1))
    end_case;

    y:= 1/x;
    
    case specfunc::sign(length(x) - length(y))
      of 1 do
        return(TRUE)
      of -1 do 
        return(FALSE)
    end_case;

    assert(length(x) = length(y));

    // the final tie-break
    sysorder(y, x)
    
  end_proc;
    
  
  z:= op(a, 1);

  // try to recognize tan

  if (mtch:= match(z, sin(`#X`)/cos(`#X`))) <> FAIL then
    // arctan(sin(X)/cos(X)) = X + PI* some "unwinding number"
    return(arctan(tan(op(mtch, [1, 2]))))
  end_if;

  
  case sign(Re(z))
    of 1 do
    of 0 do
      if inverseIsSimpler(z) then
        return(-arctan(1/z) + 1/2*PI)
      else
        break
      end_if;
    of -1 do
      if inverseIsSimpler(1/z, z) then
         return(-arctan(1/z) - 1/2*PI)
      else
        break
      end_if
  end_case;
  
  a

end_proc: