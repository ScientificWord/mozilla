// $Date: 2003-05-21 17:08:08 +0200 (Wed, 21 May 2003) $ $Author: stefanw $ $Revision: 23246 $ 

// kg, 10/12/93 

/*++
content -- content of an polynomial or polynomial expression

content(poly)
content(expr, [ind,...])

poly - polynomial
expr - polynomial expression
ind  - indets (optional)
++*/

content:=
proc(p)
begin
  if testargs() then
    // test for correct number of args 
    if args(0) = 0 then
      error("wrong no of args")
    end_if;
    if domtype(p) = DOM_POLY then
      if args(0) > 1 then
        error("wrong no of args")
      end_if
    else
      if args(0) > 2 then
        error("wrong no of args")
      end_if;
      if args(0) = 2 then
        if domtype(args(2)) <> DOM_LIST then
          error("invalid indeterminate list")
        end_if
      end_if
    end_if
  end_if;

    // allow for overloading 
  if p::dom::content <> FAIL then
    return(p::dom::content(args()))
  end_if;

    // convert expression to poly 
  if domtype(p) <> DOM_POLY then
    if args(0) = 2 then
      p:= poly(p, args(2), Expr)
    else
      case domtype(p)
        of DOM_INT do
          return(abs(p));
        of DOM_RAT do
          return(abs(p));
      end_case;
      p:= poly(p, Expr)
    end_if;
    if p = FAIL then
      return(FAIL)
    end_if;
  end_if;

  if iszero(p) then
    return(tcoeff(p))
  end_if;
  
  if domtype(op(p,3)) = DOM_DOMAIN then
    (op(p,3))::gcd(coeff(p))
  elif op(p,3) = hold(Expr) then
    case gcdlib::coeff_type([p])
      of DOM_INT do
        igcd(coeff(p)); break;
      of DOM_RAT do
        gcd(coeff(p)); break;
      of DOM_FLOAT do 1; break;
      of DOM_COMPLEX do 1; break;
      of DOM_EXPR do
        if contains(map([coeff(p)], poly), FAIL) <> 0 then
          1
        else
          gcd(coeff(p))
        end_if;
    end_case;
  elif isprime(op(p,[3,1])) then
    1
  else
    error("not a prime modulus")
  end_if
end_proc:

// end of file 
