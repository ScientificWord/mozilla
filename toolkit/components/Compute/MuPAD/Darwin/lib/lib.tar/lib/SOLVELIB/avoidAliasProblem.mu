
/*
solvelib::avoidAliasProblem(S, vars)

replace all bound identifiers in S by such that do not belong to vars

*/


solvelib::avoidAliasProblem:=
proc(S, vars: DOM_SET)
begin
  if vars = {} then
    return(S)
  end_if;
  
  if S::dom::avoidAliasProblem <> FAIL then
    return(S::dom::avoidAliasProblem(args()))
  end_if;

  if contains({DOM_EXPR, DOM_LIST, DOM_SET}, domtype(S)) then
    return(map(S, solvelib::avoidAliasProblem, args(2..args(0))))
  end_if;
      
  
// default
  S
end_proc: