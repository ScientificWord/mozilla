anames :=
  proc(DOM = hold(All), userDefined = null()) : DOM_SET 
    local res;
  begin
    if testargs() then
      if args(0) > 2 /*or args(0) = 0*/ then
        error("wrong number of arguments")
      end_if;
      if DOM = hold(User) then
        DOM := hold(All);
        userDefined := hold(User)
      end_if;
      if (DOM_DOMAIN <> domtype(DOM) and DOM <> hold(Properties) and 
         DOM <> hold(Protected) and  DOM <> hold(All)) or
         (args(0) = 2 and userDefined <> hold(User)) then
        error("illegal argument");
      end_if;
    end_if;
    if domtype(DOM) = DOM_DOMAIN then
       res := select(stdlib::anames(3), 
                     x -> domtype(context(hold(val)(x))) = DOM);
    else
       if DOM = hold(Properties) then 
         res := stdlib::anames(4)	
       elif DOM = hold(Protected) then
         /* this set contains all identifiers protected via protect;
            the - undocumented - function protected does not alter this set! */
         res := stdlib::PROTECTED;
       elif DOM = hold(All) then 
         res := stdlib::anames(3)
       elif DOM = hold(User) then 
         res := stdlib::anames(3);
         userDefined := hold(User)
       end_if;
    end_if;
    
    if userDefined = hold(User) then
      res := res minus stdlib::SYSPROTECTED 
                 minus stdlib::ENVIRONMENT_VARIABLES 
                 minus stdlib::SYSTEM_CONSTANTS;
    end_if;
    res
  end_proc:
