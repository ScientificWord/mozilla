// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ 

/*++
IV -- property::IV as Type::IV

IV
++*/

Type::Interval:=
proc()
  option noDebug;
  local iv;
begin
  if type(args()) = "id" then
    iv:= op(args())
  else
    iv:= property::IV(args());
    if iv = property::Null then
      return(property::Null)
      //iv:= {}, Type::Real
    else
      iv:= extop(iv, 5)
    end_if;
    if op(iv, 1) = {} then
      //return({})
    end_if
  end_if;

  new(property::IV,
      "Interval",
      proc(t,x)
	name Type::Interval;
      begin
	if args(0) <> 2 then return(FALSE) end_if;
	case domtype(x)
	  of DOM_INT do
	  of DOM_RAT do
	  of DOM_FLOAT do
	    property::IV::testtype_in(x, op(t));
	    break
	  of DOM_EXPR do
	    if type(x) = "_range" then
	      property::IV::testtype_in(op(x, 1), op(t))
	      and property::IV::testtype_in(op(x, 2), op(t))
	    else
	      FALSE
	    end_if;
	    break
	  otherwise
	    FALSE
	end_case
      end_proc,
      iv, FALSE,
      iv
     )
end_proc:
