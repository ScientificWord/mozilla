// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*++

	unexport - the converse of export

	unexport(dm [,f1,...])

	dm      -   library domain
	f1, ... (optional) functions of dm
++*/

unexport:= proc(dm) 
   option hold, noDebug;
   local ver, unex;
begin 
   dm := context(dm);
   ver:=slot(dm,"_exported");
   if domtype(ver) = DOM_FAIL then 
	return(null())
   elif args(0) = 1 then
	map(ver,sysdelete); 
	sysdelete(slot(dm,"_exported"));
   else
	unex:= {args(2..args(0))};
	ver:= ver minus unex;
	map(unex,sysdelete);
	if ver={} then
            sysdelete(slot(dm,"_exported"));
	else
	    sysassign(slot(dm,"_exported"), ver);
	end_if;
   end_if;
   
   null()
end_proc:

