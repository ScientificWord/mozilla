// $Id: simplifyCondition.mu 39569 2006-06-08 15:38:40Z stefanw $

/* ignoreSingularities gibt an, ob Singularit�ten beim "�quivalenten" Umformen ignoriert werden sollen
 * z.B.:
 * a/b = 0    => a=0
 * 1/a = 1/b => a=b
 * etc
 */
simplify::ignoreSingularities := TRUE:
simplify::ignoreImplicitR_Property := FALSE:

simplify::simplifyCondition := proc( cond ) /* options: UseSolver=TRUE */
  local i, s, v,
            necessary,
            _simplifyConditionForIdent, _simplifyCondition,
            _simplifyConditionSet, _simplifyConditionMapToSet,
            __simplifyConditionMapToSet,
            _simplifyExpr, /* proc */
            typereal, /*proc */
            result, /* Ergebnis */
            inds, /* idents of cond */
            typecond, /* type(cond) */
            realvars, /* set of all vars which are of Type::Real */
            unrealvars, /* set of all vars which are NOT of Type::Real */
            simplifyChainedConditions, /* proc */
            simplifySyntactically,
          OPTIONS, /* optionen */
          decide; /* proc */

begin
  typecond := type(cond);
  /* schneller Test auf TRUE, FALSE */
  if cond=TRUE or cond=FALSE or cond=Otherwise then return( cond ); end_if;

  /* simplifySyntactically::decide
    * tries to make some fast decisions whether cond is TRUE or FALSE
    * decide can be seen as the small brother of is()
    */
  decide := proc( cond )
    local inds, sidea, sideb, v1, v2, R, lhs, rhs, i, p, v, j;
  begin
    inds := freeIndets( cond );
    case type( cond )
      of "_leequal" do
      of "_less" do
          j := _if( indets( op(cond,1) ) minus Type::ConstantIdents<>{}, 1, 0 ) + _if( indets( op(cond,2) ) minus Type::ConstantIdents<>{}, 2, 0 );
          if j=0 then
            if op(cond,1)=0 and type(op(cond,2))=unit then return(TRUE); end_if;
            if op(cond,2)=0 and type(op(cond,1))=unit then return(FALSE); end_if;
            return( property::constRel(cond) );
          end_if;
          if j=1 or j=2 then
            sidea := op( cond, j );
            sideb := op( cond, 3-j );
            case type(sidea)
              of "abs" do
                if sideb=0 then
                  if type(cond)="_leequal" and j=2 then return(TRUE); end_if;
                  if type(cond)="_less" and j=1 then return(FALSE); end_if;
                end_if;
                if j=1 then
                  if type(cond)="_leequal" then
                    v := [-sideb], [sideb];
                  else
                    v := -sideb, sideb;
                  end_if;
                  return( decide( op(sidea) in Dom::Interval( v ) ) );
                end_if;
                break;
              of "ln" do /* ln(x)<0 <= x<1, ln(x)>0 <= x>1 */
                if sideb=0 then
                  v := decide( subsop( cond, j=op(sidea), 3-j=1 ) );
                  if v=TRUE then return(TRUE); end_if;
                  if v=FALSE and typereal(op(sidea)) then return(FALSE); end_if;
                end_if;
                break;
              of "sin" do
              of "cos" do
                if typereal( op(sidea) )<>TRUE then return( UNKNOWN ); end_if;
                if j=1 then
                  if (property::constRel( op(cond,0)(1,sideb)) )=TRUE then return( TRUE ); end_if;
                  if (property::constRel( op(cond,0)(sideb,-1)) )=TRUE then return( FALSE ); end_if;
                else
                  if (property::constRel( op(cond,0)(1,sideb)) )=TRUE then return( FALSE ); end_if;
                  if (property::constRel( op(cond,0)(sideb,-1) ))=TRUE then return( TRUE ); end_if;
                end_if;
                break;

              /* fast decision of X <= constant depending on properties */
              of DOM_IDENT do
                if ( v1:=necessary[sidea] )<>C_ then
                  case type(v1)
                    of "_intersect" do
                      if ( i := contains( map( ( v2 := [op(v1)] ), type ), Dom::Interval ) )=0 then break; end_if;
                      v1 := v1[i];
                    of Dom::Interval do
                      if j=1 then /* X </<= constant. */
                        v2 := [ Dom::Interval::rightB( v1 ), Dom::Interval::leftB( v1 ) ];
                      else /* const </<= X */
                        v2 := [ Dom::Interval::leftB( v1 ), Dom::Interval::rightB( v1 ) ];
                      end_if;
                      /* 1. check if the interval X is in the interval spanned by cons.
                        * we have sidea <= sideb  =>  [a,b] <= const. if b <= const this is true
                        */
                      if type(v2[1])=DOM_LIST then
                        R := subsop( cond, j=op(v2,[1,1]) )
                      else
                        /* if the right side is open, it can be less or equal const. */
                        R := _leequal( _if(j=1, (op(v2,1),sideb), (sideb,op(v2,1)) ) );
                      end_if;
                      if indets( R ) minus Type::ConstantIdents={} then
                        if property::constRel(R)=TRUE then return(TRUE); end_if;
                      end_if;
                      /* 2. check if the interval X is outside the interval spanned by cons
                        * we have sidea <= sideb => [a,b] <= const. if a>const this is false
                        */
                      if type(v2[2])=DOM_LIST then
                        if type(cond)="_less" then
                          R := _leequal(_if(j=2, (op(v2,[2,1]),sideb), (sideb,op(v2,[2,1])) ) );
                        else
                          R := _less(_if(j=2, (op(v2,[2,1]),sideb), (sideb,op(v2,[2,1])) ) );
                        end_if;
                      else
                        /* if the left side is open, it can be greater or rqual const. */
                        R := _leequal(_if(j=2, (op(v2,2),sideb), (sideb,op(v2,2)) ) );
                      end_if;
                      if indets( R ) minus Type::ConstantIdents={} then
                        if property::constRel(R)=TRUE then return(FALSE); end_if;
                      end_if;
                      break;
                  end_case;
                end_if;
                break;
              otherwise
            end_case;
          end_if;
          /* check if sidea-sideb is a univariant polynom */
          if nops(inds)<>1 then break; end_if;
          inds := op(inds);
          lhs := op(cond,1); rhs := op(cond,2);

          /* check if we have a domain */
          v := necessary[ inds ];
          if type(v)="_intersect" then
            if (i := contains( map( ( v := [op(v)] ), type ), Dom::Interval ) )<>0 then
              v := v[i];
            else
              v := FAIL;
            end_if;
          elif type(v)<>Dom::Interval then
            if typereal( inds )=TRUE then
              v:=Dom::Interval(-infinity,infinity);
            else
              v := FAIL;
            end_if;
          end_if;
          if v=FAIL then break; end_if;
          v := Dom::Interval::left( v )..Dom::Interval::right( v );
          if freeIndets(v)<>{} then break; end_if;
          if typereal(lhs)<>TRUE or typereal( rhs )<>TRUE then break; end_if; /* everything real? */
          lhs := lhs-rhs;
          if ( p := poly( lhs, [inds] ) )=FAIL then break; end_if; /* is this a polynom? */
          if freeIndets( coeff(p,0) )<>{} then break; end_if; /* we have to check the constant coefficient to be real constant */
          if degree( p )<1 then break; end_if;
          if numeric::hasroot(lhs, inds, op(v)) <> FALSE then break; end_if; /* do we have roots? */
          if op(v,1)<>-infinity then v := op(v,1)
          elif op(v,2)<>infinity then v:=op(v,2)
          else v:=0; end_if;
          return( property::constRel( subs(lhs, inds=v)<0 ) ); /* if we have no roots, then check the sign */
          break;
      of "_equal" do
        /* check constant equation */
        if inds={} then return( property::constRel(cond) ); end_if;
        [lhs, rhs] := [op(cond)];
        /* if one side is real but not the other than this is FALSE */
        if ( typereal(lhs) <=> typereal(rhs) )=FALSE then return(FALSE); end_if;
        /* check the properties */
        if contains(inds,lhs) and necessary[lhs]<>C_ and not has(rhs,lhs) then
          if decide( rhs in necessary[lhs] )=FALSE then return(FALSE); end_if;
        end_if;
        /* check some special cases for X = 0 */
        if lhs=0 then [ rhs, lhs ] := [ lhs, rhs ]; end_if;
        if rhs=0 then
          case type(lhs)
            of "exp" do return(FALSE);
          end_case;
        end_if;
        break;
      of "_unequal" do
        return( not decide( op(cond,1)=op(cond,2) ) );
        if inds={} then return( property::constRel(cond) ); end_if;
        [lhs, rhs] := [op(cond)];
        if contains(inds,lhs) and necessary[lhs]<>C_ and not has(rhs,lhs) then
          if decide( rhs in necessary[lhs] )=FALSE then return(TRUE); end_if;
        end_if;
        if lhs=0 then [ rhs, lhs ] := [ lhs, rhs ]; end_if;
        if rhs=0 then
          case type(lhs)
            of "exp" do return(TRUE);
          end_case;
        end_if;
        break;
      of "_in" do
        sidea := op(cond,1);
        sideb := op(cond,2);
        if sideb=C_ then return(TRUE); end_if;
        if sideb=R_ then return( typereal(sidea) ); end_if;
        if freeIndets(sidea)={}  then
          case type(sideb) of
            DOM_SET do
              return( _or( op(map( (sideb), X->decide( X=sidea ) )) ) );
            of "_union" do
              return( _lazy_or( map( op(sideb), X->decide(sidea in X) ) ) );
            of "_intersect" do
              return( _lazy_and( map( op(sideb), X->decide(sidea in X) ) ) );
            of "_minus" do
              return( decide( sidea in op(sideb,1) ) and not decide( sidea in op(sideb,2) ) );
            otherwise
              if (R:=(sideb)::dom::simpexIn)<>FAIL then
                cond := (R(op(cond), op(cond, 2)));
                if cond=TRUE or cond=FALSE then return(cond); end_if;
              end_if;
          end_case;
        else
          case type(sidea)
            of DOM_IDENT do
              v := necessary[ sidea ];
              if v<>C_ then
                if _subset( v, sideb )=TRUE then return(TRUE); end_if;
                v := _intersect( v, sideb);
                if v={} then return(FALSE); end_if;
              end_if;
              if _subset( {sidea}, sideb )=TRUE then return(TRUE); end_if;
              case type(sideb)
                of "_minus" do
                  v := decide( sidea in op(sideb,1) );
                  if v=FALSE then return(FALSE); end_if;
                  v := decide( sidea in op(sideb,2) );
                  if v=TRUE then return(FALSE); end_if;
                  break;
                of Dom::Interval do
                  if sidea=Dom::Interval::left(sideb) then return( _lazy_and( not Dom::Interval::isleftopen(sideb), decide( sidea<sideb )  ) ); end_if;
                  if sidea=Dom::Interval::right(sideb) then return( _lazy_and( not Dom::Interval::isrightopen(sideb), decide( sidea<sideb) ) ); end_if;
                  break;
              end_case;
              break;
            of "sin" do
            of "cos" do
              if typereal(op(sidea))=TRUE then
                v := _subset( Dom::Interval( [-1], [1] ), sideb );
                if type(v)=DOM_BOOL then return(v); end_if;
              end_if;
          end_case;
        end_if;
    end_case;
    UNKNOWN;
  end_proc: /* decide */

  /* simplifyCondition::typereal( xpr )
   * Checks whether xpr is real or not
   * Returns TRUE, FALSE or UNKNOWN
    */
  typereal := proc( xpr )
    local i, v, haveFalse;
  begin
    if indets(xpr) minus Type::ConstantIdents={} then
      v := property::isConstReal( xpr );
      if v<>UNKNOWN then return( v ); end_if;
    end_if;
    case type(xpr)
      of Dom::Interval do
        return(TRUE);
      of "ln" do
        return( decide( op(xpr)>=0 ) );
      of "arg" do
      of "Re" do
      of "Im" do
      of "abs" do
        return( TRUE );
      of "sign" do
      of "sin" do
      of "cos" do
      of "sinh" do
      of "cosh" do
        if typereal(op(xpr))=TRUE then return(TRUE); end_if;
        break;
      of "_mult" do
        return( _and( map( op(xpr), typereal ) ) or UNKNOWN );
      of "_plus" do
        /* check cases:
         * 1) all summands real => sum is real
         * 2) any summand cant be decided => UNKNOWN
         * 3) only one summand is imaginary => sum is imaginary
         */
        haveFalse := FALSE;
        for i in [op(xpr)] do
          case typereal(i)
            of TRUE do break;
            of UNKNOWN do return( UNKNOWN );
            of FALSE do if haveFalse then return( UNKNOWN ); end_if; haveFalse := TRUE;
          end_case;
        end_for;
        return( not haveFalse );
      of "_power" do
        if type( op(xpr,2) )=DOM_INT then
          return( typereal(op(xpr,1)) or UNKNOWN );
        end_if;
        if op(xpr,2)=1/2 then
          return( decide( op(xpr,1)>=0 ) );
        end_if;
        break;
      of DOM_IDENT do
        if contains( {PI}, xpr ) then return(TRUE); end_if;
        if contains( realvars, xpr ) then return(TRUE); end_if;
        if contains( unrealvars, xpr ) then return(FALSE); end_if;
        break;
      of DOM_INT do
      of DOM_RAT do
        return(TRUE);
      of DOM_LIST do
        return( _and( map( op(xpr), typereal ) ) );
      of DOM_COMPLEX do
        return( FALSE );
    end_case:
    UNKNOWN;
  end_proc:  /* typereal */

  /* schneller Test auf konstante Relationen */
  inds := indets( cond ) minus Type::ConstantIdents;
  if inds={} and contains( {"_leequal", "_less", "_equal", "_unequal"}, typecond ) then
    /* this is necessary to have true for infinity = infinity */
    if op(cond,1)=op(cond,2) then
      case type(cond)
        of "_equal" do
          return(TRUE);
        of "_leequal" do
          if op(cond,1)=infinity or typereal( op(cond,1) )=TRUE and typereal( op(cond,2) )=TRUE then
            return(TRUE);
          end_if;
          break;
        of "_unequal" do
        of "_less" do
          return(FALSE);
      end_case;
    end_if;
    v := property::constRel( cond );
    if v<>UNKNOWN then return( v ); end_if;
  end_if;


/* simplifyCondition::simplifySyntactically (cond)
 * simplifies on syntactical basis
 * for example: a<=b and b<=a => a=b
 * also uses knowledge of realvars
 */
  simplifySyntactically := proc( cond )
    local lhs, rhs, res, R, s, simplifySyntactically_not, simplifySyntactically_and, set, i, j, v, r,
        inds, /* freeIndets */
        ready, /* abbruchbedingung f�r schleifen */
        simplifySyntactically_or, /* simplifies _or-expressions */
        b, ex, /* basis, exponent */
        ouv, orv,
        subsid; /* proc */

  begin
      /* simplifySyntactically::subsid( f, ident=new )
       * returns a copy a of f in which all operands matching ident are replaced by new
       * checks the following: in Dom::ImageSet only free identifiers are replaced
       */
      subsid := proc( f, s : "_equal" )
        local ident, new, rec, res;
      begin
        ident := op(s,1); new := op(s,2);
        rec := f -> misc::maprec( f, proc(X)
          begin
            case type(X)
              of Dom::ImageSet do:
                return( TRUE );
              of DOM_IDENT do:
                return( bool(X=ident) );
            end_case:
            FALSE;
          end_proc = proc(X)
          begin
            if type(X)=Dom::ImageSet then
              if contains( Dom::ImageSet::freeIndets(X), ident ) then
                return( eval(extsubsop( X, 1=rec(Dom::ImageSet::expr(X)) ) ) );
              end_if;
            end_if;
            _if( X=ident, new, X);
          end_proc, PostMap );
          /* error implies substitution is illegal */
          if traperror( ( res := rec(f); ) )<>0 then return( FALSE ); end_if;
          res;
      end_proc: /* simplifySyntactically::subsid */

    simplifySyntactically_or := proc ( cond:"_or" )
      local operands, ops, i, j, o1, o2,
          vartypes, /* list of all vars which are implicit declard real/ not real */
          orv, ourv, /* realvars, unrealvars */
          implicitAssumptions, /* proc */
        sstr;
    begin
        cond := simplify::simplifyLogic( cond );
        if type(cond)<>"_or" then return( simplifySyntactically(cond) ); end_if;

        /* save variables */
        orv := realvars; ourv := unrealvars;

        cond := [op(cond)];
        sstr := [ "_in", "_equal", "_unequal", "_less", "_leequal", "_not", "_and" ];
        cond := sort( cond, (a,b)->freeIndets(a)<>{} and ( freeIndets(a)={} or bool(contains( sstr, a )-contains( sstr, b )>0) ) );
        operands := [];
        ops := {};

        /* get the list of all implicit real/ not real declard identifiers */
        implicitAssumptions := proc(X=null() )
        begin
          case type(X)
            of "_not" do
              X := op(X,1);
              case type(X)
                of "_in" do
                  if  type(op(X,1))=DOM_IDENT then
                    case type(op(X,2))
                      of solvelib::BasicSet do
                        if op(X,2)<>C_ then
                          return( [ {op(X,1)}, {} ] );
                        end_if;
                      of Dom::Interval do
                        return( [ {op(X,1)}, {} ] );
                    end_case;
                  end_if;
                  break;
              of "_less" do
              of "_leequal" do
                if type(op(X,1))=DOM_IDENT then return( [ {op(X,1)}, {} ] ); end_if;
                if type(op(X,2))=DOM_IDENT then return( [ {op(X,2)}, {} ] ); end_if;
                break;
              end_case;
            of "_in" do
              if type(op(X,1))=DOM_IDENT and op(X,1)=R_ then
                return( [ {}, {op(X,1)} ] );
              end_if;
              break;
            end_case;
            return( [ {}, {} ] );
          end_proc;
        vartypes := map( cond, implicitAssumptions );
        /* if identifiers can be real AND not real this is TRUE */
        if _union( op(map( vartypes, op, 1 )) ) intersect _union( op(map( vartypes, op, 2 )) ) <> {} then
          return(TRUE);
        end_if;

        i := 1;
        while i<=nops(cond) do
          /* update realvars/ unrealvars */
          if i<=nops(vartypes) then
            realvars := _union( orv, op(map( subsop(vartypes,i=[{},{}]), op, 1 )) );
            unrealvars := _union( ourv, op(map( subsop(vartypes,i=[{},{}]), op, 2 )) );
          else
            realvars := _union( orv, op(map( vartypes,op, 1 )) );
            unrealvars := _union( ourv, op(map( vartypes, op, 2 )) );
          end_if;
          v := simplifySyntactically( cond[i] );

          case type(v)
            of DOM_BOOL do
              if v=TRUE then return(TRUE); end_if;
              if v=FALSE then v:=null(); end_if;
              break;
            of "or" do
              operands := operands.[op(v)];
              v:=null;
              break;
          end_case;

          /* d) check for paris of relations with
            * (A op B) and (A op B)
            * or
            * (A op B) and (B op A)
            */
          case type(v)
            of "_less" do
            of "_leequal" do
            of "_equal" do
            of "_unequal" do
              if _subset( {op(v)}, ops )=TRUE then
                j := 1;
                while j<=nops(operands) and v<>null() do
                    if contains( {"_less", "_leequal", "_equal", "_unequal"}, type( operands[j] ) ) then
                      o2 := operands[j];
                      /* case 1: ( A op B ) or ( B op A ) */
                      if op(v,1)=op(o2,2) and op(v,2)=op(o2,1) then
                        case {type(v),type(o2)}
                          of { "_less" } do
                            delete operands[j];
                            cond := cond.[ op(v,1)<>op(v,2) and op(v,1) in R_ and op(v,2) in R_ ];
                            v := null();
                            break;
                          of { "_less", "_leequal" } do
                            cond := cond.[ op(v,1) in R_ and op(v,2) in R_ ];
                            delete operands[j];
                            v := null();
                            break;
                          of { "_unequal", "_equal" } do
                            return(TRUE);
                          of { "_equal" } do
                          of {"_unequal" } do
                            v := null();
                            break;
                        end_case;
                      end_if;
                      /* case 2: ( A op B ) or ( A op B ) */
                      if op(v,1)=op(o2,1) and op(v,2)=op(o2,2) then
                        case {type(v),type(o2)}
                          of { "_unequal", "_equal" } do
                            return(TRUE);
                        end_case;
                      end_if;
                    end_if;
                    j := j+1;
                end_while;
              else
                ops := ops union {op(v)};
              end_if;
              break;
          end_case;

          if i<=nops(vartypes) then vartypes[i] :=implicitAssumptions(v); end_if;
          if v<>null() then
            operands := operands.[v];
          end_if;
          i := i+1;
        end_while;

        cond := _or( op(operands) );

        if type(cond)="_or" then
          return( /*Simplify::consensus_or*/simplify::simplifyLogic(cond) );
        else
          return( cond );
        end_if;
    end_proc: /* simplifySyntactically::simplifySyntacically_or */

    simplifySyntactically_and := proc( cond : "_and" )
        local lhs, rhs, i, j, k, ops, o1, o2, i1, i2, v, res, s,
          t1, t2, /* types of operands */
          sstr, /* sort order */
          vartypes, /* list of all vars which are implicit declard real/ not real */
          orv, ourv, /* realvars, unrealvars */
          operands; /* list of all operands */
    begin
          cond := simplify::simplifyLogic( cond );
          if type(cond)<>"_and" then return( simplifySyntactically(cond) ); end_if;

          /* save variables */
          orv := realvars; ourv := unrealvars;

          /* sort conditions
           * first all constant expressions, then _ins, then relations, at last _nots ...
           */
          cond := [op(cond)];
          sstr := [ "_in", "_equal", "_unequal", "_less", "_leequal", "_not", "_or" ];
          cond := sort( cond, (a,b)->indets(a) minus Type::ConstantIdents<>{} and ( indets(a) minus Type::ConstantIdents={} or bool(contains( sstr, a )-contains( sstr, b )>0) ) );
          operands := [];

          /* get the list of all implicit real, not real declard identifiers */
          vartypes := map( cond, proc(X)
            begin
                case type(X)
                of "_not" do
                  if type(op(X,1))="_in" and type(op(X,[1,1]))=DOM_IDENT and op(X,[1,2])=R_ then
                    return( [ {}, {op(X,[1,1])} ] );
                  end_if;
                  break;
                of "_in" do
                  if type(op(X,1))=DOM_IDENT then
                    case type(op(X,2))
                      of solvelib::BasicSet do
                        if op(X,2)=C_ then break; end_if
                      of Dom::Interval do
                        return( [ {op(X,1)}, {} ] );
                    end_case;
                  end_if;
                  break;
                of "_less" do
                of "_leequal" do
                  if type(op(X,1))=DOM_IDENT then return( [ {op(X,1)}, {} ] ); end_if;
                  if type(op(X,2))=DOM_IDENT then return( [ {op(X,2)}, {} ] ); end_if;
                  break;
                end_case;
                return( [ {}, {} ] );
              end_proc );

            /* be sure no identifiers are real AND not real */
            if _union( op(map( vartypes, op, 1 )) ) intersect _union( op(map( vartypes, op, 2 )) ) <> {} then
              return(FALSE);
            end_if;

          ops := {};
          /* simplify _and-conditions syntactically. this means:
           * a) map simplifySyntactically to all subexpression
           * b) if we have X=(const.) then replace X in all other subexpressions
           * c) check for pares of relations
           */
          i := 1;
          while i<=nops(cond) do
            /* update realvars/ unrealvars */
            if i<=nops(vartypes) then
              realvars := _union( orv, op(map( subsop(vartypes,i=[{},{}]), op, 1 )) );
              unrealvars := _union( ourv, op(map( subsop(vartypes,i=[{},{}]), op, 2 )) );
            else
              realvars := _union( orv, op(map( vartypes,op, 1 )) );
              unrealvars := _union( ourv, op(map( vartypes, op, 2 )) );
            end_if;

            /* a) map to subexpression */
            v := simplifySyntactically( op(cond,i) );
            case type(v)
              of "_and" do
                cond := cond.[op(v)];
                v:=null();
                break;
              of DOM_BOOL do
                if v=FALSE then return(FALSE); end_if;
                if v=TRUE then v:=null(); end_if;
                break;
              /* b) replace X=(const.) in all other subexpressions */
              of "_equal" do
                res := op(v,1) - op(v,2);
                k := FALSE;
                for i2 in freeIndets(res) do
                  if k=FALSE then k := Type::Linear( res, [i2] ); i1 := i2; end_if;
                end_for;
                if k=FALSE or decide(k[1]<>0)<>TRUE then break; end_if;
                s := -k[2]/k[1];
/*                k := 0;
                if type( op(v,1) )=DOM_IDENT then k := 1; end_if;
                if type( op(v,2) )=DOM_IDENT then k := 2; end_if;
                if k<>0 then */
                j := 1;
                while j<=nops(operands) do
                  if contains( indets(operands[j] ), i1 ) then
                    /* substitute and do a fast decision. if it can't be decided put it back into the queue */
                    res := subsid( operands[j], i1=s );
                    case decide(res)
                      of UNKNOWN do cond := cond.[res]; break;
                      of FALSE do return(FALSE);
                    end_case;
                    delete( operands[j] );
                    j := j-1;
                  end_if;
                  j := j+1;
                end_while;
                j := i+1;
                while j<=nops(cond) do
                  if contains( indets(cond[j] ), i1 ) then
                    res := subsid( cond[j], i1=s ); /* simplifySyntactically() will be called later */
                    /* substitute and do a fast decision. if it can't be decided let it in the queue */
                    case decide(res)
                      of UNKNOWN do cond[j] := res; break;
                      of FALSE do return(FALSE);
                      of TRUE do delete cond[j]; j:=j-1; break;
                    end_case;
                  end_if;
                  j := j+1;
                end_while;
                break;
            end_case;

            /* d) check for paris of relations with
             * (A op B) and (A op B)
             * or
             * (A op B) and (B op A)
             */
             o1 := v;
            case type(v)
              of "_not" do
                if not contains( {"_less", "_leequal", "_equal", "_unequal"}, type( op(v) ) ) then break; end_if;
                o1 := op(v);
              of "_less" do
              of "_leequal" do
              of "_equal" do
              of "_unequal" do
                if _subset( {op(o1)}, ops )=TRUE then
                  j := 1;
                  t1 := type(o1);
                  if type(v)="_not" then t1 := "not".t1; end_if;
                  while v<>null() and j<=nops(operands) do
                    o2 := operands[j];
                    if contains( {"_less", "_leequal", "_equal", "_unequal"}, type( o2 ) ) or (type(o2)="_not" and contains( {"_less", "_leequal", "_equal", "_unequal"}, type( op(o2) ) )) then
                      if type(o2)="_not" then
                        o2 := op(o2);
                        t2 := "not".type(o2);
                      else
                        t2 := type(o2);
                      end_if;
                      /* case 1: (A op B) and (A op B) */
                      if op(o1,1)=op(o2,1) and op(o1,2)=op(o2,2) then
                        case { t1, t2 }
                          of { "not_leequal", "not_less" } do /* not x<y and not x<=y */
                          of { "_unequal", "not_less" } do /* x<>y and not x<y */
                          of { "_unequal", "not_leequal" } do /* x<>y and not x<=y */
                            operands[j] := not op(o1,1)<=op(o1,2);
                            v:=null();
                            break;
                          of { "_less", "_leequal" } do /* x < y and x <= y */
                          of { "_less", "_unequal" } do /* x < y and x <> y */
                          of { "_leequal", "_unequal" } do /* x <= y and x <> y */
                            case decide( op(o1,1)<op(o1,2) )
                              of FALSE do return(FALSE);
                              of TRUE do operands[j] := null();
                              of UNKNOWN do operands[j] := op(o1,1)<op(o1,2);
                            end_case;
                            v:=null();
                            next;
                          of { "_leequal", "_equal" } do /* x <= y and x = y */
                            operands[j] := op(o1,1)=op(o1,2);
                            if not simplify::ignoreImplicitR_Property then cond := cond.[ op(o1,1) in R_ ] end_if;
                            v:=null();
                            next;
                          of { "_less", "_equal" } do /* x < y and x = y */
                          of { "_unequal", "_equal" } do /* x <> y and x = y */
                            return( FALSE );
                        end_case;
                      /* case 2: (A op B) and (B op A) */
                      elif op(o1,1)=op(o2,2) and op(o1,2)=op(o2,1) then
                        case { t1, t2 }
                          of { "not_leequal" } do /* not x<=y and not y<=x */
                            operands[j] := not op(o1,1) in R_ or not op(o1,2) in R_;
                            v:=null();
                            break;
                          of { "not_less" } do /* not x<y and not y<x */
                            operands[j] := op(o1,1)=op(o1,2) or not op(o1,1) in R_ or not op(o1,2) in R_;
                            v:=null();
                            break;
                          of { "_less", "not_leequal" } do /* x<=y and not y<=x */
                          of { "_leequal", "not_leequal" } do /* x<=y and not y<=x */
                            if t1= "not_leequal" then
                              operands[j] := op(o2,1)<op(o2,2);
                            else
                              operands[j] := op(o1,1)<op(o1,2);
                            end_if;
                            v:=null();
                            break;
                          of { "_unequal", "not_leequal" } do /* x<>y and not y<=x */
                          of { "_unequal", "not_less" } do /* x<>y and not y<x */
                            if type(o1)="_unequal" then
                              operands[j] := not op(o2,1)<=op(o2,2);
                            else
                              operands[j] := not op(o1,1)<=op(o1,2);
                            end_if;
                            v:=null();
                            break;
                          of { "_equal" } do /* x = y and y = x */
                            operands[j] := op(o1,1)=op(o1,2);
                            v:=null();
                            next;
                          of { "_equal", "_leequal" } do /* x = y and y <= x */
                          of { "_leequal" } do /* x <= y and y <= x */
                            operands[j] := op(o1,1)=op(o1,2);
                            if not simplify::ignoreImplicitR_Property then cond := cond.[ op(o1,1) in R_ ] end_if;
                            v:=null();
                            next;
                          of { "_less", "_unequal" } do /* x < y and y <> x */
                          of { "_leequal", "_unequal" } do /* x <= y and y <> x */
                            if type(o1)="_unequal" then
                              operands[j] := op(o2,1)<op(o2,2);
                            else
                              operands[j] := op(o1,1)<op(o1,2);
                            end_if;
                            v:=null();
                            next;
                          of { "_less" } do /* x < y and y < x */
                          of { "_less", "_leequal" } do /* x < y and y <= x */
                          of { "_equal", "_unequal" } do /* x = y and y <> x */
                          of {"_less", "_equal" } do /* x=y and x<y */
                            return( FALSE );
                        end_case;
                      end_if;
                    end_if;
                    j:=j+1;
                  end_while;
                else
                  ops := ops union {op(o1)};
                end_if;
            end_case;

            if v<>null() and contains( operands, v )=0 then
              operands := operands.[v];
            end_if;
            i := i+1;
          end_while;

          /* do we have anything left to check? */
          if nops(operands)=0 then return(TRUE); end_if;

          /* remap simplifyLogic after all terms are in normal form */
          cond :=  _and(  op(operands) );
          cond := simplify::simplifyLogic( cond );

          return( cond );
        /* Step 4:
         * search for all A and ( not A or xy )
         * and replace by A and ( xy )
         */
        operands := split( operands, X->type(X)="_or" );
        operands[1] := map( operands[1], proc(X)
          begin
            X := map( X, Y->_if( contains( operands[2], _not(Y) )>0, FALSE, Y ) );
            map( X, Y->_if( contains( operands[2], (Y) )>0, TRUE, Y ) );
          end_proc );

        cond := _and( op(operands[1]), op(operands[2]) );
    end_proc:  /* simplifySyntactically::simplifySyntactically_and */

      simplifySyntactically_not := proc( ncond : "_not" )
        local cond;
      begin
        cond := op(ncond);
        case type(cond)
          of "_less" do
          of "_leequal" do
            if typereal( op(cond,1) )=TRUE and typereal( op(cond,2) )=TRUE then
              if type(cond)="_less" then
                return( simplifySyntactically( op(cond,1)>=op(cond,2) ) );
              else
                return( simplifySyntactically( op(cond,1)>op(cond,2) ) );
              end_if;
            end_if;
        end_case;
        return( _not(simplifySyntactically(cond)) );
      end_proc: /* simplifySyntactically::simplifySyntactically_not */

      case type(cond)
        of DOM_BOOL do
          return( cond );
        of "_not" do
          return( simplifySyntactically_not( cond ) );
        of "_and" do
          ouv := unrealvars;
          orv := realvars;
          v := simplifySyntactically_and(cond);
          unrealvars := ouv;
          realvars := orv;
          return(v);
        of "_or" do
          ouv := unrealvars;
          orv := realvars;
          v := simplifySyntactically_or(cond);
          unrealvars := ouv;
          realvars := orv;
          return( v );

        of "_in" do
          if ( v := decide( cond ) )<>UNKNOWN then return(v); end_if;
          lhs := op(cond,1);
          set := op(cond,2);
          if (R:=(set)::dom::simpexIn) <> FAIL and set<>R_ then
            //t := time( ( cond := (R(op(cond), op(cond, 2))) ) );
            cond := ( R(op(cond), op(cond, 2)) );
            if contains( {TRUE,FALSE}, cond ) then return( cond ); end_if;
            if type(cond)<>"_in" then return( simplifySyntactically(cond) ); end_if;
            [ lhs, set ] := [ op(cond) ];
          end_if;
          if set={} then return( FALSE ); end_if;
          if set=C_ then return( TRUE ); end_if;
          if indets( cond ) minus Type::ConstantIdents = {} then
            res := decide( cond );
            if res<>UNKNOWN then return( res ); end_if;
          end_if;
          case type(set)
            of "_union" do
              res := [];
              for i in [op(set)] do
                v := decide( lhs in i );
                if v=UNKNOWN then
                  res := res.[i];
                elif v=TRUE then
                  return(TRUE);
                end_if;
              end_for;
              case nops(res)
                of 0 do return(FALSE);
                of 1 do return( simplifySyntactically( lhs in op(res) ) );
                otherwise return( lhs in _union(op(res)) );
              end_case;
              break;
            of "_minus" do
              if decide( lhs in op(set,1) )=TRUE then //op(set,1)=R_ and typereal( lhs )=TRUE then
                return(simplifySyntactically( not lhs in op(set,2) ) );
              end_if;
            of Dom::Interval do
              if stdlib::hasmsign(lhs) then
                lhs := -lhs; set := -set;
              end_if;
              cond := lhs in set;
              break;
          end_case;

          if type(set)=DOM_SET and nops(set)=1 then
            return( simplifySyntactically( op(cond,1)=op(set) ) );
          end_if;

          repeat
            ready := TRUE;
            /* copy&pasted from piecewise::simplifyCondition */
            if op(cond, 2) = R_ then
              case type(op(cond, 1))
                of "_mult" do
                  s := split( op(cond,1), a -> decide( a in R_ )=TRUE );
                  if s[1]<>1 then
                    return( simplifySyntactically(s[2] in R_ or s[1]=0 ) );
                  end_if;
                  break;
                of "_plus" do
                  s := split( op(cond,1), a -> decide( a in R_ ) );
                  if s[1]<>0 then
                    if s[3]=0 and type(s[2])<>"_plus" then return( FALSE ); end_if;
                    cond := subsop( cond, 1=s[2]+s[3] );
                    ready := FALSE;
                  end_if;
                  break;
                of "_power" do
                  // some very important special cases
                  case op(cond, [1, 2])
                    of -1 do
                      return(simplifySyntactically(op(cond, [1, 1]) in R_))
                    of 1/2 do
                      return(simplifySyntactically(op(cond, [1, 1]) >= 0))
                    of -1/2 do
                      return(simplifySyntactically(op(cond, [1, 1]) > 0))
                  end_case;
                  break
                of "exp" do
                  cond:= Im(op(cond, [1, 1]))/PI in Z_;
                  return(simplifySyntactically(cond))
                of "ln" do
                  return(simplifySyntactically(op(cond, [1, 1]) > 0))
                of "sign" do
                  return(simplifySyntactically(op(cond, [1, 1]) in R_))
                of "sin" do
                of "cos" do
                  if is(op(cond, [1, 1]), Type::Real) = TRUE then
                    return(TRUE)
                  else
                    break
                  end_if;
                of "arcsin" do
                of "arccos" do
                  return( simplifySyntactically( op(cond, [1, 1]) in Dom::Interval([-1, 1]) ) );
              end_case;
            end_if;
          until ready end_repeat;
          break;

        /* simplifySyntacically(cond): case relations */
        of "_less" do
        of "_leequal" do
          lhs := op(cond,1);
          rhs := op(cond,2);

          /* x < infinity or -infinity < x => x in R_ */
          if type(cond)="_less" then
            if lhs=-infinity then
              if rhs=infinity then return(TRUE); end_if;
              return( simplifySyntactically( rhs in R_ ) );
            end_if;
            if rhs=infinity then return( simplifySyntactically( lhs in R_ ) ); end_if;
            if lhs=infinity then return( FALSE ); end_if;
            if rhs=-infinity then return( FALSE ); end_if;
          end_if;

          /* flatten x < y < z to  (x < y) and (y < z) */
          if contains( {"_less", "_leequal"}, type(lhs) ) then
            return( simplifySyntactically( lhs and subsop(cond,1=op(lhs,2)) ) );
          end_if;
          if contains( {"_less", "_leequal"}, type(rhs) ) then
            return( simplifySyntactically( subsop(cond,2=op(rhs,1)) and rhs ) );
          end_if;

          inds := freeIndets( cond );

          /* test for constant relations */
          if inds={} then
            res := property::constRel( cond );
            if res<>UNKNOWN then return( res ); end_if;
          end_if;

          /* special case: X <=,<,<>,= X */
          if lhs=rhs then
            if type(cond)="_less" then return(FALSE); end_if;
            v := typereal( lhs );
            if v<>UNKNOWN then return(v); end_if;
            if simplify::ignoreImplicitR_Property then
              return( TRUE );
            else
              return( simplifySyntactically( lhs in R_ ) );
            end_if;
          end_if;

          /* lhs<=rhs implies lhs-rhs<=0 so if this is FALSE lhs<=rhs is FALSE too */
          if type(cond)="_less" then
            v := decide( lhs-rhs<0 );
          else
            v := decide( lhs-rhs<=0 );
          end_if;
          if v=FALSE then return(FALSE); end_if;

          /* test if lhs/rhs are real */
          if ( typereal(lhs)=FALSE or typereal(rhs)=FALSE) and not has( [lhs, rhs], infinity ) then
            return(FALSE);
          end_if;

          /* test if lhs, rhs are linear with real constants */
          if nops(inds)=1 then
            if ( r := Type::Linear( rhs, [op(inds)] ) )<>FALSE and ( s := Type::Linear( lhs, [op(inds)] ) )<>FALSE then
              if typereal( r )=TRUE and typereal( s )=TRUE then
                if v=TRUE then
                  if simplify::ignoreImplicitR_Property then
                    return(TRUE);
                  else
                    return( simplifySyntactically( op(inds) in R_ ) );
                  end_if;
                end_if;
                s[1] := s[1]-r[1];
                s[2] := s[2]-r[2];
                if numeric::isnonzero( s[1] )=TRUE then
                  lhs := lhs-rhs; rhs := 0;
                end_if;
              end_if;
            end_if;
          end_if;

          if type(lhs)="_plus" then
            [s,lhs,r] := split( lhs, X->typereal(X)=TRUE );
          elif typereal(lhs)=TRUE then
            s := lhs; lhs := 0;
          else
            s := 0;
          end_if;
          if type(rhs)="_plus" then
            [i,rhs,r] := split( rhs, X->typereal(X)=TRUE );
            s := s-i;
          elif typereal(rhs)=TRUE then
            s := s-rhs; rhs := 0;
          end_if;

          if s<>0 then
            /* 1. distribute the terms containing indets */
            if indets( s ) minus Type::ConstantIdents<>{} then
              if type(s)="_plus" then
                s := split( s, X->bool(indets(X) minus Type::ConstantIdents<>{}) );
              else
                s := [ s, 0, 0 ];
              end_if;
              i := s[1]; s := s[2];
              if type(i)="_plus" then
                i := split( i, stdlib::hasmsign );
                lhs := lhs+i[2];
                rhs := rhs-i[1];
              elif stdlib::hasmsign(i) then
                rhs := rhs - i;
              else
                lhs := lhs + i;
              end_if;
            end_if;
            /* 2. distribute all other terms */
            j := _if( indets( lhs ) minus Type::ConstantIdents={}, 1, 0 ) + _if( indets( rhs ) minus Type::ConstantIdents={}, 2, 0 );
            if j=1 or j=2 then
              if j=1 then
                lhs := lhs + s;
              else
                rhs := rhs - s;
              end_if;
            else
              if type(s)="_plus" then
                s := split( s, stdlib::hasmsign );
                lhs := lhs+s[2];
                rhs := rhs-s[1];
              elif stdlib::hasmsign(s) then
                rhs := rhs - s;
              else
                lhs := lhs + s;
              end_if;
            end_if;
          else
            j := _if( indets( lhs ) minus Type::ConstantIdents={}, 1, 0 ) + _if( indets( rhs ) minus Type::ConstantIdents={}, 2, 0 );
          end_if;

          if j=3 then
            j := _if( rhs=0, 2, 1 );
          end_if;

          if j=1 or j=2 then
            if j=1 then i:= lhs; lhs := rhs; rhs := i; end_if;
            case type(lhs)
              of "_mult" do
                if rhs=0 then
                  s := [op(lhs)];
                  /* first remove all positive factors */
                  s := split( s, X->decide( X>0 ) );
                  lhs := _mult( op(s[3]) );
                  /* second remove all negative factors */
                  s := split( s[2], X->decide( X<0 ) );
                  i := ( nops( s[1] ) mod 2 )=1;
                  lhs := _mult( op(s[2]), op(s[3]) ) * lhs;
                else
                  s := split( lhs, X->testtype(X, Type::Constant ) );
                  if ( i := property::constRel( s[1]<0 ) )<>TRUE then
                    if ( i := not property::constRel( s[1]>0 ) )<>FALSE then
                      break;
                    end_if;
                  end_if;
                  rhs := rhs / s[1];
                  lhs := s[2];
                end_if;
                if i then j := 3-j; end_if;
                break;
              of "_power" do
                if rhs=0 then
                  [ b, ex ] := [ op(lhs) ];
                  if type(ex)=DOM_INT then
                    if ex=2 and j=1 then
                      if type(cond)="_leequal" then
                        return( simplifySyntactically( b in R_ ) );
                      else
                        return( simplifySyntactically( b in R_ minus {0}) );
                      end_if;
                    elif ex<0 then
                      cond := hold(_less)(0,0);
                      if ex mod 2=0 then
                        lhs := b^2;
                      else
                        lhs := b;
                      end_if;
                    end_if;
                  elif ex=1/2 then
                    if j=2 then return( FALSE ); else
                      lhs := b;
                    end_if;
                  end_if;
                end_if;
                break;
            end_case;
            if j=1 then i:= lhs; lhs := rhs; rhs := i; end_if;
          end_if;

          cond := subsop( cond, 1=lhs, 2=rhs );
          i := decide(cond);
          if i<>UNKNOWN then return(i); end_if;
          break;

        of "_unequal" do /* X<>Y is reduced to not X=Y */
          return( _not( simplifySyntactically( op(cond,1)=op(cond,2) ) ) );

        of "_equal" do
          if op(cond, 1) = op(cond, 2) then
            return( TRUE );
          end_if;

          /* test for constant equations */
          if indets( cond ) minus Type::ConstantIdents={} then
            res := property::constRel( cond );
            if res<>UNKNOWN then return( res ); end_if;
          end_if;

          lhs := rhs := 0;
          s := op(cond,1)-op(cond,2);

          repeat
            ready := TRUE;
            case type(s) /* some special cases for expr=0 */
              of "arg" do /* arg(x)=0 means x>=0 */
                 return( simplifySyntactically( op(s)>=0 ) );
              of "ln" do /* ln(x)=0 means x=1 */
                  s := op(s)-1;
                  ready := FALSE;
                  break;
              of "Im" do /* Im(x)=0 is equivalent to x in R_ */
                return( simplifySyntactically( op(s) in  R_ ) );
              of "exp" do /* exp(x)=0 is false for any x */
              of stdlib::Undefined do /* stdlib::Undefined=0 is FALSE */
                return( FALSE );
              of DOM_INT do /* s = 0 implies TRUE */
              of DOM_RAT do
              of DOM_COMPLEX do
                return( bool(s=0) );
              of DOM_IDENT do /* X = 0 */
                v := decide( s=0 );
                if v<>UNKNOWN then return(v); end_if;
                return( s=0 );
              of "_mult" do /* a*b*c... = 0 */
                return( simplifySyntactically( _or( map(op(s), X->X=0 ) ) ) );
               of "_power" do
                  case type(op(s,2))
                    of DOM_INT do
                    of DOM_RAT do
                      if op(s,2)<0 then return( FALSE ); end_if;
                      if op(s,2)>0 then s := op(s,1); end_if;
                      ready := FALSE;
                      break;
                  end_case;
                break;
              of "_plus" do
                /* build some kind of gcd */
                v := gcd( map( op(s), X->case type(X)
                    of "_mult" do _if( type(op(X,nops(X)))=DOM_INT, op(X,nops(X)), 1 ); break;
                    of DOM_INT do X; break;
                    otherwise 1; break;
                  end_case ) );
                if v<>1 then
                  s := _plus( op(map( s, X->X/v )) );
                  if type(s)<>"_plus" then s:=[s]; break; end_if;
                end_if;
                v := _intersect( map( op(s), X->_if(type(X)="_mult",{op(X)},{X}) ) );
                if v<>{} then
                  v := _mult( op(v) );
                  s := _plus( op(map( s, X->X/v )) );
                  if type(v)="_mult" then
                    v := [op(v)];
                  else
                    v :=[v];
                  end_if;
                  return( simplifySyntactically( _or( s=0, op(map( v,X->X=0)) ) ) );
                end_if;
                break;
            end_case;
          until ready end_repeat;

          if type(s)="_plus" then
            s := [op(s)];
          else
            s := [s];
          end_if;

          /* 1. distribute the terms containing indets */
          if indets( s ) minus Type::ConstantIdents<>{} then
            /* special case: s is a sum of products, i.e. s=a+b=0. redistribute all fractions
              * this solve 1/x+1/y = 0 to x=-y */
            if nops(s)=2 and {type(op(s,1)),type(op(s,2))} intersect {"_mult", "_power"}<>{} then
              v := [];
              for i from 1 to 2 do
                r := s[i];
                case type(r)
                  of "_power" do
                    if testtype( op(r,2), Type::NegInt ) then
                      s := subsop( s, i=1, 3-i=( op(s,3-i)*_power(op(r,1),-op(r,2)) ) );
                      if not simplify::ignoreSingularities then v:=v.[op(r,1)<>0]; end_if;
                    end_if;
                    break;
                  of "_mult" do
                    r := split( [op(r)], X->_lazy_and( type(X)="_power", testtype(op(X,2),Type::Rational), bool(op(X,2)<0) ) );
                    if not simplify::ignoreSingularities then v:=v.map(r[1], X->op(X,1)<>0); end_if;
                    s := subsop( s, i=_mult(op(r[2])), 3-i=( op(s,3-i)*op(map( r[1], X->subsop(X,2=-op(X,2)) )) ) );
                    break;
                end_case;
              end_for;
              if not simplify::ignoreSingularities and nops(v)<>0 then return( simplifySyntactically( _and( _plus(op(s))=0, op(v) ) ) ); end_if;
              /* recalculate sum */
              s := _plus( op(s) );
              if type(s)="_plus" then s := [op(s)]; else s := [s]; end_if;
            end_if;
            s := split( s, X->bool(indets(X) minus Type::ConstantIdents<>{}) );
            /* now s is a list of lists: [ [summands containing indets,...], [summands containing indets,..], [] ] */

            i := s[1]; s := s[2];
            i := split( i, stdlib::hasmsign );
            /* if we have no positive indets, negate anything and put the indets to the left side */
            if i[2]=[] then
              lhs := -_plus( op(i[1]) );
              s := map( s, _negate );
            else
              lhs := _plus( op(i[2]) );
              rhs := -_plus( op(i[1]) );
            end_if;
          end_if;
          /* if we have only indets at one side of the equation this should be on the left side at this point, i.r. indets(lhs)={} => indets(rhs)={} */

          /* 2. distribute all other terms */
          if nops(s)<>0 then
            j := _if( indets( lhs ) minus Type::ConstantIdents={}, 1, 0 ) + _if( indets( rhs ) minus Type::ConstantIdents={}, 2, 0 );
            /* if we have idents on one side, then put the constants on the other one */
            if j=2 then
              rhs := rhs - _plus(op(s));
              /* if we have c*X = a change this to X=a/c */
              if type(lhs)="_mult" then
                s := split( lhs, X->_lazy_and( indets(X) minus Type::ConstantIdents={}, property::constRel(X<>0)=TRUE ) );
                lhs := s[2];
                rhs := rhs/s[1];
              end_if;
            else
              s := split( s, stdlib::hasmsign );
              lhs := lhs+_plus(op(s[2]));
              rhs := rhs-_plus(op(s[1]));
            end_if;
          elif rhs=0 then
            /* now: cond := ( lhs = 0 ) */
            case type(lhs)
              of "_mult" do /* a*b*c... = 0 */
                /* remove all constant multiplicands */
                s := split( lhs, X->_lazy_and( indets(X) minus Type::ConstantIdents={}, property::constRel(X<>0)=TRUE ) );
                if type(s[2])<>"_mult" then return( simplifySyntactically( op(cond,0)( s[2], 0 ) ) ); end_if;
                /* reduce all _power */
                s := split( [op(s[2])], X->type(X)="_power" );
                s[1] := map( s[1], proc(X)
                  begin
                    case type(op(X,2))
                      of DOM_INT do
                      of DOM_RAT do
                        if op(X,2)<0 then return(1); end_if;
                        if op(X,2)>0 then return( op(X,1) ); end_if;
                        break;
                    end_case;
                    X;
                  end_proc );
                lhs := _mult( op(s[1]), op(s[2]) );
                break;
              of "_power" do  /* a^b = 0 */
                if contains( {DOM_INT,DOM_RAT}, type(op(lhs,2)) ) then
                  if op(lhs,2)<0 then /* 1/a^n = 0 is false */
                    return( FALSE );
                  elif op(lhs,2)>0 then /* a^n = 0 <=> a=0 */
                    return( simplifySyntactically( op(lhs,1)=0 ) );
                  end_if
                end_if;
            end_case;
          end_if;

          /* some special cases */
          if indets( rhs ) minus Type::ConstantIdents = {} then
            case type(lhs)
              of "_power" do
                [ b, ex ] := [ op(lhs) ];
                /* n-te Wurzel(x) = const */
                if type(op(lhs,2))=DOM_RAT and numer(op(lhs,2))=1 then
                  if ( v := property::constRel( rhs<0 ) )=TRUE then return(FALSE); end_if;
                  if v=UNKNOWN then break; end_if;
                  if ( v := property::constRel( rhs>=0 ) )=TRUE then
                    rhs := _power( rhs, denom(op(lhs,2)) );
                    lhs := op(lhs,1);
                  elif v=FALSE then
                    /* rhs is imaginary */
                    if contains( realvars, lhs ) then return( FALSE ); end_if;
                  end_if;
                elif indets( b ) minus Type::ConstantIdents = {} and indets( ex ) minus Type::ConstantIdents <> {} and typereal(ex)=TRUE then
                  if property::constRel( b>0 )=TRUE and property::constRel( b<>1 )=TRUE then
                    if property::constRel(rhs>0) then
                      return( simplifySyntactically( ex=ln(rhs)/ln(b) ) );
                    elif property::constRel(rhs<=0) then
                      return( FALSE );
                    end_if;
                  end_if;
                end_if;
            end_case;
          end_if;

          cond := lhs=rhs;

          i := decide(cond);
          if i<>UNKNOWN then return(i); end_if;
          break;
      end_case;
      cond;
  end_proc: /* simplifySyntactically */


  /* simplifyCondition::_simplifyExpr( cond )
   * This is the second used heuristic. It uses interval arithmetics to decide/simplify expressions.
   */
  _simplifyExpr := proc( cond, constraints = null(), implicants = null() )
    local t, i, j, k, ls, rs,
      simplify_and, /* proc */
      simplify_or, /* proc */
      id, iv, bs, c,
      checkCondition, /* proc */
      removeSet, /* proc */
      intersectSet, /* proc */
      checkImplicants: DOM_PROC,
      updateImplicant: DOM_PROC,               
      inds, /* set of all indets */
      condIndex, /* the index of the condition we are working on */
      condlist; /* list of all indices to be checked */
    /* contraints: table with
      Expression =[ interval/ set, type, mult,
        4={expressions that were used to create this constraint},
        5={expressions that were build depending on this constraint. these have to be removed if this constraint changes},
        6={indices of condition where this constraint was used. these have to be reevaluated if this constraint changes},
        7={indices of conditions which bound this constraint. these can be removed if we have a real subset},
        8 = [ left bound, right bound, basicset ] ]
      */
      /* implicants: table with
       Expression = [ interval/ set, type, mult,
       ]
       */
  begin
      checkCondition := proc( xpr, isAnd )
        local i1, i2, j, v, s,
          inds,
          intersectCS, createCS, _mapIV, mapIV, /* proc */
          sidea, sideb,
          updateCond, /* proc */
          updateConstraint, /* proc */
          condDep, /* [ bool, bool, bool ] */
          constDep; /* constraints that were used to create the current constraint */
      begin
        /* mapIV( xpr, constr )
         * Maps the constraints/implicants through the term xpr.
         * constr=FALSE means the implicants are mapped
         */
        mapIV := proc( xpr, constr=TRUE )
          local s;
        begin
          if contains( map( freeIndets( xpr ), X->constraints[X][2]=C_ ), TRUE ) then return(FAIL); end_if;
          constDep := {};
          s := _mapIV( xpr, constr );
          if constr then
            constDep := constDep minus {xpr};
            map( constDep, proc(X)
              begin
                constraints[X] := subsop( constraints[X], 5=constraints[X][5] union {xpr}, 6=constraints[X][6] union {condIndex} );
              end_proc );
          end_if;
          if s=FAIL then return( FAIL ); end_if;
          [ s[1], s[2], 1, constDep, {}, {}, {}, [FALSE,FALSE,FALSE] ];
        end_proc:  /* _simplifyExpr::checkCondition::mapIV */

        /* _mapIV( xpr, constr )
         * recursive part of mapIV
         */
        _mapIV := proc( xpr, constr )
          local s, v, i;
        begin
          if constr and contains( constraints, xpr ) then
            s := constraints[xpr];
            constraints[xpr] := subsop( constraints[xpr], 6=constraints[xpr][6] union {condIndex} );
            constDep := constDep union {xpr} union s[4];
            if s[1]=C_ then return(FAIL); end_if;
            return( [ s[1], s[2] ] );
          elif not constr and contains( implicants, xpr ) then
            s := implicants[xpr];
            implicants[xpr] := subsop( implicants[xpr], 6=implicants[xpr][6] union {condIndex} );
            constDep := constDep union {xpr} union s[4];
            if s[1]=C_ then return(FAIL); end_if;
            return( [ s[1], s[2] ] );
          end_if;
          case type(xpr)
            of "exp" do
            of "Re" do
              v := _mapIV(op(xpr), constr);
              if v=FAIL then return(FAIL); end_if;
              v := eval( op(xpr,0)( v[1] ) );
              if not contains( {Dom::Interval,DOM_SET},type(v) ) then return(FAIL); end_if;
              return( [v,R_] );
            of DOM_INT do
            of DOM_RAT do
              return( [{xpr},R_] );
            of "_mult" do:
              s := map( [op(xpr)], _mapIV, constr );
              if contains(s,FAIL)>0 then return(FAIL); end_if;
              s :=_mult( op(map( s, op, 1 )) );
              return( [ s, R_ ] );
            of "_plus" do:
              v := Z_;
              s := map( [op(xpr)], _mapIV, constr );
              if contains(s,FAIL)>0 then return(FAIL); end_if;
              v := _union( op(map( s, op, 2 )) );
              s :=_plus( op(map( s, op, 1 )) );
              return( [ s,v ] );
            of "_power" do
              if type( op(xpr,2) )=DOM_INT then
                s := _mapIV( op(xpr,1), constr );
                if s=FAIL then return(FAIL); end_if;
                v := _power( s[1], op(xpr,2) );
                if not contains( {Dom::Interval,DOM_SET},type(v) ) then return(FAIL); end_if;
                return( [ v, R_ ] );
              end_if;
              break;
          end_case;
          return( FAIL );
        end_proc: /* _simplifyExpr::checkCondition::_mapIV */

        createCS := proc( open, dir, border )
          local b;
        begin
          if open="_equal" then
            if decide( border in R_ )=TRUE then
              return( [ {border}, R_, 1, constDep, {}, {}, {condIndex}, [FALSE,FALSE,FALSE] ] );
            else
              return( [ {border}, C_, 1, constDep, {}, {}, {condIndex}, [FALSE,FALSE,FALSE] ] );
            end_if;
          end_if;
          if dir=1 then
            [ Dom::Interval( -infinity, _if( open="_less", border, [border] ) ), R_, 1, constDep, {}, {}, {condIndex}, [FALSE,TRUE,FALSE] ];
          else
            [ Dom::Interval( _if( open="_less", border, [border] ), infinity ), R_, 1, constDep, {}, {}, {condIndex}, [TRUE,FALSE,FALSE] ];
          end_if;
        end;  /* _simplifyExpr::checkCondition::createCS */

        intersectCS := proc( CS, typ, dir, border, xpr )
          local v, s;
        begin
          v := createCS(typ, dir, border);
          condDep := op(v,8);
          return( intersectSet( CS, op(v,1), xpr ) );
        end_proc;  /* _simplifyExpr::checkCondition::intersectCS */

        intersectSet := proc( CS, set, xpr )
          local v, s, iv, bs, cI;
        begin
          if _subset( CS[2], set )=TRUE or _subset( CS[1], set )=TRUE or _subset( CS[2] intersect CS[1], set )=TRUE then
            return( TRUE );
          end_if;
          cI := {condIndex};
          v := CS[1] intersect CS[2] intersect set;
          if type(v)="_intersect" then
            s := split( v, X->type(X)<>solvelib::BasicSet );
            if type(s[1])="_intersect" then
              iv := CS[1]; bs := R_;
              cI := {};
            else
              iv := s[1]; bs := s[2];
            end_if;
          else
            if type( v )=solvelib::BasicSet then
              iv := Dom::Interval( -infinity, infinity );
              bs := v;
            else
              iv := v;
              bs := R_;
            end_if;
          end_if;
          if iv={} then return( FALSE ); end_if;
          case type(iv)
            of DOM_SET do
              if nops(iv)=1 // and typ<>"_equal" // global ident !!!
                then
                cond[condIndex] := simplifySyntactically(xpr=op(iv));
              end_if;
              break;
            of Dom::Interval do
              break;
            otherwise
              iv := CS[1];
              break;
          end_case;
          return( [ iv, bs, 1, CS[4], CS[5], CS[6], cI, zip(CS[8],condDep,_or) ] );
        end_proc;  /* _simplifyExpr::checkCondition::intersectSet */

        /* updateCond( expr, set )
         * 1. updates the constraints/implicants-table
         * 2. update the list of conditions by removing all appearence of expr
         * and adding "expr in set".
         */
        updateCond := proc( expr, v )
          local c;
        begin
          if not contains( {Dom::Interval, DOM_SET}, type(v[1]) ) then return(); end_if;
          if isAnd  then
            updateConstraint( expr, v );
            if constraints[expr][2]<>C_ then
              v := constraints[ expr ];
              map( {condIndex} union constraints[expr][7], X->( cond[X]:=TRUE ) );
              constraints[expr][7] := {condIndex};
              case type(v[1])
                of DOM_SET do
                  if nops(v[1])=1 then
                    cond[condIndex] := expr = op(v[1]);
                  else
                    cond[condIndex] := expr in v[1];
                  end_if;
                  break;
                of Dom::Interval do
                  if v[8][3] then
                    cond[condIndex] := expr in v[1] intersect v[2];
                  else
                    if v[8][1] and v[8][2] then
                        cond[condIndex] := expr in v[1];
                    elif v[8][1] then
                      c := Dom::Interval::leftB( v[1] );
                      cond[condIndex] := simplifySyntactically( _if( type(c)=DOM_LIST, expr >= op(c), expr > c ) );
                    elif v[8][2] then
                      c := Dom::Interval::rightB( v[1] );
                      cond[condIndex] := simplifySyntactically( _if( type(c)=DOM_LIST, expr <= op(c), expr < c ) );
                    end_if;
                  end_if;
                  break;
                otherwise
                  if v[8][3] then
                    cond[condIndex] := expr in v[1] intersect v[2];
                  else
                    cond[condIndex] := expr in v[1];
                  end_if;
              end_case;
            end_if;
          elif not isAnd then
            updateImplicant( expr, v );
            if implicants[expr][2]<>{} then
              v := implicants[ expr ];
              map( {condIndex} union implicants[expr][7], X->( cond[X]:=FALSE ) );
              implicants[expr][7] := {condIndex};
              case type(v[1])
                of DOM_SET do
                  if nops(v[1])=1 then
                    cond[condIndex] := expr = op(v[1]);
                  else
                    cond[condIndex] := expr in v[1];
                  end_if;
                  break;
                of Dom::Interval do
                  if v[8][3] then
                    if v[8][1] or v[8][2] then
                      cond[condIndex] := expr in v[1] intersect v[2];
                    else
                      cond[condIndex] := expr in v[2];
                    end_if;
                  else
                    if v[8][1] and v[8][2] then
                        if Dom::Interval::leftB(v[1])=-infinity and Dom::Interval::rightB(v[1])=infinity then
                          cond[condIndex] := expr in R_;
                      else
                          cond[condIndex] := expr in v[1];
                        end_if;
                    elif v[8][1] then
                      c := Dom::Interval::leftB( v[1] );
                      cond[condIndex] := simplifySyntactically( _if( type(c)=DOM_LIST, expr >= op(c), expr > c ) );
                    elif v[8][2] then
                      c := Dom::Interval::rightB( v[1] );
                      cond[condIndex] := simplifySyntactically( _if( type(c)=DOM_LIST, expr <= op(c), expr < c ) );
                    end_if;
                  end_if;
                  break;
                otherwise
                  if v[8][3] then
                    cond[condIndex] := expr in v[1] intersect v[2];
                  else
                    cond[condIndex] := expr in v[1];
                  end_if;
              end_case;
            end_if;
          end_if;
        end_proc; /* _simplifyExpr::checkCondition::updateCond */

        /* updateConstraint( expr, constr )
         * sets the constraint "expr" to "constr"
         * Also checks which conditions have to be reevaluated and removes all depending constraints
         */
        updateConstraint := proc( expr, constr )
          local s, i, ls, rs;
        begin
          /* we only handle intervals */
          if constr[1] = R_ then constr[1] := Dom::Interval( -infinity, infinity ); end_if;
          if not contains( {Dom::Interval, DOM_SET}, type(constr[1]) ) then return(); end_if;

          /* check if we already have an entry */
          if contains( constraints, expr ) then
            /* reevaluate all expressions depending on this constraint */
            condlist := condlist.[ op(constraints[ expr ][6] minus {condIndex}) ];
            /* remove all constraints depending on this constraint */
            s := constraints[ expr ][5];
            while nops(s)>0 do
              i := op(s,1);
              if contains( constraints, i ) then
                s := s union constraints[i][5];
                delete constraints[i];
              end_if;
              s := s minus {i};
            end_while;
            /* update all dependings */
            constr[ 7 ] := constr[7] union constraints[expr][7];
            constr[ 8 ] := zip(constr[8],constraints[expr][8],_or);
          end_if;

          /* update the table */
          constraints[ expr ] := constr;
        end_proc:

        checkImplicants := proc( sidea, v )
          local w, s;
        begin
          if ( w := mapIV( sidea,FALSE ) )<>FAIL then
            if _subset( w[1], v[1] )=TRUE and nops(constDep)=1 and contains(implicants,op(constDep)) then
              map( implicants[op(constDep)][7], X->( cond[X]:=FALSE ) );
            end_if;
            s := ( v[1] intersect v[2] ) union (w[1] intersect w[2] );
            if type( s ) <> "_union" then
              case type( s )
                 of "_intersect" do
                  s := split( s, X->type(X)<>solvelib::BasicSet );
                  v[1] := s[1];
                  v[2] := s[2];
                  break;
                of solvelib::BasicSet do
                  v[1] := Dom::Interval( -infinity, infinity );
                  v[2] := s;
                  break;
                of DOM_SET do
                of Dom::Interval do
                  v[1] := s;
                  v[2] := R_;
                  break;
              end_case;
            else
              return( UNKNOWN );
            end_if;
          end_if;
          v;
        end_proc;

        updateImplicant := proc( expr, implicant )
          local s, i;
        begin
          /* we only handle intervals */
          if implicant[1] = R_ then implicant[1] := Dom::Interval( -infinity, infinity ); end_if;
          if not contains( {Dom::Interval, DOM_SET}, type(implicant[1]) ) then return(); end_if;

          /* check if we already have an entry */
          if contains( implicants, expr ) then
            /* reevaluate all expressions depending on this constraint */
            condlist := condlist.[ op(implicants[ expr ][6] minus {condIndex}) ];
            /* remove all constraints depending on this constraint */
            s := implicants[ expr ][5];
            while nops(s)>0 do
              i := op(s,1);
              if contains( implicants, i ) then
                s := s union implicants[i][5];
                delete implicants[i];
              end_if;
              s := s minus {i};
            end_while;
            /* update all dependings */
            implicant[ 7 ] := implicant[7] union implicants[expr][7];
            implicant[ 8 ] := zip(implicant[8],implicants[expr][8],_or);
          end_if;

          /* update the table */
          implicants[ expr ] := implicant;
        end_proc:

        condDep := [ FALSE, FALSE, FALSE ];

        case type(xpr)
          of "_or" do
            v := _simplifyExpr( xpr, constraints );
            cond[condIndex] := v;
            if type(v)=DOM_BOOL then return(v); end_if;
            break;

          of "_and" do
            v := _simplifyExpr( xpr, constraints );
            if type(v)=DOM_BOOL then return(v); end_if;
            cond[condIndex] := v;
            break;

          of "_not" do
            v := _simplifyExpr( op(xpr), constraints );
            rs := ls := FALSE;
            /* check if we have a relation with real sides */
            if contains( {"_less","_leequal"}, type(v) ) then
              ls := typereal( op(v,1) );
              if ls=UNKNOWN then
                ls := mapIV( op(v,1) );
                if ls=FAIL then
                  ls=UNKNOWN
                else
                  ls := typereal( ls[1] );
                end_if;
              end_if;
              if ls=TRUE then
                rs := typereal( op(v,2) );
                if rs=UNKNOWN then
                  rs := mapIV( op(v,2) );
                  if rs=FAIL then
                    rs=UNKNOWN
                  else
                    rs := typereal( rs[1] );
                  end_if;
                end_if;
              end_if;
            end_if;
            /* if we have a relation and both sides are real, then remove the _not and swap sides */
            if rs=TRUE and ls=TRUE then
              if type(v)="_less" then
                v := op(v,2)<=op(v,1);
              else
                v := op(v,2)<op(v,1);
              end_if;
              condlist := condlist.[condIndex];
            else
              v := _not(v);
            end_if;
            cond[condIndex] := v;
            if type(v)=DOM_BOOL then return(v); end_if;
            break;

          of "_in" do
           [ sidea, sideb ] := [ op(xpr) ];
            if sideb=C_ then /* this should not happen */
              return(TRUE);
            elif op(xpr,2)=R_ then
              if contains(constraints,sidea) then
                v := R_ intersect constraints[ sidea ][1];
                if type(v)="_intersect" then break; end_if;
                constDep := {};
              else
                v := mapIV( sidea );
                if v<>FAIL then return(TRUE); end_if;
                v := Dom::Interval( -infinity, infinity );
              end_if;
              v := [ v, R_, 1, constDep, {}, {}, {condIndex}, [FALSE,FALSE,TRUE] ];

              v := checkImplicants( sidea, v );
              if type(v)=DOM_BOOL then return(v); end_if;

              updateCond( op(xpr,1), v );
            elif type(sideb) = solvelib::BasicSet then /* sideb = Z_ / Q_ */
              v := mapIV( sidea );
              if v=FAIL then
                v := [ Dom::Interval( -infinity, infinity ), sideb, 1, constDep, {}, {}, {condIndex}, [FALSE,FALSE,TRUE] ];
              else
                v := intersectSet( v, sideb, sidea );
                if type(v)=DOM_BOOL then return(v); end_if;
                v[8][3] := TRUE;
              end_if;

              v := checkImplicants( sidea, v );
              if type(v)=DOM_BOOL then return(v); end_if;
              updateCond( sidea, v );
            elif type(sideb) = Dom::Interval then
              if FALSE and contains(constraints,sidea) then
                v := op(xpr,2) intersect constraints[ sidea ][1];
                if type(v)="_intersect" then break; end_if;
                constDep := {};
              else
                v := mapIV( sidea );
                condDep := [TRUE,TRUE,FALSE];
                if v<>FAIL then
                  //v := intersectSet( v, sideb );
                  //if type(v)=DOM_BOOL  then return(v); end_if;
                  s := op(v,1);

                  if type(s)=Dom::Interval then
                    /* check if the intersection is empty */
                    if not Dom::Interval::isrightopen(s) and not Dom::Interval::isleftopen(sideb) then
                      ls := decide( Dom::Interval::right(s)<Dom::Interval::left(sideb) );
                    else
                      ls := decide( Dom::Interval::right(s)<=Dom::Interval::left(sideb) );
                    end_if;
                    if ls=TRUE then return(FALSE); end_if;
                    if not Dom::Interval::isrightopen(sideb) and not Dom::Interval::isleftopen(s) then
                      ls := decide( Dom::Interval::right(sideb)<Dom::Interval::left(s) );
                    else
                      ls := decide( Dom::Interval::right(sideb)<=Dom::Interval::left(s) );
                    end_if;
                    if ls=TRUE then return(FALSE); end_if;

                    /* check if the left/right side is redundant */
                    if not Dom::Interval::isleftopen(s) and Dom::Interval::isleftopen(sideb) then
                      ls := decide( Dom::Interval::left(s) > Dom::Interval::left(sideb) );
                    else
                      ls := decide( Dom::Interval::left(s) >= Dom::Interval::left(sideb) );
                    end_if;
                    if not Dom::Interval::isrightopen(s) and Dom::Interval::isrightopen(sideb) then
                      rs := decide( Dom::Interval::right(s) < Dom::Interval::right(sideb) );
                    else
                      rs := decide( Dom::Interval::right(s) <= Dom::Interval::right(sideb) );
                    end_if;

                    if ls=TRUE and rs=TRUE then
                      return(TRUE);
                    elif ls=TRUE then
                      condDep[1] := FALSE;
                      if Dom::Interval::isrightopen(sideb) then
                        cond[condIndex] := simplifySyntactically( sidea < Dom::Interval::right(sideb) );
                      else
                        cond[condIndex] := simplifySyntactically( sidea <= Dom::Interval::right(sideb) );
                      end_if;
                    elif rs=TRUE then
                      condDep[2] := FALSE;
                      if Dom::Interval::isleftopen(sideb) then
                        cond[condIndex] := simplifySyntactically( sidea > Dom::Interval::left(sideb) );
                      else
                        cond[condIndex] := simplifySyntactically( sidea >= Dom::Interval::left(sideb) );
                      end_if;
                    end_if;
                  end_if;
                  v := intersectSet( v, sideb, sidea );
                  if type(v)=DOM_BOOL  then return(v); end_if;
                  v := op(v,1);
                else
                  v := sideb;
                end_if;
              end_if;
              if indets( sideb ) minus Type::ConstantIdents <> {} then break; end_if;
              v := [ v, R_, 1, constDep, {}, {}, {condIndex}, condDep ];

              v := checkImplicants( sidea, v );
              if type(v)=DOM_BOOL then return(v); end_if;

              updateCond( sidea, v );
            end_if;
            break;

          of "_equal" do
          of "_less" do
          of "_leequal" do
            i1 := indets( op(xpr,1) ) minus Type::ConstantIdents;
            i2 := indets( op(xpr,2) ) minus Type::ConstantIdents;
            j := 0;
            if i1<>{} then j:=j+1; end_if;
            if i2<>{} then j:=j+2; end_if;
            if j=1 or j=2 then
              sidea := op(xpr,j);
              v := mapIV( sidea );

              if v<>FAIL then
                v := intersectCS( v, type(xpr), j, op(xpr,3-j), sidea );
              else
                v := createCS( type(xpr), j, op(xpr,3-j) );
              end_if;

              /* v=FALSE means this condition is a contradiction */
              /* v=TRUE means this condition is redundant */
              if type(v)=DOM_BOOL then return(v); end_if;

              v := checkImplicants( sidea, v );
              if type(v)=DOM_BOOL then return(v); end_if;

              updateCond( sidea, v );
            else
              [ sidea, sideb ] := [ op(xpr) ];
              if typereal( sidea )<>TRUE or typereal( sideb )<>TRUE then break; end_if;
              v := mapIV( sidea-sideb );
              if v<>FAIL then
                if type(xpr)="_leequal" then
                  s := v[1] intersect Dom::Interval( -infinity, [0] );
                else
                  s := v[1] intersect Dom::Interval( -infinity, 0 );
                end_if;
                if s={} then return( FALSE ); end_if;
                if s=v[1] then cond[condIndex]:=TRUE; return( TRUE ); end_if;
                if s={0} then cond[condIndex] := subsop( cond[condIndex], 0=hold(_equal) ); end_if;
              end_if;
            end_if;
            break;
          end_case;
          UNKNOWN;
      end_proc: /* _simplifyExpr::checkCondition */

      simplify_and := proc()
        local v, i, l, r;
      begin
        /* sort set by inclusion of indets */
        cond := sort( [op(cond)], proc(x,y)
            local a,b;
          begin
            a := freeIndets(x); b := freeIndets(y);
            if a<>b then return( _subset( freeIndets(x), freeIndets(y) )=TRUE ); end_if;
            return( type(y)="_or" or type(y)="_not" );
          end_proc );
        condlist := [ i $ i=1..nops(cond) ];

        while nops(condlist)>0 do
          condIndex := condlist[1]; delete condlist[1];
          v := checkCondition( cond[condIndex], TRUE );
          if v=FALSE then return(FALSE); end_if;
          if v=TRUE then cond[condIndex] := TRUE; end_if;
        end_while;

        /* remove all _intersects */
        cond := split( cond, X->type(X)="_in" and type(op(X,2))="_intersect" );
        for i in cond[1] do
          cond[2] := cond[2].( map( [op(op(i,2))], X-> op(i,1) in X ) );
        end_for;
        /* remove all intervals with one border being infinity */
        cond := split( cond[2], X->type(X)="_in" and type(op(X,2))=Dom::Interval );
        for i in cond[1] do
          l := Dom::Interval::leftB( op(i,2) );
          r := Dom::Interval::rightB( op(i,2) );
          if l=-infinity then
            if r=infinity then
              cond[2] := cond[2].[ op(i,1) in R_ ];
            else
              cond[2] := cond[2].[ _if( type(r)=DOM_LIST, op(i,1) <= op(r), op(i,1) < r ) ];
            end_if;
          else
            if r=infinity then
              cond[2] := cond[2].[ _if( type(l)=DOM_LIST, op(i,1) >= op(l), op(i,1) > l ) ];
            else
              cond[2] := cond[2].[ i ];
            end_if;
          end_if;
        end_for;

        return( _and(op(cond[2])) );
      end_proc: /* _simplifyExpr::simplify_and */

      /* removeSet( xpr )
       * produces better readable expressions of sets
       * e.g.: x in Dom::Interval( -infinity, 0 ) intersect Z_ => x < 0 and x in Z_
       */
      removeSet := proc( xpr )
        local l,r,iv;
      begin
        if type( xpr )="_in" and type(op(xpr,2))="_intersect" then
          return( _and( map( op(op(xpr,2)), X-> op(xpr,1) in X ) ) );
        elif type(xpr)="_in" and type(op(xpr,2))=Dom::Interval then
          iv := op(xpr,2);
          l := Dom::Interval::leftB( iv );
          r := Dom::Interval::rightB( iv );
          if l=-infinity then
            if r=infinity then
              return( op(xpr,1)  in R_ );
            else
              return( _if( type(r)=DOM_LIST, op(xpr,1)  <= op(r), op(xpr,1)  < r ) );
            end_if;
          else
            if r=infinity then
              return( _if( type(l)=DOM_LIST, op(xpr,1)  >= op(l), op(xpr,1)  > l ) );
            else
              return( xpr );
            end_if;
          end_if;
        else
          return( xpr );
        end_if;
      end_proc:

      simplify_or := proc()
        local v, i;
      begin
        cond := sort( [op(cond)], proc(x,y)
            local a,b;
          begin
            a := freeIndets(x); b := freeIndets(y);
            if a<>b then return( _subset( freeIndets(x), freeIndets(y) )=TRUE ); end_if;
            return( type(y)="_and" );
          end_proc );
        condlist := [ 1+nops(cond)-i $ i=1..nops(cond) ];
        condlist := [ i $ i=1..nops(cond) ];

        while nops(condlist)>0 do
          condIndex := condlist[1]; delete condlist[1];
          v := checkCondition( cond[condIndex], FALSE );
          if v=FALSE then cond[condIndex]:=FALSE; end_if;
          if v=TRUE then return(TRUE); end_if;
        end_while;

//        if type(cond)="_or" then cond := _not( _simplifyExpr( _not(cond) ) ); end_if;

        return( _or(op(cond)) );
      end_proc: /* _simplifyExpr::simplify_or */

      inds := freeIndets( cond );
      if implicants=null() then
        implicants := table();
      end_if;
      if constraints=null() then
        constraints := table();
        for i in inds do
          case type( ( v := necessary[i] ) )
            of solvelib::BasicSet do
                if v<>C_ then
                  constraints[ i ] := [ Dom::Interval( -infinity, infinity), v , 1, {} $ 4, [FALSE $ 3] ];
                else
                  constraints[ i ] := [ C_, C_, 1, {} $ 4, [FALSE $ 3] ];
                end_if;
                break;
            of "_intersect" do
              /* do we have an Interval */
              if ( j:=contains( map( [op(v)], type ), Dom::Interval ) )=0 then
                iv := Dom::Interval( -infinity, infinity );
              else
                if indets( op(v,j) ) minus Type::ConstantIdents={} then
                  iv := op(v,j);
                else
                iv := Dom::Interval( -infinity, infinity );
                end_if;
              end_if;
              /* do we have a solvelib::BasicSet */
              if ( k:=contains( map( [op(v)], type ), solvelib::BasicSet ) )=0 then
                bs := R_;
              else
                bs := op(v,k);
              end_if;
              /* build constraint */
              if i<>0 or j<>0 then
                constraints[ i ] := [ iv, bs , 1, {} $ 4, [FALSE $ 3] ];
              else
                constraints[ i ] := [ C_, C_ , 1, {} $ 4, [FALSE $ 3] ];
              end_if;
              break;
            of DOM_SET do
            of Dom::Interval do
              if indets(v) minus Type::ConstantIdents <> {} then
                constraints[ i ] := [ C_, C_ , 1, {} $ 4, [FALSE $ 3] ];
                break;
              end_if;
              constraints[ i ] := [ v, R_ , 1, {} $ 4, [FALSE $ 3] ];
              break;
            otherwise
              constraints[ i ] := [ C_, C_ , 1, {} $ 4, [FALSE $ 3] ];
          end_case;
        end_for;
      else
        for i in constraints do
          constraints[ op(i,1) ] := [ op(op(i,2),1..3), {} $ 4, [FALSE $ 3] ];
        end_for;
      end_if;

      case type(cond)
        of "_and" do
          cond := simplify_and( cond );
          break;
        of "_or" do
          cond := simplify_or( cond );
          break;
        otherwise
          condIndex := 1; cond := [cond];
          condlist := [1];
          v := checkCondition( cond[1], TRUE );
          if v=TRUE or v=FALSE then return(v); end_if;
          cond := removeSet( op(cond) );
          break;
      end_case;
      /* add our information to the necessary-table */
      /*for i in constraints do
        if type(op(i,1))=DOM_IDENT then
          necessary[ op(i,1) ] := necessary[ op(i,1) ] intersect op(i,[2,1]);
          if contains(realvars,op(i,1)) or _subset( necessary[ op(i,1) ], R_ )=TRUE then realvars := realvars union {op(i,1)} end_if;
        end_if;
      end_for;*/
      return( cond );
  end_proc: /* _simplifyExpr */

  simplifyChainedConditions := proc( cond )
    local s, inds, condIndex, xpr, dxpr, getBounding, v, i,
      checkExpr; /* proc */
  begin

    /* getBounding(xpr)
     * returns a list of possible upper/lower boundaries for xpr. the boundaries may exceed the real boundaries, but
     * may not be smaller. this means [getBounding(lower),getBounding(upper)] must be a superset of the real
     * value set.
     * returns a list [{open},{close}] where open may not be reached but close may be reached.
     */
    getBounding := proc( xpr, upper=TRUE, blocked={} )
      local s, v, ret, lhs, rhs, i, cls, all;
    begin
      case type(xpr)
        of "_plus" do
          v := map( [op(xpr)], getBounding, upper, blocked );
          if contains( v, FAIL )>0 then return(FAIL); end_if;
          all := _plus(  op(map(v, X->_union(op(X,1),op(X,2)) )) );
          cls := _plus(  op(map(v,op,2)) );
          return( [ all minus cls, cls ] );
        of "_mult" do
          s := split( xpr, X->freeIndets(X)={} );
          if type( s[2] )="_mult" then return(FAIL); end_if;
          v := property::constRel( s[1]>0 );
          if v=TRUE then return( map( getBounding(s[2], upper,blocked ), _mult, s[1] ) ); end_if;
          if v=FALSE then return( map( getBounding(s[2], not upper,blocked ), _mult, s[1] ) ); end_if;
          break;
        of "_power" do
          return( [ {}, { xpr } ] );
          s := map( getBounding( op(xpr,1), TRUE,blocked ), abs );
          v := map( getBounding( op(xpr,1), FALSE,blocked ), abs );
          ret := zip( s, v, max );
break;
print( xpr, ret, s, v, upper );
          if type(op(xpr,2))=DOM_INT then
            return( _power( max( abs(getBounding( op(xpr,1), TRUE,blocked )), abs(getBounding( op(xpr,1), FALSE,blocked )) ), op(xpr,2) ) );
          end_if;
          break;
        of DOM_IDENT do
          v := necessary[ xpr ];
          /* check properties */
          if type(v)=Dom::Interval then
            if upper then
              if Dom::Interval::isrightopen(v) then
                ret := [ {Dom::Interval::right(v)}, {} ];
              else
                ret := [ {}, {Dom::Interval::right(v)} ];
              end_if;
            else
              if Dom::Interval::isleftopen(v) then
                ret := [ {Dom::Interval::left(v)}, {} ];
              else
                ret := [ {}, {Dom::Interval::left(v)} ];
              end_if;
            end_if;
          elif type(v)="_intersect" then
            ret := [{},{}];
            s := select( [op(v)], X->type(X)=Dom::Interval );
            if upper then
              for v in s do
                if Dom::Interval::isrightopen(v) then
                  ret := zip( ret, [ {Dom::Interval::right(v)}, {} ], _union );
                else
                  ret := zip( ret, [ {}, {Dom::Interval::right(v)} ], _union );
                end_if;
              end_for;
            else
              for v in s do
                if Dom::Interval::isleftopen(v) then
                  ret := zip( ret, [ {Dom::Interval::left(v)}, {} ], _union );
                else
                  ret := zip( ret, [ {}, {Dom::Interval::left(v)} ], _union );
                end_if;
              end_for;
            end_if;
          else
            ret := [{},{}];
          end_if;
          /* check other conditions */
          for i from 1 to nops(cond) do
            if i<>condIndex and not contains( blocked,i ) and (v := cond[i])<>TRUE then
              case type(v)
                of "_in" do
                  if type(op(v,2))<>Dom::Interval then break; end_if;
                  if upper then
                    if Dom::Interval::isrightopen(op(v,2)) then
                      v := op(v,1) < Dom::Interval::right(op(v,2));
                    else
                      v := op(v,1) <= Dom::Interval::right(op(v,2));
                    end_if;
                  else
                    if Dom::Interval::isleftopen(op(v,2)) then
                      v := op(v,1) > Dom::Interval::left(op(v,2));
                    else
                      v := op(v,1) >= Dom::Interval::left(op(v,2));
                    end_if;
                  end_if;
                of "_less" do
                of "_leequal" do
                of "_equal" do
                  [ lhs, rhs ] := [op(v)];
                  if upper then
                    if lhs<>xpr then
                      if ( s := Type::Linear( lhs, [xpr] ) )<>FALSE and decide(s[1]<>0)=TRUE and typereal(s)=TRUE then
                        rhs := ( rhs - s[2] )/s[1];
                        if ( s := getBounding( rhs, upper, blocked union {i} ) )<>FAIL then
                          if type(v)="_less" then
                            ret[1] := ret[1] union s[1] union s[2];
                          else
                            ret := zip( ret , s, _union );
                          end_if;
                        end_if;
                      else
                        next;
                      end_if;
                    end_if;
                    lhs := _if (type(v)="_less", [ {rhs}, {} ], [ {}, {rhs} ] );
                  else
                    if rhs<>xpr then next; end_if;
                      if ( s := Type::Linear( rhs, [xpr] ) )<>FALSE and decide(s[1]<>0)=TRUE and typereal(s) then
                        lhs := ( lhs - s[2] )/s[1];
                        if ( s := getBounding( lhs, upper, blocked union {i} ) )<>FAIL then
                          if type(v)="_less" then
                            ret[1] := ret[1] union s[1] union s[2];
                          else
                            ret := zip( ret , s, _union );
                          end_if;
                        end_if;
                      else
                        next;
                      end_if;
                    lhs := _if (type(v)="_less", [ {lhs}, {} ], [ {}, {lhs} ] );
                  end_if;
                  ret := zip( ret , lhs, _union );
                  break;
              end_case;
            end_if;
          end_for;
          ret := zip( ret, [ {},{xpr} ], _union );
          return( ret );
        of DOM_RAT do
        of DOM_COMPLEX do
        of DOM_FLOAT do
        of DOM_INT do
          return( [{}, {xpr}] );
      end_case;
      FAIL;
    end_proc:

     if type( cond )="_and" then
      /* select all conditions with at least two identifiers */
      s := split( [ op(cond) ], X->( nops( freeIndets(X) )>=1 and contains( {"_equal", "_unequal", "_not", "_less", "_leequal", "_in"}, type(X) ) ) );
      if s[1]=[] then return( cond ); end_if;
    elif contains(  { "_equal", "_unequal", "_less", "_leequal", "_in", "_not" }, type( cond ) ) then
      if nops( freeIndets(cond) )>1 then
        s := [ [cond], [], [] ];
      else
        return( cond );
      end_if;
    else
      return( cond );
    end_if;

    checkExpr := proc( xpr )
      local v, dxpr, lhs, a, lb, rb, lc, rc, has0;
    begin
      case type(xpr)
        of "_not" do
          v := checkExpr( op(xpr) );
          return( not(v) );
        of "_in" do
          if type(op(xpr,2))<>Dom::Interval then break; end_if;
          lhs := op(xpr,1);
          a := op(xpr,[2,2]);
          if type(a)=DOM_LIST then
            rc := lhs<=op(a);
          else
            rc := lhs<a;
          end_if;
          v := checkExpr( rc );

          if v=FALSE then return(FALSE); end_if;
          rb := bool(v=TRUE);

          a := op(xpr,[2,1]);
          if type(a)=DOM_LIST then
            lc := lhs>=op(a);
          else
            lc := lhs>a;
          end_if;
          v := checkExpr( lc );
          if v=FALSE then return(FALSE); end_if;
          lb := bool(v=TRUE);

          if lb and rb then
            return(TRUE);
          elif lb then
            return( rc );
          elif rb then
            return( lc );
          end_if;
          break;
        of "_less" do
        of "_leequal" do
          dxpr := op(xpr,1)-op(xpr,2);
          has0 := FALSE;
          /* if lhs -rhs<0 is FALSE then lhs<rhs is FALSE */
          v := getBounding(dxpr,FALSE);
          if v<>FAIL then
            if type(xpr)="_leequal" then
              if contains( op(v,2), 0 ) then has0 := TRUE; end_if;
              v := map( op(v,1), X->decide( X>=0 ) ) union map( op(v,2), X->decide( X>0 ) );
            else
              v := map( op(v,1), X->decide( X>=0 ) ) union map( op(v,2), X->decide( X>=0 ) );
            end_if;
            if contains( v, TRUE ) then return(FALSE); end_if;
          end_if;

          //if typereal(op(xpr,1))<>TRUE and typereal(op(xpr,2))<>TRUE then break; end_if;
          v := getBounding(dxpr);
          if v<>FAIL then
            if type(xpr)="_leequal" then
              v := map( op(v,1), X->decide( X<=0 ) ) union map( op(v,2), X->decide( X<=0 ) );
            else
              v := map( op(v,1), X->decide( X<=0 ) ) union map( op(v,2), X->decide( X<0 ) );
            end_if;
            if contains( v, TRUE ) then
              return(TRUE);
            end_if;
            if has0 then
              xpr := simplifySyntactically( op(xpr,1)=op(xpr,2) );
            end_if;
          end_if;
          break;
        of "_equal" do
        of "_unequal" do
          if typereal(op(xpr,1))<>TRUE or typereal(op(xpr,2))<>TRUE then break; end_if;
          dxpr := op(xpr,1)-op(xpr,2);
          v := getBounding(dxpr);
          if v<>FAIL then
            v := map( op(v,1), X->decide( X<0 ) ) union map( op(v,2), X->decide( X<0 ) );
            if contains( v, TRUE ) then return( bool(type(xpr)="_unequal") );  end_if;
          end_if;

          v := getBounding(dxpr,FALSE);
          if v<>FAIL then
            v := map( op(v,1), X->decide( X>0 ) ) union map( op(v,2), X->decide( X>0 ) );
            if contains( v, TRUE ) then return( bool(type(xpr)="_unequal") );  end_if;
          end_if;
          break;
      end_case;
      xpr
    end_proc:

    cond := s[1];
    for condIndex from 1 to nops(cond) do
      xpr := cond[condIndex];
      v := checkExpr( xpr );
      if v=FALSE then return(FALSE); end_if;
      cond[condIndex] := v;
    end_for;
    return( _and( op(cond), op(s[2]) ) );
  end_proc: /* simplifyChainedConditions */

  _simplifyCondition := proc( cond )
    local s, inds, i, boolExpr, ncond, val, oldnecessary, oldrealvars;
    save realvars;
  begin
    oldnecessary := null();
    oldrealvars := realvars;

    /* simplify syntactically */
    cond := simplifySyntactically( cond );

    /* schnelle Entscheidungen */
    case type(cond)
      of DOM_BOOL do
        return(cond);
      of "_equal" do
      of "_unequal" do
      of "_less" do
      of "_leequal" do
        //if _subset( {type(op(cond,1)),type(op(cond,2))}, { DOM_IDENT, DOM_INT, DOM_RAT, DOM_FLOAT, DOM_COMPLEX} )=TRUE then return( cond ); end_if;
        break;
      of "_and" do
      of "_or" do
        oldnecessary := necessary; /* the table could be edited by _simplifyExpr */
        break;
    end_case;
//return(cond);
    /* this does real interval arithmetics to decide conditions */
    cond := _simplifyExpr( cond );
//return(cond);
    /* this part is especially to decide conditions with chained relations, e.g. x<y and y<z and z<x */
    cond := simplifyChainedConditions( cond );
//return(cond);

    if oldnecessary<>null() then necessary := oldnecessary; end_if;
    realvars := oldrealvars;

    /* this part solve for idents and tries to intersect/unite the sets */
    inds := indets(cond) minus Type::ConstantIdents;
    if contains( {"_or","_and"}, type( cond ) ) then

      for i in inds do
        boolExpr := op(cond,0);
        s := split( cond, X->contains( indets(X), i ) );
        if not contains({TRUE,FALSE}, s[1]) then
          val := _simplifyConditionForIdent( s[1], i );
          val := _simplifyConditionSet( val );
          ncond := eval(boolExpr( s[2], val ));
          if Simplify::defaultValuation( cond )>Simplify::defaultValuation( ncond ) then
            cond := ncond;
            if not contains( {"_or","_and"}, type( cond ) ) then break; end_if;
          end_if;
        end_if;
      end_for;
    else
      for i in inds do
          val := _simplifyConditionForIdent( cond, i );
          ncond := _simplifyConditionSet( val );
          if Simplify::defaultValuation( cond )>Simplify::defaultValuation( ncond ) then
            cond := ncond;
          end_if;
      end_for;
    end_if;

    cond;
  end_proc:

  /* simplifyConditionForIIdent ( cond, ident )
   */
  _simplifyConditionForIdent := proc( cond, ident )
    local i, res, v, wasAnd, t, ncond;
  begin
    t := table();
    if contains( {"_or","_and"}, type( cond ) ) then
      wasAnd := bool( type(cond)="_and" );
      ncond := map( [op(cond)], X->_if( contains( {"_or","_and"}, type(X) ), _simplifyConditionForIdent(X, ident), X )  );
      i := 1;
      while i<=nops(ncond) do
        res := _simplifyConditionMapToSet( ( v := op(ncond,i) ), ident, 1 );
        if res<>FAIL then
          t[v] := res;
          ncond[i] := null();
          i := i-1;
        end_if;
        i := i+1;
      end_while;

      if nops(t)>1 then
        v := map( op(t), op, 2 );
        if wasAnd then v := _intersect(v); else v := _union(v); end_if;
        cond :=( ident in v ), op(ncond);
        if wasAnd then cond := _and(cond); else cond := _or(cond); end_if;
      end_if;
    else
        res := _simplifyConditionMapToSet( cond, ident, 1, TRUE );
        if res<>FAIL then return( ident in res ); end_if;
    end_if;
    cond;
  end_proc:

  _simplifyConditionSet := proc( xpr, intersectProperties=TRUE )
    local l, r, ident, set, v;
  begin
//print(xpr);
    case type(xpr)
      of "_and" do
      of "_or" do
        return( map(xpr, _simplifyConditionSet ) );
      of "_in" do
        break;
      otherwise
        return(xpr);
    end_case;
    set := op(xpr,2);
    ident := op(xpr,1);
    if set={} then return( FALSE ); end_if;
    if intersectProperties and contains(necessary,ident) and necessary[ident]<>C_ then
      set :=_intersect( set, necessary[ident] );
      set := simplify::simplifySets(set);
      if set=necessary[ident] then return(TRUE); end_if;
      if type(set)="_intersect" then
        v := contains( [op(set)], necessary[ident] );
        if v>0 then set := simplify::simplifySets( subsop( set, v=C_ ) ); end_if;
      end_if;
      if set=C_ then return( TRUE ); end_if;
      if set={} then return( FALSE ); end_if;
    else
      set := simplify::simplifySets(set);
    end_if;
    case type( set )
      of "_minus" do
        if op(set,1)=C_ or (contains(necessary,ident) and op(set,1)=necessary[ident] )  then
          return( _not( _simplifyConditionSet( ident in op(set,2), FALSE ) ) );
        end_if;
        return( ident in op(set,1) and _not( _simplifyConditionSet( ident in op(set,2), FALSE ) ) );
        break;
      of "_intersect" do:
        return( _and( op( map( [op(set)], X->_simplifyConditionSet( ident in X, FALSE ) ) ) ) );
      of "_union" do:
        return( _or( op( map( [op(set)], X->_simplifyConditionSet( ident in X, FALSE ) ) ) ) );
      of DOM_SET do:
        return(  _or( op(map( (set), X->ident = X  )) ) );
      of Dom::Interval do
        l := Dom::Interval::leftB( op(xpr,2) );
        r := Dom::Interval::rightB( op(xpr,2) );
        if l=-infinity then
          if r=infinity then
            return( op(xpr,1) in R_ );
          else
            return( _if( type(r)=DOM_LIST, op(xpr,1) <= op(r), op(xpr,1) < r ) );
          end_if;
        else
          if r=infinity then
            return( _if( type(l)=DOM_LIST, op(xpr,1) >= op(l), op(xpr,1) > l ) );
          else
          end_if;
        end_if;
        break;
    end_case;
    return( xpr );
  end_proc:

  _simplifyConditionMapToSet := proc( cond, ident, lev, singleOp=FALSE )
    local res;
  begin
    if type(cond)="_in" and op(cond,1)=ident then
      res := op(cond,2);
    else
      if singleOp and contains( {"_equal", "_unequal", "_less", "_leequal"}, type(cond) ) then
        /* this does not need to be solved if ident has a explicit representation */
        res := poly( op(cond,1)-op(cond,2), [ident] );
        if res<>FAIL and degree(res)<=1 and not has(coeff(res,0), ident) then return(FAIL); end_if;
      end_if;

      res := __simplifyConditionMapToSet( cond, ident, lev, singleOp );
    end_if;

    /* don't return any sets containing indets. this should have been handled before */
    if res<>FAIL and freeIndets(res)<>{} then res:=FAIL; end_if;
    res;
  end_proc:

  __simplifyConditionMapToSet := proc( cond, ident, lev, singleOp )
    local A, lin, p;
    save MAXEFFORT;
  begin
    if type(cond)="_not" then
      A := _simplifyConditionMapToSet( op(cond), ident, lev, singleOp );
      if A=FAIL then
        return(FAIL);
      else
        return( necessary[ident] minus A );
      end_if;
    end_if;

    case lev
      of 1 do: case type( cond )
          of "_unequal" do
            if {ident} intersect indets(op(cond,1)) intersect indets(op(cond,2))={} then
              if op(cond,1)=ident then
                /* if we have only one operand this should already have been decided */
                if singleOp then return( FAIL ); end_if;
                return( C_ minus {op(cond,2)} );
              elif op(cond,2)=ident then
                /* if we have only one operand this should already have been decided */
                if singleOp then return( FAIL ); end_if;
                return( C_ minus {op(cond,1)} );
              end_if;
            end_if;
            break;
          of "_equal" do
            A := op(cond,1)-op(cond,2);
            if indets( cond ) minus Type::ConstantIdents <> {ident} then return( FAIL ); end_if;
            if ( lin := Type::Linear( A, [ident] ) )<>FALSE and lin[1]<>0 then
              return( {-lin[2]/lin[1]} );
            end_if;
            break;
          of "_less" do
            if op(cond,1)=ident and indets(op(cond,2)) minus Type::ConstantIdents={} then
              return( Dom::Interval( -infinity, op(cond,2) ) );
            end_if;
            if op(cond,2)=ident and indets(op(cond,1)) minus Type::ConstantIdents={} then
              return( Dom::Interval( op(cond,1), infinity ) );
            end_if;
            break;
          of "_leequal" do
            if op(cond,1)=ident and indets(op(cond,2)) minus Type::ConstantIdents={} then
              return( Dom::Interval( -infinity, [op(cond,2)] ) );
            end_if;
            if op(cond,2)=ident and indets(op(cond,1)) minus Type::ConstantIdents={} then
              return( Dom::Interval( [op(cond,1)], infinity ) );
            end_if;
            break;
          of "_in" do
            p := poly( op(cond,1), [ident] );
            if p=FAIL then return(FAIL); end_if;
            if degree(p)=0 then return(FAIL); end_if;
            if degree(p)=1 then
              if singleOp and contains( {R_,C_}, necessary[ident] ) then return(FAIL); end_if;
              A := ( op(cond,2) - coeff(p,0) ) / coeff(p,1);
              if freeIndets(A)<>{} then return(FAIL); end_if;
              return( A );
            end_if;
          end_case;

      of 2 do: if OPTIONS[UseSolver] then case type(cond)
        of "_unequal" do
          A := indets(cond) minus Type::ConstantIdents;
          if A={ident}  then
            MAXEFFORT := 1000.0;
            A := solve( op(cond,1)=op(cond,2), ident, MaxRecLevel = 5);
            if has((A),solve) then break; end_if;
            return( necessary[ident] minus A );
          end_if;
          break;
        of "_in" do
        of "_equal" do
          A := indets(cond) minus Type::ConstantIdents;
          if A={ident}  then
            MAXEFFORT := 1000.0;
            A := solve(cond, ident, MaxRecLevel = 5);
            if has((A),solve) then break; end_if;
            return( A );
          end_if;
          break;
      end_case; end_if;
      break;

    end_case;
    FAIL;
  end_proc:

  /* Optionen auslsesn */
  OPTIONS := table( UseSolver=TRUE );
  OPTIONS := prog::getOptions( OPTIONS, [args(2..args(0))] );

  necessary := table();
  for i in inds do
    if ( property::hasprop( i ) ) then
      necessary[i] := property::prop2set( getprop(i) );
    else
      necessary[i] := C_;
    end_if;
  end_for;

  result := [];
  realvars := map( select( {op(necessary)}, X->bool( _subset( op(X,2), R_ )=TRUE ) ), op, 1 );
  unrealvars := {};
  if contains( {"_or", "_and" }, typecond ) then
    if inds={} then
      s := [op(cond)]
    else
      s := simplify::splitCond(cond);
    end_if;
    for i from 1 to nops(s)  do
      v := _simplifyCondition( s[i] );
      if v=TRUE or v=FALSE then
        if v=TRUE and typecond="_or" then return( TRUE ); end_if;
        if v=FALSE and typecond="_and" then return( FALSE ); end_if;
      else
        if type(v)=typecond then v:=op(v);end_if;
        result := result.[v];
      end_if;
    end_for;
    if nops(result)>1 then
      eval( op(cond,0)( op(result) ) );
    elif nops(result)=0 then
      bool(typecond="_and");
    else
      op(result);
    end_if;
  else
    _simplifyCondition( cond );
  end_if;
end_proc:

simplify::splitCond := proc ( cond )
  local t, i, v, ind, j;
begin
  if not contains( { "_or", "_and" }, type( cond ) ) then
    return( cond );
  end_if;
  t := table();
  for i in [op(cond)] do
    ind := indets(i) minus Type::ConstantIdents;
    v := select( [op(t)], X->op(X,1) intersect ind<>{} );
    if nops(v)=0 then
      if contains( t, ind ) then
        t[ind] := t[ind],i;
      else
        t[ind] := i;
      end_if;
    else
      for j in map( v, op, 1 ) do
        delete t[j];
        ind := ind union j;
      end_for;
      i := i, op(map( v, op, 2 ));
      t[ind] := i;
    end_if;
  end_for;
  if contains( t, {} ) then
    v := [t[{}]];
    delete t[{}];
    v.map( [op(t)], X->( _if( type( (i:=op(X,2)) )="_exprseq", op(cond,0)( i ), i ) ) );
  else
    map( [op(t)], X->( _if( type( (i:=op(X,2)) )="_exprseq", op(cond,0)( i ), i ) ) );
  end_if;
end_proc:

simplify::simplifyCondition := prog::remember( simplify::simplifyCondition, property::depends ):
//simplify::simplifyCondition := prog::remember( simplify::simplifyCondition, property::depends, hold(PreventRecursion), UNKNOWN):
