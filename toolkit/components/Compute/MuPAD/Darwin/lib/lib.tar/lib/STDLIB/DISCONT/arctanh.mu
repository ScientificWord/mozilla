arctanh::complexDiscont :=
  Dom::Interval(-infinity, [-1]) union Dom::Interval([1], infinity):
