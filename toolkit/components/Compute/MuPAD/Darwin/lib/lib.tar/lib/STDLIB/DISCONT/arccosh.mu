// Folgendes complexDiscont ist richtig!  Fehler in  Abramowitz/Stegun!
arccosh::complexDiscont :=
    Dom::Interval(-infinity, -1) union Dom::Interval(1, infinity):
