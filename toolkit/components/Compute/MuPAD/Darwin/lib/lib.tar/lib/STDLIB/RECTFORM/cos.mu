// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	cos/rectform -- the function attribut "rectform" for cos
--*/

cos := slot( cos, "rectform", proc(xx)
        local a, b, x;
    begin
        x:= rectform::new(xx);

        if extop(x,3) <> 0 then
            new(rectform,0,0,hold(cos)(rectform::expr(x)))
        else
            a := extop(x,1);
            b := extop(x,2);
            if domtype(a+I*b) = DOM_COMPLEX
               and (domtype(a) = DOM_FLOAT or domtype(b) = DOM_FLOAT)
            then
                rectform::new(cos(a+I*b))
            else
                new(rectform,cos(a)*cosh(b),-sin(a)*sinh(b),0)
            end_if
        end_if
    end_proc
):

// end of file 
