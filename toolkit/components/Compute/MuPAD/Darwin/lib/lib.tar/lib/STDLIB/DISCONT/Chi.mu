Chi::complexDiscont:= Dom::Interval(-infinity, [0]):
