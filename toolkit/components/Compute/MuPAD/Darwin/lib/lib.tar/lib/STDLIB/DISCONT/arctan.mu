genident("z"):

arctan::complexDiscont:=
   Dom::ImageSet(%*I, %, Dom::Interval(-infinity, [-1]) union
                 Dom::Interval([1], infinity)):
