// $Date: 2006-12-05 13:05:41 +0100 (Tue, 05 Dec 2006) $ $Author: Stefan Wehmeier $ $Revision: 41898 $ 

/*--
	simplify/exp -- the function attribut "exp" for simplify

	simplifies expressions containing exponentials
        with algebraic dependencies, for example exp(x)
        and exp(x/2), by substituting with new variables,
        calling simplify, and substituting back.
--*/

simplify::exp:=
proc(a)
  name simplify::exp;
  local l,e,i,m,j,found,s, inds;
begin
  a:= combine::exp(a);
  l:=[]; // list of arguments of exponentials
  m:=[]; // list of substituted variables
  s:=[]; // list of substitutions
  for e in DOM_SET::sort(indets(a,RatExpr)) do
    if type(e)="exp" then
      found:=FALSE;
      for j from 1 to nops(l) do
        i:=op(e)/l[j];
        if contains({DOM_INT,DOM_RAT},type(i)) then
          if abs(i)>1 then
            s:=append(s,e=m[j]^i)
          else
            s:=subs(s,m[j]=m[j]^(1/i));
            s:=append(s,e=m[j]);
            l[j]:=op(e);
          end_if;
          found:=TRUE;
          break
        end_if
      end_for;
      if not found then
        l:=append(l,op(e));
        j:=genident();
        /* it is necessary to declare that j depends on all indeterminates
             of e because it could affect the evaluation of integrals and
           limits if j were assumed to be independent of the
           integration/limit variable
        */
        inds:= op(indets(e));
        m:=append(m, j(inds));
        s:=append(s,e=j(inds));
      end_if
    end_if;
  end_for;
  // here, the recursive call to simplify is necessary
  // because simplification has to happen before re-substitution
  if nops(s) > 0 then
    a:= simplify(normal(subs(a,s)), args(2..args(0)));
    for j from 1 to nops(l) do
      a:= subs(a,m[j]=exp(l[j]))
    end_for;
  end_if;
  a
end_proc:

// end of file 
