
/* The simplify attribute of tan

   Rules:
   1) tan(x)            -> apply simplify and stdlib::normalizesign to x
   2) tan(x + k*PI/2)   -> (-1)^k * tan/cot (x + frac(k)*PI/2)
                           if domtype(k) = DOM_RAT
   3) tan(x + k*PI/2)   -> (-1)^k * tan/cot (x) if is(k, Type::Residue(?,2))
   4) tan(x)            -> -tan(-x) if stdlib::hasmsign(x) = TRUE

Author: Juergen Gerhard, 14.4.00
*/

tan := slot(tan, "simplify", proc(a)
   name tan::simplify;
   local x, l, i, e, rest, integer_expo, prop, tmp, sgn;
begin
   // recursively simplify the argument
   /* the double simplify is a workaround for the following simplify bug:
      simplify((x+y)^2) -> (x+y)^2, but
      simplify(-(x+y)^2) -> x^2+2*x*y+y^2 */
   x := simplify(-simplify(-op(a)));
   x := _mult(op(stdlib::normalizesign(x))):

   /* final integer exponent of -1 */
   integer_expo := 0;
   // finally remaining arguments
   rest := 0;

   // l := list of summands
   if type(x) = "_plus" then
     l := [op(x)]
   else
     l := [x]
   end_if;

   // l := list of pairs [summand, summand*2/PI]
   l := map(l, proc(x) begin [x, x*2/PI] end_proc);

   /* check whether there is a summand with domtype(summand*2/PI) =
      DOM_RAT or DOM_INT (there can be at most one) */
   l := split(l, proc(x) begin
     contains({DOM_RAT, DOM_INT}, domtype(op(x, 2))) end_proc);
   if nops(l[1]) > 0 then
     // reduce the rational number modulo 1
     tmp := op(l, [1,1,2]);
     rest := frac(tmp)*PI/2;
     integer_expo := floor(tmp) mod 2;
   end_if;

   // select those summands with is(summand*2/PI, Type::Integer) = TRUE
   l := split(l[2], proc(x) begin is(op(x, 2), Type::Integer) end_proc);

   // rest := unsimplified arguments
   rest := _plus(op(map(l[2].l[3], op, 1)), rest);
 
   // process arguments of Type::Integer
   l := l[1];
   for i from 1 to nops(l) do
     e := op(l, [i, 2]);

     // simplify exponents that are known to be odd or even
     prop := property::_getprop(e, property::Residue);
     if type(prop) = "Residue"
        and domtype(prop::dom::modulus(prop) / 2) = DOM_INT then
       integer_expo := integer_expo + prop::dom::remainder(prop) mod 2;
     else
       rest := rest + op(l, [i, 1]);
     end_if
   end_for;

   /* extract a minus sign from rest if necessary */
   sgn := 1;
   if stdlib::hasmsign(rest) then
     rest := -rest;
     sgn := -1
   end_if;

   if integer_expo = 0 then
     return(sgn * tan(rest))
   else // = 1
     return(-sgn * cot(rest))
   end_if
end_proc):
