// $Id: Option.mu 21756 2003-01-31 21:16:29Z bij $

Type::Option := Type::Union(Type::Equation(DOM_IDENT, Type::AnyType), DOM_IDENT):
Type::OptionsTable := Type::TableOfIndex(DOM_IDENT):
