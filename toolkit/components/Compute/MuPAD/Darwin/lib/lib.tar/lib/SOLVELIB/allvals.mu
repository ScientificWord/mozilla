/* allvalues(s) returns all complex solutions of a polynomial
  system, where s is the symbolic solution.

Example:
>> s:=solve({x^4+x+1,y^4+x+1},{x,y}):
>> DIGITS:=3: allvalues(s);
*/ 

solvelib::allvalues := 
proc(s)
local eq,x,sol,v;
begin
  userinfo(3, "solvelib::allvalues called with ".expr2text(s));
  case type(s)
    of DOM_SET do
       return(_union(map(s,op@solvelib::allvalues)))
    of DOM_LIST do
      if s=[] then
        return({[]})
      end_if;
      eq:=s[nops(s)];
      x:=op(eq,1);
      eq:=op(eq,2);
      delete s[nops(s)];
      if hastype(eq, RootOf) then
        misc::maprec(eq, {RootOf}=
                     proc(u)
                     begin
                       if numeric::indets(op(u,1))={op(u,2)} then
                         numeric::solve(op(u,1), op(u,2))
                       else
                         misc::breakmap();
                         u
                       end_if
                     end_proc);
        if type(%) <> DOM_SET then
          s:= map(s, float@op, 2);
          return({[op(s), x in map(eq, float)]});
        else
          eq:=[op(%)]
        end_if;
        userinfo(20, "Expanding the RootOf gives ".expr2text(eq))
      else /* can this happen ? */
        eq:=[float(eq)]
      end_if;
      sol:={};
      for v in eq do
        // works, since RootOf uses new variable
        sol:=sol union map(solvelib::allvalues(subs(s,x=v)),append,x=v)
      end_for;
      return(sol)
   of "solve" do
      if nops(s)<3 then
        warning("solution(s) may be lost");
        s:= numeric::fsolve(op(s));
        if s<>[] then
          return({s})
        end_if;
      end_if;
    otherwise
      s:= float(s);
  end_case;
  //return(hold(float)(s));
   return(float(s));
end_proc:


