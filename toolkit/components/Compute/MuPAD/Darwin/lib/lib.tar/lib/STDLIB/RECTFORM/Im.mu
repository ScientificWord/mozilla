// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	Im/rectform -- the function attribut "rectform" for Im
--*/

Im:= slot( Im, "rectform", proc(xx)
        local x;
    begin
        x:= rectform::new(xx);

        if extop(x,3) <> 0 then
            new(rectform,0,0,hold(Im)(rectform::expr(x)))
        else
            new(rectform,extop(x,2),0,0)
        end_if
    end_proc
):

// end of file 
