/* */
/* $Date: 2003-02-21 11:30:47 +0100 (Fri, 21 Feb 2003) $ $Author: stefanw $ $Revision: 22011 $ */
/* */
/* zimmerma, 14/12/95 */

/*--
	solvelib::solve_isalgebraic

	returns FALSE if sys is not an algebraic system with respect 
	to unk, otherwise
   [sys, denominators] where all equalities a=b have been 
	replaced by a-b and all 0 equations have been deleted in sys,
   and denominators contains all denominators

   Parameters:

   sys -  set or list of equations or arithmetical expressions
     u - set or list of identifiers

--*/

solvelib::solve_isalgebraic :=
proc(sys,unk)
  local eq, den, denominators, d;
begin
  denominators:= {};
  den := 1;
  for eq in sys do
    d:= denom(eq);
    den:= expand(den * d);
    denominators:= denominators union {d}
  end_for;
  if not testtype(den, Type::PolyExpr([op(unk)])) then
    return(FALSE)
  end_if;

  sys:= map(sys, numer);
  if has(map(sys, testtype,Type::PolyExpr([op(unk)])), FALSE) then
    return(FALSE)
  end_if;

    // zeroes of the denominator cannot be solutions, we may divide
    // them off 
  
  [map(sys,
      proc(eq)
        local g;
      begin
        while degree((g:= gcd(eq, den))) > 0 do
          eq:= divide(eq, g, Exact)
        end_while;
      eq
      end_proc
      ), den]
end_proc:

/* end of file */

