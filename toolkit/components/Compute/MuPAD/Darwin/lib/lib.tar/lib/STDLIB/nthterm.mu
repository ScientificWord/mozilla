// $Date: 2001-07-30 14:30:58 +0200 (Mon, 30 Jul 2001) $ $Author: kg $ $Revision: 13260 $ 


/*
   nthterm(f, n, <order>)

   return the n-th term of f w.r.t. to order (default is LexOrder)

*/


nthterm:=
proc(f, n, ord)

begin
  if args(0)=0 then
    error("nthterm called without arguments")
  end_if;
  if f::dom::nthterm <> FAIL then
    return(f::dom::nthterm(args()))
  end_if;
  if args(0)<2 or args(0)>4 then
    error("Wrong number of arguments")
  end_if;
  if type(n)=DOM_LIST then
    nthterm(poly(f,n), args(3..args(0)));
    if testtype(f, Type::Arithmetical) then
      return(expr(%))
    else
      return(%)
    end_if
  end_if;
  if args(0)=2 or ord=hold(LexOrder) then
    polylib::nthterm(f, n)
  else
    nthterm(op(polylib::sortMonomials(f, ord),n),1)
  end_if
end_proc:


