// $Date: 2007-01-17 13:07:39 +0100 (Wed, 17 Jan 2007) $ $Author: Christopher Creutzig $ $Revision: 42425 $

/*++
	int -- integration

	int(f,x)
	int(p <, ... >)
	int(f,x=a..b)
	int(f,x=a..b, options)

	f - expression or domain
	x - identifier
	p - piecewise defined function or domain element

        currently as options are allowed:
           - PrincipalValue
           - Continuous

	This is merely a front end for indefinite integration via intlib::int,
	and definite via intlib::defInt.
++*/

int:= funcenv(
prog::remember(
proc(f, x=null())
  name int;
  local integral;
begin
  if args(0)=0 then error("No argument given") end_if;

  if testargs() and has([args()],FAIL) then
    error("illegal argument(s)")
  end_if;

  if has([args()], undefined) then
    return(undefined);
  end_if;

  if f::dom::int <> FAIL then
    return( f::dom::int(args()) )
  elif testtype(f,Type::Arithmetical)=FALSE then
    error("Illegal integrand")
  end_if;

  // now f is of type DOM_EXPR
  if args(0)=1 then
      error("Second argument is missing")
  end_if;

  if domtype(x)=DOM_IDENT then
     // indefinite integration
    integral := hold(int)(args());
    traperror((integral :=
	       intlib::int(f,x,intlib::getOptions(args(3..args(0))))));
    return(integral);
  else
     if type(x)= "_equal" and type(op(x, 2)) = "_range" then
       // definite integration
       if testargs() then intlib::xrngTest(x) end_if;
       integral := hold(int)(args());
       traperror((integral :=
		  intlib::defInt(f, x, intlib::getOptions(args(3..args(0))))));
       if not hastype(integral, "int") and not hastype(integral, "limit") then
         integral := Simplify(integral);
       end_if;
       return(integral);
     else
       return(intlib::alt(args()));
//     error("Second argument must be either of form x or x=a..b")
     end_if;
  end_if
end_proc, () -> [//Pref::experimentalInt(),
		 property::depends([args()])],
PreventRecursion, ()->hold(int)(args())),
proc(a)
  local eq, integralSign, PVintegralSign;
begin
  if PRETTYPRINT = TRUE then
    integralSign := "  /",
                    " | ",
                    " | ",
                    "/  ":
    PVintegralSign := "  /",
                      "_|_",
                      " | ",
                      "/  ":
    if contains({op(a, 3..nops(a))}, PrincipalValue) then
      integralSign := PVintegralSign;
    end_if;
    if type(op(a, 2)) = "_equal" then
      // definite integral
      eq := op(a, [2,2]);
      if testtype(eq, "_range") then
        _outputSequencePower(stdlib::Exposed(stdlib::align(expr2text(op(eq, 2)),
                                                  integralSign,
                                                  expr2text(op(eq, 1)))),
                    _outputSequenceINFINITE(stdlib::Exposed(" "), op(a, 1),
                    stdlib::Exposed(" d"), op(a, [2,1])));
       else
        _outputSequencePower(stdlib::Exposed(
                                  stdlib::align(expr2text(eq), integralSign)),
                    _outputSequenceINFINITE(stdlib::Exposed(" "), op(a, 1),
                    stdlib::Exposed(" d"), op(a, [2,1])));
       end_if
     else
      // indefinite integral
      _outputSequencePower(stdlib::Exposed(stdlib::align(integralSign)),
                      _outputSequenceINFINITE(stdlib::Exposed(" "), op(a, 1),
                      stdlib::Exposed(" d"), op(a, 2)));
     end_if;
  else
    FAIL
  end:
end_proc):
int::type := "int":

int::info := "definite and indefinite integration [try ?int for details]":

int::type:= "int":
int::print:= "int":

// diff-attribute of int

int::diff :=
    proc(f)
	local i, a, u, t, x,chainmult,evaluate;
    begin
	if args(0) = 1 then return(f) end_if;

	a:= []; // variables that appear in the integration variable or the bounds
	u:= []; // other variables
	for i from 2 to args(0) do
	    if has(op(f,2), args(i)) then
		a:= append(a, args(i))
	    else
		u:= append(u, args(i))
	    end_if
	end_for;

	// exchange diff and int
	if nops(u) <> 0 then
	    return(diff(int(diff(op(f,1), op(u)), op(f,2)), op(a)))
	end_if;

	i:= contains(a, op(f,2));
	if i = 0 then
	    // diff(int(g,t=a..b),y)
	    if contains(a, (t:=op(f,[2,1]))) = 0 then
		// diff(int(g,t=a(x)..b(x)),x)
		// hold(diff)(args())
                x:=a[1]; delete a[1];
                // chainmult is necessary to prevent {+/-}infinity*0
                chainmult:=(f,d)->if d=0 then 0 else d*f end_if;
                // evaluate takes care of limitation process e.g. sin(t)/t,t=0
                evaluate:=
                  proc(g,x,dir)
                    local s;
                  begin
                    s:=NIL;
                    traperror((s:=subs(g,x)));
                    if s=NIL then
                      s:=intlib::limit(g,x,dir);
                    else
                      s
                    end_if;
                  end_proc;
                diff(chainmult(evaluate(op(f,1),t=op(f,[2,2,2]),Left),
                               diff(op(f,[2,2,2]),x))
                     -chainmult(evaluate(op(f,1),t=op(f,[2,2,1]),Right),
                                diff(op(f,[2,2,1]),x))
                     +int(diff(op(f,1),x),op(f,2)),
                     op(a))
	    else // diff(int(g,x=a..b),x)
		0
	    end_if
	else // diff(int(g,x),x)
	    delete a[i];
	    diff(op(f,1), op(a))
	end_if
    end_proc:

// float-attribute of int (numerical integration)

// old float attribute
//int:= slot(int, "float", proc(f, x) local r; begin
//   r := intlib::numint(f,x);
//   if r = FAIL then hold(int)(f, x) else r end_if
//end_proc):
// changed to new float attribute (W. Oevel, 31.8.99)

int::float := numeric::int:

int::expand :=
proc(integrand)
  local moreargs, s;
begin
  moreargs := args(2..args(0));
  integrand := expand(integrand);
  case type(integrand)
    of "_plus" do
      return(_plus(int(s, moreargs) $ s in integrand));
    of "sum" do
      return(subsop(integrand,
		    1 = int(op(integrand, 1), moreargs)));
    of "_mult" do
      s := split([op(integrand)],
		 has,
		 if type(args(2)) = "_equal" then
		   lhs(args(2))
		 else
		   args(2)
		 end_if);
      return(_mult(op(s[2]), int(_mult(op(s[1])), moreargs)));
  end_case;
  int(integrand, moreargs);
end_proc:


int::freeIndets:=
proc(J: "int")
begin
  if type(op(J, 2)) = "_equal" then
    (freeIndets(op(J, 1)) union freeIndets(op(J, [2, 2]))) minus
    freeIndets(op(J, [2, 1]))
  else  
    freeIndets(op(J, 1)) union freeIndets(op(J, 2))
  end_if
end_proc:

int::operandsToSimplify:= [1]:


int::laplace:=
    loadproc(int::laplace,
        pathname("TRANS","LAPLACE"), "L_int"):

int::addpattern :=
loadproc(int::addpattern, pathname("INTLIB"), "addpattern"):

int::Content      := proc(Out, data)
                     begin
                       if type(op(data, 2)) = "_equal" then
                         if type(op(data, [2, 2])) = "_range" then
                           // definite integral
                           Out::Capply(Out::Cint,
                                       Out::Cbvar(Out(op(data, [2,1]))),
                                       Out::Clowlimit(Out(op(data, [2,2,1]))),
                                       Out::Cuplimit( Out(op(data, [2,2,2]))),
                                       Out(op(data,1)));
                         else
                           // domain of integration
                           Out::Capply(Out::Cint,
                                       Out::Cbvar(Out(op(data, [2,1]))),
                                       Out::Ccondition(Out(op(data, [2,2]))),
                                       Out(op(data,1)));
                         end_if
                       else
                         // indefinite integral
                         Out::Capply(Out::Cint,
                                     Out::Cbvar(Out(op(data, 2))),
                                     Out(op(data,1)));
                       end_if;
                     end_proc:

int::simplify := loadproc(int::simplify,pathname("STDLIB","SIMPLIFY"), "int"):

// end of file
