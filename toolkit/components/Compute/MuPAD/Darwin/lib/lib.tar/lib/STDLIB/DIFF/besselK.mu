/*--
	besselK/diff -- the function attribute "diff" for besselK
--*/

besselK := slot(besselK,"diff",proc(e,x) // e=besselK(v,f) 
   local v,f;
begin
   if has(op(e,1),[args(2..args(0))]) then hold(diff)(args())
   // now we only have to diff. with respect to second argument 
   elif args(0)>2 then diff(diff(e,x),args(3..args(0)))
   else
      v:=op(e,1): f:=op(e,2):
      specfunc::besselDiffMain(besselK,0,v,f,[-1,-1,0,-1,1,0],x);    
   end_if:
end_proc):
