// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	igamma/diff -- the function attribut "diff" for igamma

(1) Due to the complexity compute this sum only if a < 1000 
(2) To compute igamma(x, n/2) call igamma recursively.      
    Recursion depth is ceil(abs(n/2)), so restrict this     
    computation to a maximum depth of 100                   
--*/

igamma:= slot(igamma, "diff",proc(e,y) local a,x,t;
begin
   case args(0)
   of 1 do return(e)
   of 2 do
      a:=op(e,1); x:=op(e,2); t:=genident():
      return(diff(a,y)*hold(int)(exp(-t)*t^(a-1)*ln(t),t=x..infinity)
        -diff(x,y)*exp(-x)*x^(a-1))
   otherwise diff(diff(e,y),args(3..args(0)))
   end_case
end_proc):

// end of file 
