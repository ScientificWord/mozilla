// $Date: 2006-12-07 13:07:44 +0100 (Thu, 07 Dec 2006) $ $Author: Ralf Hillebrand $ $Revision: 41939 $ 

// kg, 09/05/94 

/*++
version -- return current version number of MuPAD

version()

version returns a list with 3 integers: the major version
number, the minor version number and the release number.

Example:
version() returns [1,2,1] for the MuPAD kernel 1.2.1.
++*/

version:= proc() option noDebug;
begin
    if testargs() then
	if args(0) <> 0 then error("wrong no of args") end_if;
    end_if;
    [4, 0, 2]
end_proc:

// end of file 
