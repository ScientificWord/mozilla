// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	abs/conjugate -- the function attribut "conjugate" for abs
--*/

abs:= slot( abs, "conjugate", 
    proc(x) name abs::conjugate; begin hold(abs)(x) end 
):

// end of file 
