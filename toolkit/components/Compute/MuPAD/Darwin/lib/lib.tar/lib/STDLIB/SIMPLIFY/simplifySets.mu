// $Id: simplifySets.mu 36334 2006-01-16 17:42:08Z rensmann $

simplify::simplifySets_union := proc( X : "_union" )
  local i, j, a, c, C_minusChecked, s, operands;
begin
  /* first simplify all subsets */
  X := map( X, simplify::simplifySets );
  if not testtype( X, "_union" ) then return( simplify::simplifySets(X) ); end_if;

  C_minusChecked := FALSE;
  operands := [ op(X) ];
  i := 1;
  while i<= nops( operands ) do
    if testtype( operands[i], "_minus" ) then
//      if contains(map( [simplify::aops( operands, i)], X->bool( _subset(X, op(operands[i],2) )=TRUE ) ), TRUE )>0 then
//        operands[i] := op( operands[i], 1 );
//      end_if;
      if op( operands[i],1)=C_ and not C_minusChecked then
        C_minusChecked := TRUE;
        s := split( operands, X->bool(type(X)="_minus" and op(X,1)=C_) );
        a := simplify::simplifySets( _intersect( op(map( s[1], op, 2 ) )) );
        if type(a)="_intersect" then
          operands := s[2].[ map( op(a), X->C_ minus X ) ];
        else
          operands := s[2].[C_ minus a];
        end_if;
        next;
      end_if;
    elif testtype( operands[i], "_intersect" ) then
      a := map( [op(operands[i])], simplify::simplifySets@_union, simplify::aops(operands, i) );
      c := 0;
      for j from 1 to nops(a) do
        if testtype( a[j], "_union" ) then
          a[j] := op( operands, [ i, j ] );
          c := 1;
        end_if;
      end_for;
    end_if;
    i := i+1;
  end_while;

  X := _union( op( operands ) );

  return( X );
end_proc:

simplify::aops := proc( X : DOM_LIST, i : Type::Integer )
begin
  if i=1 then
    return( op(X, 2..nops(X)) )
  elif i=nops(X) then
    return( op(X, 1..(nops(X)-1)) )
  else
    return( op(X, 1..(i-1)), op(X, (i+1)..nops(X) ) )
  end_if;
end_proc:

simplify::simplifySets_intersect := proc( X : "_intersect" )
  local i, j, operands, a, c, C, C_minusChecked, s;
begin
  /* first simplify all subsets */
  X := map( X, simplify::simplifySets );
  if not testtype( X, "_intersect" ) then return( simplify::simplifySets(X) ); end_if;

  C_minusChecked  := FALSE;
  operands := [ op(X) ];
  i := 1;
  while i<= nops( operands ) do
    case type( operands[i] )
      of "_union" do
        c := 0;
        a := map( [op(operands[i])], simplify::simplifySets@_intersect, simplify::aops(operands, i) );
        for j from 1 to nops(a) do
          if testtype( a[j], "_intersect" ) then
            a[j] := op( operands, [ i, j ] );
            c := 1;
          end_if;
        end_for;
        if FALSE and map( [simplify::aops( operands, i)], X->contains( a, X ) )<>[0] then
          operands[i] := null();
          i := i-1;
        else
          a := _union(op(a));
          if c=0 then
            return( simplify::simplifySets( a ) );
          end_if;
          operands[i] := a;
        end;
        break;
      of "_minus" do
        C := bool( op( operands[i], 1 )=C_ );
        for j from 1 to nops( operands ) do if i<>j then
          if _subset( operands[j], op( operands[i], 2 ) )=TRUE then return( {} ); end_if;
          if C then
            c := _minus( operands[j], op( operands[i], 2 ) );
            if type(c)<>"_minus" then
              operands[j] := c;
              delete operands[i];
              i := i-1;
              break;
            end_if;
          end_if;
        end_if; end_for;
        if C and not C_minusChecked then
          C_minusChecked := TRUE;
          s := split( operands, X->bool(type(X)="_minus" and op(X,1)=C_) );
          a := simplify::simplifySets( _union( op(map( s[1], op, 2 ) )) );
          if type(a)="_union" then
            operands := s[2].[ map( op(a), X->C_ minus X ) ];
          else
            operands := s[2].[C_ minus a];
          end_if;
          break;;
        end_if;
        break;
    end_case;
    i := i+1;
  end_while;

  X := _intersect( op(operands) );
  if not testtype( X, "_intersect" ) then return( simplify::simplifySets(X) ); end_if;

  X;
end_proc:

simplify::simplifySets_minus := proc( X : "_minus" )
  local a, b, c, i;
begin
  if type( op(X,1) )="_minus" then
    return( simplify::simplifySets( op(X,[1,1]) minus _union( op(X,[1,2]), op(X,2) ) ) );
  end_if;

  /* first simplify all subsets */
  X := map( X, simplify::simplifySets );
  if not testtype( X, "_minus" ) then return( simplify::simplifySets(X) ); end_if;

  [ a, b ] := [op(X)];
  if testtype( a, "_intersect" ) then
    c := FAIL;
    a := _intersect( map( map( op(a), simplify::simplifySets@_minus, b ), X->_if( testtype( X, "_minus" ), op( X, 1 ), ( c := X ) ) ) );
    if c <> FAIL then
      return( simplify::simplifySets(a) );
    end_if;
  end;

    if testtype( b, "_intersect" ) then
      c := [op(b)];
      i := 1;
      while i<=nops(c) do
        if _subset( a, c[i] )=TRUE then
          delete c[i];
        else
          i := i+1;
        end_if;
      end_while;
      b := _intersect( op(c) );
  end;

_minus( a, b );
end_proc:

simplify::simplifySets := proc( X )
begin
  case type(X)
    of "_minus" do
      X := simplify::simplifySets_minus( X );
      break;
    of "_intersect" do
      X := simplify::simplifySets_intersect( X );
      break;
    of "_union" do
      X := simplify::simplifySets_union( X );
      break;
//    of "Union" do
//      X := solvelib::Union( op(X,1), op(X,2), simplify::simplifySets( op(X,3) ) );
  end_case;
  X;
end_proc:

//S1 := Z_ intersect Dom::Interval(-infinity,[-1]) minus Z_ intersect Dom::Interval( [1], infinity );
//simplifySets( S1 );

//S2 := ( Dom::Interval( [2],[6] ) union Dom::Interval( [-6],[-2] ) ) intersect ( R_ union I*R_);
//simplifySets( S2 );

//S3 := read( "b" ):
//S4 := simplifySets( S3 );
//length( S3 ), length( S4 );

//S := Z_ intersect Dom::Interval( -infinity, [0] ) minus {0};
//simplifySets( S );

//S5 := Z_ intersect Dom::Interval(0,infinity) intersect (Z_ intersect (Dom::Interval(0,infinity) minus Z_ intersect Dom::Interval(0,infinity)) union Z_ intersect (Dom::Interval(-infinity,[0]) minus Z_ intersect Dom::Interval(-infinity,[0])));
//"A";
//simplifySets( S5 );

//S6 := Dom::Interval(0,infinity) intersect ( Z_ union Dom::Interval(0,infinity) );
//simplifySets( S6 );

//S7 := {0} union (C_ minus {0} );
//simplifySets( S7 );

//S8 :=  {0} union ( C_ minus {0} ) intersect Q;
//simplifySets( S8 );

//S9 := Dom::Interval([0],infinity) intersect ( Z_ union Dom::Interval(0,infinity) );
//simplifySets( S9 );
