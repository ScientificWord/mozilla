// $Date: 2000-10-10 14:32:10 +0200 (Tue, 10 Oct 2000) $ $Author: frankp $ $Revision: 9652 $ 

/*--
    sign/rectform -- the function attribut "rectform" for sign
--*/

sign := slot(sign,"rectform",proc(xx)
    local r, i, t, x;
begin
    x:= rectform::new(xx);

    if extop(x,3) <> 0 then
        new(rectform,0,0,hold(sign)(xx))
    elif extop(x,2) = 0 then
        new(rectform,sign(extop(x,1)),0,0)
    else
        r:= extop(x,1); i:= extop(x,2);
        t:= sqrt(r^2+i^2);
        new(rectform,r/t,i/t,0)
    end_if
end_proc):

// end of file 
