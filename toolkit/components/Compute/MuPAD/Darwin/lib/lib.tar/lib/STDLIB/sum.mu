/*===========================================================================

sum -- (in)definite summation

Calling sequence:
sum(f, x)

Parameters:
f -- an expression (rational function)
x -- identifier

Summary:
sum(f,x) computes the indefinite sum of f(x) with respect to x.


Copyright for the original version:
Paul Zimmermann and Inria, November 1994

--------------------------------------------------------------------------

Examples for indefinite sums:

1) Polynomial case:

>> sum(1,k);

                                     k

>> sum(k^2,k);

                                     2    3
                                k   k    k
                                - - -- + --
                                6   2    3

>> sum(a*x^2+b*x+c,x);

                    3
                 a x      / a   b     \    2 /   a   b  \
                 ---- + x | - - - + c | + x  | - - + -  |
                  3       \ 6   2     /      \   2   2  /


2) Fractional case:

a) Decomposition into the polynomial part and the rational part:

>> sum(k/(k+1),k);

                              k - psi(k + 1)

>> sum((x^2+1)/(x-1),x);

                              2
                         x   x
                         - + -- + 2 psi(x - 1)
                         2   2


b) Reduced rational expressions:
   (degree of numerator is less than degree of denominator)

>> sum(1/k/(k-2),k);

                                1           1
                          - --------- - ---------
                            2 (k - 1)   2 (k - 2)


>> sum(1/k/(2*k-1),k);

                          - psi(k) + psi(k - 1/2)


==========================================================================*/

/*

Calling sequence:

sum(f, x <,"LookupOnly">)

The "option"" "LookupOnly" is undocumented, because it should be only used
internally. It means only the lookup mechanism should be used.

*/

sum :=
proc(s, x)
  local k, l, r, a, y, t, myE, branches, conditions,
        lookupOnly, options: DOM_TABLE;

begin
  if args(0) = 0 then
    error("Wrong number of arguments")
  end_if;

  if args(args(0)) = "LookupOnly" then
    lookupOnly:= TRUE ;
  else
    lookupOnly:= FALSE ;
  end_if;

  // overloading
  if s::dom::sum <> FAIL then
    if lookupOnly then
      s::dom::sum(args(1..args(0)-1));
    else
      s::dom::sum(args()) ;
    end_if;
  end_if;

  if args(0) < 2 then
    error("at least two arguments expected")
  end_if;

  if testargs() then
    if type(x) = "_equal" then
      if domtype(op(x, 1)) <> DOM_IDENT and type(op(x,1)) <> "_index" then
        error("summation variable must be an identifier or indexed identifier")
      elif type(op(x, 2)) = "_range" then
        if map(op(x, 2), testtype, Type::Arithmetical) <> (TRUE..TRUE) then
          error("bounds must be of Type::Arithmetical")
        end_if;
        if is(op(x, [2, 1]) <= op(x, [2, 2])) = FALSE then
          error("Left border must not exceed right border")
        end_if;
      elif domtype(op(x, 2)) <> RootOf then
        error("range or RootOf expected as rhs")
      elif has(op(x, 2), op(x, 1)) then
        error("summation variable occurs in rhs")
      elif stdlib::hasfloat(op(x, 2)) then
        error("floating-point numbers not allowed in rhs")
      end_if;
    elif type(x) = "_in" then
      if domtype(op(x, 1)) <> DOM_IDENT and type(op(x,1)) <> "_index" then
        error("summation variable must be an identifier or indexed identifier")
      elif testtype(op(x, 2), Type::Set) = FALSE then
        error("summation variable must range over a set")
      elif has(op(x, 2), op(x, 1)) then
        error("summation variable occurs in rhs")
      end_if
    elif domtype(x) <> DOM_IDENT and type(x) <> "_index" then
      error("identifier, indexed identifier, or equation expected ".
            "as 2nd argument")
    end_if
  end_if;



  // simple form
   if type(x) = "_equal" and type(op(x, 2)) = "_range" then
    // definite summation; make assumptions about the summation
    // variable if possible
     k := op(x, 1);
     [l, r]:= [op(op(x, 2))];
     if protected(k) = hold(None) then
       save k;
       assume(k, property::IV([l, r]));
       assume(k, Type::Integer, _and);
     end_if;

     a:= r - l;
     for y in select(indets(a) minus Type::ConstantIdents,
                     ind -> protected(ind) = hold(None)) do
       // we solve the condition a >= 0 for y, provided that
       // a is linear in y
       if (t:= Type::Linear(a, [y])) <> FALSE then
         // a = t[1] * y + t[2]
         // thus a >= 0 iff t[1] is positive and y >= -t[2]/t[1]
         // or t[1] is negative and y <= -t[2]/t[1] or t[1] = 0
         if is(t[1] > 0) = TRUE then
           save y;
           assume(y >= -t[2]/t[1], _and)
         elif is(t[1] < 0) = TRUE then
           save y;
           assume(y <= -t[2]/t[1], _and)
         end_if
       end_if;
     end_for;


     s:= eval(s)
   end_if;


  if testargs() then
    if domtype(s) <> DOM_POLY and not testtype(s, Type::Arithmetical) then
      error("1st argument must be of Type::Arithmetical")
    end_if
  end_if;


  if lookupOnly then
    options:= prog::getOptions(sum, 3, hold(Error));
    options["LookupOnly"] := TRUE ;
  else
    options:= prog::getOptions(sum, 2, hold(Error));
    options["LookupOnly"] := FALSE ;
  end_if:

  if domtype(s) = DOM_POLY then
    s:= expr(s)
  end_if;

  // In Sum::sum, exp(x) is written as `#E`^x.
  // Do not mistake this with `#E` used by the user.
  myE:= genident("E"):
  if has(s, `#E`) then
     s:= subs(s, `#E` = myE);
  end_if;

  a:= Sum::sum(s, x, options);

  // In Sum::sum, exp(x) is written as `#E`^x.
  // Upon return, this should have been cleaned 
  // by Sum::sum, but sometimes this does not
  // happen.
  if has(a, `#E`) then
     a:= subs(a, `#E` = exp(1));
  end_if;
  a:= subs(a, myE = `#E`);

  if domtype(a) <> piecewise then
    return(a)
  end_if;

  // fill "uncovered case" if the result is a piecewise
  // and the condition allows to replace an identifier
  t:= not _or(op(map([op(a)], op, 1)));
  if type(t) = "_or" then
    branches:=[op(t)]
  else
    branches:= [t]
  end_if;

  conditions:= map({extop(a)}, op, 1);
  for t in branches do
    if testtype(t, DOM_IDENT = Type::Constant) and
      traperror
      ((
        t:= piecewise::flattenBranch
        (stdlib::branch(t, sum(subs(s, t), subs(x, t), options)))))=0
      then
      for y in [t] do
        if not contains(conditions, op(y, 1))
          then
          conditions:= conditions union {op(y, 1)};
          a:= piecewise::insert(a, y)
        end_if
      end_for;
    end_if;
  end_for;

  a

end_proc:

sum:= funcenv(sum,
proc(a)
  local eq, sumSign;
begin
  if PRETTYPRINT = TRUE then
    sumSign := "---",
               "\\  ",
               "/  ",
               "---":
    if type(op(a, 2)) = "_equal" then
      // definite sum or RootOf
      eq := op(a, [2,2]);
      if domtype(eq) = RootOf then
        _outputSequencePlus(stdlib::Exposed(stdlib::align(sumSign,
                                                      expr2text(op(a, [2,1])=eq))),
                        stdlib::Exposed(" "), op(a, 1));
      else
        _outputSequencePlus(stdlib::Exposed(stdlib::align(expr2text(op(eq, 2)),
                                                      sumSign,
                                                      expr2text(op(a, [2,1])=op(eq, 1)))),
                        stdlib::Exposed(" "), op(a, 1));
       end_if;
     else
      // indefinite sum
      _outputSequencePlus(stdlib::Exposed(stdlib::align(sumSign,
                                                    expr2text(op(a, 2)))),
                      stdlib::Exposed(" "), op(a, 1));

     end_if;
  else
    FAIL
  end:
end_proc):
sum:= slot(sum, "type", "sum"):
sum:= slot(sum, "print", "sum"):

sum::options:= table(MaxOrder = 2,
                     ExpandFinite = 1000):
sum::optionTypes:= table(MaxOrder = Type::PosInt,
                         ExpandFinite = Type::NonNegInt):


sum::int:=
proc(s,x)
begin
  sum(int(op(s,1),x),op(s,2))
end_proc:


sum::freeIndets:=
proc(S: "sum"): DOM_SET
begin
  if type(op(S, 2)) = "_equal" or type(op(S, 2))="_in" then
    (freeIndets(op(S, 1)) union freeIndets(op(S, [2, 2]))) minus
    freeIndets(op(S, [2, 1]))
  else
    freeIndets(op(S, 1)) union freeIndets(op(S, 2))
  end_if
end_proc:

sum::operandsToSimplify:= [1]:


sum::Content      :=
  proc(Out, data)
    local bvar;
  begin
    if type(op(data, 2)) = "_equal" then
      if type(op(data, [2,2])) = "_range" then
        Out::Capply(Out::Csum,
                    Out::Cbvar(Out(op(data, [2,1]))),
                    Out::Clowlimit(Out(op(data, [2,2,1]))),
                    Out::Cuplimit( Out(op(data, [2,2,2]))),
                    Out(op(data,1)));
      else
        bvar := Out::Cbvar(Out(op(data, [2,1])));
        Out::Capply(Out::Csum, bvar,
                    Out::Ccondition(
                          Out::Capply(Out::Cin,
                                      bvar,
                                      Out(op(data, [2,2])))),
                    Out(op(data,1)));
      end_if:
    else
      Out::Capply(Out::Csum,
                  Out::Cbvar(Out(op(data, 2))),
                  Out(op(data,1)));
    end_if;
  end_proc:

sum::float := loadproc(sum::float, pathname("NUMERIC"), "floatsum"):

sum::diff :=
proc(e) // e = sum(f, x)
  local l, _x;
begin
  l := [args(2..args(0))]; // variables to differentiate
  if map({op(l)}, testtype, Type::Indeterminate) = {TRUE}
    and not has((_x := op(e, 2)), l) then
     // summation independent of differentiation
    sum(diff(op(e, 1), op(l)), _x)
  else
    hold(diff)(e, op(l))
  end_if
end_proc:

sum::expand:=
proc()
  local s, d, l, k, f, u;
begin
  if type(args(2)) = "_equal" and
    type((k:= op(args(2), 2))) = "_range" and
    domtype((d:= op(args(2),[2,2]) - op(args(2), [2, 1]))) = DOM_INT then
    // left border must not exceed right border, this should
    // have been checked before
    assert(d>=0);
    l:= op(args(2), [2, 1]);
    k:= op(args(2), 1);
    f:= subs(args(1), k = k + l);
    f:= _plus(eval(subs(f, k=u)) $ u=0..d);
    return(eval(%))
  end_if;
  s:=expand(args(1));
  if type(s)="_plus" then
    _plus(map(s, expand@sum,args(2)))
  elif type(s)="_mult" then
    split(s,has,(if type(args(2))=DOM_IDENT
                   then
                   args(2)
                 else
                   op(args(2),1)
                 end_if));
    %[2]*hold(sum)(%[1],args(2))
  else
    hold(sum)(args())
  end_if
end_proc:

sum::ztrans:= proc(s, k, z)
begin
   sum(transform::ztrans(extop(s, 1), k, z), extop(s, 2..extnops(s)));
end_proc:

sum::invztrans:= proc(s, z, k)
begin
   sum(transform::invztrans(extop(s, 1), z, k), extop(s, 2..extnops(s)));
end_proc:

sum::addpattern:= Sum::addpattern:

sum::simplify :=loadproc(sum::simplify,pathname("STDLIB","SIMPLIFY"),"sum"):
