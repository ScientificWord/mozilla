// $Date: 2004-07-07 16:40:25 +0200 (Wed, 07 Jul 2004) $ $Author: stefanw $ $Revision: 27998 $ 

// apply f on e after substituting the sub-expressions of type
// not in l
maprat :=
proc(ee, ff, l, s)
  option hold; 
  local spec, e, f;

begin
  if args(0)<2 then error("missing arguments") end_if;
  e:=context(ee); f:=context(ff);
  if (spec:=bool(nops([e])<>1)) then e:=[e] end_if;
  e:=rationalize(e, (if args(0)>=3 then context(l) end_if), 
		 (if args(0)>=4 then context(s) end_if));
  userinfo(3,"new expression is",e[1]);
  if spec then
    subs(f(op(e[1])),op(e[2]))
  else
    subs(f(e[1]),op(e[2]))
  end_if
end_proc:

// returns newe,t where newe is the new expression, and t is a set of substitutions,
// Input: l is either a list of types or a procedure defining the expressions
//	  that must be left unchanged (but recurse in them),
//        s is a set of basic types that are left as they are,
//        t is a set of special types to be rationalized (default is {}),
//	  for example "sin" or "cos" or "exp"

rationalize :=
proc(e, l= FAIL, s=FAIL, _t={}:DOM_SET) 
  local i,l1,XI,lsincos,lexp,d,g,xx,exptoE,Etoexp,_E,recurse, equ,
  maprat_indets,l0, iexpo, showDep: DOM_BOOL, substitutions, subst,
  genid: DOM_PROC,
  found: DOM_BOOL,
  identsSoFar:DOM_SET;
begin

  
// p is an expression, l is procedure that returns TRUE for expressions not to be frozen,
// k is a procedure that returns TRUE for objects to leave as they are

  showDep:= bool(contains([args()], hold(ShowDependencies)) > 0):


  // local method genid(string, expression)
  // generate an identifier starting with string if showDep is FALSE
  // generate an expression identifier(variables) if showDep is TRUE
  if showDep then
    identsSoFar:= {};
    genid:=
    proc(s, a)
      local ident;
    begin
      if a = I then
        return(`#I`)
      end_if;
      ident:= genident(s);
      identsSoFar:= identsSoFar union {ident};
      ident(op(indets(a) minus identsSoFar minus Type::ConstantIdents))
    end_proc
  else
    genid:= (s, a) -> if a=I then `#I` else genident(s) end_if
  end_if;
  
  _E:= genident("E");
  
  maprat_indets :=
  proc(p,l,k)
    name maprat_indets;
    local i;
  begin
    userinfo(20, "Processing subexpression ".expr2text(p));
    if contains(Type::ConstantIdents, p) then
      userinfo(30, "Irrational constant");
      {p} // these are not rationals
    elif domtype(p) = DOM_COMPLEX then
      {I}
    elif bool(k(p))=TRUE then
      userinfo(30, "Rational constant");
      {}
    elif bool(l(p))=TRUE then
      userinfo(30, "Recursing on subexpressions");
      _union(maprat_indets(op(p,i),l,k)$i=1..nops(p))
    else
      if recurse<>TRUE or p=op(p,1) then
        // cannot call recursively for atomic objects!
        userinfo(30, "Do not recurse further because option Recursive ".
                 "has not been given, or object is atomic");
        {p}
      else
        userinfo(30, "Expression is irrational;".
                 "in addition, recurse on subexpressions");
        _union({p},maprat_indets(op(p,i),l,k)$i=1..nops(p))
      end_if
    end_if
  end_proc:

  recurse:=bool(contains({args()},Recursive));
  case domtype(l)
    of DOM_PROC do
    of DOM_EXEC do
    of DOM_FUNC_ENV do  
      break
    of DOM_SET do 
      l0:=l;
      l:=
      proc(x)
        name l;
      begin
        contains(l0,type(x))
      end_proc;
      break
    of DOM_DOMAIN do
      if l=DOM_POLY then
        l:=stdlib::maprat_makepoly;
        break
      end_if
    otherwise
      l:=stdlib::maprat_makerat
  end_case;
  if type(s)=DOM_SET then
    l0:=s;
    s:=
    proc(x)
      name s;
    begin
      contains(l0,type(x))
    end_proc
  elif not contains({DOM_PROC,DOM_EXEC, DOM_FUNC_ENV},domtype(s)) then
    s:=stdlib::maprat_basic
  end_if;
  l:=maprat_indets(e,l,s);
  userinfo(15, "Indeterminates are ".expr2text(l));
  delete maprat_indets, s; // dead closure
  lsincos:={};
  lexp:=[];
  if nops(l)>=2 and _t<>{} or (nops(l)=1 and has(_t,"_power")) then
    if _t intersect {"sin","cos"} <> {} then
      // try to recognize algebraic dependencies between sin(x) and cos(x) 
      l1:=map(select(l,testtype,Type::Union("sin","cos","tan","cot")),op);
      // {x,y,...} 
      // select those that appear in at least two functions 
      l1:=select(l1,proc(x)
                    begin
                      nops(l intersect {sin(x),cos(x),tan(x),cot(x)})>=2
                    end_proc);
      // convert tan and cot to sin and cos 
      e:=subs(e,map(l1,proc(x)
                       begin
                         op([tan(x)=sin(x)/cos(x),cot(x)=cos(x)/sin(x)])
                       end_proc ));
      l:=l minus map(l1,tan) minus map(l1,cot) union map(l1,sin)
          union map(l1,cos);
      l1:=select(l1,proc(x)
                    begin
                      nops(l intersect {sin(x),cos(x)})>=2
                    end_proc);
      if l1<>{} then // some sin and cos in common 
        l:=(l minus map(l1,sin)) minus map(l1,cos);
        lsincos:=map(l1,proc(x)
                        begin
                          tan(x/2)=genid("T", x)
                        end_proc );
        l1:=map(l1,proc(x)
                   begin
                     op([cos(x)=rewrite(cos(x),tan),
                         sin(x)=rewrite(sin(x),tan)])
                   end_proc );
        e:=subs(e,op(l1),op(lsincos));
      end_if;
    end_if;
    if _t intersect {"exp","_power"} <> {} then
      // try to recognize algebraic dependencies between exp(a*x) and exp(b*x)
      // and more generally between t^a and t^b where t is any expression
      l1:=select(l,testtype,Type::Union(op(_t)));
      // {exp(x/3), exp(2*x), exp(x/2), x^(1/2), x^(1/3)} 
      if has(l1,hold(exp)) then
        exptoE:=map(select(l1,testtype,"exp"),
                    proc(x)
                    begin
                      x=_E^op(x)
                    end_proc );
        Etoexp:=op(map(exptoE,
                       proc(x)
                       begin
                         op(x,2)=op(x,1)
                       end_proc ));
        l1:=subs(l1,op(exptoE));
      else
        Etoexp:=null()
      end_if;
      while nops(l1)<>0 do
        l1:=sort([op(l1)],
                 proc(x,y)
                 begin
                   length(x)>=length(y)
                 end_proc );
        i:=op(l1,1); // exp(x) or x^(1/2) 
        delete l1[1];
        if op(i,1)<>_E and type(op(i,1))<>DOM_INT then
          l1:=append(l1,hold(_power)(op(i,1),1))
        end_if;
        // let XI be the set of all powers that have the same base
        // as i
        XI:=select({op(l1)},
                   proc(x)
                   begin
                     op(x,1)=op(i,1) and
                     contains({DOM_INT,DOM_RAT},type(op(x,2)/op(i,2)))
                   end_proc );
        l1:={op(l1)} minus XI;
        // XI = {exp(x/3), exp(2*x), exp(x/2)} 
        if XI<>{} then
          l:=l minus
              subs(XI union {i},Etoexp);

          if stdlib::hasmsign(op(i, 2)) then
            iexpo:= -op(i, 2)
                     // i:= subsop(i, 2 = -op(i, 2))
          else
            iexpo:= op(i,2);
          end_if;
          
          XI:=map(XI,proc(x)
                     begin
                       op(x,2)/iexpo
                     end_proc )
               union {1};
          // {1,1/3,2,1/2}
          d:=map(XI,denom);
          d:=ilcm(op(d)); // 6 in the example 
          XI:=map(XI,_mult,d); // {6,2,12,3} 
          g:=igcd(op(XI)); // 1 in the example 
          xx:=genid("xx", i);
          // this is to represent op(i,1)^(g*iexpo) 
          if contains(XI,1) then
            XI:=[op(XI minus {1}),1]
          end_if;
          XI:=map(XI,proc(x)
                       local xpow;
                     begin
                       xpow:=op(i,1)^(x/d*iexpo);
                      // if xpow <> op(i, 1) then
                         xpow = xx^(x/g)
                      // else
                      //   null()
                      // end_if
                     end_proc );
          XI:=subs(XI,Etoexp);
          // since we may have replaced the exponent by its negative,
          // we have to add the inverse of every substitution
          XI:= [(equ, 1/op(equ, 1) = 1/op(equ, 2)) $equ in XI];
          // sort by length
          XI:= sort(XI,
                    (equ1, equ2) -> length(op(equ1, 1)) > length(op(equ2, 1)));
          e:=subs(e,XI);
          l:=subs(l, XI);
          if recurse then
            lexp:=subs(lexp,XI)
          end_if;
          lexp:=append(lexp,subs(op(i,1)^(g/d*iexpo),Etoexp)=xx);
        end_if;
      end_while;
    end_if
  end_if;


// only replace such irrational subexpressions by new identifiers that
// are not identifiers themselves
  l:= select(l, x -> domtype(x) <> DOM_IDENT);
  l:={(op(l,i)=genid("D", op(l, i)))$ i=1..nops(l)} union lsincos;
  if recurse then
    lexp:=subs(lexp,l)
  end_if; 

  l:=append(lexp,op(l));


  // now l is a list of substitutions of the form expression = ident
  // we sort l such that the expression in l[i] does not depend on the
  // idents in l[1], ..., l[i]
  g:= {op(map(l, op, 2))}; // idents
  l1:=[];
  // loop invariant: g contains all right hand sides of elements of l
  // l.l1 = the original l (in different order)
  while nops(l) > 0 do
    [l, l0, d]:= split(l, equ -> indets(op(equ, 1)) intersect g <> {});
    assert(d = []);
    // among several independent expressions, put the shorter one to the end
    // of the list
    l0:= sort(l0, (x, y) -> length(y) <= length(x) );
    l1:= l0.l1;
    g:= {op(map(l, op, 2))}    
  end_while;  
  l:= l1;
  
  substitutions:= [(op(l,[i,2])=op(l,[i,1]))$ i=1..nops(l)];

  e:= subs(e, op(l));  
// remove substitutions for identifiers that do not appear elsewhere
  XI:= indets(e, All);
  subst:= substitutions;
  substitutions:= [];
  repeat
    found:= FALSE;
    for i from 1 to nops(subst) do
      if XI intersect indets(op(subst[i],1), All) <> {} then
        XI:= XI union indets(op(subst[i],2), All);
        substitutions:= append(substitutions, subst[i]);
        subst[i] := FAIL;
        found:= TRUE
      end_if;
    end_for;
    subst:= select(subst, _unequal, FAIL)
  until not found end_repeat;
  
  userinfo(3,"substitutions are", substitutions);
  e,(if recurse then substitutions else {op(substitutions)} end_if)
end_proc:

stdlib::maprat_makerat := 
proc(x) 
begin 
  case type(x) 
    of DOM_SET do
    of DOM_LIST do
    of "_plus" do 
    of "_mult" do
      return(TRUE)
    of "_power" do
      return(testtype(op(x,2),DOM_INT)) 
  end_case; 
  FALSE 
end_proc:

stdlib::maprat_makepoly := 
proc(x) 
begin 
  case type(x)
    of DOM_SET do
    of DOM_LIST do
    of "_plus" do 
    of "_mult" do
      return(TRUE)
    of "_power" do
      return(testtype(op(x,2),Type::PosInt))
  end_case; 
  FALSE 
end_proc:


stdlib::maprat_basic :=
proc(x)
begin
  contains({DOM_RAT, DOM_INT, DOM_IDENT, Type}, domtype(x))
end_proc :
