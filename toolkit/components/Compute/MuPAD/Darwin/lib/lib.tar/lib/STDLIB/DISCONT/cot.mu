genident("n"):
cot::undefined:= Dom::ImageSet(% * PI, %, Z_):
 
cot::realDiscont:= cot::undefined:
cot::complexDiscont:= cot::undefined:


