
log  := slot(log ,"diff",proc(ausdruck,ableit)
begin
        diff(ln(op(ausdruck,2))/ln(op(ausdruck, 1)),ableit);
end_proc):

// end of file 
