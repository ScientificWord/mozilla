/* $Date: 2003-10-20 12:55:22 +0200 (Mon, 20 Oct 2003) $ $Author: tonner $ $Revision: 25461 $ */

/*++


solvelib::conditionalSort(l)


sort a list l of expressions

the result is either a list (if the sorting is the same for all real
values the parameters can take on) or an object of type piecewise


++*/


solvelib::conditionalSort:=
proc(l:DOM_LIST)
local inds, var,indep,dep,dummy,i;
  
begin
  userinfo(2, "Conditional sorter called");
  userinfo(10, "List to sort is: ".expr2text(l));

  
  inds:=indets(l);

  userinfo(5, "The set of indeterminates is: ".expr2text(inds));
  
  if inds={} then
    return(sort(l, (x,y)->bool(float(x)<=float(y))))
  end_if;

  
  var:=op(inds,1);

  userinfo(5, "Choosing main variable ".expr2text(var));

  [dep, indep, dummy]:=split(l, has, var);

  if dummy<>[] then
    /* should never happen ! */
    error("Function has could not decide occurrence of variable")
  end_if;

  userinfo(5, "Sorting the independent entries");

  indep:=solvelib::conditionalSort(indep);
  
  /* compare the dependent entries */

  for i in dep do

    /* insert i into indep */
    
    if type(indep)=piecewise then
      map([extop(indep)],
          proc(t:stdlib::branch)
          begin
            solvelib::conditionalinsert(t::dom::expression(t), i, var);
            if type(%)=DOM_LIST then
              piecewise([t::dom::condition(t), %])
            else
              piecewise::restrict(%, t::dom::condition(t))
            end_if
          end_proc);
      indep:=piecewise::_concat(op(%))
    else /* type(indep)=DOM_LIST */
      indep:= solvelib::conditionalinsert(indep, i, var)      
    end_if;   
  end_for;

  return(indep)
  
end_proc:
  

/*++

solvelib::conditionalinsert(l, a, x)

l - DOM_LIST
a - expression
x - identifier

returns a sorted list consisting of a and the elements of l.
l must be a sorted list. If the sorting depends of the values of
identifiers occuring in a, an object of type piecewise is returned;
cases analysis is done w.r.t. the main variable x.                           

++*/


solvelib::conditionalinsert:=
proc(l:DOM_LIST, a, x)
  local i, sol, cases;

begin
  if l=[] then
    return([a])
  end_if;
  cases:=[];
  sol:=solve(a<=l[1], x);
  userinfo(10, "Determining interval of numbers satisfying ".
             expr2text(a<=l[1]));
  if type(sol)="solve" then
    cases:=append(cases, [a<=l[1], [a].l]);
  elif sol={} then
    userinfo(15, "Case ".expr2text(a<=l[1])." cannot occur")
  else
    cases:=append(cases, [_in(x, sol), [a].l])
  end_if;
  
  for i from 2 to nops(l) do
    sol:=solve({a<= l[i], a>l[i-1]}, x);
    userinfo(10, "Determining interval of numbers satisfying ".
             expr2text(a<=l[i] and a>l[i-1]));
    if type(sol)="solve" then
      cases:= append(cases, [a <= l[i] and a>l[i-1],
                           [op(l,1..i-1)].[a].[op(l,i..nops(l))]])
    elif sol={} then
      userinfo(15, "Case ".expr2text(a<= l[i] and a>l[i-1]).
               "cannot occur");
    else
      cases:= append(cases, [_in(x, sol),
                             [op(l,1..i-1)].[a].[op(l,i..nops(l))]])
    end_if;
  
  end_for;
  sol:=solve(a> l[nops(l)], x);
  userinfo(10, "Determining interval of numbers satisfying ".
             expr2text(a>l[nops(l)]));
  if type(sol)="solve" then
    cases:=append(cases, [a> l[nops(l)], append(l,a)]);
  elif sol={} then
    userinfo(15, "Case ".expr2text(a>l[nops(l)]). " cannot occur")
  else
    cases:=append(cases, [_in(x,sol), append(l,a)])
  end_if;
  if nops(cases)=1 then
    op(cases[1],2)
  else
    piecewise::new(op(cases))
  end_if
  
end_proc:
                                