
// Control routine for numeric integration.				
//									
// References:								
// [1] Numerical Integration in a Symbolic Context, K.O. Geddes,  	
//     pp. 185 - 191, Proceedings of SYMSAC '86, ACM, 1986.		
// [2] Numerical Integration using Symbolic Analysis, K.O. Geddes,	
//     pp. 8 - 17, Maple Technical Newsletter 6, 1991			
//									
// Input:								
// f -- an expression (integrand)					
// y -- an equation of the form x=a..b . 				
//									
// Output:								
// The value of the integral or FAIL					


intlib::numint :=  proc(f, x)
   local __a, __b, eps, _x;
   name numeric::int;
begin   
   if type(x) <> "_equal" then
     return(FAIL)
   end_if; 
   eps:= 10^(2-DIGITS);
   _x:= op(x, 1); __a := op(x,[2,1]); __b := op(x,[2,2]);
   intlib::control(f, _x, __a, __b, eps);
end_proc:

intlib::control :=  proc(f, x, __a, __b, eps)
   local c, err, ffunc, h, l, left, nofun,
         osc, pleft, pright, r, right, tol;
begin

if type(f) = DOM_PROC or type(f) = "function" then
   // We have to modify this control routine to	
   // handle user defined procedures/functions.	
   return(FAIL);
end_if;

if has({__a,__b}, [infinity, -infinity]) then
        return( intlib::improper(f,x,__a,__b,eps) )
end_if;

left := float(__a);  right := float(__b);

if not testtype(left, Type::Numeric) or not testtype(right, Type::Numeric) then
   return(FAIL)
end_if;

userinfo(1,"integrating on ".expr2text(__a)." .. ".expr2text(__b)." the integrand ".expr2text(f));

h := float(__b-__a);
if abs(h) < 10^(-DIGITS) then 
   return( 0.0 )
elif not testtype(left,Type::Numeric) or not testtype(right,Type::Numeric) then 
   return( FAIL )
elif left > right then 
   return( intlib::control(-f,x,__b,__a,eps) )
end_if;

pleft  := intlib::singular(f, x, __a, Right);
pright := intlib::singular(f, x, __b, Left );

if pleft = FAIL or pright = FAIL then
   return(FAIL);
end_if;

if pleft and pright then
        // Singularity in both endpoints.                 
        // Split interval in two, a..(a+b)/2 , (a+b)/2..b 
        userinfo(1, "splitting interval into ".expr2text(__a)." .. ".expr2text((__a+__b)/2)." and ".expr2text((__a+__b)/2)." .. ".expr2text(__b));
	if h < sqrt(eps) then
	    error("integrand is apparently singular everywhere")
	end_if;
	return( intlib::control(f,x,__a,(__a+__b)/2,eps/2)
		+  intlib::control(f,x,(__a+__b)/2,__b,eps/2) )

elif pright then
        // Singularity in the right endpoint.                 
	// Transform singularity to be at the left end-point. 
        userinfo(1, "singularity at right end-point. transforming to the interval 0 .. ".expr2text(__b-__a));
	return( intlib::control(subs(f, x=__b-x),x,0,__b-__a,eps) )

elif pleft then
	// Deal with singularity at the left end-point. 		
        userinfo(1, "singularity at left end-point.");
	if left <> 0.0 then
	    // Transform left end-point to zero. 		
            userinfo(1, "transforming to the interval 0 ..".expr2text(__b-__a));
	    return( intlib::control(subs(f,x=x+__a),x,0,__b-__a,eps) )
	else
	    return( intlib::singleft(f,x,__b,eps) )
	end_if
else
	// Attempt numerical integration. 			

        // Before calling the numerical integrator it is useful	
      	// to analyze the integrand for removable singularities	
	// in the interval and for accurate evaluation (for	
	// example to avoid cancellation in floating-point	
	// arithmetic. See [1], makeproc. This isn't implemented	
	// yet.							

	ffunc := intlib::makeproc(f, x, __a, __b, eps);

        if traperror( (
              l := intlib::ccquad(ffunc,left,right,eps,487)
           ) ) <> 0 then
	
           userinfo(1, "singularity in or near interval of integration");
           return(FAIL)
        end_if;

        r := l[1]; err := l[2]; nofun := l[3]; c := l[4];

        if r = FAIL then
            
           userinfo(1, "Clenshaw-Curtis quadrature fails.");
           userinfo(1, "Function probably oscillates. Trying adaptive method.");

           if traperror( (
              l := intlib::ncquad(ffunc,left,right,eps,eps)
              ) ) <> 0 then
    
              userinfo(1, "singularity in or near interval of integration");
              return(FAIL)
           end_if;

           r := l[1]; err := l[2]; nofun := l[3]; c := l[4];

           if r = FAIL then
           
              userinfo(1, "Newton-Cotes quadrature fails.");

              if traperror( (
                 osc := intlib::oscillate(ffunc, left, right, 500, 10)
                 ) ) <> 0 then
                 userinfo(1, "singularity in or near interval of integration");
	             // Not implemented yet.                           
                 // return( intlib::singnear(f,x,left,right,eps) ) 
                 return(FAIL) 
	          elif osc = FAIL then
                 userinfo(1, "function apparently oscillates infinitely");
	             return(FAIL)
              else
                 userinfo(1, "oscillating integral detected.");
	             userinfo(1, "splitting interval into ".expr2text(__a)." .. ".expr2text((__a+__b)/2)." and ".expr2text((__a+__b)/2)." .. ".expr2text(__b));
	             return( intlib::control(f,x,__a,(__a+__b)/2,eps/2)
                         +  intlib::control(f,x,(__a+__b)/2,__b,eps/2) )
	      end_if
           end_if
	end_if;

	// Calculate error tolerance, with eps as a relative error	
	//   criterion;  if too small then use absolute error.		
	tol := max(eps*abs(r), 0.001*eps);
        userinfo(1, "error = ".expr2text(err).", error tolerance = ".expr2text(tol).", result = ".expr2text(r));
	if err <= tol then 
	   return( r ) 
        else
	   error("numerical integration failed to converge")
	end_if
end_if
end_proc:


intlib::singular := proc(f, x, a, dir)
   option remember;
   local d, ord, s;
begin

   d := discont(f, x=a..a);
   if testtype(d, DOM_SET) then
      if d = {} then
         return(FALSE)
      elif testtype(float(limit(f, x=a, dir)), Type::Numeric) then
         return(FALSE)
      else
         return(TRUE)
      end_if
   end_if;

   ord := 2;
   // compute series expansion 
   if traperror((s := series(f, x=a, ord, dir))) <> 0 then
      return(FAIL)
   end_if;
   if type(s) = "series" then
      // series expansion not possible. 
      // Try with default ord.          
      ord := ORDER;
      s := series(f, x=a, ord, dir);
      if type(s) = "series" then
         // Unable to compute series expansion 
         return(FAIL)
      end_if
   end_if;
   if ldegree(s) = FAIL then
      // series expansion contains only an ord 
      // term. Increase ord of expansion.      
      s := series(f, x=a, 2*ord, dir);
      if type(s)="series" or ldegree(s)=FAIL then
         return(FAIL)
      end_if;
   end_if;

   // If not "pure Taylor series" then there is an end-point singularity. 

   if not testtype(s, Type::Series(Taylor)) then
      TRUE
   else
      FALSE
   end_if;
   
end_proc:

// end of file 
