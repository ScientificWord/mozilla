
// Platzhalter. Funktion wird noch implementiert zur
// Codierung von implizit definierten Funktionen in 
// MuPAD. 

stdlib::implicitFcn:= () -> args():


