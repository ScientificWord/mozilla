// $Date: 2001-07-30 14:30:58 +0200 (Mon, 30 Jul 2001) $ $Author: kg $ $Revision: 13260 $ 


/* degreevec - return the degree vector of a polynomial
   or expression */


degreevec:=
proc(f,l)
local ord,ff;
begin
  if args(0)=0 then
    error("degreevec called without args")
  end_if;
  if f::dom::degreevec<>FAIL then
    return(f::dom::degreevec(args()))
  end_if;
  case args(0)
    of 1 do
      return(polylib::degreevec(f))
    of 2 do
      if type(l)=DOM_LIST then
        return(polylib::degreevec(f,l))
      elif domtype(f)=DOM_EXPR and iszero(degree(f)) then
        return([0 $nops(indets(f))])
      else
        ff:=poly(f);
        ord:=l
      end_if;
      break
    of 3 do
      if type(l)<>DOM_LIST then
        error("Second argument must be list of indeterminates")
      end_if;
      ff:=poly(f, l);
      ord:=args(3);
      break
    otherwise
      error("Too many arguments")
  end_case;

  if type(ord)=DOM_IDENT then
    polylib::degreevec(ff, ord)
  else
    polylib::degreevec(lterm(f, ord))
  end_if

end_proc:
