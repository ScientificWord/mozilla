/*++
min, max -- compute minima and maxima

min(a,...)
max(a,...)

a - expression
++*/

min:= stdlib::min:
min::info := "min -- the minimum":
min::float := () -> if args(0) = 1  // e.g., a RootOf object
                       then min(float(args(1)));
                       else min(map(args(), float)):
                    end_if:
min::operator := _op_plusmult:
min::hull := () -> hull(args()):
min::Content := (Out, data) -> Out::Capply(Out::Cmin, op(map([op(data)], Out))):
min::TeX := (m, data, prio) -> generate::TeXseq("\\min\\left(", "\\right)",
						op(data)):
min::simplify:= loadproc(min::simplify, pathname("STDLIB", "SIMPLIFY"), "min"):

max:= stdlib::max:
max::info := "max -- the maximum":
max::float := () -> if args(0) = 1  // e.g., a RootOf object
                       then max(float(args(1)));
                       else max(map(args(), float)):
                    end_if:
max::operator := _op_plusmult:
max::hull := () -> hull(args()):
max::Content := (Out, data) -> Out::Capply(Out::Cmax, op(map([op(data)], Out))):
max::TeX := (m, data, prio) -> generate::TeXseq("\\max\\left(", "\\right)",
						op(data)):
max::simplify:= loadproc(max::simplify, pathname("STDLIB", "SIMPLIFY"), "max"):
