// 
// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 
// 
// frankp, 25.11.1994 

/*--
	rectform::_mult  --  multiply elements of domain rectform
--*/

slot(rectform,"_mult") := proc(x,y)
    name rectform::_mult;
    local i;
begin
    if args(0) > 2 then
        return(
          rectform::_mult(x,rectform::_mult(args(i) $ i = 2..args(0)))
        )
    end_if;

    if domtype(x) <> rectform then x := rectform::new(x) end_if;
    if domtype(y) <> rectform then y := rectform::new(y) end_if;

    new(rectform,
        extop(x,1)*extop(y,1)-extop(x,2)*extop(y,2), // Re(x*y) 
        extop(x,1)*extop(y,2)+extop(x,2)*extop(y,1), // Im(x*y) 
        extop(x,1)*extop(y,3)+extop(x,3)*extop(y,1)+
            extop(x,3)*extop(y,3)+I*(extop(x,2)*extop(y,3)+
            extop(x,3)*extop(y,2))
    )
end_proc:

// end of file 
