// $Date: 2004-12-10 12:57:37 +0100 (Fri, 10 Dec 2004) $ $Author: stefanw $ $Revision: 29735 $ 

/*--
	ln/simplify -- the function attribut "simplify" for ln

	Rules (take properties into account):

	1) ln( posint1/posint2 * r )  -->  ln(posint1) - ln(posint2) + ln(r)
	2) ln( exp(real) * r )        -->  real + ln(r)
        3) ln( positive^real * r )    -->  real*ln(positive) + ln(r)
           ln( negative^even * r )    -->  even*ln(-negative) + ln(r)
           ln( negative^odd  * r )    -->   odd*ln(-negative) + ln(-r)
        4) ln( positive * r )         -->  ln(positive) + ln(r)
           ln( negative * r )         -->  ln(-negative) + ln(-r)

        5) ln( y^n )                  -->  n*ln(y) if
                                           -1 < n <= 1 or
                                           n = -1 and is(y <= 0) = FALSE or
                                           -2 <= n <= 2 and Re(y) > 0
        6) ln( exp(z) )               -->  z if -PI < Im(z) <= PI

        //7) ln( x^(p/q)/y )            -->  1/q * ln(x^p/y^(q/p))
        //   -> detour: ln::simplify | combine | ln::simplify

        The ideology is to have only positive arguments in ln's where
        possible.
--*/

ln::simplify :=
proc(x: "ln")
  local l, t, r, k, z, y, n;
begin


  l:= op(x);
  
  // convert the result into a list of factors
  if type(l) = "_mult" then
    l := [op(l)];
  else
    l := [l];
  end_if;

  // determine all factors that are recognized as positive or negative by "is"
  l := split(l, proc(a) begin
      is(a > 0) or is(a < 0)
  end_proc);

  r := op(l[2])*op(l[3]);
  l := l[1];
  // now x = ln(_mult(op(l)) * r), and every element of l "is" either >0 or <0

  // handle positive or negative factors
  k := 0;
  for t in l do
    case type(t)

      of DOM_INT do
        if t < 0 then
          t:= -t;
          r:= -r
        end_if;
        y:= numlib::ispower(t);
        if y <> FALSE then
          k:= k + op(y,2)* ln(op(y, 1))
        else
          k:= k + ln(t)
        end_if;
        break
        
      of DOM_RAT do // rule 1)
      // ln(numer/denom) = ln(numer) - ln(denom)
      if t < 0 then
        t := -t;
        r := -r;
      end_if;
      k := k + ln(op(t, 1)) - ln(op(t, 2));
      break;
    of "exp" do // rule 2)
      if is(op(t), Type::Real) = TRUE then
	// t "is" positive and ln(t) = op(t)
        k := k + op(t);
      else
        r := r * t;
      end_if;
      break;

    of "_power" do // rule 3)
      [y, n] := [op(t)];
      if is(y > 0) = TRUE then
        // ln(y^n * r) = n*ln(y) + ln(r) if y > 0 and n is real
        if is(n, Type::Real) = TRUE then
          k := k + n*ln(y);
        else
          r := r * t;
        end_if;
      elif is(y < 0) = TRUE then
        // ln(y^n * r) = n*ln(-y) + ln(r) if y < 0 and n is even
        // ln(y^n * r) = n*ln(-y) + ln(-r) if y < 0 and n is odd
	if is(n, Type::Even) = TRUE then
	  k := k + n*ln(-y);
        elif is(n, Type::Odd) = TRUE then
	  k := k + n*ln(-y);
          r := -r;
        else
          r := r * t;
        end_if;
      else
        r := r * t;
      end_if;
      break;
      
    otherwise // rule 4)
      if is(t < 0) = TRUE then
        t := -t;
        r := -r;
      end_if;
      k := k + ln(t);

    end_case;
  end_for;
  // now x = k + ln(r)

  // handle the remainder ln(r)
  case type(r)

  of "_power" do // rule 5
    [y, n] := [op(r)];
    /* ln(y^n)=n*ln(y) when -1< n <=1
       and for n = -1 if y is not real nonpositive
       and for -2 <= n <= 2 if Re(y) > 0
    */
    if (is(-1 < n) = TRUE and is(n <= 1) = TRUE) or
       (is(n = -1) = TRUE and is(y <= 0) = FALSE) or
       (is(-2 <= n) = TRUE and is(n <= 2) = TRUE and is(Re(y) > 0) = TRUE) then
       return(k + n*ln(y));
    end_if;
    break;

  of "exp" do // rule 6
    // ln(exp(z)) = z if -PI < Im z <= PI
    z := op(r);
    if (is(Im(z) > -PI) = TRUE and is(Im(z) <= PI) = TRUE) or
       contains({-1, 0, 1}, sign(z)) then
      return(k + z);
    end_if;

  end_case;

  return(k + ln(r));

end_proc:

ln::Simplify:= [Rule(ln::simplify, {}, table("Default" = 0.5))]: