arccoth::complexDiscont := Dom::Interval([-1, 1]):
