
// The expression f in the variable x has an essential singularity at	
// at x = a. The general series expansion of f at x=a is ser with the	
// the O-term removed and in sum-of-products form.			
//									
// This routine first checks if the singularity can be "subtracted off"	
// yielding an analytic part and a remaining singular part.		
// If so, the value returned is a list of the form ["subtract off", expr]
// where expr is the "singular part" to subtract from f.			
//									
// Next, if there is an algebraic transformation to remove fractional	
// powers, this transformation is returned in the form specified below.	
//									
// Finally, it attempts to find a transformation x = w(t) such that the	
// function  f(w(t)) * diff(w(t),t)  is analytic at 			
//                    -1  						
//               t = w  (a) .						
//									
// If successful, the value returned is a list [sbst, inv_sbst], each is	
// an expression in x) such that sbst represents the transformation 	
// function w and inv_sbst represents w^(-1).				
//									
// Otherwise, the value returned is FAIL.				

// References:                                                           
// [1] Numerical Integration in a Symbolic Context, K.O. Geddes,         
//     pp. 185 - 191, Proceedings of SYMSAC '86, ACM, 1986.              
// [2] Numerical Integration using Symbolic Analysis, K.O. Geddes,       
//     pp. 8 - 17, Maple Technical Newsletter 6, 1991                    


intlib::transform := proc( f,x,a,ser)
	local e,inds,q,s, powinds, base, n, t, i, tmp;
begin
        if testtype(ser, "_plus") then

        inds := {}; q := 0;
        for e in indets(ser, PolyExpr) do
            if has(e,x) and e<>x then  
               inds := inds union {e};
               q := q + select(ser, has, e); 
            end_if
        end_for;

	// Check if the singularity can be "subtracted off", 	
	// looking at series. 					

	if q - ser <> 0 then
              if traperror( (tmp:= taylor(f-q, x=a)) ) = 0 and tmp <> FAIL then
	         return(["subtract off", q])
	      end_if
	end_if;

        else

        inds := indets(ser, PolyExpr);

	end_if;

	// Check if the singularity can be "subtracted off", 	
	// looking at f. 					

        if testtype(f, "_plus") then
	
	q := 0;
	for e in f do 
	    if has(e,x) and e<>x then
               if traperror( (tmp:= taylor(e, x=a)) ) = 0 and tmp <> FAIL then
                  q := q + e;
	       end_if
	    end_if
	end_for;
	
	if q - ser <> 0 then
              if traperror( (tmp:= taylor(f-q, x=a)) ) = 0 and tmp <> FAIL then
                 return(["subtract off", q])
              end_if
        end_if;

	end_if;

	// Separate from inds the the fractional powers of x-a 	

	powinds := {};
	for e in inds do 
            if testtype(e, "_power") then
               if testtype(op(e,2), DOM_RAT) then
                  powinds := powinds union {e};
               end_if
            end_if
        end_for;
 	inds := inds minus powinds;
	if nops(powinds) > 0 then
           base := op(powinds, [1,1]);
	   n := ilcm(op(powinds, [i,2,2]) $ i=1..nops(powinds));
           t:=genident();
	   assume(t>=0); s := solve(t=base^(1/n), x);
           if nops(s) = 1 then
              return([subs(op(s,1), t=x), base^(1/n)])
	   end_if
	end_if;

	// Search for a non-algebraic transformation. 

        intlib::findtransform(f, x, a, inds);

end_proc:

intlib::findtransform := proc(f, x, a, inds)
   local ind,t,inv_sbst,sbst,newf,t0,s;
begin

        // Search for a substitution that transforms the integrand f	
        // into an integrand which is analytic at x = a.  The		
        // substitutions are to be based on the indets in the set inds.	
 
        t:= genident();
        for ind in inds do
            inv_sbst := t=ind;
            assume(t>=0); sbst := solve(inv_sbst, x);
            if testtype(sbst, DOM_SET) then
               if nops(sbst) = 1 then
		  sbst := op(sbst,1);
                  newf := subs(f, x=sbst) * diff(sbst, t);
                  t0 := limit(ind, x = a);
                  if testtype(float(t0), Type::Numeric) then
                     if traperror( (s:= taylor(newf, t=t0, 25)) ) = 0 and s <> FAIL then
                        return( subs(sbst, t=x), ind )
                     end_if
                  elif has(t0, infinity) then
                     if traperror( (s:= taylor(subs(newf, t=1/t), t=0)) ) = 0 and s <> FAIL then
			if s <> FAIL then
			   return( subs(sbst, t=x), ind )
			end_if
		     end_if
                  end_if
               end_if
	    end_if
        end_for;
	userinfo(1, "no transformation found");
        FAIL
end_proc:

