// $Date: 2004-12-07 23:06:53 +0100 (Tue, 07 Dec 2004) $  $Author: nthiery $  $Revision: 29691 $ #

// Function -- executable objects

Type::Function:=
    new(Type,
	"Function",
	proc(t,x)
	  option noDebug;
	  name Type::Function;
        local res;
         begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_PROC, DOM_FUNC_ENV, DOM_EXEC, operators::overloaded, "_fconcat", "_fnest"}, type(x)) then
		TRUE
        elif domtype(x) = DOM_EXPR then
          case type(x)
            of "_power" do
            of "_mult" do
            of "_plus" do
              // allow sin^-1, sin/cos, sin+1 ...
              res := select({op(x)}, _not@testtype, Type::Numeric);
              break;
              
            otherwise
              res := {op(x)};
          end_case;
          res := map(res, testtype, Type::Function);
         if contains(res, FAIL) then FAIL else _and(op(res)) end;
        else
		FAIL
	    end_if;
	end_proc,
	FALSE, FALSE):
