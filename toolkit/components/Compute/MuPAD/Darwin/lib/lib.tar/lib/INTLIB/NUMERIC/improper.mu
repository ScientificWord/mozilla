
// Handle improper integrals, i.e. integrals where the lower and/or 	
// upper limit of integration is infinite.				
//									
// References:                                                           
// [1] Numerical Integration in a Symbolic Context, K.O. Geddes,         
//     pp. 185 - 191, Proceedings of SYMSAC '86, ACM, 1986.              
// [2] Numerical Integration using Symbolic Analysis, K.O. Geddes,       
//     pp. 8 - 17, Maple Technical Newsletter 6, 1991                    

intlib::improper :=  proc(f, x, __a, __b, eps)
   	local lower, newf;
begin
	userinfo(1, "integrating on interval ".expr2text(__a)." .. ".expr2text(__b));
	if has(__a,[infinity, -infinity]) and 
           not has(__b,[infinity, -infinity]) then
	    intlib::improper(-f,x,__b,__a,eps)
	elif has(__a,[infinity, -infinity]) and 
             has(__b,[infinity, -infinity]) then
	    if __a=__b then
		error("integration limits are both plus (or minus) infinity")
	    end_if;
	    intlib::improper(-f,x,0,__a,eps/2) + intlib::improper(f,x,0,__b,eps/2)
	elif has(__b,[infinity, -infinity]) then
	    if __b = -infinity then
		return(intlib::improper(-subs(f, x=-x), x, -__a, -__b, eps))
	    end_if;
	    lower := float(__a);
	    if not testtype(lower,Type::Numeric) then
		error("non-numeric integration limit encountered")
	    end_if;
	    if lower < 0.0 then
		intlib::control(f,x,lower,0,eps/2) 
                + intlib::improper(f,x,0,__b,eps/2)
	    else
		userinfo(1, "applying transformation ".expr2text(x)." = ".expr2text(1/x));
		newf := normal( subs(f, x=1/x) * (-1/x^2) );
		if abs(lower) < 10^(-DIGITS) then // lower = 0 ? 
		    userinfo(1, "interval is 0 .. 1 for the two functions ".expr2text(f)." and ".expr2text(-newf));
		    intlib::control(f,x,0,1,eps/2) 
                    + intlib::control(-newf,x,0,1,eps/2)
		else
		    userinfo(1, "interval is 0 .. ".expr2text(1/lower)." for the function ".expr2text(-newf));
		    intlib::control(-newf,x,0,1/lower,eps)
		end_if
	    end_if
	else
	    error("expecting an infinite integration limit")
	end_if
end_proc:

// end of file 
