// ceiling a complex number is defined as applying ceil to both its real and
// imaginary part

ceil::rectform:=
proc(x)
begin
  new(rectform, op(map([extop(rectform(x))], ceil)))
end_proc:
  