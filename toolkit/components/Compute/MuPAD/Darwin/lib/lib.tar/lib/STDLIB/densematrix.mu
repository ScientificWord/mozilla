// $Date: 2003-04-14 16:58:22 +0200 (Mon, 14 Apr 2003) $ $Author: walter $ $Revision: 22598 $
// frankp, 18.05.2000

// densematrix is just an abbreviation for the domain 'Dom::DenseMatrix()':
densematrix:= Dom::DenseMatrix():

