/*--
	_mult/simplify -- the function attribut "simplify" for _mult
--*/

_mult::simplify:=
proc(e)
  name _mult::simplify;
  local t,
  combineIntPowers: DOM_PROC,
  combineExponents: DOM_PROC,
  combineConstantWithRoots: DOM_PROC;
begin

  

  // local simplification methods
  
  combineIntPowers:=
  proc(e)
    local t;
  begin  
    t:= split(e, fctor -> type(fctor) = "_power" and
              type(op(fctor, 1)) = DOM_INT);
    // there should be no "unknown"
    assert(t[3] = 1);
    t:= combine(t[1])*t[2]*t[3];
    // combine powers with non-rational exponent and the constant
    // (such as 4*2^n -> 2^(n+2))
    if type(t) <> "_mult" then
      return(t)
    end_if;
    
    t:= split(t, fctor -> type(fctor) = "_power" and
              type(op(fctor, 1)) = DOM_INT and type(op(fctor, 2)) <> DOM_RAT
              or type(fctor) = DOM_INT);
    combine(t[1])*t[2]*t[3]
    
  end_proc;


  combineExponents:=
  proc(e)
    local t: DOM_TABLE, a, sgn: DOM_INT, bas, expo, reduceMod2;
  begin
 // rewrite x^a*x^b --> x^(a+b)

    sgn:= 1;
    
    t:= table();
    for a in e do
      if type(a) = "_power" then
        bas:= op(a, 1);
        expo:= op(a, 2);
      else
        bas:= a;
        expo:= 1;
      end_if;
      // special case
      if bas = I then
        bas:= -1;
        expo:= expo/2
      elif bas = -I then
        bas:= -1;
        expo:= -expo/2
      end_if;
      
      if contains(t, bas) then
        t[bas]:= t[bas] + expo
      else
        t[bas]:= expo
      end_if;
    end_for;

    if contains(t, -1) then
  // symmetric reduction modulo 2
      reduceMod2:=
      proc(b)
        local p, q;
      begin
        case type(b)
          of DOM_INT do
            return(b mod 2)
          of DOM_RAT do
            return(frac(1/2 + b/2)*2 - 1)
          of DOM_COMPLEX do
            p:= op(b, 1);
            q:= op(b, 2);
            // reduce p modulo 2
            return(reduceMod2(op(b, 1)) + op(b, 2)*I)
          of "_plus" do
            return(map(b, reduceMod2))
        end_case;
        if is(b, Type::Integer)=TRUE and stdlib::hasmsign(b) then
          -b
        else
          b
        end_if
      end_proc;

      t[-1] := reduceMod2(t[-1]);
      if contains({DOM_INT, DOM_RAT, DOM_FLOAT}, domtype(t[-1])) and t[-1] < 0 then
        t[-1]:= t[-1] + 1;
        sgn:= -sgn
      end_if
    end_if;
  
    sgn*_mult(op(a, 1)^op(a, 2) $a in t)
  end_proc;



  combineConstantWithRoots:=
  proc(e: "_mult")
    local constant, num, den, expo, base, d,
    other: DOM_LIST,
    i: DOM_INT;
  begin

    constant:= op(e, nops(e));
    other:= [op(e, 1..nops(e) - 1)];
    
    case domtype(constant)
      of DOM_INT do
        den:= 1;
        num:= constant;
        break
      of DOM_RAT do
        [num, den]:= [op(constant)];
        break
      of DOM_COMPLEX do
        if map({op(constant)}, type) minus {DOM_INT, DOM_RAT} = {} then
          // extract common factors of real and imaginary part
          // we compute gcd(op(e,1), op(e, 2)) "by hand", avoiding a gcd call
          num:= igcd(numer(op(constant, 1)), numer(op(constant, 2)));
          if op(constant, 1) = 0 then
            den:= denom(op(constant, 2))
          else        
            den:= ilcm(denom(op(constant, 1)), denom(op(constant, 2)))
          end_if;
          other:= append(other, constant/ (num/den));
          constant:= num/den;
          break
        else
          return(e)
        end_if
      otherwise
        return(e)
    end_case;


  
    for i from 1 to nops(other) do
      if type(other[i]) = "_power" and
        type((expo:= op(other[i], 2))) = DOM_RAT then

        case domtype((base:= op(other[i], 1)))
          of DOM_INT do

            // let den = d*a, base = d*b; then
            // (num/den) * base^(expo) = (num/a) * b^expo * d^(expo - 1)
            // = constant * d * (base/d)^expo * d^(expo - 1) 
            d:= igcd(base, den);
            if d<>1 then
              constant:= constant * d;
              den:= den/d;
              other[i]:= subsop(other[i], 1 = base/d);
              other:= append(other, d^(expo-1));
              /* since num and den cannot have a common divisor,
                 we may stop here */
              break
            end_if;
           
            // let num = d*a, base = d*b; then
            // (num/den) * base^(expo) = (a/den) * b^expo * d^(expo + 1)
            // = constant / d * (base/d)^expo * d^(expo + 1)
            d:= igcd(base, num);
            if d<>1 then
              constant:= constant / d;
              num:= num/d;
              other[i]:= subsop(other[i], 1 = base/d);
              other:= append(other, d^(expo + 1))
              end_if;
            break
        end_case;

        
      end_if;
        
    end_for;

    return(_mult(op(other)) * constant )
    

  end_proc;
  
  
 // main program of _mult::simplify


  if MAXEFFORT < 500 or MAXEFFORT < property::complexity(e) then
    return(e)
  end_if;
  
  if not testtype(e, Type::Arithmetical) then
    return(e)
  end_if;
  
   
  t:= normal(e);
  if property::complexity(t) < property::complexity(e) then
    e:= t
  end_if;

  if type(e) <> "_mult" then
    return(e)
  end_if;
    
  e:= combineIntPowers(e);

  if type(e) <> "_mult" then
    return(e)
  end_if;
    
  e:= combineExponents(e);

  if type(e) <> "_mult" then
    return(e)
  end_if;

  
  e:= combineConstantWithRoots(e);

  return(e)
  
end_proc:

// end of file 
