// Platzhalter, Code kommt von Fu

// Call:    intlib::alt(f(x), x = g(y))
// 
//  int(f(x), x = g(y), <options>) 
//ruft 
//  intlib::alt(f(x), x = g(y), <options>) 
//  auf.

intlib::alt:= proc(f,x)
begin
  if type(x) <> "_equal" or type(op(x,2)) = "_range" then
     error("2nd argument: expecting an equation such as x = g(y)");
  end_if;

  // The present dummy code just throws the traditional error.
  // To be replaced.
  error("Second argument must be either of form x or x=a..b")
end_proc:
