// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ #

// Zero -- expression to test for zero numbers

Type::Zero:=
    new(property::NRange,
	"Zero",
	proc(t,x)
	  name Type::Zero;
	  option noDebug;
	begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    iszero(x)
	end_proc,
	FALSE, FALSE,
	["Zero", property::Null]):
