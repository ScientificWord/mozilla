collect :=
proc(p, ll)
  local l, f, fn,
  i: DOM_INT,
  myplus: DOM_PROC,
  mymult: DOM_PROC;

begin
  if args(0) = 0 then
    error("collect called without arguments")
  end_if;

  if p::dom::collect <> FAIL then
    return(p::dom::collect(args()))
  end_if;
  
  if args(0)<2 or args(0)>=4 then
    error("Wrong number of args")
  end_if;

  if not testtype(p, Type::Arithmetical) then
    error("First argument must be arithmetical expression")
  end_if;
  
  if type(ll) <> DOM_LIST then
    l:=[ll]
  else
    l:=ll
  end_if;

  if args(0)<3 then
    fn := id;
  else
    fn := args(3);
  end_if;
  
  // hold(_plus), but treat one and zero ops correctly
  myplus := proc()
	    begin
	      if args(0) = 0 then 0
	      elif args(0) = 1 then args()
	      else hold(_plus)(args()); end_if;
            end_proc;
  
  // hold(_mult), but treat one and zero args correctly
  // and flatten out ones.
  mymult := proc()
	      local factors;
	    begin
	      factors := select([args()], _unequal, 1);
	      if nops(factors) = 0 then 1
	      elif nops(factors) = 1 then factors[1]
	      else hold(_mult)(op(factors)); end_if;
	    end_proc;
  
  f:= poly(p, l);
  if f <> FAIL then
    if nops(l) = 1 then
      myplus(op(map(poly2list(f),
		    e -> mymult(generate::sortSums(fn(e[1])),
				l[1]^e[2]))));
    else
      myplus(op(map(poly2list(f),
		    e -> mymult(generate::sortSums(fn(e[1])),
				l[i]^e[2][i] $ i = 1..nops(l)))));
    end_if;
  else
    f:= normal(p, List);
    f:= map(f, poly, l);
    if contains(f, FAIL) > 0 then
      return(FAIL)
    end_if;
    if nops(l) = 1 then
      myplus(op(map(poly2list(f[1]),
		    e -> mymult(generate::sortSums(fn(e[1])),
				l[1]^e[2]))))/
      myplus(op(map(poly2list(f[2]),
		    e -> mymult(generate::sortSums(fn(e[1])),
				l[1]^e[2]))));
    else
      myplus(op(map(poly2list(f[1]),
		    e -> mymult(generate::sortSums(fn(e[1])),
				l[i]^e[2][i] $ i = 1..nops(l)))))/
      myplus(op(map(poly2list(f[2]),
		    e -> mymult(generate::sortSums(fn(e[1])),
				l[i]^e[2][i] $ i = 1..nops(l)))));
    end_if;
  end_if
end_proc:
