alias(relation = stdlib::relation):

relation := newDomain("relation"):

relation::simplify := proc(EXPR)
   local i;
begin
   if testtype(EXPR, "_mult") then
      relation::prod(op(EXPR))
   elif testtype(EXPR, "_plus") then
      relation::sum(op(EXPR))
   elif domtype(EXPR) = DOM_EXPR then
      op(EXPR, 0)(relation::simplify(op(EXPR, i)) $ i = 1..nops(EXPR))
   else
      EXPR
   end_if
end_proc:



relation::sum := proc()
   local arg, relsum, s, SUM;
begin
   relsum := []; SUM := 0;

   for arg in args() do
      if testtype(arg, Type::Relation) then 
         relsum := relsum.[arg]
      else
         s := relation::simplify(arg);
         if testtype(s, Type::Relation) then 
            relsum := relsum.[s]
         else
            SUM := SUM + s
         end_if
      end_if
   end_for;

   if relsum = [] then return(SUM) end_if;
   if SUM <> 0 then
      relsum := relsum.[SUM = SUM]
   end_if;

   relation::sum_simple(op(relsum))

end_proc:



relation::sum_simple := proc()
   local a, b, n, r, ta, tb;
begin
   n := args(0);
   if n < 2 then return(args()) end_if;
   a := args(1); b := args(2);
   ta := type(a); tb := type(b);

   if ta = "_equal" then
      r := op(b, 0)(op(a,1)+op(b,1), op(a,2)+op(b,2))
   elif tb = "_equal" then
      r := op(a, 0)(op(a,1)+op(b,1), op(a,2)+op(b,2))
   elif ta = "_leequal" and tb = "_leequal" then
      r := op(a,1)+op(b,1) <= op(a,2)+op(b,2)
   elif (ta = "_leequal" or ta = "_less") and 
        (tb = "_leequal" or tb = "_less") then
      r := op(a,1)+op(b,1) < op(a,2)+op(b,2)
   else
      error("invalid terms in sum")
   end_if;

   if n < 3 then
      r
   else
      relation::sum_simple(r, args(3..n))
   end_if

end_proc:

      
relation::prod := proc()
   local arg, a, b, c, p, prod, relterm;
begin
   prod := 1;
   relterm := FAIL;

   for arg in args() do
       if testtype(arg, Type::Relation) then
          if relterm <> FAIL then
             error("invalid term in product")
          end_if;
          relterm := arg
       else
          p := relation::simplify(arg);
          if testtype(p, Type::Relation) then
             if relterm <> FAIL then
                error("invalid term in product")
             end_if;
             relterm := p
          else
             prod := prod * p
          end_if
       end_if
   end_for;

   if relterm = FAIL then return(prod) end_if;

   a := relation::simplify(op(relterm,1));
   b := relation::simplify(op(relterm,2));
   if (testtype(relterm, "_less") or testtype(relterm, "_leequal"))
      and relation::psign(prod) < 0 then
      c := a; a := b; b := c
   end_if;

   op(relterm, 0)(a*prod, b*prod)

end_proc:

relation::psign := proc(x)
begin
   if not testtype(x, Type::Numeric) then
      x := poly(x);
      if x = FAIL then
         error("can't determine sign")
      end_if;
      x := lcoeff(x)
   end_if;
   sign(x)
end_proc:

simplify::relation := relation::simplify:
