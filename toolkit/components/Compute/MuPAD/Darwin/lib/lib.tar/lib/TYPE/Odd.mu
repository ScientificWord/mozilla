// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ 

/*++
Odd -- expression to test for odd numbers

Odd
++*/

Type::Odd:=
  new(property::Residue,
      "Type::Odd",
      proc(t,x)
	name Type::Odd;
      begin
        if args(0) <> 2 then return(FALSE) end_if;
       bool(domtype((x - 1)/2) = DOM_INT)
      end_proc,
      FALSE, FALSE,
      [1, 2, Type::Integer]
      ):

// Type::Odd:= 
// 	subsop(property::EO(1),
// 	       1 = "Odd",
// 	       2 = proc(t,x)
// 		     option noDebug;
//                    begin
// 		     if args(0) <> 2 then return(FALSE) end_if;
// 	             bool(domtype((x-1)/2) = DOM_INT)
// 	           end_proc):
  
// end of file 
