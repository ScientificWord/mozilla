// $Date: 2006-04-26 14:25:28 +0200 (Wed, 26 Apr 2006) $ $Author: stefanw $ $Revision: 38641 $


/*

solvelib::set2prop(S, opt)

returns a property
- satisfied by all elements of S, but possibly also by other objects
  (option Superset)
- satisfied by all elements of S, and by no other objects; the return value
  may be FAIL if no such property exists (option Exact)
- satisfied by no objects except for elements of S; but there may be
elements of S that do not satisfy this property (option Subset)

*/

solvelib::set2prop:=
proc(S, opt=hold(Exact))
  local i;
  
begin
  if testargs() then
    if args(0)=0 or args(0)>2 then
      error("Wrong number of arguments")
    end_if;

    if args(0)=2 and not contains({hold(Exact), hold(Superset),
                                   hold(Subset)}, args(2)) then
      error("Unknown option")
    end_if
  end_if; 
  
  if S::dom::set2prop<>FAIL then
    return(S::dom::set2prop(args()))
  end_if;

  case type(S)
    of DOM_SET do
      case nops(S)
        of 0 do
          return(property::Null)
        of 1 do
          return(property::Rel(_equal, op(S,1)))
        otherwise
          return(hold(_or)(property::Rel(_equal, op(S,i)) $i=1..nops(S)))
      end_case
    of "_union" do
      [solvelib::set2prop(op(S,i), opt) $i=1..nops(S)];
      if has(%, FAIL) then
        break
      else
        return(_or(op(%)))
      end_if
    of "_intersect" do
      [solvelib::set2prop(op(S,i), opt) $i=1..nops(S)];
      if has(%, FAIL) then
        break
      else
        return(_and(op(%)))
      end_if
    of "_minus" do
      case opt
        of hold(Exact) do
          [solvelib::set2prop(op(S,1)), solvelib::set2prop(op(S,2))];
          if has(%, FAIL) then
            return(FAIL)
          else
            return(%[1] and not %[2])
          end_if
        of hold(Superset) do
          return(solvelib::set2prop(op(S,1), hold(Superset)) and
                 not solvelib::set2prop(op(S,2), hold(Subset)))
        of hold(Subset) do
          return(solvelib::set2prop(op(S,1), hold(Subset)) and
                 not solvelib::set2prop(op(S,2), hold(Superset)))
      end_case
      // NOT REACHED
 
  end_case;


  // default: no suitable property available
  case opt
    of hold(Exact) do
      FAIL;
      break
    of hold(Superset) do
      Type::Complex;
      break
    of hold(Subset) do
      property::Null
  end_case
      
end_proc:

