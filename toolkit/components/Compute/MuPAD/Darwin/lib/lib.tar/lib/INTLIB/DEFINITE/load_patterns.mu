
proc()
  save FSA, FSA_cauchy;
begin
  unprotect(FSA);
  unprotect(FSA_cauchy);
  read("INTLIB".stdlib::PathSep."DEFINITE".stdlib::PathSep."patternFSA.mb", Plain);
  intlib::definite::patternFSA := FSA;
  intlib::definite::patternFSA_Cauchy := FSA_cauchy;
end():

