// $Date: 2001-07-30 14:30:58 +0200 (Mon, 30 Jul 2001) $  $Author: kg $ $Revision: 13260 $ 

/* General convention: a monomial ordering is a function
  ord: N^k x N^k -> {-1, 0, 1}

  for elements of Dom::MonomOrdering, this is satisfied
  (by definition of Dom::MonomOrdering::func_call)

  Here ord([m_1,..,m_k],[n_1,..,n_k])=-1 iff [m_1,..,m_k] < [n_1,..,n_k]
                                     = 1 iff              >
                                     = 0 iff              =
*/


/* lmonomial(f,ord <,Rem>)
  
  f   - polynomial
  ord - monomial ordering 

  computes the leading monomial with respect to ord
  if the option Rem is given, a list 
  [lmonomial(f),f-lmonomial(f)] is returned
*/

lmonomial:=
proc(ff,ord)
  local f, result,dv,nt,dvec,i;

begin
  if args(0)=0 then
    error("lmonomial called without arguments")
  end_if;
  if ff::dom::lmonomial <> FAIL then
    return(ff::dom::lmonomial(args()))
  end_if;
  if args(0)=1 or type(ord)=DOM_IDENT then
	return(polylib::lmonomial(args()))
  end_if;
  if type(ord)=DOM_LIST then
    lmonomial(poly(ff,ord), args(3..args(0)));
    if testtype(ff, Type::Arithmetical) then
      if type(%)=DOM_LIST then
        return(map(%, expr))
      else
        return(expr(%))
      end_if
    else
      return(%)
    end_if;
  end_if;
  if degree(ff)=0 then
    return(ff)
  end_if;    
  f:=poly(ff);
  if domtype(ff)=DOM_EXPR then
    return(expr(lmonomial(f, args(2..args(0)))))
  end_if;
  if f=FAIL then
	error("Cannot convert to polynomial")
  end_if;
  result:=nthmonomial(f,1);
  dv:=degreevec(result);
  for i from 2 to nterms(f) do
	if ord(dv,(dvec:=degreevec((nt:=nthmonomial(f,i)))))=-1 then
     dv:=dvec;
     result:=nt
   end_if
  end_for;
  if args(0)=2 then
    result
  elif args(3)=Rem then
    [result,f-result]
  else
    error("Illegal third argument")
  end_if
end_proc:

// end of file 

