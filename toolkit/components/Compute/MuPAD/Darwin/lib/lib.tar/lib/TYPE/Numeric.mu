// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ #

//
// Numeric -- expression to test for numerical numbers
//            DOM_INT, DOM_FLOAT, DOM_RAT, DOM_COMPLEX
//

Type::Numeric:=
    new(Type,
	"Numeric",
	proc(t,x) 
	  name Type::Numeric;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_INT, DOM_RAT, DOM_FLOAT, DOM_COMPLEX}, domtype(x)) then
		TRUE
	    else
		FAIL
	    end_if;
	end_proc,
	FALSE, FALSE):
