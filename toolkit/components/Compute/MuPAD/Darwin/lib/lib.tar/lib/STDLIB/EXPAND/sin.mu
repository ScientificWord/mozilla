// $Date: 2002-04-04 10:23:38 +0200 (Thu, 04 Apr 2002) $ $Author: stefanw $ $Revision: 17914 $ 

/*--
	sin/expand -- the function attribut "expand" for sin

 sin(-x)     = -sin(x)                                                 
 sin(x +- y) = sin(x) * cos(y) +- sin(y) * cos(x)                      
               n/2                                                     
               ---                                                     
               \   (   n  )                                            
 sin(n * x)  = /   ( 2*i+1) cos(x)^(n-2*i-1)*sin(x)^(2*i+1)*(-1)^(i+1) 
               ---                                                     
               i=0  
--*/

sin := slot
(sin, "expand",
 proc(x)
   local n, t, y, C, S;
 begin
   y := expand(x);

   case type(y)

     of "_plus" do
       
       n := op(y, 1); y := subsop(y, 1=null());
       return(expand(sin(n)*cos(y)+cos(n)*sin(y)));

     of "_mult" do
       n := op(y, nops(y));
       t := type(n);
       // first apply sin(I*x) = I*sinh(x)
       if t = DOM_COMPLEX and iszero(op(n, 1)) then
         return(I* expand(sinh(y/I)))
       end_if;
       // sin(n*x) = sin(x)^(..)*cos(x)^(..) + ...
       // Do this, if n is integer and x contains at least on symbol,
       // because we do not want to expand sin(5*sqrt(2)) etc.
       if indets(y) minus Type::ConstantIdents = {} then
         break;
       end_if:
       if t = DOM_INT or t = DOM_RAT then
          if n < 0 then
             return(expand(-sin(-y)));
          else // n > 0
               // the following is due to Francois Maltey
             if n=1 then
               return(sin(y))
             end_if; // avoids loop in expand(sin(1))
             if t = DOM_INT then
               y := y / n;
               S:= genident("S");
               C:= genident("C");
               return(
                  subs(expand(((C+I*S)^n-(C-I*S)^n)/2/I),[C=cos(y),S=sin(y)])
                     );
             end_if;
          end_if;
       end_if;

  end_case;

  sin(y)

end_proc):

// end of file
