// $Date: 2006-03-30 12:08:28 +0200 (Thu, 30 Mar 2006) $ $Author: ccr $ $Revision: 38172 $ 

/*--
intlib::insert(f) - adds a new extension to the tower of field extensions if
necessary.
--*/

intlib::insert:=proc(j,oper,L)
  local i,x,T;
// global _global_n,_global_k,_global_k_sub,_global_k_ident,_global_k_diff,_global_k_deg,_global_k_alg,_global_Q,_global_Q_sub; 
begin
  if nops({op(_global_k_sub)} intersect indets(L))>0
    then if (i:=contains(_global_k,oper(L)))>0 then return(_global_k_sub[i]); end_if;
    T:=intlib::algdep(oper(L),_global_n);
    if T[2]=1 then return(normal(T[1])); end_if;
    if (i:=contains(_global_k_sub,T[1]))>1
      then
      _global_k[i]:=oper(L);
      _global_k_deg[i] :=j;
      _global_k_diff[i]:=polylib::lcoeff(poly(intlib::diffs(oper(L),_global_n),[_global_k_sub[_global_n]]));
/*        don't remove the further extensions, e.g.
         int(-exp(x^2)^(-1/2)*(x^3 + Y^2*x), x)
	 for j from i+1 to n do
         _delete _global_k[i+1], _global_k_sub[i+1], _global_k_deg[i+1], 
                 _global_k_ident[i+1], _global_k_diff[i+1], _global_k_alg[i+1];
         end_for; */ 
      return(FALSE);
    end_if;
 
    x:=genident();
    _global_k      :=append(_global_k,oper(L));
    _global_k_sub  :=append(_global_k_sub,x);
    _global_k_deg  :=append(_global_k_deg,j);
    _global_k_ident:=append(_global_k_ident,genident());
    _global_n:=_global_n+1;
    _global_k_diff:=append(_global_k_diff,
			   intlib::diffs(oper(L),_global_n));
    if poly(_global_k_diff[-1], [_global_k_sub[_global_n]]) <> FAIL then
      _global_k_diff[-1] := polylib::lcoeff(poly(_global_k_diff[-1],
						 [_global_k_sub[_global_n]]));
    end_if;
    assert(_global_k_diff[-1] <> FAIL);
    if T[2]>0 then _global_k_alg  :=append(_global_k_alg,poly(x^T[2]-T[1],[x]));
    else _global_k_alg  :=append(_global_k_alg,0);
    end_if;
    assert(_global_k_alg[-1] <> FAIL);
    return(x);
  else if (i:=contains(_global_Q,oper(L)))>0
	 then return(_global_Q_sub[i]);
       else x:=genident(); _global_Q:=append(_global_Q,oper(L)); _global_Q_sub:=append(_global_Q_sub,x);
	 return(x);
       end_if;
  end_if;
end_proc:
