// $Date: 2006-06-08 09:16:01 +0200 (Thu, 08 Jun 2006) $ $Author: ccr $ $Revision: 39553 $ 

/*++
  Synopsis: changevar(f,eq) changes the variables in f according to eq.
  Author: Paul Zimmermann, 8 Feb 1996
          Winfried Fakler
  24.9.02: W. Oevel: further code added to avoid calls to solve for
           problems of the type 
                int(f(g(x))*diff(g(x), x), x), t = g(x), t)

  Examples:
  >> intlib::changevar(hold(int)(ln(x)*2, x=0..1),x=exp(t));

                     int(2 t exp(t), t = -infinity..0)
++*/

intlib::changevar :=
  proc(i,eq=FAIL,t)
    local _x,xoft,u,tofx,s, foft, old_foft, skip, tmp;
  begin
    if type(eq)=DOM_FAIL then
      error("Missing equation for substitution");
    elif type(eq)<>"_equal" then
      error("Second argument must be an equation describing the substitution");
    end_if;
    if not( type(i)="int" ) then
       if args(0) < 3 then
         return(misc::maprec(i, {"int"} = (x -> intlib::changevar(x, eq))));
       else
         return(misc::maprec(i, {"int"} = (x -> intlib::changevar(x, eq, t))));
       end_if;
    end_if;
    if has(i, hold(D)) then
       i:= rewrite(i, diff);
    end_if;
    if has(eq, hold(D)) then
       eq:= rewrite(eq, diff);
    end_if;
        
    if type((_x:=op(i,2)))="_equal" then _x:=op(_x,1) end_if;
    if not has(eq,_x) then
      error("The old integration variable ".expr2text(_x).
            " is missing in the substitution equation");
    end_if;
    if args(0)<3 then // try to find the new variable
      t:=indets(eq) minus {_x};
      if nops(t)<>1 then
        error("Please specify the new integration variable")
      end_if;
      t:=op(t)
    end_if;
    if not has(eq,t) then
      error("The new integration variable ".expr2text(t).
            " is missing in the substitution equation");
    end_if;

    //-----------------------------------------------------
    // Additional code by W. Oevel, 24.9.02:
    // Before inverting xoft = x(t) to tofx = t(x) via
    // solve, we look for situations
    //   int(f(x(t)))*diff(x(t), t), t) = int(f(u), u)
    // (with u = x(t)), where no inverse of x(t) is
    // needed.
    //      -->    int(f(t), t)

    skip:= TRUE; // the transformation may be of the form
                 // x = g@@(-1)(t) instead of t = g(x).
                 // In such a case, the following will
                 // not be successful and we have to go
                 // to the branch below (the old code).
    // eq:  t = g(x)
    if lhs(eq) = t and not has(rhs(eq), t) then
       tofx := rhs(eq); // t(x) = g(x)
       skip:= FALSE;
    elif rhs(eq) = t and not has(lhs(eq), t) then
       tofx:= lhs(eq); // t(x) = g(x)
       skip:= FALSE;
    else
       tmp:=solvelib::discreteSolve(eq,t); //,PrincipalValue;
       if type(tmp) = DOM_SET and 
          tmp <> {} and
          type(op(tmp, 1)) <> RootOf then
          skip:= FALSE;
          tofx:= op(tmp,1);
       end_if;
    end_if;
    if skip = FALSE then
       foft:= op(i, 1)/diff(tofx, _x); // foft = f(x(t))/ (dg(x)/dx)
       // beware: if diff(tofx, x) = diff(g(x), x) is not 
       // cancelled in the expression above, then
       // subsex(%, tofx = t) = subsex(%, g(x) = t) contains
       // a factor 
       // subsex(something/diff(g(x), x), g(x) = t) = 
       // something/diff(t, x).
       // The next step will produce a 'division by zero'
       //   ---> use traperror
       if traperror(( foft:= eval(subsex(foft, tofx = t)))) = 0 then 
         old_foft:= foft;
         foft:=simplify(foft);
         if foft <> old_foft and has(foft, _x) then
            // try again
            if traperror(( foft:= eval(subsex(foft, tofx = t)))) = 0 then
               foft:=simplify(foft);
            end_if;
         end_if;
         // The transformation was successful if the new integrand foft
         // does not contain the original integration variable _x anymore:
         if not has(foft, _x) then
            if type(op(i, 2)) = "_equal" then
               // definite intral. We need to transform the
               // boundaries x = a..b ---> t = g(a)..g(b)
           //  u:= t = 
           //      eval(subs(tofx, _x = op(i, [2, 2, 1]))) 
           //       ..   
           //      eval(subs(tofx, _x = op(i, [2, 2, 2])));   
               u:=  t = 
                    limit(tofx,_x = op(i, [2,2,1]), Right)
                     ..
                    limit(tofx,_x = op(i, [2,2,2]), Left);
            else
               u:= t:
            end_if;
            if (has(foft, sin) or has(foft, cos)) and 
               has(foft, arctan) then
               tmp:= rewrite(foft, tan):
               if not has(tmp, tan) then
                  foft:= expr(factor(tmp));
                  u:= rewrite(u, tan);
               end_if;
            end_if;
            return(hold(int)(foft, u, op(i, 3..nops(i))));
         end_if;
       end_if:
    end_if;
    //-----------------------------------------------------
    // End of additional code by W. Oevel, 24.9.02
    //-----------------------------------------------------

    //assume(t,Type::Real);
    // invert t = g(x) to x = x(t) by some solver:
    if lhs(eq) = _x then
       xoft:= rhs(eq)
    elif rhs(eq) = _x then
       xoft:= lhs(eq)
    else
       s:=solvelib::discreteSolve(eq,_x); //,PrincipalValue;
       if type(s)<>DOM_SET or s={} or type(op(s, 1)) = RootOf then
         error("Cannot solve the transformation ".expr2text(eq)." for "._x)
       end_if;
       xoft:=op(s,1);
       for u from 2 to nops(s) do
         // Aeh? 
         if length(op(s,u))<length(xoft) then xoft:=op(s,u) end_if
       end_for;
    end_if:
    if type(op(i,2))="_equal" then
      if lhs(eq) = t then
         tofx:= rhs(eq);
      elif rhs(eq) = t then
         tofx:= lhs(eq);
      else
         tofx:=solvelib::discreteSolve(eq,t); //,PrincipalValue;
         if type(tofx) <> DOM_SET or tofx = {} then
           error("Cannot solve the transformation ".expr2text(eq)." for ".t)
         end_if;
         tofx:=op(tofx,1);
      end_if;
      // The new integration interval for the new integration variable t:
      u:=  t = limit(tofx,_x = op(i, [2,2,1]), Right)
                ..
               limit(tofx,_x = op(i, [2,2,2]), Left);
    else u:= t;
    end_if;
    foft:=eval(subsex(op(i,1),[tofx=t, _x=xoft]));
    foft:=simplify(foft*diff(xoft, t));
    if (has(foft, sin) or has(foft, cos)) and 
       has(foft, arctan) then
       tmp:= rewrite(foft, tan):
       if not has(tmp, tan) then
          foft:= expr(factor(tmp));
       end_if;
    end_if;
    hold(int)(foft, u, op(i, 3..nops(i))):
  end_proc:
  
// internal routine, with an outer counter for the depth
proc()
  option escape;
  local depth;
begin
intlib::tryChangeVar :=
proc(i, to_subs)
  local t, i2, er, dis;
begin
  // to bail out from pattern lookup, throw an error
  if depth > 10 then error("deep recursion"); end_if;
  depth := depth+1;
  dis := discont(to_subs,
		 if type(op(i, 2))="_range" then
		   op(i, [2, 1])
		 else
		   op(i, 2)
		 end, Dom::Real);
  if dis <> {} then error("bad substitution"); end;
  er := traperror((i := unblock(subs(i, [hold(hold(intlib::intfn))=hold(int),
					 hold(intlib::intfn)=hold(int)]),
				blockTransparent, TRUE, FALSE);
		   t := genident("cv");
		   i2 := eval(intlib::changevar(i, t=to_subs, t))));
  depth := depth - 1;
  if er <> 0 then lasterror(); end_if;
  if not hastype(i2, "int") then
    subs(i2, t=to_subs);
  else
    // pattern failure: do not return FAIL, raise an error!
    error("");
  end_if;
end_proc:
  
  depth := 0;
end_proc():
  
// end of file 
