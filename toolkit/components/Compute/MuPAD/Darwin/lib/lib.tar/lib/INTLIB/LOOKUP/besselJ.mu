/* tries to compute the indefinite integral of an expression
  containing the Bessel J function.

  Reference: Integrals and Series vol. 2, 
             Prudnikov, Brychkov and Marichev, 1986, OPA (Amsterdam) */

//alias(_pattern = intlib::_pattern): geht nicht!

intlib::lookupbesselJ := proc(f) save v,a;
begin
   delete v,a;
   case type(f) of "_mult" do return((
      // case 1/x^2*J(v,x)^2, formula 20 page 41 
      if intlib::matchassign(f,1/_X^2*besselJ(_pattern(v,not has,_X),_X)^2) then
	 expand(2/(4*v^2-1)/_X*((_X*diff(besselJ(v,_X),_X)+besselJ(v,_X)/2)^2
	   +(_X^2-v^2+1/4)*besselJ(v,_X)^2))
      // case x^v*J(v-1,x): formula 9.1.30 part 1 of Abramowitz & Stegun 
      elif intlib::matchassign(f,_X^_pattern(v,not has,_X)*besselJ(_pattern(v)-1,_X))
	   then _X^v*besselJ(v,_X)
      // case 1/x^v*J(v+1,x): formula 9.1.30 part 2 of Abramowitz & Stegun 
      elif intlib::matchassign(f,_X^(-_pattern(v,not has,_X))*besselJ(_pattern(v)+1,_X))
	   then -_X^(-v)*besselJ(v,_X)
      // case x*J(p,a*x)^2 
      elif intlib::matchassign(f,_X*besselJ(_pattern(v,not has,_X),
	_pattern(a,not has,_X)*_X)^2) then
	   _X^2/2*(besselJ(v,a*_X)^2-besselJ(v-1,a*_X)*besselJ(v+1,a*_X))
      else FAIL
      end_if))
   of "besselJ" do return((
      if op(f,1)=1 and not has((a:=op(f,2)/_X),_X) then
         -besselJ(0,a*_X)/a
      else FAIL end_if))
   end_case;
   FAIL
end_proc:
