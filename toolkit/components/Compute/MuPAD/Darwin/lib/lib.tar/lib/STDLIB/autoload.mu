// $Id: autoload.mu 36915 2006-02-15 09:09:15Z ccr $

/*
   autoload -- an advanced loadproc

   autoload(somelib::function) causes the same effect as
   somelib::function := loadproc(somelib::function, "SOMELIB", "function"),
   handling nested libraries in the obvious way.

   To think about: Additional arguments, should they denote
   the filename to use or regarded as additional args to loadproc,
   i.e., a function to call after loading the file?
*/

stdlib::standardFilename :=
proc(p)
  option hold;
  local prefix, file, t;
begin
  if domtype(p) = DOM_VAR then
    p := context(p);
  end_if;
  case domtype(p)
    of DOM_IDENT do
      prefix := "STDLIB/";
      file := expr2text(p);
      break;
    of DOM_EXPR do
      if op(p, 0) = hold(slot) then
	file := op(p, 2);
	t := op(p, 1);
	prefix := "";
	while op(t, 0) = hold(slot) do
	  prefix := stringlib::upper(op(t,2)).stdlib::PathSep.prefix;
	  t := op(t, 1);
	end_while;
	case t
	  of hold(Dom) do
	    prefix := "DOMAINS".stdlib::PathSep."DOMAIN".
		     stdlib::PathSep.prefix;
	    break;
	  of hold(Cat) do
	    prefix := "DOMAINS".stdlib::PathSep."CATEGORY".
		     stdlib::PathSep.prefix;
	    break;
	  of hold(Ax) do
	    prefix := "DOMAINS".stdlib::PathSep."AXIOM".
		     stdlib::PathSep.prefix;
	    break;
	  of hold(transform) do
	    prefix := "TRANS".stdlib::PathSep.prefix;
	    break;
	  otherwise
	    prefix := stringlib::upper(expr2text(t)).
		     stdlib::PathSep.prefix;
	end_case;
	break;
      end_if;
      // else fall through
    otherwise
      error("expecting an identifier or a slot expression");
  end_case;
  [prefix, file];
end_proc:
  
autoload :=
proc(p)
  option hold;
  local prefix, file;
begin
  [prefix, file] := context(hold(stdlib::standardFilename)(p));
  
  context(hold(_assign)(p,
			hold(loadproc)(p, prefix, file)));
end_proc:
