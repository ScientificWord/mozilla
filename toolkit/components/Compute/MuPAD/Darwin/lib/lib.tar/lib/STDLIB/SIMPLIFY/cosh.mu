
/* The simplify attribute of cosh

   Rules:
   1) cosh(x)            -> apply simplify and stdlib::normalizesign to x
   2) cosh(x + k*PI*I/2) -> I^k * cosh/sinh (x + frac(k)*PI*I/2)
                            if domtype(k) = DOM_RAT
   3) cosh(x + k*PI*I/2) -> I^k * cosh/sinh (x) if is(k, Type::Residue(?,2)
	                    or is(k, Type::Residue(?,4))
   4) cosh(x)            -> cosh(-x) if stdlib::hasmsign(x) = TRUE

Author: Juergen Gerhard, 14.4.00
*/

cosh := slot(cosh, "simplify", proc(a)
   name cosh::simplify;
   local x, l, i, e, rest, symbolic_expo, integer_expoI,
     prop, Mod, Rem, tmp;
begin
   // recursively simplify the argument
   /* the double simplify is a workaround for the following simplify bug:
      simplify((x+y)^2) -> (x+y)^2, but
      simplify(-(x+y)^2) -> x^2+2*x*y+y^2 */
   x := simplify(-simplify(-op(a)));
   x := stdlib::normalizesign(x)[2]:

   // final symbolic exponent of -1
   symbolic_expo := 0;
   /* final integer exponent of I */
   integer_expoI := 0;
   // finally remaining arguments
   rest := 0;

   // l := list of summands
   if type(x) = "_plus" then
     l := [op(x)]
   else
     l := [x]
   end_if;

   // l := list of pairs [summand, summand*2/I/PI]
   l := map(l, proc(x) begin [x, x*2/I/PI] end_proc);

   /* check whether there is a summand with domtype(summand*2/I/PI) =
      DOM_RAT or DOM_INT (there can be at most one) */
   l := split(l, proc(x) begin
     contains({DOM_RAT, DOM_INT}, domtype(op(x, 2))) end_proc);
   if nops(l[1]) > 0 then
     // reduce the rational number modulo 1
     tmp := op(l, [1,1,2]);
     rest := frac(tmp)*I*PI/2;
     integer_expoI := floor(tmp) mod 4;
   end_if;

   // select those summands with is(summand*2/I/PI, Type::Integer) = TRUE
   l := split(l[2], proc(x) begin is(op(x, 2), Type::Integer) end_proc);

   // rest := unsimplified arguments
   rest := _plus(op(map(l[2].l[3], op, 1)), rest);
 
   // process arguments of Type::Integer
   l := l[1];
   for i from 1 to nops(l) do
     e := op(l, [i, 2]);

     // simplify exponents that are known to be in some residue class mod 4
     prop := property::_getprop(e, property::Residue);
     if type(prop) = "Residue" then
	Mod := prop::dom::modulus(prop);
	Rem := prop::dom::remainder(prop);
        if domtype(Mod / 4) = DOM_INT then
          // e is in the residue class of Rem mod 4
          integer_expoI := integer_expoI + Rem mod 4;
	elif domtype(Mod / 2) = DOM_INT then
          // e is odd or even
          Rem := Rem mod 2;
          integer_expoI := integer_expoI + Rem mod 4;
	  symbolic_expo := symbolic_expo + (e - Rem)/2;
        else
          rest := rest + op(l, [i, 1]);
        end_if
     else
       rest := rest + op(l, [i, 1]);
     end_if
   end_for;

   /* extract a minus sign from rest if necessary */
   if stdlib::hasmsign(rest) then
     rest := -rest;
     integer_expoI := - integer_expoI mod 4;
   end_if;

   /* determine final result according to the formula
      cosh(x+I*k*PI/2) = cos(-I*x+k*PI/2) */
   case modp(integer_expoI, 4)
   of 0 do
     return((-1)^(symbolic_expo) * cosh(rest))
   of 1 do
     return((-1)^(symbolic_expo) * I*sinh(rest))
   of 2 do
     return((-1)^(symbolic_expo) * -cosh(rest))
   of 3 do
     return((-1)^(symbolic_expo) * -I*sinh(rest))
   end_case;
   error("should never happen")
end_proc):
