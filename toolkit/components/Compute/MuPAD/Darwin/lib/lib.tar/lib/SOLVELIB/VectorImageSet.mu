

domain solvelib::VectorImageSet
  category Cat::Set;
  inherits Dom::ImageSet;
  
    allowVectors:= TRUE;


    inhomogleft_minus:=
    table(
          DOM_SET =
          proc(vset, S: DOM_SET)
          begin
            if S= {} then
              return(vset)
            end_if;
            FAIL
          end_proc
          );


    inhomogright_minus:=
    table(
          DOM_SET =
          proc(S: DOM_SET, vset)
            local x, newS, unk;
          begin
            newS:= unk := {};
            for x in S do
              case vset::dom::simpexIn(x, vset)
                of TRUE do
                  // x has to be deleted, do nothing
                  break;
                of FALSE do
                  // x belongs to the result
                  newS:= newS union {x};
                  break
                otherwise
                  // the status of x remains unknown
                  unk:= unk union {x}
              end_case;
            end_for;
            if unk = {} then
              return(newS)
            elif newS = {} then
              return(hold(_minus)(unk, vset))
            else
              return(hold(_union)(newS, hold(_minus)(unk, vset)))
            end_if
          end_proc
          );

    
    inhomog_union:=
    table(
          DOM_SET =
          proc(vset, S: DOM_SET)
          begin
            if S= {} then
              return(vset)
            end_if;
            FAIL
          end_proc
          );

    inhomog_intersect:=
    table(
          DOM_SET =
          proc(vset, S: DOM_SET)
            local newS, x, unk;
          begin
            newS:= {};
            unk:= {};
            for x in S do
              case vset::dom::simpexIn(x, vset)
                of FALSE do
                  // x has to be deleted, do nothing
                  break;
                of TRUE do
                  // x belongs to the result
                  newS:= newS union {x};
                  break
                otherwise
                  // the status of x remains unknown
                  unk:= unk union {x}
              end_case;
            end_for;
            if unk = {} then
              return(newS)
            elif newS = {} then
              return(hold(_intersect)(unk, vset))
            else
              return(hold(_union)(newS, hold(_intersect)(unk, vset)))
            end_if
          end_proc
          );

    inhomog_plus:=
    table(
          DOM_SET =
          proc(vset, S: DOM_SET)
          begin
            // for each vector s in S and v = expr(vset), compute
            // {s+v; op(vset, 2) in op(vset, 3)} and take the union of all
            // these
            map(map(S, zip, expr(vset), _plus),
                solvelib::VectorImageSet, extop(vset, 2..3));
            _union(op(%))
          end_proc
          );

    // vectors cannot be multiplied
    inhomog_mult:= table();
    
    bin_union:= () -> FAIL;

    /*
       bin_intersect(v, w) - compute v \cap w
       With
         v= {[v1, ..., vn]; x1 \in S_1, .., xk \in S_k}
       and
         w= {[w1,..., wn]; y1 \in S_1, .., yl \in S_l}

       that is, we have to solve
       {v1 = w1, ..., vn = wn} for x1, .., xk, y1,..,yl 

    */
    bin_intersect:=
    proc(v: dom, w:dom)
      local x, y, sol, var, X;
    begin
      if solvelib::dimension(v) <> solvelib::dimension(w) then
        error("Dimensions do not match")
      end_if;
      x:= v::dom::variables(v);
      y:= w::dom::variables(w);
      v:= expr(v);
      w:= expr(w);
      // handle alias - problem
      for var in {op(x)} intersect {op(y)} do
        X:= genident();
        y:= subs(y, var = X);
        w:= subs(w, var = X)
      end_for;
      sol:= solve(v = w, x.y, VectorFormat);
      if sol = {} then
        return({})
      end_if;
      X:= solvelib::splitVectorSet(solvelib::selectIndices
                                   (sol, [$1..nops(x)]));
      if X = FAIL then
        FAIL
      else
        solvelib::VectorImageSet(v, x, X)
      end_if
    end_proc;


    /* substituteBySet(a, x, S)

       creates the set of all a that can be obtained by substituting some
       element of S for x

     */
    substituteBySet:=
    proc(a, x: DOM_LIST, S: dom)
      local i;
    begin
      if nops(x) <> solvelib::dimension(S) then
        error("dimensions do not match")
      end_if;
      dom::new(subs(a, x[i] = expr(S)[i] $i=1..nops(x)),
               dom::variables(S),
               dom::sets(S))
    end_proc;

    
    simpexIn:=
    proc(a, S: dom)
      local x, vars: DOM_LIST, eq, newx, sol;
    begin

      vars:= dom::variables(S);
      eq:= expr(S);
      for x in vars do
        if has(a, x) then
          // avoid alias - problem
          newx:= genident();
          eq:= subs(eq, x= newx);
          vars:= subs(vars, x = newx)
        end_if
      end_for;
        
      if indets(eq) minus Type::ConstantIdents minus {op(vars)} = {} then
        sol:= solve(zip(eq, a, _equal), vars, VectorFormat) intersect
              solvelib::cartesianProduct(op(S::dom::sets(S)));
        if sol = {} then
          return(FALSE)
        elif type(sol) = DOM_SET then
          return(TRUE)
        end_if
      end_if;
  
      hold(_in)(a, S) // not yet implemented, would require an "exists"-
                        // quantifier
    end_proc;
    
end_domain:
