Ci::complexDiscont:= Dom::Interval(-infinity, [0]):
