// $Date: 2005-11-22 14:16:15 +0100 (Tue, 22 Nov 2005) $  $Author: rensmann $  $Revision: 35046 $


/*

Arithmetical -- the type of all arithmetical expressions
without equations/inequations

*/

//Type::Arithmetical:= new(Type, "Arithmetical",
//                         proc(t, x)
Type::Arithmetical :=
newDomain("Type::Arithmetical"):

Type::Arithmetical::non_arith_fns :=
hold({_equal, _less, _leequal, _unequal,
      _and, _or, _not, _lazy_and, _lazy_or,
      _exprseq,
      _intersect, _union, _minus,
      _assign, _range, _in,
      _break, _case, _for, _for_down,
      _for_in, _if, _next, _repeat,
      _stmtseq, _seqbegin, _while,
      _fconcat, _fnest}):

Type::Arithmetical::testtype :=
  proc(x, t)
    option noDebug;
    local r, subexprs, i;
  begin
    if args(0) <> 2 and args(0) <> 3 then
      return(FAIL);
    end_if;

    case domtype(x)
      of DOM_EXPR do
        if contains(dom::non_arith_fns, op(x, 0)) then
          return(FALSE)
        elif contains(hold({_mult, _plus, _power}), op(x, 0)) then
          subexprs := select([op(x)], has, dom::non_arith_fns);
          r := _lazy_and(dom::testtype(op(subexprs, i), t, TRUE)
                         $i=1..nops(subexprs));
          if args(0) = 2 and r = UNKNOWN then
            return(FAIL);
          else
            return(r);
          end_if;
        end_if;
        return(TRUE);

      of DOM_IDENT        do
      of DOM_INT          do
      of DOM_COMPLEX      do
      of DOM_FLOAT        do
      of DOM_RAT          do
      of DOM_INTERVAL     do
        return(TRUE);
      of stdlib::Infinity do
      of stdlib::CInfinity do
      of undefined        do
      of rectform         do
      of O                do
      of Series::gseries  do
      of Series::Puiseux  do
      of numlib::contfrac do
      of contfrac         do
      of unit             do
        return(TRUE);

      of piecewise        do
      of Type             do
      of DOM_POLY         do
      of DOM_STRING       do
      of DOM_BOOL         do
      of DOM_NIL          do
      of DOM_NULL         do
      of DOM_FAIL         do
      of DOM_ARRAY        do
      of DOM_LIST         do
      of DOM_SET          do
      of DOM_TABLE        do
      of DOM_FUNC_ENV     do
      of DOM_EXEC         do
      of DOM_PROC         do
      of DOM_DOMAIN       do
        return(FALSE);

      of Factored         do
        subexprs:= coerce(x, DOM_LIST);
        r := _lazy_and(dom::testtype(op(subexprs, i), t, TRUE)
                       $i=1..nops(subexprs));
        if args(0) = 2 and r = UNKNOWN then
          return(FAIL);
        else
          return(r);
        end_if;
        // NOT REACHED
        assert(FALSE);

      otherwise
        r := x::dom::testtype(x, Type::Arithmetical);
        if args(0) = 3 and r = FAIL then
          return(UNKNOWN);
        else
          return(r);
        end_if;
    end_case
  end_proc:


null():

// end of file

