/* $Date: 2006-02-09 13:15:52 +0100 (Thu, 09 Feb 2006) $ $Author: stefanw $ $Revision: 36834 $ */

/*--
	solvelib::solve_poly --  solve a polynomial

	solve_poly( p, x, options )

	p  : polynomial
	x  : indeteminate
	

--*/

solvelib::solve_poly :=
proc(p: DOM_POLY, x: DOM_IDENT): Type::Set

local
  d, l, s,
  i: DOM_INT,
  j: DOM_INT,
  multi: DOM_BOOL,
  hasfloat: DOM_BOOL,
  options: DOM_TABLE;
  
begin
  if testargs() then
    if args(0) < 2 then
      error("expecting at least two arguments")
    end_if
  end_if;
  
  options:= solvelib::getOptions(args(3..args(0)));
  userinfo(3, "solve_poly called with ".expr2text(p));
  userinfo(10, "solving for ".expr2text(x));
  userinfo(10, "Options are ".expr2text(options));
  multi:= options["Multiple"];
  
  if stdlib::hasfloat(op(p,1)) then /* remove 0.0 terms */
    hasfloat:= TRUE;
    userinfo(4, "Removing floating-point zeroes");
    p:=mapcoeffs(p,
                 proc(a)
                 begin
                   if iszero(a) then
                     0
                   else
                     a
                   end_if
                 end_proc)
  else
    hasfloat:= FALSE
  end_if;
  d:=degree(p,x);
  if d<=1 then
    userinfo(10,  "poly has small degree, do not try to factor");
    return(solvelib::solve_poly_irred(p, x, options))
  else /* d >=2 */
    if hasfloat then
      s:= mapcoeffs(p, float);
      if {op(map(poly2list(s), domtype@op, 1))}
        // include DOM_INT, because of future float(0)=0
        minus {DOM_INT, DOM_FLOAT, DOM_COMPLEX} = {} then
        // no symbolic coefficients remain
        // Use numeric solver
        if multi then
          return(Dom::Multiset(op(numeric::polyroots(s))))
        else
          return({op(numeric::polyroots(s))})
        end_if
      end_if;
    end_if;
     
    userinfo(1,"trying to factor polynomial of degree ".d);
    userinfo(2,"polynomial is ".expr2text(p));
    // do not try factor with field extensions
    // because there could be many irrational
    // coefficients
    l:= factor(p, MaxDegree = 1);
    assert(domtype(l) = Factored);
    l:= Factored::convert_to(l, DOM_LIST);
    userinfo(5, "Factorization is ".expr2text(l));
      
    assert(type(l) = DOM_LIST);

    // remove all factors with negative multiplicity
    // (they must have degree 0, since p is a polynomial)
    // since they must be nonzero, we multiply all other factors
    // by them: this is an equivalence, and it is the best way
    // to express the implicit assumption that the denominators
    // of the input are nonzero
    
    i:= 1;
    while 2*i < nops(l) do
      if l[2*i+1] >=0 then
        i:= i+1
      else
        // this may happen, but such factors must be independent
        // of x, since p is known to be a poly
        assert(degree(l[2*i]) = 0);
        userinfo(5, "Implicitly assuming ".expr2text(l[2*i] <> 0));
        // multiply factors by l[2*i] to make them monic if possible
        for j from 2 to nops(l) step 2 do
          if l[j+1] >= 0 then
            l[j]:= multcoeffs(l[j],
                              gcd(coeff(l[2*i], 0)^l[2*i+1], lcoeff(l[j])))
          end_if
        end_for;
        // delete factor and multiplicity
        delete l[2*i];
        delete l[2*i];
      end_if;
    end_while;

    s:= denom(l[1]);
    for j from 2 to nops(l) step 2 do
      l[j]:= multcoeffs(l[j], 1/s)
    end_for;

    if multi then
      s:= Dom::Multiset()
    else
      s:= {}
    end_if;
      
    for i from 1 to nops(l) div 2 do
      userinfo(4, "Processing ".expr2text(i)."th irreducible factor");
      if l[2*i+1] < 0 then
        // this may happen, but such factors must be independent
        // of x, since p is known to be a poly
        assert(not has(l[2*i], x));
        userinfo(5, "Implicitly assuming ".expr2text(l[2*i] <> 0));
        
      elif multi then
        s:= s union
        (Dom::Multiset)::_union(
                 solvelib::solve_poly_irred(poly(l[2*i],[x]),x,options)
                                $l[2*i+1]);
        
      else
        s:=s union
            _union(solvelib::solve_poly_irred(poly(l[2*i],[x]), x,options))
      end_if;
    end_for;

    return(s)
  
  end_if;

  // NOT REACHED
  assert(FALSE)
end_proc:

/* end of file */

