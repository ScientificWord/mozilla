/* $Id: patterns_write.mu 39052 2006-05-16 17:00:42Z meista $
 * patterns_write: generate and write pattern FSA used by solvelib::pattern
 */



generateFSA :=
proc()
  local plist, pattern, C1, C2, C3, a, b, m, n, Rhs, x, opts, k, i;
begin
  genidents :=
  proc()
  begin
    C1   := genident();
    C2   := genident();
    C3   := genident();
    a    := genident();
    b    := genident();
    m    := genident();
    n    := genident();
    Rhs  := genident();
    x    := genident();
    opts := genident();
    k    := genident();
    i    := genident();
  end_proc;

  allCases :=
  proc(pl, vars)
    local v;
  begin
    if vars = {} then
      return(pl);
    else
      v := vars[1];
      return(allCases(pl.subs(pl, `##`(v) = 1, v = 1), vars minus {v}));
    end_if;
  end_proc;

  plist := [];

  /* C1*f(x)+C2*ln(C3*f(x)) = Rhs
   * (first wrightOmega case, real)
   */
  genidents();
  pattern :=
    [`#solve`(`##`(C1)*`##`(a)+`##`(C2)*ln(`##`(C3)*`##`(b)) = `##`(Rhs),
              `##`(x),
              `##`(opts)),
     piecewise([C1/C2/C3*exp(Rhs/C2) >= -exp(-1),
                {C2/C1*lambertW(0, C1/C2/C3*exp(Rhs/C2))}],
               [C1/C2/C3*exp(Rhs/C2) < -exp(-1),
                {}]),
     [op(map([C1, C2, C3, Rhs],
             foo->subs(blockTransparent(not has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      op(map([a, b],
             foo->subs(blockTransparent(has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      subs(blockTransparent(bool(testeq(`#a`, `#b`) = TRUE)),
           `#a` = a, `#b` = b),
      subs(blockTransparent(`#opts`["Real"]),
           `#opts` = opts)]];
  plist := plist.allCases([pattern], {C1, C2, C3});

  /* C1*f(x)+C2*ln(C3*f(x)) = Rhs
   * (first wrightOmega case)
   */
  genidents();
  pattern :=
    [`#solve`(`##`(C1)*`##`(a)+`##`(C2)*ln(`##`(C3)*`##`(b)) = `##`(Rhs),
              `##`(x),
              `##`(opts)),
     freeze(solvelib::preImage)(a, x,
       piecewise([Re(Rhs) <= -1 and Im(Rhs) = PI and
                  exp(-wrightOmega(ln(C1/C2/C3)+(Re(Rhs)-I*PI)/C2))
                    *exp(Rhs/C2)/C3 in R_,
                  {exp(-wrightOmega(ln(C1/C2/C3)+Rhs/C2))
                     *exp(Rhs/C2)/C3,
                   exp(-wrightOmega(ln(C1/C2/C3)+(Re(Rhs)-I*PI)/C2))
                     *exp(Rhs/C2)/C3}],
                 [Re(Rhs) <= -1 and Im(Rhs) = PI and
                  not exp(-wrightOmega(ln(C1/C2/C3)+(Re(Rhs)-I*PI)/C2))
                        *exp(Rhs/C2)/C3 in R_
                  or Re(Rhs) > -1 or abs(Im(Rhs)) <> PI,
                  {exp(-wrightOmega(ln(C1/C2/C3)+Rhs/C2))
                     *exp(Rhs/C2)/C3}],
                 [Re(Rhs) <= -1 and Im(Rhs) = -PI,
                  {}]),
       opts),
     [op(map([C1, C2, C3, Rhs],
             foo->subs(blockTransparent(not has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      op(map([a, b],
             foo->subs(blockTransparent(has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      subs(blockTransparent(bool(testeq(`#a`, `#b`) = TRUE)),
           `#a` = a, `#b` = b),
      subs(blockTransparent(not `#opts`["Real"]),
           `#opts` = opts)]];
  plist := plist.allCases([pattern], {C1, C2, C3});

  /* C1*f(x)^n+C2*ln(C3*f(x)^m) = Rhs
   * (second wrightOmega case)
   */
  genidents();
  pattern :=
    [`#solve`(`##`(C1)*`##`(a)^`##`(n)
                +`##`(C2)*ln(`##`(C3)*`##`(b)^`##`(m)) = `##`(Rhs),
              `##`(x),
              `##`(opts)),
     freeze(solvelib::preImage)(a, x,
       piecewise([Re(Rhs) > -1 or Im(Rhs) <> -PI,
                  {exp(-wrightOmega(ln(C1*n/C2/C3^(n/m)/m)+n*Rhs/C2/m)/n)
                     *exp(Rhs/C2/m)/C3^(1/m)}],
                 [Re(Rhs) <= -1 and Im(Rhs) = -PI,
                  {}]),
       opts),
     [op(map([C1, C2, C3, m, n, Rhs],
             foo->subs(blockTransparent(not has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      op(map([a, b],
             foo->subs(blockTransparent(has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      op(map([m, n],
             foo->subs(blockTransparent(bool(is(`#foo` in Z_) = TRUE)),
                       `#foo` = foo))),
      subs(blockTransparent(bool(testeq(`#m`, `#n`) = FALSE and
             (testeq(`#m`, 1) = FALSE or testeq(`#n`, 1) = FALSE))),
           `#m` = m, `#n` = n),
      subs(blockTransparent(bool(testeq(`#a`, `#b`) = TRUE)),
           `#a` = a, `#b` = b),
      subs(blockTransparent(not `#opts`["Real"]),
           `#opts` = opts)]];
  plist := plist.allCases([pattern], {C1, C2, C3, m, n});

  /* C1*f(x)+C2*exp(C3*f(x)) = Rhs
   * (second lambertW case, real)
   */
  genidents();
  pattern :=
    [`#solve`(`##`(C1)*`##`(a)+`##`(C2)*exp(`##`(C3)*`##`(b)) = `##`(Rhs),
              `##`(x),
              `##`(opts)),
     piecewise([C2*C3*exp(C3*Rhs/C1)/C1 >= -exp(-1),
                freeze(solvelib::preImage)(a, x,
                  hold(Dom::ImageSet)(
                    Rhs/C1-lambertW(k, C2*C3*exp(C3*Rhs/C1)/C1)/C3,
                    k,
                    piecewise([C2*C3*exp(C3*Rhs/C1)/C1 < 0,
                               {-1, 0}],
                              [C2*C3*exp(C3*Rhs/C1)/C1 >= 0,
                               {0}])),
                  opts)],
               [C2*C3*exp(C3*Rhs/C1)/C1 < -exp(-1),
                {}]),
     [op(map([C1, C2, C3, Rhs],
             foo->subs(blockTransparent(not has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      op(map([a, b],
             foo->subs(blockTransparent(has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      subs(blockTransparent(bool(testeq(`#a`, `#b`) = TRUE)),
           `#a` = a, `#b` = b),
      subs(blockTransparent(`#opts`["Real"]),
           `#opts` = opts)]];
  plist := plist.allCases([pattern], {C1, C2, C3});

  /* C1*f(x)+C2*exp(C3*f(x)) = Rhs
   * (second lambertW case)
   */
  genidents();
  pattern :=
    [`#solve`(`##`(C1)*`##`(a)+`##`(C2)*exp(`##`(C3)*`##`(b)) = `##`(Rhs),
              `##`(x),
              `##`(opts)),
     freeze(solvelib::preImage)(a, x,
       hold(Dom::ImageSet)(
         Rhs/C1-lambertW(k, C2*C3*exp(C3*Rhs/C1)/C1)/C3,
         k,
         Z_),
       opts),
     [op(map([C1, C2, C3, Rhs],
             foo->subs(blockTransparent(not has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      op(map([a, b],
             foo->subs(blockTransparent(has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      subs(blockTransparent(bool(testeq(`#a`, `#b`) = TRUE)),
           `#a` = a, `#b` = b),
      subs(blockTransparent(not `#opts`["Real"]),
           `#opts` = opts)]];
  plist := plist.allCases([pattern], {C1, C2, C3});

  /* C1*f(x)^n+C2*exp(C3*f(x)) = 0
   * (third lambertW case)
   */
  genidents();
  pattern :=
    [`#solve`(`##`(C1)*`##`(a)^`##`(n)+`##`(C2)*exp(`##`(C3)*`##`(b)) = 0,
              `##`(x),
              `##`(opts)),
     freeze(_union)(freeze(_seqgen)(
       freeze(solvelib::preImage)(a, x,
         hold(Dom::ImageSet)(
           -n*lambertW(k, sign(n)*(-1)^(sign(n)*n)*exp(2*PI*I*i/n)
                            *(-C2*C3^n/C1)^(sign(n)/n)/n)/C3,
           k,
           Z_),
         opts),
       i,
       1..abs(n))),
     [op(map([C1, C2, C3, n],
             foo->subs(blockTransparent(not has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      op(map([a, b],
             foo->subs(blockTransparent(has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      subs(blockTransparent(bool(testeq(`#a`, `#b`) = TRUE)),
           `#a` = a, `#b` = b),
      subs(blockTransparent(bool(is(`#n` in Z_) = TRUE)),
           `#n` = n),
      subs(blockTransparent(not `#opts`["Real"]),
           `#opts` = opts)]];
  plist := plist.allCases([pattern], {C1, C2, C3, n});

  /* C1*f(x)^n*exp(C2*f(x)^m) = Rhs
   * (yet another lambertW case)
   */
  genidents();
  pattern :=
    [`#solve`(`##`(C1)*`##`(a)^`##`(n)*exp(`##`(C2)*`##`(b)^`##`(m))
                = `##`(Rhs),
              `##`(x),
              `##`(opts)),
     piecewise([Rhs <> 0,
                freeze(solvelib::preImage)(a, x,
                  hold(Dom::ImageSet)(
                    (sign(m)*m)^(-1/m)*n^(1/m)*(Rhs/C1)^(1/n)
                      /(sign(m)*C2*(Rhs/C1)^(m/n))^(1/m)
                      *lambertW(k, m*C2*(Rhs/C1)^(m/n)/n)^(1/m),
                    k,
                    Z_),
                  opts)],
               [Rhs = 0,
                freeze(solvelib::preImage)(a, x, {0}, opts)]),
     [op(map([C1, C2, m, n, Rhs],
             foo->subs(blockTransparent(not has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      op(map([a, b],
             foo->subs(blockTransparent(has(`#foo`, `#x`)),
                       `#foo` = foo, `#x` = x))),
      op(map([m, n],
             foo->subs(blockTransparent(bool(is(`#foo` in Z_) = TRUE)),
                       `#foo` = foo))),
      subs(blockTransparent(bool(testeq(`#m`, `#n`) = FALSE or
             testeq(`#m`, 1) = TRUE and testeq(`#n`, 1) = TRUE)),
           `#m` = m, `#n` = n),
      subs(blockTransparent(bool(testeq(`#a`, `#b`) = TRUE)),
           `#a` = a, `#b` = b),
      subs(blockTransparent(not `#opts`["Real"]),
           `#opts` = opts)]];
  plist := plist.allCases([pattern], {C1, C2, m, n});

  return(matchlib::compile::toFSA(plist));
end_proc:



solvepatternFSA := generateFSA():
write("patternFSA.mb", solvepatternFSA):
