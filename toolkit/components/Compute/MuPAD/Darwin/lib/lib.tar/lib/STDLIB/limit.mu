// $Date: 2007-01-24 13:44:49 +0100 (Wed, 24 Jan 2007) $ $Author: Stefan Wehmeier $ $Revision: 42621 $
// frankp, 11.01.1995

/*
        limit  -- computing the limit of expressions

        limit(expr,x[=a] [,dir])

        expr -- expression in x
        x    -- limit variable x (an identifier)
        a    -- (optional) limit point (possible infinity or -infinity)
                default is 0
        dir  -- (optional) direction: one of 'Left', 'Right', or 'Real'

        The limit function attempts to compute the limiting value of expr
        as x goes to a.
   
        If dir is not specified, or if dir is 'Real', the limit is the real 
        bidirectional limit, except in the case where the limit point is 
        infinity or -infinity. In this case the limit is from the left to 
        infinity and from the right to -infinity, respectivly.
   
        limit only consider real valued functions, and any assigned 
        variables in the expression are assumed to be real.

        limit returns 'undefined' if the limit is not defined, or 
        FAIL if ORDER is not big enough for series.  

        If the limit could not be computed then limit returns
        unevaluated, i.e. the result is of type "limit".
*/

//	S.H.: Dec. 2002 inserted option Intervals. 
//	If TRUE then an interval containing all accumulations points 
//	will be returned
//	if FALSE then if more than one accumulation point is 
//	encountered, undefined is returned


alias(EPS = 10^(-7)):


limit:=
proc(f,pointt,dir=hold(Real), AccumPoints=hold(FALSE))
  option hold;
  save MAXEFFORT;
  local i, t, s, u, x, lp, rf, rlp, applyFloat, argv, oldprop,
  success: DOM_BOOL,
  maxeffort: DOM_FLOAT;
begin

/**********************************
  argument evaluation and overloading section
  Problem: the limit variable should have the property to be near
           the limit point; f should not be evaluated until this property has
           been set.
           If the arguments are nonsense, there is no limit variable, and thus
           no property can be set.
           But if f::dom overloads limit, we cannot decide whether the
           arguments are nonsense. Thus we also have to evaluate f if argument
           checking fails, in order to find out what f::dom actually is.
*******/

  
  case args(0)
    of 0 do
      error("limit called without arguments")
    of 1 do
      f:= context(f);
      if type(f) = "_exprseq" then
        return(eval(hold(limit)(f)))
      end_if;
      if f::dom::limit <> FAIL then
        return(f::dom::limit(f))
      else
        error("at least two arguments expected")
      end_if;
    otherwise
      argv:= [context(args(2..args(0)))];
  end_case;

  case nops(argv)   
    of 3 do
      AccumPoints := argv[3]
      // fall through
    of 2 do
      if argv[2] = Intervals then
        AccumPoints := TRUE;
        dir := Real
      else        
        dir:= argv[2]
      end_if;
      // fall through
    of 1 do
      pointt:= argv[1];
      break
    otherwise
      f:= context(f);
      if f::dom::limit <> FAIL then
        return(f::dom::limit(context(args())))
      end_if;
      error("too many arguments")
  end_case;
  


  if testargs() then
    if traperror
    ((
      if type(pointt) = "_equal" then
        if domtype(op(pointt,1)) <> DOM_IDENT then
          error("invalid limit variable (expecting an identifier)")
        end_if;
      if has( op(pointt,2), op(pointt,1) ) then
        error("expansion variable appears in limit point")
      elif not testtype( op(pointt,2),Type::Arithmetical ) then
        error("limit point must be of 'Type::Arithmetical'")
      end_if
      elif domtype(pointt) <> DOM_IDENT then
      error("invalid limit variable (expecting an identifier)")
      end_if;
      
      if not contains({infinity, -infinity}, op(pointt,2)) and
        has( op(pointt,2),infinity ) then
        error("invalid limit point")
      end_if;

      if has(op(pointt,2), complexInfinity) then
        error("invalid limit point")
      end_if;

      
      if args(0) >= 3 and args(args(0)) <> Intervals then
        if not contains({hold(Right),hold(Left),hold(Real)},dir) then
          error("unknown limit direction")
        elif op(pointt,2) = infinity and
          dir = Right or
          op(pointt,2) = -infinity and dir = Left
          then
          error("inconsistent limit direction")
        end_if;
      end_if)) <> 0 then
      f:= context(f);
      if f::dom::limit <> FAIL then
        return(f::dom::limit(f, pointt, dir, AccumPoints))
      else
        lasterror()
      end_if; 
    end_if; // traperror <> 0
  end_if; // testargs()

    
  
  if type(pointt) = "_equal" then
    x:= op(pointt,1);
    lp:= op(pointt,2)
  else
    x:= pointt;
    lp:= 0
  end_if;


  // evaluate f in context, taking properties into account
  save x;
  oldprop:= getprop(x);
  if traperror
    ((
      case lp
        of infinity do
          assume(x > 20, _and);
          break
        of -infinity do
          assume(x < -20, _and);
          break
        otherwise
          if dir = Left then
            assume(x, Type::Interval(lp - EPS, lp), _and);
          elif dir = Right then
            assume(x, Type::Interval(lp, lp + EPS), _and)
          else
            assume(x, Type::Interval(lp - EPS, lp + EPS), _and)
          end_if
      end_case
      )) <> 0 then
    if stdlib::limit::printWarningsFlag = TRUE then
      warning("Could not attach the property of being close to ".
              "the limit point to limit variable")
    end_if
  end_if;

  if traperror((f:= context(f))) <> 0 then
    error("First argument is not defined on assuming that ".
          expr2text(x)." has property ".expr2text(getprop(x)))
  end_if;
    
  // we have to call unassume because the current series implementation
  // tends to slow down greatly if properties are used.
  if oldprop = x then
    unassume(x)
  else
    assume(x, oldprop)
  end_if;
  
  // allow overloading of the first argument of limit:
  if f::dom::limit <> FAIL then
    return(f::dom::limit( context(args()) ))
  end_if;

  
  if contains(argv, Intervals) > 0 then
    AccumPoints := TRUE;    //we want only points as limits
  end_if;				// unless otherwise desired by user


/****************************************************
  end of argument evaluation and overloading section
*****************************************************/

  
  case type( f )
    of "limit" do
      x:= op(f,1);
      t:= genident();
      if type(pointt) = "_equal" then
        lp:= op(pointt,2);
        if lp = infinity then
          assume( t > 0 );
        elif lp = -infinity then
          assume( t < 0 );
        elif testtype(lp,Type::Real) then
          case sign(lp)
            of 1 do
              assume( t>0 );
              if lp-1 > 0 then
                assume( t>1 )
              elif lp-1 < 0 then
                assume( t<1, _and )
              end_if;
              break
            of -1 do
              assume( t<0 );
              break
            of 0 do
              case dir
                of hold(Left) do
                  assume( t<0 );
                  break
                of hold(Right) do
                  assume( t>0 );
                  break
                of hold(Real) do
                  assume( t,Type::Real );
              end_case;
              break
            otherwise
              assume( t,Type::Real );
          end_case
        else
          return( procname(f, op(argv)) )
        end_if;

        x:= subs( x,op(pointt,1)=t );
        s:= limit( x,op(f,2..nops(f)) );
      else
        case dir
          of hold(Left) do
            assume( t<0 );
            break
          of hold(Right) do
            assume( t>0 );
            break
          of hold(Real) do
            assume( t,Type::Real );
        end_case;

        x:= subs( x,op(pointt,1)=t );
        s:= limit( x,op(f,2..nops(f)) );
      end_if;

      if s = f then
        return( procname(f, op(argv)) )
      elif type(s) = "limit" then
        return( procname(subs(s,t=op(pointt,1)),pointt) )
      else
        s:= limit( subs(s,t=op(pointt,1)),pointt );
        return( s )
      end_if
    of "sum" do
      if not has(op(f, 2), x) then
        // let us hope that limit(sum(...)) = sum(limit(...)) which
        // is mathematically not correct in general
        return(sum(limit(op(f, 1), op(argv)), op(f, 2)))
      end_if;
      if not has(op(f, 1), x) and type(op(f, 2)) = "_equal" then
        s:= limit(op(f, [2, 2, 1]), op(argv));
        t:= limit(op(f, [2, 2, 2]), op(argv));
        if [s, t] = [-infinity, infinity] then
          s:= sum(op(f, 1), op(f, [2, 1]) = -infinity..infinity);
          if not hastype(s, "sum") then
            return(s)
          end_if
        elif not hastype([s, t], "limit") and s <> infinity
          and t <> - infinity then
          return(sum(op(f, 1), op(f, [2, 1]) = s..t))
        end_if;  
      end_if;
      return(procname(f, op(argv)))
    // unevaluated cases
    of DOM_PROC do
    of DOM_EXEC do
    of Series::Puiseux do
    of Series::gseries do
    of "series" do
    of "int" do
    of DOM_SET do
    of DOM_LIST do
    of DOM_DOMAIN do
    of DOM_ARRAY do
    of "diff" do
      return( procname(f, op(argv)) )
    end_case;

 

  if domtype(x) <> DOM_IDENT then
    error("invalid limit variable (expecting an identifier)");
  end_if;


    
  applyFloat := id;
  // replace all floating point constants by rational approximations
  rf := misc::maprec(f, {DOM_FLOAT, DOM_COMPLEX} =
                     proc(f)
                       local r;
                     begin
                       r := numeric::rationalize(args(1), Minimize);
                       if r<> f then
                         applyFloat := float;
                       end_if;
                       r
                     end_proc);
  rlp := misc::maprec(lp, {DOM_FLOAT, DOM_COMPLEX} =
                      proc(f)
                        local r;
                      begin
                        r := numeric::rationalize(args(1), Minimize);
                        if r<> f then
                          applyFloat := float;
                        end_if;
                        r
                      end_proc);


  // extract constants
  case type(rf)
    of "_plus" do
      [s, t, u]:= split(rf, _not@has, x);
      if s <> 0 then
        return(applyFloat(s + limit(t, op(argv))))
      end_if;
      maxeffort:= MAXEFFORT/2;
      MAXEFFORT:= MAXEFFORT/nops(rf);
      u:= [op(rf)];
      t:= map(u, limit, op(argv));
      s:= 0;
      for i from 1 to nops(t) do
        if not hastype(t[i], "limit") and
          not has(t[i], {infinity, -infinity}) and
          t[i]<> undefined then
          s:= s+ t[i];
          u[i]:= 0;
        end_if;
      end_for;
      MAXEFFORT:= maxeffort;
      if contains(u, 0) > 0 then
        return(applyFloat(s + limit(_plus(op(u)), op(argv))))
      end_if;
      break
    of "_mult" do
      [s, t, u]:= split(rf, _not@has, x);
      s:= normal(s);
      if s <> 1 then
        return(applyFloat(s * limit(normal(t), op(argv))))
      end_if;
      // try to compute limit of each factor first
      u:= [op(rf)];
      maxeffort:= MAXEFFORT;
      // initialize
      t:= [FAIL $nops(u)];   
      s:= 1;
      success:= FALSE;
      MAXEFFORT:= MAXEFFORT/nops(u)/2;
      for i from 1 to nops(u) do
        t[i]:= limit(u[i], op(argv));
        if not has(t[i], {undefined, infinity}) and is(t[i]=0) = FALSE and
          not hastype(t[i], "limit") then
          s:= s*t[i];
          u[i]:= 1;
          success:= TRUE
        end_if
      end_for;
      MAXEFFORT:= maxeffort/2;
      if success then
         return(applyFloat(s * limit(_mult(op(u)), op(argv))))
      end_if;
      break
    of "_power" do
      if not has(op(rf, 1), x) and
        (is(op(rf, 1) <> 0) = TRUE or
         is(limit(sign(op(rf, 2)), x = rlp) > 0) = TRUE) then
        s:= limit(op(rf,2), op(argv));
        s:= op(rf, 1)^s;
        if s <> undefined then
          assert(s = infinity or s =-infinity or not has(s, infinity)
                 or type(s) = piecewise);
          return(applyFloat(s))
        end_if;
        // we may leave here, as the other heuristics will not apply
        break
      end_if;
      if domtype(op(rf, 2)) = DOM_INT then
        s:= limit(op(rf ,1), op(argv));
        if s = undefined or hastype(s, "limit") then
          break
        end_if;
        if op(rf,2) > 0 then
          return(applyFloat(s^op(rf,2)))
        end_if;
        // negative exponent
        case s
          of infinity do
          of -infinity do
            return(applyFloat(0))
          otherwise
            if op(rf,2) mod 2 = 0 then
              return(piecewise([s=0, infinity],
                               [s<>0, applyFloat(s^op(rf, 2))]
                               ))
            else  
              // op(rf, 2) is odd
              return(piecewise
                     ([s=0, limit(sign(op(rf ,1)), op(argv))*infinity],
                      [s<>0, applyFloat(s^op(rf, 2))]
                      )
                     )
            end_if
        end_case;
      end_if;
      // try heuristic a^b -> exp(b*ln(a))
      // since we know that a formally depends on x,
      // we only have to exclude the case that it is really = 0
      // avoid testeq for performance reasons
      // if testeq(op(rf, 1), 0, Steps = 1) = FALSE then
      if not iszero(op(rf, 1)) then
        s:= limit(op(rf, 2)*ln(op(rf, 1)), op(argv));
        if has(s, infinity) then
          s:= expand(s);
          if Re(s) = -infinity then
            return(applyFloat(0))
          end_if;
          if s=infinity then
            return(infinity)
          end_if;
          if contains({infinity+I*infinity, infinity-I*infinity}, s) then
            return(undefined)
          end_if;
        elif s<>FAIL and s<>undefined then
          return(applyFloat(normal(exp(s))))
        end_if;
        break
      end_if;
      break
    of "erf" do
      s:= limit(op(rf, 1), op(argv));
      if Re(s) = infinity and not has(Im(s), {infinity, hold(Im)}) then
        return(1)
      end_if;
      if Re(s) = -infinity and not has(Im(s), {infinity, hold(Im)}) then
        return(-1)
      end_if;
      if s <> FAIL and not hastype(s, "limit") and not has(s, infinity) then
        return(erf(s))
      end_if;
      break
    of "Ei" do
      s:= limit(op(rf, 1), op(argv));
      if Re(s)=infinity then
        return(0)
      end_if;
      if s=-infinity then
        return(-infinity - I*PI)
      end_if;
      if s <> FAIL and not hastype(s, "limit") and not has(s, infinity) and
        is(s<>0) = TRUE then
        return(Ei(s))
      end_if;
      break
    of "Shi" do
      s:= limit(op(rf, 1), op(argv));
      if s=infinity or s=-infinity then
        return(s)
      end_if;
      if s <> FAIL and not hastype(s, "limit") and not has(s, infinity) then
        return(Shi(s))
      end_if;
      break
    of "zeta" do
      // cannot be done by asymptotic expansion
      // since zeries(zeta(s), s=infinity) does not work
      s:= limit(op(rf, 1), op(argv));
      if s=infinity then
        return(1)
      end_if;
      if s=-infinity then
        return(undefined)
      end_if;
      if s<>undefined and not hastype(s, "limit") and is(s<>1) = TRUE then
        return(zeta(s))
      end_if;
  end_case;
  

  
  if rlp <> infinity and rlp <> -infinity and dir = hold(Real) then
    if traperror((s:= stdlib::limit::limit_main( rf,x,rlp,hold(Right),
                                                AccumPoints )))
      <> 0 then
      stdlib::limit::reset();
      return( procname(f, op(argv)) )
    end_if;
    
    case s
      of UNKNOWN do
        stdlib::limit::reset();
        return( FAIL )
      of FAIL do
        stdlib::limit::reset();
        return( procname(f, op(argv)) )
      otherwise
        if traperror((t:= stdlib::limit::limit_main( rf,x,rlp,hold(Left),
                                                    AccumPoints )))
          <> 0 then
          stdlib::limit::reset();
          return( procname(f, op(argv)) )
        end_if;

        stdlib::limit::reset();
        case t
          of UNKNOWN do
            return( FAIL )
          of FAIL do
            return( procname(f, op(argv)) )
          otherwise
            if AccumPoints then
              if s=t then
                return(s)
              end_if;
              if testtype(s, Type::Set) then
                if testtype(t, Type::Set) then
                  return(s union t)
                else
                  return(s union {t})
                end_if
              elif testtype(t, Type::Set) then
                return({s} union t)
              else
                return({s, t})
              end_if
            end_if;
            // limit is s if s=t, and undefined otherwise
            return(
                   piecewise
                   ([s=t, applyFloat(s)])
                   )
        end_case
    end_case
  else
    // Note: the limit points infinity and -infinity will be handled in
    // the subroutine 'limit_main':
    if traperror((s:= stdlib::limit::limit_main( rf,x,rlp,dir, AccumPoints )))
		<> 0 then
      stdlib::limit::reset();
      return( procname(f, op(argv)) )
    end_if;

    stdlib::limit::reset();
    case s
      of UNKNOWN do
        return( FAIL )
      of FAIL do
        return( procname(f, op(argv)) )
      otherwise
        return( applyFloat(s) )
    end_case
  end_if
end_proc:

limit:= funcenv
(limit, NIL,
 table(
       "type" = "limit",
       "info" = "limit -- calculate limits [try ?limit for options]",
       "print"= "limit"
)):


limit::Simplify:=
proc(a: "limit")
  local S;
begin
  S:= Simplify(op(a, 1));
  if S <> op(a, 1) then
    eval(hold(limit)(S, op(a, 2..nops(a))))
  else
    a
  end_if
end_proc:

limit::Content :=
proc(Out, data)
  local direction, condition, tendsto, bvar;
begin
  if type(op(data, 2)) = "_equal" then
    tendsto := Out(op(data, [2,2]));
    bvar := Out(op(data, [2,1]));
  else
    tendsto := Out(0);
    bvar := Out(op(data, 2));
  end_if;
      
  if nops(data) = 3 then
    if op(data, 3) = hold(Right) then
      direction := Out::Ctendsto(["type" = "above"]);
    elif op(data, 3) = hold(Left) then
      direction := Out::Ctendsto(["type" = "below"]);
    else
      direction := Out::Ctendsto(["type" ="two-sided"]);
    end_if;
    condition := Out::Ccondition(
                                 Out::Capply(direction, bvar, tendsto)
                                 );
  else
    condition := Out::Clowlimit(tendsto);
  end_if;

  Out::Capply(Out::Climit, Out::Cbvar(bvar), condition, Out(op(data,1)));
end_proc:

limit::TeX := 
proc(l, data, prio)
  local direction, tendsto, bvar;
begin
  if type(op(data, 2)) = "_equal" then
    tendsto := "{".
               generate::tex(op(data, [2,2]), output::Priority::Stmtseq).
    "}";
    bvar := generate::tex(op(data, [2,1]), output::Priority::Stmtseq);
  else
    tendsto := "0";
    bvar := generate::tex(op(data, 2), output::Priority::Stmtseq);
  end_if;
  
  direction := "";
  if nops(data) = 3 then
    if op(data, 3) = hold(Right) then
      direction := "^+";
    elif op(data, 3) = hold(Left) then
      direction := "^-";
    else
      direction := "^{\\pm}";
    end_if;
  end_if;

  "\\lim_{".bvar."\\to ".tendsto.direction."}".
  generate::tex(op(data,1), output::Priority::Mult);
end_proc:

limit::diff := (lim, x) -> limit(diff(op(lim, 1), x), op(lim, 2..nops(lim))):


/*********************************************************************************/
/*******  The domain stdlib::limit used for a namespace for the           ********/
/*******  limit routines.                                                 ********/
/*********************************************************************************/
stdlib::limit:= newDomain("stdlib::limit"):
stdlib::limit::create_dom:=hold(stdlib::limit):

stdlib::limit::printWarningsFlag:= FALSE:
stdlib::limit::printWarnings:=
proc(flag)
  local tmp;
begin
  if args(0) = 0 then
    return( stdlib::limit::printWarningsFlag )
  else
    case flag
      of TRUE do
      of FALSE do
        tmp:= stdlib::limit::printWarningsFlag;
        sysassign( stdlib::limit::printWarningsFlag, flag );
        return( tmp )
      otherwise
        error("invalid argument")
    end_case
  end_if
end_proc:

stdlib::limit::setuserinfo:=
proc()
begin 
  // set userinfo
  setuserinfo(stdlib::limit::limit_main, 10 );
  setuserinfo(stdlib::limit::limitMRV, 10 );
  setuserinfo(stdlib::limit::lterm, 10 );
  setuserinfo(stdlib::limit::getMRV, 10 );
  setuserinfo(stdlib::limit::rewrite, 10 );
  setuserinfo(stdlib::limit::maxMRV, 10 );
  TRUE
end_proc:

stdlib::limit::reset :=
proc()
begin 
  // clear remember tables
  sysassign(stdlib::limit::limitMRV,     subsop(stdlib::limit::limitMRV,     5=NIL));
  sysassign(stdlib::limit::lterm,        subsop(stdlib::limit::lterm,        5=NIL));
  sysassign(stdlib::limit::getMRV,       subsop(stdlib::limit::getMRV,       5=NIL));
  sysassign(stdlib::limit::rewrite,      subsop(stdlib::limit::rewrite,      5=NIL));
  sysassign(stdlib::limit::maxMRV,       subsop(stdlib::limit::maxMRV,       5=NIL));
  sysassign(stdlib::limit::sign,         subsop(stdlib::limit::sign,         5=NIL));
  sysassign(stdlib::limit::simp2explog,  subsop(stdlib::limit::simp2explog,  5=NIL));
  sysassign(stdlib::limit::limitIV_main, subsop(stdlib::limit::limitIV_main, 5=NIL));
  sysassign(stdlib::limit::limitIV_cmp,  subsop(stdlib::limit::limitIV_cmp,  5=NIL));
  sysassign(stdlib::limit::limitIV_join, subsop(stdlib::limit::limitIV_join, 5=NIL));
end_proc:

stdlib::limit::limit_main:=
proc( ex,lx,lp,dir, AccumPoints )
  local x, nex, s, t, S, ld, order, useGseries, one_sided, re, im;
  save MAXEFFORT;
begin
  if not has(ex,lx) then
    return( ex )
  end_if;

  x:= lx;
  save x;
  if domtype(lp) = stdlib::Infinity
    or dir = hold(Left) or dir = hold(Right) then
    // one-sided limit
    one_sided := TRUE
  else
    // two-sided limit
    one_sided := FALSE
  end_if;

  // ********************************
  // Try series computation directly:
  // ********************************
  userinfo(3,"First, try series computation directly ...");
  
  nex:= ex;
  
  s:= FAIL;
  S:= FAIL;
  useGseries := Series::useGseries(FALSE);
  for order from 2 to ORDER do
    // an error occurs if the requested order is too small!
    if traperror((s:= series(nex, x = lp, order, dir,
                             /*
                             if one_sided then
                               hold(Right)
                             else
                               hold(Real)
                             end_if,
                             */
                             hold(NoWarning)))) = 0 then
      if domtype(s) <> Series::Puiseux then
        // try the MRV algorithm ...
        break
      end_if;
      S := FAIL;
      // the traperror is necessary since otherwise
      // Series::useGseries would  not be reset if ldegree
      // produces an error
      if traperror((S := ldegree(s))) <> 0 then
        // ldegree produces an error, so it does not make
        // much sense to continue with higher order
        break;
      end_if;
      if S <> FAIL then
        // success
        break
      end_if
    end_if;
  end_for;
  Series::useGseries(useGseries);
  if domtype(s) = Series::Puiseux and S <> FAIL then
    case sign(S)
      of  0 do
        ld:= lmonomial(s);
        if hastype(ld, {"sin", "cos"}) then
          // rewrites, e.g., sin(x)^2 + cos(x)^2 --> 1
          ld := combine(expand(ld), sincos);
        end_if;
        if hastype(ld, "exp") then
          ld := combine(expand(ld), exp)
        end_if;
        if has(ld,x) then
          if Simplify::defaultValuation(ld) >= Simplify::defaultValuation(nex)
            then
            // avoid infinite loop, continue with the MRV algorithm ...
            break
          else
            MAXEFFORT:= MAXEFFORT/2;
            return( stdlib::limit::limit_main(ld,x, lp, dir, AccumPoints) )
          end_if
        else
          return( ld )
        end_if
      of  1 do
        // if the leading coefficient contains x, the we do not know in
        // general whether it is bounded.
        // We assume that the leading coefficient is continuous and therefore
        // bounded near 0 if evaluation at zero does not fail
        s:= lcoeff(s);
        assert(s <> FAIL);
        if stdlib::limit::logBounded(s, x) = TRUE then
          return(0)
        end_if;
        break
      of -1 do
        // NOTE: the leading coefficient could contain x!
        // Example: limit(ln(x)/x,x=0,Left).
        // However, it is guaranteed that the lcoeff does not grow
        // stronger than the rest of the leading monomial. So the
        // limit is infinity*sign(lcoeff).
        s:= lcoeff(s);
        if s = FAIL then
          // try the MRV algorithm
          // Example: series((sqrt(2*x)-4)/(sqrt(x+1)-3),x=8,2,Right)
          break
        end_if;
        if not has(s,x) then
          if S mod 2 = 1 and (dir=Left or lp=-infinity) and lp <> infinity then
            s:= -s
          end_if;
          return( sign(s)*infinity )
        else
          s:= sign(stdlib::limit::limit_main(s,x,lp, dir, AccumPoints));
          if s = 1 or s = -1 then
            if S mod 2 = 1 and (dir=Left or lp=-infinity) and lp <> infinity then
              s:= -s
            end_if;
            return( s*infinity )
          end_if;
          // continue with the MRV algorithm
          break
        end_if
      otherwise
        if stdlib::limit::printWarningsFlag = TRUE then
          warning("cannot determine sign of ".expr2text(S) );
        end_if;
        return( FAIL )
    end_case;
    // continue with the MRV algorithm ...
  end_if;
  
  userinfo(3,"Direct series computation fails. Enter MRV algorithm ...");

  // ********************
  // Enter MRV algorithm:
  // ********************
  // we transform the problem to the case x -> infinity:

  save x;
  // TODO: transform the old assumptions of x according to the substitution
  // done in the following
  
  
  // trap possible error due to evaluation with variable (see above)
  if lp = -infinity then
    assume(x > 20);
    if traperror((ex:= eval(subs(ex,lx=-x)) )) <> 0 then
      return( FAIL )
    end_if
  elif lp = infinity then
    assume(x > 20, _and); // in order to have ln(x) positive ...
    if traperror((ex:= eval(subs(ex,lx=x)) )) <> 0 then
      return( FAIL )
    end_if
  elif dir = hold(Right) then
    assume(x > 20);
    if traperror((ex:= eval(subs(ex,lx=lp+1/x)) )) <> 0 then
      return( FAIL )
    end_if
  else
    assume(x > 20);
    if traperror((ex:= eval(subs(ex,lx=lp-1/x)) )) <> 0 then
      return( FAIL )
    end_if
  end_if;

  ex:= simplify(ex);

  // try quick IV-check first, use is, then use rectform
  if has(ex, I) or
    not iszero(Im(hull(ex))) and not (is(ex, Type::Real) = TRUE) then
    if MAXEFFORT < 500 then
      return(FAIL)
    end_if;
    MAXEFFORT:= MAXEFFORT - 300; // calculated speed of rectform
                                 // rectform does not react to MAXEFFORT,
    re:= rectform(ex);
    if op(re, 3) <> 0 then
      return(FAIL)
    end_if;
    if op(re, 2) <> 0 then
      // calculate one third for computation of real and imaginary part,
      // plus one third for the rest of the computation
      MAXEFFORT:= MAXEFFORT / 3;
      im:= stdlib::limit::limit_main(op(re, 2), x, infinity, Left, AccumPoints);
      if im = FAIL then
        return(FAIL)
      end_if;
      re:= stdlib::limit::limit_main(op(re, 1), x, infinity, Left, AccumPoints);
      if re <> FAIL then
        return(normal(rewrite(re + I*im, Re)))
      else
        return(FAIL)
      end_if
    end_if;
    if has(ex, I) then
      // ex is real since op(re, 2), op(re, 3) are zero;
      // probably op(re ,1) is as impler way to express it
      ex:= op(re, 1)
    end_if
  end_if;

  
  nex:= normal(ex);
  nex:= stdlib::limit::simp2explog( nex,x, AccumPoints );
  
  if has(ex,stdlib::limit::setPreProcessFunc) then
    nex:= stdlib::limit::preProcess( nex,x );
  end_if;

  s:= stdlib::limit::limitMRV(nex,x);
  case s
    of FAIL    do
    of UNKNOWN do
    of "tryIV" do
      save x;
      assume(x > 1000);
      if is(ex, Type::Real) <> TRUE and
        piecewise::simplifyCondition(ex in R_) <> TRUE then
        return(FAIL)
      end_if;
      // **********************
      // Try interval calculus:
      // **********************
      s:= stdlib::limit::limitIV_main( ex,x );
      if s = FAIL or s = UNKNOWN then
        return( s )
      elif domtype(s) = DOM_LIST and nops(s) = 1 then
        s:= s[1];
        if s[1] = s[2] then
          return(s[1])
        end_if;
        t:= normal( s[1] - s[2] );
        if iszero(t) = TRUE or is(t = 0) = TRUE then
          return( s[1] )
        else
          if AccumPoints then
            return(Dom::Interval( s ))
          else
            // since we might have obtained a superset of the set
            // of accumulation points, we cannot say for sure that the limit
            // is undefined here; the following in thus incorrect
            return( undefined )
            // return(FAIL)
          end_if;
        end_if
      else
        return( FAIL )
      end_if
    otherwise
      return( s )
  end_case
end_proc:

/*
stdlib::limit::logBounded(f, x)

checks whether f remains bounded by some power of log(x) when x is in a small interval [0, epsilon] 

returns TRUE if f is provably bounded, and FALSE otherwise

*/

stdlib::limit::logBounded:=
proc(f, x)
  local s, i;
begin
  if not has(f, x) then
    return(TRUE)
  end_if;
  if traperror(eval(subs(f, x=0))) = 0 then
    userinfo(10, "Function is defined at zero and assumed to be continuous there");
    return(TRUE)
  end_if;
  // try interval arithmetic
  s:= eval(subs(f, x=0...0.1));
  if type(s) = DOM_INTERVAL and not has(s, {RD_NINF, RD_INF}) then
    userinfo(10, "Function proved to be bounded by interval arithmetics");
    return(TRUE)
  end_if;

  // recursive descent
  case type(f)
    of DOM_IDENT do
      assert(f = x);
      return(TRUE)
    of "_mult" do
    of "_plus" do
      return(_and(stdlib::limit::logBounded(op(f, i), x) $i=1..nops(f)))
    of "sin" do
    of "cos" do
      return(TRUE)
    of "ln" do
      return(stdlib::limit::logBounded(op(f, 1), x))
    of "_power" do
      if is(op(f, 2) >= 0) = TRUE then
        return(stdlib::limit::logBounded(op(f, 1), x))
      end_if;
      break
  end_case;
  
  return(FALSE)
end_proc:


/*********************************************************************************/
/******** The following routines implement limit computation by interval  ********/
/******** arithmetic, based on the following paper:                       ********/
/******** John Shackell: "Asymptotic estimation of oscillation functions  ********/
/******** using an interval calculus".                                    ********/
/*********************************************************************************/

/*
        limitIV_main(f,x)

        f : expression in x
        x : limit variable

        Tries to determine the limit of f(x) for x->infinity using
        an interval calculus. Return values are either
        a) a single value, the limit of f(x) for x->infinity.
        b) an interval [a,b] such that f(x) is in [a,b] for large x. 
        Note that [-infinity, infinity] is alway a valid result.

        The interval calculus implemented in Dom::Interval is used. 
        It handles parameters and takes care of possibly given 
        properties on identifiers (see assume/is).
*/
stdlib::limit::limitIV_main:=
proc(f,x)
    name stdlib::limit::limitIV;
    local c, s, t, e;
    option remember;
begin
    if f = x then
        return( [[infinity,infinity]] )
    else
        if not has(f,x) then 
            return( [[f,f]] )
        // elif hastype(f,DOM_COMPLEX) then
        //    return( FAIL )
        end_if
    end_if;

    t:= stdlib::limit::printWarnings(FALSE);
    c:= stdlib::limit::limitMRV( f,x );
    stdlib::limit::printWarnings(t);
    case c 
    of FAIL do
    of "tryIV" do
        t:= type(f);
        case t
        of "_plus"  do
        of "_mult"  do
        of "_power" do
            t:= stdlib::limit::limitIV[t];

            s:= NIL;
            for e in f do
                c:= stdlib::limit::limitIV_main( e,x );
                if c = FAIL or c = UNKNOWN then
                  return([[-infinity, infinity]])
                elif s = NIL then
                  s:= c
                else
                  s:= t( s,c )
                end_if
            end_for;
            return( s )
        otherwise
            if type((s:= stdlib::limit::limitIV[t])) <> "_index" then
                c:= stdlib::limit::limitIV_main( op(f,1),x );
                if c = FAIL or c = UNKNOWN then
                    return(s([[-infinity, infinity]]))
                else
                    return( s(c) )
                end_if
            else
                return( [[-infinity, infinity]])
            end_if
        end_case 
    of UNKNOWN do
        // ORDER of series computation seems to be not big enough
        return( [[-infinity, infinity]])
    otherwise
        return( [[c,c]] )
    end_case
end_proc:

stdlib::limit::limitIV_cmp:= proc(a, b)
    name stdlib::limit::limitIV;
    local s;
    option remember;
begin 
    if a[1] = b[1] then
        if a[2] = b[2] then
            return(TRUE)
        else
            s:= sign(a[2]-b[2]);
        end_if
    else
        s:= sign(a[1]-b[1]);
    end_if;

    return(bool(s=-1))
end_proc:

// Richtet die Reihenfolge eines Intervals der Form [linkeSeite,rechteSeite]:
stdlib::limit::limitIV_orderIV:= proc(l)
    name stdlib::limit::limitIV;
    local s;
begin
    if domtype(l[1]) = stdlib::Infinity or domtype(l[2]) = stdlib::Infinity then
        if domtype(sign(l[1])) <> DOM_INT or domtype(sign(l[2])) <> DOM_INT then
            // cannot determine sign:
            return(FAIL)
        elif l[1] > l[2] then
            return([l[2],l[1]])
        else
            return(l)
        end_if
    else
        s:= sign(l[1]-l[2]);
        if domtype(s) <> DOM_INT then
            // cannot determine sign:
            return( FAIL )        
        elif s = 1 then
            return([l[2],l[1]])
        else
            return(l)
        end_if
    end_if
end_proc:

/*--
        Liste von Intervallen wird sortiert, zusammengefasst und die 
        Reihenfolge der Intervallgrenzen werden gerichtet.
--*/
stdlib::limit::limitIV_join:= proc(liste)
    name stdlib::limit::limitIV;
    local i, a, b, c, s;
    option remember;
begin
    liste:= map(liste, stdlib::limit::limitIV_orderIV);
    if contains(liste, FAIL) <> 0 then
        return(FAIL)
    end_if;

    liste:= sort(liste,stdlib::limit::limitIV_cmp);

    // ueberlappende Intervalle vereinigen:
    i:= 1;
    a:= op(liste,i);
    b:= op(liste,i+1);
    while a <> FAIL and b <> FAIL do
        if ((a[1] = -infinity) and (a[2] = -infinity)) or
           ((a[1] =  infinity) and (a[2] =  infinity)) 
        then
            delete liste[i]
        elif ((b[1] = -infinity) and (b[2] = -infinity)) or
             ((b[1] =  infinity) and (b[2] =  infinity)) 
        then
            delete liste[i+1];
        elif ((a[2] = -infinity) and (b[1] = -infinity)) or
             ((a[2] =  infinity) and (b[1] =  infinity)) 
        then
            c:= [a[1],b[2]];
            liste[i]:= c;
            delete liste[i+1]; 
        else
            s:= sign(a[2]-b[1]);
            if domtype(s) <> DOM_INT then
                // cannot determine sign:
                return(FAIL)
            elif s = 0 or s = 1 then 
                // Intervalle ueberlappen sich:
                c:= [a[1],0]; 
                if (a[2] = infinity) and (b[2] = infinity) then
                    // rechte Intervallgrenze festlegen:
                    c[2]:= a[2];
                elif (s:= sign(a[2]-b[2])) = 0 or s = 1 then
                    c[2]:= a[2];
                else
                    c[2]:= b[2];
                end_if:

                liste[i]:= c;
                delete liste[i+1];   
            else
                i:= i + 1;
            end_if
        end_if;

        a:= op(liste,i);
        b:= op(liste,i+1); 
    end_while;

    return(liste)
end_proc:

stdlib::limit::limitIV:= table():
/*--
        Invertierung von Intervallisten
--*/
stdlib::limit::limitIV["_invert"]:= proc(liste)
    name stdlib::limit::limitIV::_invert;
    local s, a, l, sa1, sa2;
begin
    l:= [];
    for a in liste do
        a:= stdlib::limit::limitIV_orderIV(a);

        sa1:= sign(a[1]); sa2:= sign(a[2]);
        if domtype(sa1) <> DOM_INT or domtype(sa2) <> DOM_INT then
            // cannot determine sign:
            return(FAIL)
        elif sa1 = 0 and sa2 = 0 then       
            // Sonderfall: Division durch Null:
            l:= l . [[-infinity,-infinity],[infinity,infinity]]
        elif sa1 = -1 and sa2 = 1 then            
            // Sonderfall: Null liegt im Intervall ==> zwei Intervalle
            l:= l . [[-infinity,1/a[1]],[1/a[2],infinity]]
        elif sa1 = 0 then                        
            l:= l . [[1/a[2],infinity]]
        elif sa2 = 0 then                        
            l:= l . [[-infinity,1/a[1]]]
        else
           l:= l . [[1/a[2],1/a[1]]]
        end_if
    end_for;
    
    return( stdlib::limit::limitIV_join(l) )
end_proc:

/*--
        Addition zweier Intervallisten:
--*/
stdlib::limit::limitIV["_plus"]:= proc(l1,l2)
    name stdlib::limit::limitIV::_plus;
    local a, b, s;
begin
    s:= [];
    for a in l1 do
        for b in l2 do
            s:= s . [[a[1] + b[1],a[2] + b[2]]]
        end_for
    end_for;
 
    return( stdlib::limit::limitIV_join(s) )
end_proc:

/*--
        Multiplikation zweier Intervallisten:
--*/
stdlib::limit::limitIV_multIV:= proc(a,b)
    name stdlib::limit::limitIV::_mult;
    local sa1,sa2,sb1,sb2,mi,ma,s,m11,m12,m21,m22;
begin
    // some trivial cases, which also work for expressions
    // for that the sign cannot be computed (e.g., 'a' in
    // limit(a*sin(x*y)*exp(-x), x = infinity) = 0):

    /* --------------------------------
    // Frank's old code
    case b
    of [1,1] do
        return(a)
    of [-1,-1] do
        return([-a[2],-a[1]])
    end_case;
    case a
    of [1,1] do
        return(b)
    of [-1,-1] do
        return([-b[2],-b[1]])
    end_case;
    -------------------------------- */
    //------------------------------------------------
    // Walter 22.2.02: replaced the code above
    // by the following
    if b[1] = b[2] then
       case sign(b[1])
       of  0 do 
             if not has(a, infinity) then
                 return([0, 0]);
             end_if;
             break;
       of  1 do  return([b[1]*a[1], b[1]*a[2]]);
       of -1 do  return([b[1]*a[2], b[1]*a[1]]);
       otherwise return([b[1]*a[1], b[1]*a[2]]);
       end_case;
    end_if;
    if a[1] = a[2] then
       case sign(a[1])
       of  0 do 
             if not has(b, infinity) then
                 return([0, 0]);
             end_if;
             break;
       of  1 do  return([a[1]*b[1], a[1]*b[2]]);
       of -1 do  return([a[1]*b[2], a[1]*b[1]]);
       otherwise return([a[1]*b[1], a[1]*b[2]]);
       end_case;
    end_if;
    //------------------------------------------------

     // Reihenfolge richten:
     a:= stdlib::limit::limitIV_orderIV(a);
     b:= stdlib::limit::limitIV_orderIV(b);

     sa1:= sign(a[1]); 
     sa2:= sign(a[2]);
     sb1:= sign(b[1]); 
     sb2:= sign(b[2]);

     if sa1 = 0 and sa2 = 0 and b[1] = -infinity and b[2] = infinity then
         return( [-infinity,infinity] )
     elif sb1 = 0 and sb2 = 0 and a[1] = -infinity and a[2] = infinity then
         return( [-infinity,infinity] )
     elif sa1 = 0 and sa2 = 0 and b[2] = infinity then
         return( [0,infinity] )
     elif sb1 = 0 and sb2 = 0 and a[2] = infinity then
         return( [0,infinity] )
     elif sa1 = 0 and sa2 = 0 and b[1] = -infinity then
         return( [-infinity,0] )
     elif sb1 = 0 and sb2 = 0 and a[1] = -infinity then
         return( [-infinity,0] )
     elif sa2 = 0 and b[2] = infinity then
         if sa1 * sa2 = -1 then 
             return( [-infinity,0] )
         else 
             return( [-infinity,a[1]*b[1]] )
         end_if
     elif sb2 = 0 and a[2] = infinity then
         if sa1*sb1 = -1 then 
             return( [-infinity,0] )
         else 
             return( [-infinity,a[1]*b[1]] )
         end_if
     elif sb1 = 0 and a[1] = - infinity then
         if sa2*sb2 = -1 then 
             return( [-infinity,0] )
         else
             return( [-infinity,a[2]*b[2]] )
         end_if
     elif sa1 = 0 and b[1] = -infinity then
         if sa2*sb2 = -1 then
             return( [-infinity,0] )
         else 
             return( [-infinity,a[2]*b[2]] )
         end_if
     elif sa1 = 0 and b[2] = infinity then
         if sa2*sb1 = 1 then 
             return( [0,infinity] )
         else 
             return( [a[2]*b[1],infinity] )
         end_if
     elif sb1 = 0 and a[2] = infinity then
         if sa1*sb2 = 1 then 
             return( [0,infinity] )
         else 
             return( [a[1]*b[2],infinity] )
         end_if
     elif sb2 = 0 and a[1] = -infinity then
         if sa2*sb1 = 1 then 
             return( [0,infinity] )
         else
             return( [a[2]*b[1],infinity] )
         end_if
     elif sa2 = 0 and b[1] = -infinity then
         if sa1*sb2 = 1 then 
             return( [0,infinity] )
         else 
             return( [a[1]*b[2],infinity] )
         end_if
     else
         m11:= a[1]*b[1];
         m12:= a[1]*b[2];
         m21:= a[2]*b[1];
         m22:= a[2]*b[2];

         mi:= (ma:= m11);
         s:= sign(m12-mi);
         if domtype(s) <> DOM_INT then
            return([-infinity, infinity])
         elif s = -1 then 
            mi := m12
         elif s = 1 then 
            ma := m12
         end_if;

         s:= sign(m21-mi);
         if domtype(s) <> DOM_INT then
            return([-infinity, infinity])
         elif s = -1 then 
            mi := m21
         end_if;

         s:= sign(m21-ma);
         if domtype(s) <> DOM_INT then
             return([-infinity, infinity])
         elif s = 1  then 
             ma := m21 
         end_if;
         
         s:= sign(m22-mi);
         if domtype(s) <> DOM_INT then
             return([-infinity, infinity])
         elif s = -1 then
             mi := m22 
         end_if;

         s:= sign(m22-ma);
         if domtype(s) <> DOM_INT then
             return([-infinity, infinity])
         elif s = 1 then 
             ma := m22 
         end_if;

         return( [mi,ma] )
     end_if; 
end_proc:

stdlib::limit::limitIV["_mult"]:=
proc(l1,l2)
  name stdlib::limit::limitIV::_mult;
  local a, b, m, e;
begin
  m:= [];
  for a in l1 do
    for b in l2 do
      if (e:= stdlib::limit::limitIV_multIV(a,b)) = FAIL then
        return(FAIL)
      else
        m:= append(m, e);
      end_if;
    end_for;
  end_for;
  
  return( stdlib::limit::limitIV_join(m) )
end_proc:

/*--
        Potenzierung zweier Intervallisten:
--*/
stdlib::limit::limitIV_powerIV:=
proc(a,b)
  local s;
begin
  if b[1] <> b[2] then
        // Exponent darf kein Intervall sein!
    return( FAIL )
  end_if;

  // Reihenfolge richten:
  a:= stdlib::limit::limitIV_orderIV(a);
  
  case sign(b[1])
    of 0 do
      if a[1] = -infinity or a[2] = infinity then
        // infinity^0 ist undefiniert
        return(FAIL)
      else  
        return( [[1,1]] )
      end_if
    of -1 do
      return(stdlib::limit::limitIV_invert( stdlib::limit::limitIV_powerIV( a,[-b[1],-b[1]] ) ))
    of 1 do
      s:= sign(a[1]*a[2]);
      if s <> 0 then
        if s = -1 and sign(a[1]^b[1]) = 1 then
          return( [[0,a[2]^b[1]]] )
        else
          return( [[a[1]^b[1],a[2]^b[1]]] )
        end_if
      else
        return( [[a[1]^b[1],a[2]^b[1]]] )
      end_if
    otherwise
      if stdlib::limit::printWarningsFlag = TRUE then
        warning("cannot determine sign of ".expr2text(b[1]));
      end_if;
      return( FAIL )
  end_case
end_proc:
stdlib::limit::limitIV["_power"]:= proc(l1,l2)
    name stdlib::limit::limitIV::_power;
    local a, b, p, tmp;
begin
    p:= [];
    for a in l1 do
        for b in l2 do
            tmp:= stdlib::limit::limitIV_powerIV(a,b);
            if tmp = FAIL then 
                return( FAIL )
            else 
                p:= p . tmp
            end_if
        end_for
    end_for;
  
    return( stdlib::limit::limitIV_join(p) )
end_proc:

/*--
        Exponentialfunktion auf Intervalliste:
--*/
stdlib::limit::limitIV["exp"]:= proc(liste)
    name stdlib::limit::limitIV::exp;
    local i, a, expIV;
begin
    // Erweiterte Exponentialfunktion:
    expIV:= proc(a)
    begin
        case a
        of infinity  do return(infinity)
        of -infinity do return(0)
        otherwise
            return( exp(a) )
        end_case
    end;
    // ---------------------------------
    for i from 1 to nops(liste) do
        a:= liste[i];
        liste[i]:= [expIV(a[1]),expIV(a[2])]
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Logarithmus auf Intervalliste:
--*/
stdlib::limit::limitIV["ln"]:= proc(liste)
    name stdlib::limit::limitIV::ln;
    local s, i, a, T1, T2, lnIV;
begin
    // Erweiterte Logarithmusfunktion:
    lnIV:= proc(a)
    begin
        s:= sign(a);
        if domtype(s) <> DOM_INT or s = -1 or a <> -infinity then
            return(FAIL)
        end_if;

        if (a = infinity) or (a = -infinity) then
            return(infinity)
        elif iszero(a) = TRUE then
            return(-infinity)
        else
            return(ln(a))
        end_if;
    end:
    // ---------------------------------
    for i from 1 to nops(liste) do
        a := liste[i];

        T1:= lnIV(a[1]); T2:= lnIV(a[2]);
        if T1 = FAIL or T2 = FAIL then
            return( FAIL )
        else
            s:= sign(a[1]*a[2]);
            if domtype(s) <> DOM_INT then
                // cannot determine sign:
                return(FAIL)
            elif s <> 0 then
                if s = -1 then
                    s:= sign(T1-T2);
                    if domtype(s) <> DOM_INT then
                        // cannot determine sign:
                        return(FAIL)
                    elif s = 1 then
                        liste[i]:= [-infinity,T1]
                    else
                        liste[i]:= [-infinity,T2]
                    end_if;
                else
                    liste[i]:= [T1,T2]
                end_if;
            else 
                liste[i]:= [T1,T2]
            end_if
        end_if
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Absolutfunktion auf Intervalliste:
--*/
stdlib::limit::limitIV["abs"]:= proc(liste)
    name stdlib::limit::limitIV::abs;
    local i, a, s;
begin
    for i from 1 to nops(liste) do
        a:= liste[i];

        s:= sign(a[1]*a[2]);
        if domtype(s) <> DOM_INT then
            // cannot determine sign:
            return(FAIL)
        elif s <> 0 then
            if s = -1 then
                s:= sign(abs(a[1])-abs(a[2]));
                if domtype(s) <> DOM_INT then
                    // cannot determine sign:
                    return(FAIL)
                elif s = 1 then
                    a:= [0,abs(a[1])]
                else
                    a:= [0,abs(a[2])]
                end_if
             end_if
         else
             a:= [abs(a[1]),abs(a[2])]
         end_if;
         liste[i]:= a
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:


/*--
        sign auf Intervallliste
--*/
stdlib::limit::limitIV["sign"]:=
proc(liste)
  name stdlib::limit::limitIV::sign;
  local signIV;
begin
  signIV:=
  proc(a)
    local a1, a2;
  begin
    a:= stdlib::limit::limitIV_orderIV(a);
    [sign(a[1]), sign(a[2])]
  end_proc;

  liste:= map(liste, signIV);  
  return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Sinus auf Intervalliste:
--*/
stdlib::limit::limitIV["sin"]:=
proc(liste)
    name stdlib::limit::limitIV::sin;
    local i, a, s, sinIV;
begin
    // Sinus eines Intervalls:
    sinIV:=
    proc(a)
      local a1, a2, npi;
    begin
        if has(a, infinity) then
          return([-1, 1])
        end_if;
        // Reihenfolge richten:
        a:= stdlib::limit::limitIV_orderIV(a);
        a1:= a[1]; a2:= a[2];

        npi:= float(PI);
        if a1 = infinity or a1 = -infinity  or a2 = infinity or a2 = -infinity 
           // or (a2-a1 >= float(2*PI)) or (float(a1/PI+0.5) <= floor(float(a2/PI-0.5)))
           or contains( {0,1},sign(a2-a1-2*npi) ) or contains( {-1,0},sign((a1/npi+0.5) - floor(a2/npi-0.5)) )
        then
            return([-1,1])
        // elif (floor(float(a2/(2*PI)-0.25)) > float(a1/(2*PI)-0.25)) then
        elif sign(floor(a2/(2*npi)-0.25) - (a1/(2*npi)-0.25)) = 1 then
            if sign(sin(a[1])-sin(a[2])) = -1 then
                return([sin(a[1]),1]) 
            else 
                return([sin(a[2]),1])
            end_if
        // elif floor(a2/(2*PI)+0.25) > a1/(2*PI)+0.25 then
        elif sign(floor(a2/(2*npi)+0.25) - (a1/(2*npi)+0.25)) = 1 then
            if sign(sin(a[1])-sin(a[2])) = 1 then
                return([-1,sin(a[1])])
            else 
                return([-1,sin(a[2])])
            end_if
        else
            if sign(sin(a[1])-sin(a[2])) = -1 then
                return([sin(a[1]),sin(a[2])])
            else 
                return([sin(a[2]),sin(a[1])] )
            end_if
        end_if
    end:
    // ---------------------------------

  liste:= map(liste, sinIV);
 
  return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Cosinus auf Intervalliste:
--*/
stdlib::limit::limitIV["cos"]:= proc(liste)
    name stdlib::limit::limitIV::cos;
begin
    stdlib::limit::limitIV["sin"]( stdlib::limit::limitIV["_plus"]( 
        [[PI/2,PI/2]], stdlib::limit::limitIV["_mult"]( [[-1,-1]],liste )
    ) )
end_proc:

/*--
        Tangens auf Intervalliste:
--*/
stdlib::limit::limitIV["tan"]:= proc(liste)
    name stdlib::limit::limitIV::tan;
    local f1, f2;
begin
    if (f2:= stdlib::limit::limitIV["cos"](liste)) = FAIL then
        return( FAIL )
    elif (f2:= stdlib::limit::limitIV["_invert"](f2)) = FAIL then
        return( FAIL )
    elif (f1:= stdlib::limit::limitIV["sin"](liste)) = FAIL then
        return( FAIL )
    else
        return( stdlib::limit::limitIV["_mult"](f1,f2) )
    end_if
end_proc:

/*--
        Sinushyperbolikus auf Intervalliste:
--*/
stdlib::limit::limitIV["sinh"]:= proc(liste)
    name stdlib::limit::limitIV::sinh;
    local i, a;
begin
    for i from 1 to nops(liste) do  
        a := liste[i];
        liste[i] := [sinh(a[1]),sinh(a[2])]
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Cosinushyperbolikus auf Intervallliste:
--*/
stdlib::limit::limitIV["cosh"]:= proc(liste)
    name stdlib::limit::limitIV::cosh;
    local i, a, coshIV;
begin
    // Cosinushyperbolikus auf Intervall:
    coshIV:= proc(a)
        name stdlib::limit::limitIV::cosh;
        local s;
    begin
        s:= sign(a[1]*a[2]);
        if domtype(s) <> DOM_INT then
            // cannot determine sign:
            return(FAIL)
        elif s = -1 then
            if sign(cosh(a[1])-cosh(a[2])) = 1 then
                a:= [1,cosh(a[1])]
            else
                a := [1,cosh(a[2])]
            end_if
        else
            a:= [cosh(a[1]),cosh(a[2])]
        end_if;

        // Reihenfolge richten:
        a:= stdlib::limit::limitIV_orderIV(a);
    end_proc:
    // ---------------

    for i from 1 to nops(liste) do  
        a:= liste[i];
        liste[i]:= [coshIV(a[1]),coshIV(a[2])]
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Tangeshyperbolikus auf Intervallliste:
--*/
stdlib::limit::limitIV["tanh"]:= proc(liste)
    name stdlib::limit::limitIV::tanh;
    local i, a;
begin
    for i from 1 to nops(liste) do  
        a:= liste[i];
        liste[i]:= [sinh(a[1]),sinh(a[2])]
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Arcussinus auf Intervallliste:
--*/
stdlib::limit::limitIV["arcsin"]:= proc(liste)
    name stdlib::limit::limitIV::arcsin;
    local i, s, a;
begin
    for i from 1 to nops(liste) do  
        a:= liste[i];
        s:= sign(a[1]+1);
        if domtype(s) <> DOM_INT or s = -1 then
            return(FAIL)
        end_if;
        s:= sign(a[2]-1);
        if domtype(s) <> DOM_INT or s = 1 then
            return(FAIL)
        end_if;

        liste[i]:= [arcsin(a[1]),arcsin(a[2])];
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Arcuscosinus auf Intervallliste:
--*/
stdlib::limit::limitIV["arccos"]:= proc(liste)
    name stdlib::limit::limitIV::arccos;
    local i, a, s;
begin
    for i from 1 to nops(liste) do  
        a:= liste[i];
        s:= sign(a[1]+1);
        if domtype(s) <> DOM_INT or s = -1 then
            return(FAIL)
        end_if;
        s:= sign(a[2]-1);
        if domtype(s) <> DOM_INT or s = 1 then
            return(FAIL)
        end_if;

        liste[i] := [arccos(a[2]),arccos(a[1])]
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Arcustangens auf Intervallliste:
--*/
stdlib::limit::limitIV["arctan"]:= proc(liste)
    name stdlib::limit::limitIV::arctan;
    local i, a;
begin
    for i from 1 to nops(liste) do  
        a:= liste[i];
        liste[i]:= [arctan(a[1]),arctan(a[2])]
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Arcussinushyperbolikus auf Intervallliste:
--*/
stdlib::limit::limitIV["arcsinh"]:= proc(liste)
    name stdlib::limit::limitIV::arcsinh;
    local i, a, arcsinhIV;
begin
    // Arcussinushyperbolikus auf Intervall:
    arcsinhIV:= proc(a)
        name stdlib::limit::limitIV::arcsinh;
    begin
        case a
        of infinity  do return(infinity)
        of -infinity do return(-infinity)
        otherwise
            return(arcsinh(a))
        end_case
    end:
    // ---------------------------------
    for i from 1 to nops(liste) do  
        a:= liste[i];
        liste[i]:= [arcsinhIV(a[1]),arcsinhIV(a[2])]
    end_for;

    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Arcuscosinushyperbolikus auf Intervallliste:
--*/
stdlib::limit::limitIV["arccosh"]:= proc(liste)
    name stdlib::limit::limitIV::arccosh;
    local i, a, s, arccoshIV;
begin
    // Arcuscosinushyperbolikus auf Intervall:
    arccoshIV:= proc(a)
        name stdlib::limit::limitIV::arccosh;
    begin
        if a = infinity then return(infinity) else return(arccosh(a)) end_if
    end:
    // ---------------------------------
    for i from 1 to nops(liste) do  
        a:= liste[i];
        s:= sign(a[1]-1);
        if domtype(s) <> DOM_INT or s = -1 then
            return(FAIL)
        end_if;

        liste[i]:= [arccoshIV(a[1]),arccoshIV(a[2])];
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Arcustangenshyperbolikus auf Intervallliste:
--*/
stdlib::limit::limitIV["arctanh"]:= proc(liste)
    name stdlib::limit::limitIV::arctanh;
    local i, a, arctanhIV;
begin
    // Arcustangenshyperbolikus auf Intervall:
    arctanhIV := proc(a)
        name stdlib::limit::limitIV::arctanh;
        local s;
    begin
        s:= sign(a+1);
        if domtype(s) <> DOM_INT then
            // cannot determine sign:
            return(FAIL)
        elif s = 0 then
            return(-infinity)
        elif sign(a-1) = 0 then
            return(infinity)
        else
            return(arctanh(a))
        end_if
    end:
    // ---------------------------------
    for i from 1 to nops(liste) do  
        a:= liste[i];
        if sign(a[1]+1) = -1 or sign(a[2]-1) = 1 then
            return(FAIL)
        end_if;

        liste[i]:= [arctanhIV(a[1]),arctanhIV(a[2])];
    end_for;
 
    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        Signumfunktion auf Intervallliste:
--*/
/*
stdlib::limit::limitIV["sign"]:= proc(liste)
    name stdlib::limit::limitIV::sign;
    local i, a, l, sa1, sa2;
begin
    l:= [];
    for i from 1 to nops(liste) do  
        a:= liste[i];

        sa1:= sign(a[1]); sa2:= sign(a[2]);
        if domtype(sa1) <> DOM_INT or domtype(sa2) <> DOM_INT then
            // cannot determine sign:
            return(FAIL)
        elif sa1*sa2 = -1 then
            l := l . [[-1,-1],[0,0],[1,1]]
        elif sa1 = 0 and sa2 = 0 then
            l := l . [[0,0]]
        elif sa1*sa2 = 0 then
            l := l . [[sa1,sa1],[sa2,sa2]]
        else
            l := l . [[sa1,sa1]]
        end_if
    end_for;
  
    return( stdlib::limit::limitIV_join(l) )
end_proc:
*/

/*--
        Fehlerfunktion auf Intervallliste:
--*/
stdlib::limit::limitIV["erf"]:= proc(liste)
    name stdlib::limit::limitIV::erf;
    local i, a;
begin
    for i from 1 to nops(liste) do  
        a:= liste[i];
        liste[i]:= [erf(a[1]),erf(a[2])];
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:

/*--
        komplementaere Fehlerfunktion auf Intervallliste:
--*/
stdlib::limit::limitIV["erfc"]:= proc(liste)
    name stdlib::limit::limitIV::erfc;
    local i, a;
begin
    for i from 1 to nops(liste) do  
        a:= liste[i];
        liste[i]:= [erfc(a[2]),erfc(a[1])];
    end_for;
  
    return( stdlib::limit::limitIV_join(liste) )
end_proc:


/******************************************************************************/
/*********  The followig routines implement the MRV algorithm based ***********/
/*********  on the paper of Gaston H. Gonnet and Dominik Gruntz:    ***********/
/*********  "Limit Computation in Computer Algebra", Nov. 1992.     ***********/
/******************************************************************************/
// Rewrites powers to exp-log representation:
stdlib::limit::simp2explog := proc(ex, x, AccumPoints=hold(FALSE))
    name (stdlib::limit)::simp2explog;
    option remember;
    local t, b, e;
begin
    case type(ex)
    of "_plus" do
    of "_mult" do
        return(map(ex, stdlib::limit::simp2explog, x, AccumPoints))
    of "_power" do
        b:= op(ex,1); e:= op(ex,2);
        if has(e, x) then
            if sign(b) = 0 then
                return(0)
            elif not has(b, x) and 
                 indets(b) minus {x} minus Type::ConstantIdents <> {} and 
                 is(b, Type::Interval([0],1))=TRUE then
                    // handle q^f(x) for some constant q with 0<=q<1:
                    t:= stdlib::limit::limit_main(e, x, infinity, hold(Left), AccumPoints);
                    if t = infinity then
                        return(0)
                    elif t <> FAIL and t <> UNKNOWN and t <> undefined and domtype(t) <> Dom::Interval then
                        return(b^t) // note: MuPAD evaluates q^0 to 1 for any q!
                    end_if
            else
                return(
                    exp(ln(stdlib::limit::simp2explog(b, x, AccumPoints))*stdlib::limit::simp2explog(e, x,AccumPoints))
                )            
            end_if;
        elif contains({DOM_INT, DOM_RAT, DOM_FLOAT}, domtype(e)) then
            return(stdlib::limit::simp2explog(b, x, AccumPoints)^e)
        else
            return(
                exp(ln(stdlib::limit::simp2explog(b, x, AccumPoints))*stdlib::limit::simp2explog(e, x, AccumPoints))
            )
        end_if
    of DOM_IDENT do
        if is(ex = 0) = TRUE then 
            return( 0 )
        else
            return( ex )
        end_if
    otherwise
        t:= eval(op(ex,0));
        if domtype(t) = DOM_FUNC_ENV then
            if nops(ex) = 1 then
                return(t( stdlib::limit::simp2explog(op(ex,1), x, AccumPoints) ))
            else
                return(t( op(map([op(ex)],stdlib::limit::simp2explog, x, AccumPoints)) ))
            end_if
        elif is(ex = 0) = TRUE then 
            return( 0 )
        else
            return( ex )
        end_if
    end_case;
end_proc:

stdlib::limit::rewriteExpLog := proc(ex)
    name (stdlib::limit)::rewriteExpLog;
    local e, b, t;
begin
    case type(ex)
    of "_plus" do
    of "_mult" do
        return(map(ex, stdlib::limit::rewriteExpLog))
    of "_power" do
        b:= op(ex,1); e:= op(ex,2);
        if contains({DOM_INT, DOM_RAT, DOM_FLOAT}, domtype(e)) then
            return(stdlib::limit::rewriteExpLog(b)^e)
        else
            return(
                exp(ln(stdlib::limit::rewriteExpLog(b))*stdlib::limit::rewriteExpLog(e))
            )
        end_if
    otherwise
        t:= eval(op(ex,0));
        if domtype(t) = DOM_FUNC_ENV then
            if nops(ex) = 1 then
                return(t( stdlib::limit::rewriteExpLog(op(ex,1)) ))
            else
                return(t( op(map([op(ex)],stdlib::limit::rewriteExpLog)) ))
            end_if
        end_if
    end_case;
    return(ex)
end_proc:

/*
        limitMRV(ex,x)

        ex - expression
        x  - limit variable

        Calls lterm and analyzes the leading
        coefficient of the asymptotic expansion (in w), i.e.
        returns the limit of ex for x -> infinity, if possible.

        Return Values:
        l       - the limit (arithmetical expression).
        FAIL    - limit cannot be computed.
        UNKNOWN - ORDER for series seems to be not big enough.
        "tryIV" - MRV algorithm fails, but interval calculus may succeed.
*/
stdlib::limit::limitMRV:= proc(ex, x)
    name stdlib::limit::limitMRV;
    option remember;
    local lc, s; 
begin
    userinfo(2,"MRV: compute limit of ",ex);
    if not has(ex, x) then 
       return(ex);
    end_if;

                    
    lc:= stdlib::limit::lterm( ex,x );
    if contains( {UNKNOWN,FAIL,"tryIV"},lc ) then
        return( lc )
    else
        // (d) Analyze the leading degree
        case sign(lc[3])
        of  0 do 
            return( lc[1] )
        of  1 do
            return( 0 )
        of -1 do
            s:= stdlib::limit::sign(lc[1],x);
            if s = FAIL then
                if indets(lc[1]) minus Type::ConstantIdents minus {x} <> {} then
                    if stdlib::limit::printWarningsFlag = TRUE then
                        warning("cannot determine sign of ".expr2text(lc[1]));
                    end_if;
                    return( FAIL )
                else
                    // use interval calculus, as for the example (-1/2)^n,n->oo!
                    return( "tryIV" )
                end_if
            elif iszero(s) then
                // Happens if series returns zero as the leading coefficient
                // of the series expansion!
                return( FAIL )
            else
                return( s*infinity )
            end_if
        otherwise
            if stdlib::limit::printWarningsFlag = TRUE then
                warning("cannot determine sign of ".expr2text(lc[3]));
            end_if;
            return( FAIL )
        end_case
    end_if
end_proc:


/*
        moveup(ex,x)
        movedown(ex,x)

        Subroutines for stdlib::limit::lterm.
*/
stdlib::limit::moveup:= (f,x) -> eval(subs(f,[ln(x)=x,x=exp(x)])):
stdlib::limit::movedown:= (f,x) -> simplify(subs(f,[exp(x)=x,x=ln(x)])):
stdlib::limit::domoveup:=
proc(f, x, S)
  local xpos, ns, n;
begin
  // find all x^n
  xpos := select({prog::find(f, x)}, 
  p -> _lazy_and(nops(p)>0, p[-1] = 1, op(f, p[1..-2].[0])=hold(_power),
       domtype(op(f, p[1..-2].[2]))=DOM_INT));
  ns := map(xpos, p -> op(f, p[1..-2].[2])) union {1};
  stdlib::limit::moveup(f, x), x, 
    map(stdlib::limit::moveup(S, x), s -> eval(s^n) $ n in ns);
end_proc:

/*
        LnDelRemTab(<a1,a2,...>)

        a1,a2,...: any expressions
        
        Removes the entries a1, a2, ... from the remember table
        of ln.
*/
stdlib::limit::LnDelRemTab:= proc()
    local t, e;
begin
    t:= op(::ln,[1,5]);
    _delete(t[e]) $ e in [args()];

    sysassign(::ln,subsop(::ln,[1,5] = t));
    null()
end_proc:

/*
        lterm(ex, x <, S>)

        ex -- expression
        x  -- limit variable
        S  -- (optional) mrv set

m        Compute the list [c0,w,e0], where c0*w^e0 is the leading
        term of an asymptotic expansion of ex for x -> infinity.

        Return Values:
        [c0,w,e0] - c0*w^e0 as the leading term
        FAIL      - limit cannot be computed.
        UNKNOWN   - ORDER for series seems to be not big enough.
        "tryIV"   - MRV algorithm fails, but interval calculus may succeed.
*/
stdlib::limit::lterm:= proc(ex, x)
    name stdlib::limit::lterm;
    local i, S, s, e, lc, mlc, le, t, siszero, w, W, order;
    option remember;
begin
    // The series computation can rewrite terms into the form a^b, thus rewrite them 
    // again into the exp-log form (using a more simpler routine than stdlib::limit::simp2explog).
    // An example for that this step is necessary:
    //   limit((-x)^x,x=infinity) = infinity
    // Walter: Aeh?  limit((-x)^x, x = infinity) = undefined !
    ex:= stdlib::limit::rewriteExpLog(ex);
// ================

    if not has(ex, x) then return( [ex,1,0] ) end_if;

    // (a) Find the most rapidly varying subexpressions

    if args(0) = 2 then
        userinfo(3,"MRV: (1) Find MRV set");
        userinfo(4,"MRV:     of ",ex);
        S:= stdlib::limit::getMRV(ex, x);
        if contains( {UNKNOWN,FAIL,"tryIV"},S ) then
            userinfo(3,"MRV: ** determining MRV set fails");
            return( S )
        elif domtype(S) <> DOM_SET then
            // the limit could be determined directly!
            return( [S,1,0] )
        elif nops(S) = 0 then
            return( [ex,1,0] )
        end_if
    else
        S:= select( args(3), (x,y) -> has(y,x), ex );
        if S = {} then 
            S:= stdlib::limit::getMRV(ex, x);
            if contains( {UNKNOWN,FAIL,"tryIV"},S ) then
                userinfo(3,"MRV: ** determining MRV set fails");
                return( S )
            elif domtype(S) <> DOM_SET then
                // the limit could be determined directly!
                return( [S,1,0] )
            end_if
        end_if
    end_if;

    if S intersect {x} = {x} then // Upward Movement
        e:= stdlib::limit::lterm(stdlib::limit::domoveup(ex, x, S));
        if domtype(e) <> DOM_LIST then
            // lterm fails:
            return( e ) 
        else 
            return( stdlib::limit::movedown(e, x) ) 
        end_if
    end_if;


   // (b) Choose one expression in this set and call it w. Rewrite the    
   //     other expressions in that set as g(x)=w^p h(x) and consider all 
   //     expressions  independent of w as constants.                     

    userinfo(3,"MRV: (2) Rewrite MRV set ");
    userinfo(4,"MRV:     i.e. rewrite ", S);

    W:= genident("W");
    assume(W > 0);
    s:= stdlib::limit::rewrite(S, x, W);
    if contains( {UNKNOWN,FAIL,"tryIV"},s ) then
        return( s )
    end_if;

    w:= subs(W, map(s, x -> op(x,2) = op(x,1)));
    le:= op(w);
    t:= stdlib::limit::sign(le, x);
    if t = FAIL then
        return( "tryIV" )
    elif t = 1 then
        s:= subs(s, W = 1/W);
        w:= 1/w;
        le:= -le;
    end_if;
    
    userinfo(4,"MRV:     result of rewriting is ",s);

    sysassign(::ln(1/W), -le); 
    sysassign(::ln(W), le);

    // Combine products of powers, as for example w*w^(-c) must be rewritten 
    // to w^(1-c), because w^(1-c) = exp((1-c)*ln(w)) = exp((1-c)*le)!!
    // Otherwise the result would only be w*exp(-c*le).
    // An example for that this step is necessary:
    //   e3:=x -> exp(exp(exp(x))): limit(e3(n+exp(-n))/e3(n),n=infinity) = infinity

    ex:= combine(eval(subs(ex, op(s))));
                //useful:?  ex:= combine(ex, exp);

//  ================

    // (c) Compute the leading term of the Puiseux series in w around w = 0+ 

    userinfo(3,"MRV: (3) Compute series");
    userinfo(4,"MRV:     in W=0+ of ",ex);

    if not has(ex, W) then 
        stdlib::limit::LnDelRemTab(1/W,W);

        lc:= ex; le:= 0;
    else
        // Extend the zero-test for the series computation to take
        // the properties of W into account.
        // Example: Without re-implementing the zero-test, the following
        // limit computations would fail:
        //   limit(ln(1 - (ln(exp(x)/x - 1) + ln(x))/x)/x, x = infinity) = -1  // normal(expand(...))
        //   limit(ln(1/(ln(x + (2*exp(x*ln(x)^(3/2)))/x^x) - (ln(x)^(3/2) - ln(x))*x - ln(2)))/ln(x), x = infinity) = infinity // simplify(..,ln)
        // See page 111.
        siszero:= ::Series::Puiseux::iszero;
        sysassign(::Series::Puiseux::iszero, 
            proc(c) begin
                // apply 'expr' because iszero can be applied to the whole
                // domain object of domain type Series::Puiseux!
                c:= expr(c);
                if iszero(c) then
                    return(TRUE)
                elif numeric::isnonzero(c) = TRUE then
                    return(FALSE)
                  elif iszero(normal(expand(c))) // or iszero(simplify(c,ln))
                    then
                    return(TRUE)
                else
                    // anyway, UNKNOWN would be the better answer here ...
                    return(FALSE)
                end_if
            end 
        ):

        // Series computation:
        for order from 2 to ORDER do
          if traperror((s:= series(ex, W, order, hold(Right),
                                   hold(NoWarning)))) = 0 then
            if s = FAIL or type(s) = "series" or
               (domtype(s) = Series::gseries and s::dom::lterm(s) <> FAIL) then
              break;
            elif domtype(s) = Series::Puiseux then
              // The sum of two Series::Puiseux is normalized, but
              // without calling Puiseux::iszero!
              s:= Series::Puiseux::normal(s, 1); // normalize using Puiseux::iszero
              if lterm(s) <> FAIL then
                break;
              end_if
            end_if
          elif order = ORDER then
            lasterror()
          end_if
        end_for;

        sysassign( ::Series::Puiseux::iszero, siszero ):

        case domtype(s)
        of Series::Puiseux do
            le:= Series::Puiseux::ldegree(s);
            lc:= Series::Puiseux::lcoeff(s);

            stdlib::limit::LnDelRemTab(1/W,W);

            if lc = FAIL then
                if Series::Puiseux::order(s) > 0 then
                    // the limit is zero
                    return( [0,w,1] )
                else
                    if stdlib::limit::printWarningsFlag = TRUE then
                        warning("ORDER seems to be not big enough for series computation");
                    end_if;
                    return( UNKNOWN )
                end_if
            end_if;
            break
        of Series::gseries do
            userinfo(4,"MRV: series is of type 'Series::gseries': ",s);
            t:= Series::gseries::lterm(s);
            if not has(t,W) then
                le:= 0;
                lc:= Series::gseries::lmonomial(s)
            else
                // handle special gseries expansions, such as x^n:
                case type(t)
                of "ln" do
                    userinfo(4,"MRV: expression has a log-singularity");
                    le:= 0;
                    lc:= Series::gseries::lmonomial(s);
                    break
                of "_power" do 
                    if op(t,1) = W or op(t,1) = -W then
                        userinfo(4,"MRV: series has real exponents");
                        e:= Re(op(t,2));
                        le:= sign(e);
                        if domtype(le) <> DOM_INT then
                            // can't determine leading degree
                            stdlib::limit::LnDelRemTab(1/W,W);
    
                            return( FAIL )
                        end_if;
                        lc:= Series::gseries::lcoeff(s);
                        if op(t,1) = -W then
                            // check whether the exponent is odd or even:
                            e:= is(e, Type::Odd);
                            if e = UNKNOWN then
                                return(FAIL)
                            elif e = TRUE then
                                lc:=  -lc
                            end_if
                        end_if
                    else
                        stdlib::limit::LnDelRemTab(1/W,W);
    
                        // can't handle given case
                        return( FAIL )
                    end_if;
                    break
                of "exp" do 
                    // case exp(b*ln(+/-W)) ?
                    t:= op(t,1);
                    if type(t) = "_mult" then
                        t:= [op(t)];
                        i:= 0;
                        while (i:= contains( map(t,type),"ln",i+1 )) <> 0 and op(t[i],1) <> W and op(t[i],1) <> -W do end_while;
                        if i = 0 then
                            // can't handle given case
                            stdlib::limit::LnDelRemTab(1/W,W);    

                            return( FAIL )
                        else
                            le:= sign( Re(_mult(op(t,1..i-1),op(t,i+1..nops(t)))) );
                            if domtype(le) = DOM_INT then
                                lc:= Series::gseries::lcoeff(s);
                                if op(t[i],1) = -W then
                                    // exp(a*ln(-w)) = exp(I*PI)^a * exp(a*ln(w)) = (-1)^a * exp(a*ln(w))
                                    lc:= lc * (-1)^le
                                end_if
                            else
                                // can't determine leading degree
                                stdlib::limit::LnDelRemTab(1/W,W);

                                return( FAIL )
                            end_if
                        end_if
                    else
                        stdlib::limit::LnDelRemTab(1/W,W);
    
                        userinfo(3,"MRV: can't handle given case");
                        return( FAIL )
                    end_if;
                    break
                otherwise
                    lc:= Series::gseries::lmonomial(s);
                    le:= 0
                end_case;
            end_if;
            stdlib::limit::LnDelRemTab(1/W,W);
            break
        otherwise
            stdlib::limit::LnDelRemTab(1/W,W);

            userinfo(3,"MRV: ** series computation fails");
            userinfo(4,"MRV: ** on ",ex );
            return( FAIL )
        end_case
    end_if;

    if hastype(lc, {"sin", "cos"}) then
       // rewrites, e.g., sin(x)^2 + cos(x)^2 --> 1
       lc := combine(expand(lc), sincos);
    end_if;

    if hastype(lc, {"exp"}) then
      lc:= combine(lc, exp)
    end_if;
                 
    lc:= eval(subs(lc, W = w));
    // check for problems, as in
    // assume(q>0):
    // limit(exp(-q*x)*cosh(x), x=infinity)
    mlc := stdlib::limit::getMRV(lc, x);
    if domtype(mlc) = DOM_SET and nops(mlc) > 0 and
      type(op(mlc, 1)) = "exp" and
      indets(op(mlc, 1)) minus Type::ConstantIdents minus {x} <> {} and
      stdlib::limit::lterm(op(w)/op(op(mlc, 1)), x)[3] >= 0 then
      userinfo(4, "MRV: problem extracting MRV");
      stdlib::limit::LnDelRemTab(1/W,W);
      return(FAIL);
    end_if;

    userinfo(4,"MRV: lcoeff is ",lc, "; ldegree is ",le);

    s:= sign(le);
    if domtype(s) <> DOM_INT then
        if stdlib::limit::printWarningsFlag = TRUE then
            warning("could not decide zero equivalence of ".expr2text(le));
        end_if;
        return(FAIL)
    elif s <> 0 then
        return([lc,w,le])
    else    
        return( stdlib::limit::lterm(lc,x) )        
    end_if
end_proc:

/*
        getMRV(f,x)

        f -- expression
        x -- limit variable

        Find the most rapidly varying subexpressions at x=infinity
        (see section 3.1).

        Return Values:
        S       - set of MRV subexpressions (possibly empty).
        FAIL    - limit cannot be computed.
        UNKNOWN - ORDER for series seems to be not big enough.
        "tryIV" - MRV algorithm fails, but interval calculus may succeed.
*/
stdlib::limit::getMRV:= proc(f, x)
    name stdlib::limit::getMRV;
    option remember;
    local s, t, g;
begin
    if not has(f, x) then
        return( {} )
    elif f = x then
        return( {x} )
    else
        case type(f)
        of "_mult" do
            s:= stdlib::limit::getMRV(op(f,1), x);
            if domtype(s) <> DOM_SET then return( s ) end_if;
            t:= stdlib::limit::getMRV(subsop(f,1=1), x);
            if domtype(t) <> DOM_SET then return( t ) end_if;

            return(stdlib::limit::maxMRV(s, t, x));
        of "_plus" do
            s:= stdlib::limit::getMRV(op(f,1), x);
            if domtype(s) <> DOM_SET then return( s ) end_if;
            t:= stdlib::limit::getMRV(subsop(f,1=0), x);
            if domtype(t) <> DOM_SET then return( t ) end_if;

            return(stdlib::limit::maxMRV(s, t, x));
        of "_power" do
            if not has(op(f,2),x) then
                return( stdlib::limit::getMRV(op(f,1),x) )
            /* frankp: gibt Probleme, wenn {0} nach maxMRV geschickt wird! 
            elif iszero(op(f,1)) = TRUE then
                return( {0} )
            */
            elif iszero(op(f,1)) = TRUE then
                // frankp: Dieser Fall sollte nicht auftreten!
                return( FAIL )
            else
                return( stdlib::limit::getMRV(exp(ln(op(f,1))*op(f,2)),x) )
            end_if
    
        of "ln" do
            return( stdlib::limit::getMRV(op(f,1),x) )
    
        of "exp" do
            if f = exp(x) then return( {f} ) end_if;
            t:= stdlib::limit::getMRV(op(f), x);
            s:= stdlib::limit::lterm(op(f), x);
            if domtype(s) <> DOM_LIST then
                // lterm fails:
                return( s )
            elif sign(s[3]) = -1 then
                g:= stdlib::limit::compare(f, op(t,1), x);
                if g = ">" then 
                    return({f})
                elif g = "<" then 
                    return(t)
                else 
                    return({f} union t)
                end_if;
            else
                return(t)
            end_if;

        of "sin"  do
        of "cos"  do
            t:= stdlib::limit::limitMRV(op(f,1), x);
            if contains( {UNKNOWN,FAIL,"tryIV"},t ) then
                return( t )
            elif domtype(t) = stdlib::Infinity then
                // t = infinity or t = -infinity: try interval calculus!
                return( "tryIV" )
            else
                return( stdlib::limit::getMRV(op(f,1), x) )
            end_if
    
        of "tan"    do
        of "arcsin" do
        of "arccos" do
        of "cot"    do
            t:= stdlib::limit::limitMRV(op(f,1), x);
            if contains( {UNKNOWN,FAIL,"tryIV"},t ) then
                return( t )
            elif t <> infinity and t <> -infinity then
                return( stdlib::limit::getMRV(op(f,1), x) )
            else
                // essential singularity
                return( FAIL )
            end_if
    
        of "arctan" do
            if has({op(f)}, x) then
                return( FAIL )
            else
                return( {} )
            end_if
    
        of "arcsinh" do
        of "arccosh" do
        of "psi"     do
            t:= stdlib::limit::limitMRV(op(f,1), x);
            if contains( {UNKNOWN,FAIL,"tryIV"},t ) then
                return( t )
            else
                s:= sign(t);
                if s = 1 or s = 0 then
                    return( stdlib::limit::getMRV(op(f,1), x) )
                else
                    userinfo( 1,"** ".type(f).": can't handle point ",t);
                    return( FAIL )
                end_if
            end_if
    
        of "arctanh" do
            t:= stdlib::limit::limitMRV(op(f,1), x);
            if contains( {UNKNOWN,FAIL,"tryIV"},t ) then
                return( t )
            elif contains( {1,-1},t ) then
                // singularity
                return( FAIL )
            else
                return( stdlib::limit::getMRV(op(f,1), x) )
            end_if
        of "Ei" do
            return(FAIL)
        of "Si" do
            return( stdlib::limit::getMRV(op(f,1), x) )

        of "besselJ" do // f =  besselJ(n,x)
            if has(op(f, 1), x) then
               // no asymptotic formula implemented
               // for besselJ(n(x), x) as x --> infinity
               return(FAIL);
            end_if;
            t:= stdlib::limit::limitMRV(op(f,2), x);
            if contains( {UNKNOWN,FAIL,"tryIV"},t ) then
                return( t )
            elif t = -infinity then
                // essential singularity 
                return( FAIL )
            elif t = infinity or not has(t,infinity) then
                return( stdlib::limit::getMRV(op(f,2), x) )
            else 
                // complex*infinity or sign(..)*infinity
                return( FAIL )
            end_if;
            break; // just for safety
        of "dilog" do
            // series is powerfull enough to handle this case:
            return( stdlib::limit::getMRV(op(f,1),x) )
        // -------------------------------------------------------
        // functions which were treated by the pre-processing step
        of "erf"           do
        of "erfc"          do
        of "limit::erfs"   do
        of "gamma"         do
        of "limit::gammas" do
            return( stdlib::limit::getMRV(op(f,1),x) )
        end_case
    end_if;

    return( FAIL )
end_proc:

/*
        rewrite(S,x)

        S -- mrv set of f in respect to x
        x -- limit variable

        Returns [w,S,l] where w represents W and l is 
        the list of elements of S rewritten in W.
        The i.th element of l is the i.th element of S rewritten
        in W (i=1..|S|).

        Return Values:
        [w,S,l] - see above.
        FAIL    - limit cannot be computed.
        UNKNOWN - ORDER for series seems to be not big enough.
        "tryIV" - MRV algorithm fails, but interval calculus may succeed.
*/
stdlib::limit::rewrite:= proc(S, x, W)
    name stdlib::limit::rewrite;
    option remember;
    local g, c, cc, f, A, S0, subspat;
begin
    g:= op(S,1);
    for f in S do
        if length(f) < length(g) then g:= f end
    end;

    S0:= sort([op(S)], 
        (a, b) -> bool(nops(stdlib::limit::getMRV(a, x)) >= nops(stdlib::limit::getMRV(b, x))) 
    );

    subspat:= null();
    for f in S0 do
        c:= stdlib::limit::lterm(op(f)/op(g), x);
        if c[3] <> 0 then
            error("Elements must be in the same compatibility class")
        else
            c:= c[1];
            A:= exp(op(f) - c*op(g));
            // Be sure not to generate terms of the form a^b (see the comment and
            // the example given at the beginning of 'lterm'):
            // if contains({DOM_RAT, DOM_INT, DOM_FLOAT}, domtype(c)) then
            if testtype(c, Type::Constant) then
                cc:= numeric::rationalize(float(c));
                if domtype(cc) = DOM_INT then
                   subspat:= subspat, f = A*W^cc
                else
                   subspat:= subspat, f = A*W^c
                end_if;
            else
//                subspat:= subspat, f = A*exp(c*ln(W))
                subspat:= subspat, f = A*W^c
            end_if
        end
    end;
    [subspat]
end:

/*
        compare(f,g,x)

        f, g -- expressions in x
        x -- limit variable

        Returns either "<", ">", or "=".
*/
stdlib::limit::compare:= proc(f, g, x)
    name stdlib::limit::compare;
    option remember;
    local lnf, lng, c;
begin
    if type(f) = "exp" then lnf:= op(f) else lnf:= ln(f) end_if;
    if type(g) = "exp" then lng:= op(g) else lng:= ln(g) end_if;
    c:= stdlib::limit::lterm(lnf/lng, x);
    if domtype(c) <> DOM_LIST then
        error("cannot compare Mrv sets")
    else
        case sign(c[3])
        of -1 do
            return(">")
        of 1 do
            return("<")
        of 0 do
            return("=")
        end_case
    end_if
end_proc:

/*
        maxMRV(s,x)

        s -- set containing sets of rapidly varying terms in x
        x -- limit variable

        Find the more rapidly varying set (see section 3.2).

        Return Values:
        S       - the more rapidly varying set.
        FAIL    - limit cannot be computed.
        UNKNOWN - ORDER for series seems to be not big enough.
        "tryIV" - MRV algorithm fails, but interval calculus may succeed.
*/
stdlib::limit::maxMRV:= proc(s1, s2, x)
    name stdlib::limit::maxMRV;
    option remember;
    local f, g, c;
begin
    if s1 = {} then
        return(s2)
    elif s2 = {} then
        return(s1)
    elif s1 intersect s2 <> {} then
        return(s1 union s2)
    elif s1 intersect {x} = {x} then 
        return(s2)
    elif s2 intersect {x} = {x} then 
        return(s1)
    else
        f:= op(s1,1); g:= op(s2,1);

        c:= stdlib::limit::compare(f, g, x);
        if c = ">" then return(s1) 
        elif c = "<" then return(s2)
        else
            return(s1 union s2)
        end_if
    end_if
end_proc:

/*
        sign(f,x)

        f -- expression in x
        x -- ident

        Compute the sign of ex, assuming that x goes to infinity.
        Returns FAIL if this cannot be determined.
*/
stdlib::limit::sign:= proc(ex, x)
    name stdlib::limit::sign;
    option remember;
    local s, t, S;
    begin
                
    userinfo(4,"MRV: compute the sign of ",ex);
    if ex = x then return( 1 ) end_if;

    if not has(ex, x) then
        s:= sign(ex);
        if not has(s,sign) then
            return( s )
        else
            return( FAIL )
        end_if
    end_if;

    case type(ex)
    of "_mult"  do
        S:= 1;
        for t in ex do
            s:= stdlib::limit::sign(t, x);
            if s = FAIL then 
                return( FAIL )
            else
                S:= S * s
            end_if
        end_for;
        return( S )
    of "_power" do
        if domtype(op(ex,2)) = DOM_INT and modp(op(ex,2),2) = 0 then 
            return( 1 )
        elif op(ex,1) = x then
            return( 1 )
        elif stdlib::limit::sign(op(ex,1), x) = 1 then
            return( 1 )
        else
            t:= stdlib::limit::lterm(ex, x);
            if t = FAIL or t = "tryIV" then
                return( FAIL )
            else
                return( stdlib::limit::sign( t[1], x ) )
            end_if
        end_if
    of "_plus"do
        t:= stdlib::limit::lterm(ex, x);
        if t = FAIL or t = "tryIV" then
            return( FAIL )
        else
            return( stdlib::limit::sign(t[1], x) )
        end_if
    of "exp" do 
        return( 1 )
    otherwise
        t:= stdlib::limit::lterm(ex, x);
        if t = FAIL or t = "tryIV" then
            return( FAIL )
        else
            return( stdlib::limit::sign(t[1], x ))
        end_if
    end_case
end_proc:

/*
        subsFUNC(ex,f1,f2)

        ex -- expression
        f1 -- string (type of function)
        f2 -- function

        Substitutes all function calls f(x) of type f1 to 
        function calls f2(x).
*/
stdlib::limit::subsFUNC:= proc(ex,f1,f2) 
    option remember;
    name stdlib::limit::subsFUNC;
begin
    case domtype(ex) 
    of Series::Puiseux do
        return( eval(map(ex,stdlib::limit::subsFUNC,f1,f2)) )
    of DOM_EXPR do
        if type(ex) = f1 then ex := f2(op(ex)) end_if;
        return( eval(map(ex,stdlib::limit::subsFUNC,f1,f2)) )
    otherwise
        return( ex )
    end_case
end_proc:

/********************************************************************
        preProcess(ex,x)

        ex -- expression
        x  -- limit variable

        Define the pre-processing algorithms for some
        smooth functions. 

        These rules are defined as methods of the domain stdlib::limit::preProcess.
        The methods are called by the type of the regarded function. Two 
        pre-pocessing procedures must be defined, one named by the type of 
        the original function, the second by the type of the corresponding 
        smooth function (for example "erf" and "erfs").
*******************************************************************/
stdlib::limit::preProcess:= proc(ex,x)
    name stdlib::limit::preProcess;
    local p;
begin
    if domtype(ex) = DOM_EXPR then
        if (p:= contains(stdlib::limit::setPreProcessFunc,op(ex,0))) > 0 and has(ex,x) then
            return( slot(stdlib::limit::DpreProcess,expr2text( stdlib::limit::setPreProcessFunc[p] ))(
                op(map([op(ex)],stdlib::limit::preProcess,x )), x
            ) )
        else
            return( eval(map(ex,stdlib::limit::preProcess,x )) )
        end_if
    else
        return( ex )
    end_if
end_proc:

/*--
        Note: 'hold' is requiered here; otherwise the pre-processing step
        only works for the *object* and not for its name. Thus, if
        for instance, the remember table of the object was changed
        afterwards, the process never works again!
--*/
stdlib::limit::setPreProcessFunc:= [
    hold(abs),hold(sign),hold(erf),hold(gamma),hold(sinh),hold(cosh),hold(tanh),hold(coth),
    hold(arctan),hold(fact),hold(log),hold(Ei), hold(igamma),hold(erfc),hold(binomial)
]:

stdlib::limit::DpreProcess:= newDomain("stdlib::limit::DpreProcess"):

/*--
        erf(x) =  1-exp(-x^2)*erfs(x)  for x->infty
        erf(x) = -1+exp(-x^2)*erfs(-x)  for x->-infty
--*/
stdlib::limit::DpreProcess::erf:= proc(ex,x)
    local s;
begin
    s:= limit(ex,x=infinity);
    case s 
    of FAIL do
        return( FAIL )
    of infinity do
        return( 1-exp(-ex^2)*stdlib::limit::erfs(ex) )
    of -infinity do
        return( -1+exp(-ex^2)*stdlib::limit::erfs(-ex) )
    otherwise
        return( hold(erf)(ex) )
    end_case
end_proc:
slot(stdlib::limit::DpreProcess,"limit::erfs"):= proc(ex,x)
    local s;
begin
    s:= limit(ex,x=infinity);
    if s = FAIL then
        return( FAIL )
    elif domtype(s) <> stdlib::Infinity then
        // s <> infinity and s <> -infinity:
        s:= sign(s);
        if s = 1 then 
            return( (1-erf(ex))*exp(ex^2) )
        elif s = -1 then 
            return( (1+erf(-ex))*exp(ex^2) )
        else 
            return( FAIL )
        end_if
    else
        return( subsop(hold(X)(ex),0=stdlib::limit::erfs) )
    end_if
end_proc:

/*--------------------------------------------------
        erfc(x) = 1-erf(x)
--------------------------------------------------*/
stdlib::limit::DpreProcess::erfc:= proc(ex,x)
begin
    1-stdlib::limit::DpreProcess::erf(ex,x)
end_proc:


/*--------------------------------------------------
        igamma(a, x) = x^(a - 1)*exp(-x)
--------------------------------------------------*/
//--------------------------------------------------
// Walter, 26.1.02 (full of despair)
// If I only knew what the original return value 
// (a, ex, x) -> 1/x is about.
// Assuming that the return value is to give
// the leading term of the asymptotic expansion,
// I replace 1/x by ex^(a- 1)*exp(-ex).
// Note that 1/x is wrong, anyway. The resulting
// limit 0 is only correct assuming
// a = independent of x
//--------------------------------------------------
stdlib::limit::DpreProcess::igamma:= proc(a,ex,x)
    local s;
begin
    s:= limit(ex,x=infinity);
    case s 
    of FAIL do
        return( FAIL )        
    of infinity do
        // original entry by frank:
        //  return( 1/x )
        // Walter: I replace 1/x by the
        // following leading term of the
        // asymptotic expansion:
        return(ex^(a - 1)*exp(-ex));
    otherwise
        return( hold(igamma)(a,ex) )
    end_case
end_proc:


stdlib::limit::DpreProcess::Ei:=
proc(ex, x)
  local s;
begin
  s:= limit(ex,x=infinity);
  case s
    of FAIL do
      return(FAIL)
    of infinity do
    of -infinity do  
      return(1/ex/exp(ex))
    otherwise
      return(hold(Ei)(ex))
  end_case
end_proc:

/*----------------------------------------------------
        gamma(x) = exp( gammas(x) )  for x->infty
----------------------------------------------------*/
stdlib::limit::DpreProcess::gamma:= proc(ex,x)
    local s;
begin
    s:= limit(ex,x=infinity);
    if s = FAIL then 
        return( FAIL )
    elif s = infinity then
        return( exp(stdlib::limit::gammas(ex)) )
    else
        return( hold(gamma)(ex) )
    end_if
end_proc:
slot(stdlib::limit::DpreProcess,"limit::gammas"):= proc(ex,x)
    local s;
begin
    s:= limit(ex,x=infinity);
    if s = FAIL then 
        return( FAIL )
    elif domtype(s) <> stdlib::Infinity then
        // s <> infinity and s <> -infinity:
        if sign(s) = 1 then 
            return( ln(gamma(ex)) )
        else 
            return( FAIL )
        end_if
    else
        return( subsop(hold(X)(ex),0=stdlib::limit::gammas) )
    end_if
end_proc:

/*--
                   /  1  if sign(x) -> 1
        sign(x) = <
                   \  -1 if sign(x) -> -1
--*/
stdlib::limit::DpreProcess::sign:= proc(ex,x)
    local t;
begin
    t:= stdlib::limit::sign(ex,x);
    if t = 1 then 1 
    elif t = -1 then -1
    else hold(sign)(ex)
    end_if
end_proc:

/*--
        abs(x)  = x/sign(x)
--*/
stdlib::limit::DpreProcess::abs:= proc(ex,x) begin  
    ex/stdlib::limit::DpreProcess::sign(ex,x)
end_proc:

/*--
        fact(x) = gamma(x+1)
--*/
stdlib::limit::DpreProcess::fact:= proc(ex,x) 
begin
    stdlib::limit::DpreProcess::gamma(ex+1,x)
end_proc:

/*--
        binomial(n,k) = n*gamma(n)/(k*gamma(k)*(n-k)*gamma(n-k)
--*/
stdlib::limit::DpreProcess::binomial:= proc(n,k,x) 
begin
    n*stdlib::limit::DpreProcess::gamma(n, x) / k / stdlib::limit::DpreProcess::gamma(k, x) / (n-k) / stdlib::limit::DpreProcess::gamma(n-k, x)
end_proc:

stdlib::limit::DpreProcess::arctan:= proc(ex,x)
    local t;
begin
    if args(0) = 3 then
         // two-argument arcus tangens
         ex:= x/ex; x:= args(3)
    end_if;
    case (t:= limit(ex,x=infinity))
    of -infinity do
        return( -PI/2 )
    of infinity do
        return( PI/2 )
    of FAIL do
        return( FAIL )
    otherwise
        return( hold(arctan)(t) )
    end_case
end_proc:

stdlib::limit::DpreProcess::sinh:= x -> (exp(x)-exp(-x))/2:
stdlib::limit::DpreProcess::cosh:= x -> (exp(x)+exp(-x))/2:
stdlib::limit::DpreProcess::tanh:= x -> (exp(x)-exp(-x))/(exp(x)+exp(-x)):
stdlib::limit::DpreProcess::coth:= x -> (exp(x)+exp(-x))/(exp(x)-exp(-x)):
stdlib::limit::DpreProcess::log:= (b,x) -> ln(x)/ln(b):

/*******************************************************************************/

//------------------------------------------
//        The function limit::erfs(x)
//------------------------------------------
stdlib::limit::erfs:= funcenv( proc() begin procname(args()) end ):

stdlib::limit::erfs::print:= "limit::erfs":

stdlib::limit::erfs::series :=
    proc(f,x,n)
        local t, s, k, y;
    begin
        t:= Series::series(f,x,n);
        if domtype(t) <> Series::Puiseux then   
            error("unable to compute series expansion")
        end_if;
        k:= ldegree(t);
        if k = 0 then
            t := expr(t);
            s := Series::series((1-erf(t))*exp(t^2),x,n);
            return( stdlib::limit::subsFUNC(s,"erf",e -> 1-exp(-e^2)*stdlib::limit::erfs(e)) )
        elif k < 0 then 
            // f goes to +/- infinity
            if sign(lcoeff(t)) = 1 then 
                // f goes to +infinity
                y:= genident("y");
                s:= Series::Puiseux::create(
                    1,1,n,[(1/sqrt(PI)*(-1/4)^s*fact(2*s)/fact(s),0) $ s=0..iquo(n-1,2)],y
                );
                s := Series::Puiseux::_fconcat(s, Series::series(1/f,x,n));
                return(s);
            end_if
        else
            return( Series::unknown(stdlib::limit::erfs(f),x,n) )
       end_if
    end_proc:

stdlib::limit::erfs::type:= "limit::erfs":

stdlib::limit::erfs::diff :=
    proc(f,x)
    begin
        case args(0)
        of 1 do 
            return( f )
        of 2 do
            f:= op(f);
            if has(f,x) then
                return( (-2/sqrt(PI)+2*stdlib::limit::erfs(f)*f)*diff(f,x) )
            else 
                return( 0 )
            end_if
        otherwise
            return( diff( diff(f,x),args(3..args(0)) ) )
        end_case
    end_proc:
         
stdlib::limit::erfs:= slot( stdlib::limit::erfs, "stdlib::limit::sign", 
    proc(f,x)
        local s;
    begin
        s:= stdlib::limit::limitMRV(f,x);
        if contains( {FAIL,UNKNOWN,"tryIV"},s ) then
            return( FAIL )
        else
            s:= sign(s);
            if s = 0 or s = 1 then return( 1 ) else return( FAIL ) end_if
        end_if
    end_proc
):

//------------------------------------------
//        The function limit::gammas(x)
//------------------------------------------
stdlib::limit::gammas:= funcenv( proc() begin procname(args()) end ):

stdlib::limit::gammas::print:= "limit::gammas":

stdlib::limit::gammas::series :=
    proc(f,x,n)
        local t, s, k, y;
    begin
        t:= Series::series(f,x,n);
        if domtype(t) <> Series::Puiseux then
            error("unable to compute series expansion")
        end_if;
        k:= ldegree(t);
        if k = 0 then
            t:= expr(t);
            s:= Series::series(ln(gamma(t)),x,n);
            return( stdlib::limit::subsFUNC(s,"gamma",e -> exp(stdlib::limit::gammas(e))) )
        elif k < 0 then // f goes to +/- infinity
            // s := series(ln(gamma(1/x)), x = 0, Right)
            y:= genident("y");
            s:= Series::Puiseux::create(
                1,-1,13,[(-ln(y)-1),1/2*ln(y)+1/2*ln(2*PI),1/12,0,-1/360,0,1/1260,0,-1/1680, 
                0,1/1188,0,-691/360360],y
            );
            // return series(s(1/t), x)
            s := Series::series( subs(expr(s),y=1/expr(t)),x,n );
            return(s);
        else
            return( Series::unknown(stdlib::limit::gammas(f),x,n) )
       end_if
    end_proc:

stdlib::limit::gammas::type:= "limit::gammas":

stdlib::limit::gammas::diff:=
    proc(f,x)
    begin
        case args(0)
        of 1 do 
            return( f )
        of 2 do
            f:= op(f);
            if has(f,x) then
                return( psi(f)*diff(f,x) )
            else
                return( 0 )
            end_if
        otherwise
            return( diff( diff(f,x),args(3..args(0)) ) )
        end_case
    end_proc:

stdlib::limit::gammas:= slot( stdlib::limit::gammas, "stdlib::limit::sign",
    proc(f,x)
        local s;
    begin
        s:= stdlib::limit::limitMRV(f,x);
        if contains( {FAIL,UNKNOWN,"tryIV"},s ) or sign(s) <> 1 then
            return( FAIL )
        else
            return( 1 )
        end_if
    end_proc):

/*******************************************************************************/

unalias( stdlib::limit ):

