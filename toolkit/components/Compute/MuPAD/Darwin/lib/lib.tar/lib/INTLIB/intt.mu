// $Date: 2005-02-23 09:44:08 +0100 (Wed, 23 Feb 2005) $ $Author: ccr $ $Revision: 30486 $ 
/*--
intlib::intt(f,n) - is the internal integration
of the substituted function f in _global_k(n)
--*/
intlib::intt:=proc(f,n)
  local i,j,r,t,integral,q,x;
// global   _global_k,_global_k_sub,_global_k_ident,_global_k_diff,_global_k_deg,_global_k_alg,_global_Q,_global_Q_sub 
begin
  userinfo(2,"f=",f,"n=",n);
  f:=intlib::split2(f,n); f[4]:=intlib::sqffTab(f[4]);
  userinfo(2,"split -> f=",f);
  f:=intlib::hermite(f,n);
  userinfo(2,"after hermite, f=",f);
  integral:=f[5]; delete f[5];
  f:=intlib::rlti(f,n);
  userinfo(2,"after rlti, f=",f);
  if f=FAIL then
    userinfo(10,"can't integrate normal part");
    return(FAIL);
  end_if;
  integral:=integral+f[3]; delete f[3];
  if iszero(f[1]) then return(integral); end_if;
  case op(_global_k[n],0)
    of hold(exp) do 
         userinfo(2,"dealing with exponential extension");
         userinfo(2,"num=",f[1],"den=",f[2]);
         r:=degree(f[1]); t:=degree(f[2]);
         for j from r downto -t do
           if j=0
              then 
                 i:=intlib::intt(coeff(f[1],t),n-1);
                 userinfo(2,"n=",n,"have to integrate:",coeff(f[1],t),"->",i);
                 if i=FAIL then return(FAIL) end_if;
              else 
                 i:=intlib::solveRde(j*_global_k_diff[n],coeff(f[1],j+t),n-1);
                 userinfo(2,"solution of Risch DE is",i);
                 if i=FAIL then
                   userinfo(10,"can't solve Risch DE");
                   return(FAIL);
                 end_if;
           end_if;
           integral:=integral+i*_global_k_sub[n]^j;
         end_for;
         break;
    of hold(ln) do 
         userinfo(2,"dealing with logarithmic extension");
         i:=polylib::lcoeff(f[1]); r:=degree(f[1]);
         x:=_global_k_sub[n]; q:=table(i=0 $ i=0..r+1);
         for j from r downto 1 do
           q[j]:=intlib::intt(i,n-1);
           if q[j]=FAIL then return(FAIL); end_if;
           t:=n; n:=nops(_global_k);
           q[j]:=intlib::tower(q[j]);
           // intlib::tower may return FAIL, hence:
           if q[j] = FAIL then
             return(FAIL)
           end_if;
           n:=t;
           if indets(q[j]) minus {_global_k_sub[t] $ t=1..n,op(_global_Q_sub)} <>{}
             then
             userinfo(10,"the integral of ",i," = ",q[j],
                                 "is not in the correct form");
             return(FAIL);
           end_if;
           q[j]:=poly(q[j],[x]);
           q[j+1]:=normal(q[j+1]+coeff(q[j],1)/(j+1));
           q[j]:=coeff(q[j],0);
           i:=coeff(f[1],j-1)-j*q[j]*_global_k_diff[n];
         end_for;
         q[0]:=intlib::intt(i,n-1);
         if q[0]=FAIL then return(FAIL); end_if;
         integral:=_plus(integral,q[j]*x^j $ j=0..r+1);
         break;
    of FAIL do 
      userinfo(2,"dealing with",op(_global_k[n],0));
      assert(domtype(f[1])=DOM_POLY);
      f[1] := poly2list(f[1]);
      integral:=_plus(integral,
		      op(map(f[1],
			     l -> l[1]/(l[2]+1)*_global_k_sub[1]^(l[2]+1))));
      break;
    otherwise return(FAIL);
  end_case;
  return(integral);
end_proc:
