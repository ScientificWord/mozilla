// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	cosh/Im -- the function attribut "Im" for cosh
--*/

cosh := slot( cosh, "Im", proc(x)
        local r, s;
    begin
        r := Re(x);
        if r = x then 
            return( 0 )
        elif not has(r,{hold(Re),hold(Im)}) then
            s := Im(x);
            if not has(s,{hold(Re),hold(Im)}) then
                return( sinh(r)*sin(s) )
            end_if
        end_if;
        return( FAIL )
    end_proc
):

// end of file 
