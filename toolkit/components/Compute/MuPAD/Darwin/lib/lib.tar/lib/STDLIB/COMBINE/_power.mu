
// _power::combine(l, f)
// handles the call combine(l^f)


_power::combine:=
proc(l, f)
  local p, k, flag;
begin
  l:= combine(l);
  f:= combine(f);
  
  // rewrite (a^b)^c --> a^(b*c) if
  // * c in Z or
  // * a >= 0 and b in R or
  // * Re(a) > 0 and -2 <= b <= 2 or
  // * -1 < b <= 1 or (b = -1 and not a < 0)
  if type(l) = "_power" then
    flag := FALSE;
    if is(f, Type::Integer) = TRUE then
      flag := TRUE;
    elif is(op(l, 2), Type::Real) = TRUE then
      if is(op(l, 1) >= 0) = TRUE then
        flag := TRUE;
      elif is(-2 <= op(l, 2) <= 2) = TRUE then
        if is(Re(op(l, 1)) > 0) = TRUE then
          flag := TRUE;
        elif is (-1 <= op(l, 2) <= 1) = TRUE then
          flag := is(op(l, 2) = -1) = FALSE
                  or is(op(l, 1) < 0) = FALSE;
        end_if;
      end_if;
    end_if;
    if flag then
      return(op(l, 1)^combine(op(l, 2)*f));
    end_if
  end_if;

  if domtype(l) = DOM_INT and (k:= numlib::ispower(l)) <> FALSE then
    return(op(k, 1)^(op(k, 2) *f) )
  end_if;

  if (p:= slot(combine,type(l))) <> FAIL then
    return( p(l^f) )
  end_if;

  return(l^f)
  
end_proc: