/* $Id: patterns_read.mu 36099 2006-01-05 15:32:04Z meista $
 * patterns_read: read pattern FSA used by solvelib::pattern
 */



proc()
  save solvepatternFSA;
begin
  read("SOLVELIB".stdlib::PathSep."patternFSA.mb", Plain);
  solvelib::patternFSA := solvepatternFSA;
end_proc:

%():
