/*

Use intlib::float instead of float for numerical evaluation of multiple
integrals. intlib::float calls the numerical integrator directly. Note, that
* the ranges of integration (intervals) must be finite, and
* there should be no endpoint singularities and no discontinuity in the
  interior of the interval of integration.
No check is done.

intlib::float uses the the Clenshaw-Curtis Quadrature. Note that numerical
evaluation of multiple integrals is very expensive. For example,
intlib::float(int(int(exp(sin(x+y)),x=0..1),y=1..2)) calls 20 times the
Clenshaw-Curtis Quadrature and calls 380 times exp(sin(x+y)).
intlib::float(int(int(int(exp(sin(x+y+z)),x=0..1),y=1..2), z=2..3))
calls 381 times the Clenshaw-Curtis Quadrature and calls 7239 times
exp(sin(x+y+z)).
Use intlib::float(..., Adaptive) to use the adaptive 8th-order Newton-Cotes 
quadrature.

Examples:

>> int(int(exp(sin(x+y)),x=0..y),y=1..2);

               int(int(exp(sin(x + y)), x = 0..y), y = 1..2)

>> float(%);
                                2.952484549

>> int(int(exp(sin(x)),x=0..1),y=1..2);

                        int(exp(sin(x)), x = 0..1)

>> float(%);
                                1.631869608
 
>> int(int(exp(sin(x)),x=0..y),y=1..2);
 
                 int(int(exp(sin(x)), x = 0..y), y = 1..2)
 
>> float(%);
                                2.919706245
 
>> int(int(besselJ(0, x*y), y = 0..1), x = 0..2);
 
               int(int(besselJ(0, x y), y = 0..1), x = 0..2)
 
>> intlib::float(%);
                                1.796685732
 
>> g := proc(x) begin if x < 1 then x else x^2 end_if end_proc:
>> int(hold(g(x)),x=0..10);
 
                           int(g(x), x = 0..10)
 
>> intlib::float(%);
                                  3.335e2
 
>> int(int(int(max(x*y,x*(1-y),(1-x)*z,(1-x)*(1-z)),x=0..1),y=0..1),z=0..1);
 
int(int(int(max(x y, x (- y + 1), z (- x + 1), (- x + 1) (- z + 1)),
 
   x = 0..1), y = 0..1), z = 0..1)
 
>> intlib::float(%, Adaptive);
 
                               0.5659985785
*/

intlib::float := proc(_f_, method = 0)
   option escape;
   local make_proc, num_int, r;
begin

   make_proc := proc(_f_)
      option escape;
      local __a, __b, _g_, g, h, _t_, _x_;
   begin
      if type(_f_) = "int" then     // _f_ = int(_g_, _x_=__a..__b) 
         _g_ := op(_f_, 1);
	 _x_ := op(_f_, [2,1]);
	 __a := op(_f_, [2,2,1]);
	 __b := op(_f_, [2,2,2]);
         if contains( {"function","int"},type(_g_) ) then
            _t_ := op(_g_, 0); //g := level(_t_, 2);
             g:= eval(last(1));
            if testtype(g, DOM_PROC) then
               if testtype(method, DOM_IDENT) then method := Adaptive; end_if;
               /*
               return( hold(num_int)(g, __a, __b) )
               */
               return( num_int(g, __a, __b) )
            end_if;
         end_if;
         h := make_proc(_g_);
	 if h <> FAIL then 
	  // hold(num_int)(subsop(proc() begin end_proc, 1=_x_, 4=h), __a, __b) 
	    num_int(proc() begin subs( h ,_x_=args(1)) end_proc, __a, __b)
	 else
	  // hold(num_int)(subsop(proc() begin end_proc, 1=_x_, 4=_g_), __a, __b) 
            num_int(proc() begin subs(_g_,_x_=args(1)) end_proc, __a, __b)
	 end_if;
      else
         FAIL
      end_if
   end_proc;

   num_int := proc(_f_, left, right)
      local l, r, err, nofun, c, tol, eps;
   begin
      if method = Adaptive
      then eps := 10^(-DIGITS)
      else eps := 10^(2-DIGITS)
      end_if;

      if traperror( ( 
              if method = Adaptive
              then l := intlib::ncquad(_f_,left,right,eps,eps) 
              else l := intlib::ccquad(_f_,left,right,eps,487)
              end_if
         ) ) <> 0 then
         userinfo(1, "singularity in or near interval of integration");
         return(FAIL)
      end_if;
      r := l[1]; err := l[2]; nofun := l[3]; c := l[4];
      if (method = Adaptive and c <> 0) or (method <> Adaptive and r = FAIL) then
         if method <> Adaptive
         then userinfo(1, "Clenshaw-Curtis quadrature fails.");
              userinfo(1, "Function probably oscillates. Try adaptive method.");
         else userinfo(1, "Newton-Cotes quadrature fails.");
         end_if;
         return(FAIL)
      end_if;
 
      // Calculate error tolerance, with eps as a relative error       
      //   criterion;  if too small then use absolute error.           
      tol := max(eps*abs(r), 0.001*eps);
      userinfo(1, "error = ".expr2text(err).", error tolerance = ".expr2text(tol).", result = ".expr2text(r));
      if err <= tol
        then return( r )
        else userinfo(1,"numerical integration failed to converge");
             return(FAIL);
      end_if
   end_proc:

   r:= make_proc(_f_);  //level(r, 2);
   eval(last(1));

end_proc:
