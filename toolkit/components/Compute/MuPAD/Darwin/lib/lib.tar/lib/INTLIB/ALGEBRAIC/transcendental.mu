/*

  intlib::algebraic::transcendental is supposed to find all the expressions needed for a
  transcendental differential field extension in which the given expression and its
  derivative are rational expressions.

  Input: expression and the indeterminate w.r.t. which to integrate
  
  Output: A list of three lists:
  - new indeterminates to use
  - original expressions these stand for
  - derivatives, expressed in the new indeterminates

*/

proc()
  local transExprs;
  option escape;
begin

  // utility function: transExprs returns all the transcendental expressions
  // in its argument which contain x.
  transExprs :=
  proc(f, x)
    local a;
  begin
    if not has(f, x) then return({}); end_if;
    case type(f)
    of DOM_LIST do
    of DOM_SET do
    of DOM_TABLE do
    of "_mult" do
    of "_plus" do
      return(_union(op(map([op(f)], transExprs, x))));
    of "_power" do
      if testtype(op(f, 2), DOM_INT) then
        return(transExprs(op(f, 1), x));
      else
        return({FAIL});
      end_if;
      break;
    // special case: don't add exp(2*x), exp(-x) etc.
    of "exp" do
      a := op(f);
      if type(a) = "_mult" then
        a := select(a, _not@testtype, Type::Integer);
      end_if;
      return({exp(a)} union transExprs(a, x));
    end_case;
    if domtype(f)=DOM_EXPR then
      return(_union({f}, op(map([op(f)], transExprs, x))));
    else
      return({f});
    end_if;
  end;

intlib::algebraic::transcendental :=
proc(f, x)
  local vars, Dex, n, diffs, i, ts, valuation, seen, simpl;
begin
  vars := indets(f, All) union {x};
  // for new vars, `#t1`, `#t2`, etc. are used.
  // Find the first one not appearing in the input:
  n := select(map(vars, expr2text),
              x -> _lazy_and(length(x) > 3, x[1..3] = "`#t"));
  if n = {} then n := 1
  else
    n := map(n, s -> text2expr(strmatch(s."x0", "\\d+", ReturnMatches)[1]));
    n := max(n)+1;
  end_if;

  vars := transExprs(f, x);
  if FAIL in vars then
    return([FAIL, FAIL, FAIL]);
  end_if;
  diffs := map(vars, diff, x);

  // to avoid non-transcendental extensions, try rewriting in terms
  // of what we already had:
  valuation := ex -> intlib::Simplify::defaultValuation(ex) +
                      1500 * nops(transExprs(ex, x) minus {op(vars)});

  // to get consistent arguments, and, hence lookups
  simpl := proc(t) option remember;
           begin
             intlib::Simplify(t,
                     Valuation=valuation, 
                     Steps=ceil(intlib::Simplify::defaultValuation(t)/20));
           end_proc;
  seen := {}; // handled these expressions already
  i := 1;
  repeat
    i := i+1;
    if i > 5 then
      return([FAIL, FAIL, FAIL]); 
    end_if;
    Dex  := map(diffs, ex -> op(transExprs(ex, x))) minus vars minus seen;
    seen := seen union Dex;
    Dex := map(Dex, t -> op(transExprs(simpl(t), x)));
    
    vars := vars union Dex;
    diffs := map(vars, diff, x);
  until Dex = {} end_repeat;
  
  vars := prog::sort([op(vars)], intlib::Simplify::defaultValuation);
  diffs := map(vars, diff, x);

  // this uses remembered value from above, so make sure
  // the arguments remain synchronized!
  diffs := map(diffs,
               t -> if transExprs(t, x) minus {op(vars)} = {} then
                      t
                    else
                      simpl(t)
                    end_if);

  ts := [`#t`.(i+n) $ i = 0..nops(vars)-1];
  
  diffs := subsex(diffs, revert(zip(vars, ts, _equal)));

  [ts, vars, diffs];
end_proc;

end_proc():
