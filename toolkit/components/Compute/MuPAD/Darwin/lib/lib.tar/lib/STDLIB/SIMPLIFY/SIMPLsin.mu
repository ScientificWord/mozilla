// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	simplify/sin -- the function attribut "sin" for simplify

 	tries combine( normal(%),sincos ).
--*/

simplify:=slot(simplify,"sin",proc(a)
name simplify::sin;
begin
   if type(a) = "_plus" then
	a:= normal( a )
   end_if;
   combine( a,hold(sincos) );
end_proc):

// end of file 
