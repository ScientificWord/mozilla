// $Date: 2002-02-23 21:54:19 +0100 (Sat, 23 Feb 2002) $ $Author: walter $ $Revision: 17574 $ 

/* These procedures were implemented by Akos Korosmezey <akos@rmki.kfki.hu>
  in September 1995, and integrated to MuPAD by P. Zimmermann.
*/

intlib::gaussian := proc(f,x) // integrates x^n*exp(-a*x^2) 
local b, b0, b1, b2, b2w, b2arg, p, ef, i;
begin
   if not has(f,x) then return(f*x) end_if;
   ef:=expand(f);
   case type(ef)
   of "_plus" do return(map(ef,intlib::gaussian,x))
   of "exp" do return(intlib::gaussian_int(0,f,x))
   of "_power" do                              
      if type(op(ef,1))="exp" then           // power of exp 
         return(intlib::gaussian_int(0,exp(op(ef,2)*op(op(ef,1),1)),x))
      else                                   // not implemented, e.g. x^n 
         return(FAIL)
      end_if;
   of "_mult" do                             // a product 
      b:=select(ef,has,x);
      b0:=ef/b;
      if type(b)="exp" then                  // const*exp() 
         b2:=b;
         b1:=1
      elif type(b)="_power" then
         if type(op(b,1))="exp" then 	     // const/exp(), etc. 
	    b2:=exp(op(b,2)*op(op(b,1),1));
	    b1:=1
         else                                // not a Gaussian 
            return(FAIL)
         end_if
      elif b=x then                          // const*x 
         b2:=1;
         b1:=x
      else                                   // otherwise this select works: 
         if type(b) <> "_mult" then
            return(FAIL);
         end_if;
         b2w:=select(b,has,exp);
         b1:=expand(b/b2w);
         case type(b2w)
         of "exp" do                         // f(x)*exp() 
            b2:=combine(b2w,exp);
            break;
         of "_power" do                      // f(x)/exp(), etc. 
            if type(op(b2w,1))="exp" then 
               b2:=exp(op(b2w,2)*op(op(b2w,1),1))
            else
               return(FAIL);
            end_if;
            break
	 of "_mult" do                       // f(x)*exp()*exp(), etc. 
	    b2arg:=0;
	    i:=1;
	    while op(b2w,i)<>FAIL do             // combine arguments 
               b:=op(b2w,i);
               if type(b)="exp" then             // exp() 
                  b2arg:=b2arg+op(b,1)
	       elif type(b)="_power" and type(op(b,1))="exp" then
                  b2arg:=b2arg+op(b,2)*op(op(b,1),1) // power of exp's 
	       else                              // not implemented 
	          return(FAIL);
               end_if;
               i:=i+1
            end_while;
            b2:=exp(b2arg);
            break
         otherwise                           // not implemented 
            return(FAIL)
         end_case
      end_if;                                // call gaussian_int 
      if b1=1 then                                     // f(x)=1   
         return(b0*intlib::gaussian_int(0,b2,x))
      elif b1=x then                                   // f(x)=x   
         return(b0*intlib::gaussian_int(1,b2,x))
      elif type(b1)="_power" and op(b1,1)=x then       // f(x)=x^n 
         p:=op(b1,2);
	 return(b0*intlib::gaussian_int(p,b2,x))
      else                                   // other f(x): not implemented 
         return(FAIL);
      end_if
   end_case;
   FAIL
end_proc:

/* interface to gaussian_part. Here e is an exponential,
  gaussian_int determines the coefficients c0, c1, c2 for
  gaussian_part */
intlib::gaussian_int :=
proc(p,e,x) // interface to gaussian_part 
  local a, c0, c1, c2;
  save __c_gauss1,__c_gauss2;
begin
   delete __c_gauss1,__c_gauss2;                       
   if type(p)<>DOM_INT then return(FAIL) end_if;
   if type(e)<>"exp" then return(FAIL) else
      a:=op(e,1);
      if not testtype(a,Type::PolyExpr(x)) then
         if intlib::matchassign(a,-_pattern(__c_gauss1,Type::IndepOf(x))*x^2
		-_pattern(__c_gauss2,Type::IndepOf(x))/x^2) then
           c1:=__c_gauss1; c2:=__c_gauss2;
           if c1<>0 then
             return(PI^(1/2)/4*(exp(2*(c1*c2)^(1/2))*erf(c1^(1/2)*x+c2^(1/2)/x)
		+exp(-2*(c1*c2)^(1/2))*erf(c1^(1/2)*x-c2^(1/2)/x))/c1^(1/2))
           else return(FAIL)
           end_if;
         else return(FAIL)
         end_if
      end_if;
      case degree(a,[x])
         of 0 do return(x^(p-1)/p*e,x)      // x^p*exp(const);         
         of 1 do return(FAIL)               // x^p*exp(const*x)        
               // needs to be fixed for x^(n+1/2)*exp(a*x) 
         of 2 do                            // x^p*exp(c2*x^2+c1*x+c0) 
            c2:=coeff(a,[x],x,2);
            c1:=coeff(a,[x],x,1);
	    c0:=coeff(a,[x],x,0);
         return(intlib::gaussian_part(p,c0,c1,c2,x))
      end_case
   end_if;
   FAIL    // too complicated: (Bessel func. could be implemented!) 
end_proc:

/* carries out the integral int(x^p*exp(c0+c1*x+c2*x^2),x)
  by integration by parts */
intlib::gaussian_part := proc(p,c0,c1,c2,x) // partial integration 
begin
   if p=-1 then
      if c1=0 then -1/2*exp(c0)*Ei(-c2*x^2) else FAIL end_if
   elif p<0 then FAIL
   elif p=0 then 
      1/2*PI^(1/2)/(-c2)^(1/2)*exp(c0-c1^2/(4*c2))
         *erf((-c2)^(1/2)*(x+c1/(2*c2)))
   elif p=1 then 
      1/(2*c2)*exp(c2*x^2+c1*x+c0)
         -c1/(2*c2)*intlib::gaussian_part(0,c0,c1,c2,x)
   else 
      1/(2*c2)*x^(p-1)*exp(c2*x^2+c1*x+c0)
         -c1/(2*c2)*intlib::gaussian_part(p-1,c0,c1,c2,x)
         -(p-1)/(2*c2)*intlib::gaussian_part(p-2,c0,c1,c2,x)
   end_if
end_proc:

