// $Date: 2005-09-01 13:47:04 +0200 (Thu, 01 Sep 2005) $ $Author: stefanw $ $Revision: 33288 $

/* solvelib::substituteBySet(a, x, S)

   given an object a that is not a set and contains the variable x,
   return the set of all objects that can be
   obtained by substituting some element of S for x

*/


solvelib::substituteBySet:=
proc(a, x, S)
  local newidents;
begin
  if args(0)<>3 then
    error("Wrong number of arguments")
  end_if;
  

  if type(x) = DOM_LIST then
    return(solvelib::substituteByVectorSet(a, x, S))
  end_if;


  if S::dom::substituteBySet <> FAIL then
    return(S::dom::substituteBySet(args()))
  end_if;
  
  if domtype(x) <> DOM_IDENT then
    error("Second argument must be identifier")
  end_if;
  
  case domtype(S)
    of DOM_INT do
    of DOM_RAT do
    of DOM_COMPLEX do
      return(a)
    of DOM_SET do
      return(map(S, proc(u)
                      local c;
                      begin
                      traperror((c:= eval(subs(a, x=u))));
                      if %<>0 then
                        null()
                      else
                        c
                      end_if
                      end_proc))
    of DOM_EXPR do
      case type(S)
        of "solve" do
        of "_minus" do
        of "_intersect" do  
        of "discont" do
          break
        of solvelib::cartesianPower do
          if op(S, 2) <> 1 then
            error("Vector-valued variables are not allowed")
          end_if;
          //identify S^1 = S
          return(solvelib::substituteBySet(a, x, op(S, 1)))
        otherwise
          return(eval(map(S, u-> solvelib::substituteBySet(a, x, u))))
      end_case;
      break
  end_case;

  if not has(a, x) then
    {a}
  else
    newidents:= genident();
    if domtype(a) = DOM_LIST then
      solvelib::VectorImageSet( subs(a, x = newidents), newidents, S)
    else  
      Dom::ImageSet(subs(a, x = newidents), newidents, S)
    end_if
  end_if
end_proc:


/*
    solvelib::substituteByVectorSet(a, v, S)

    a - expression
    v = [v1, ..., vn] - list of variables
    S - n-dimensional set

    returns the set {a | v1=x1, .., vn=xn;  [x1, .., xn] \in S }
    of all objects that can be obtained from a and some [x1, .., xn] in S
    by substitution vi=xi

*/
solvelib::substituteByVectorSet:=
proc(a, v: DOM_LIST, S: Type::Set)
  local substituteVector: DOM_PROC;
begin
  if nops(v) = 0 then
    return(a)
  end_if;
  
  if a = matrix(v) then
    return(S)
  end_if;
  
  if S::dom::substituteBySet <> FAIL then
    return(S::dom::substituteBySet(args()))
  end_if;
  
  if nops(v) = 1 then
    return(solvelib::substituteBySet(a, op(v, 1),
                                     solvelib::vectorSetToNumberSet(S)))
  end_if;
  
  // substituteVector(a, x)
  // substitute v1=x1, v2=x2, ... in a
  // where v=[v1, ..., vn] and x=[x1, .., xn]
  substituteVector:=
  proc(x: matrix)
    local i;
  begin
    if testargs() then
      if nops(v) <> nops(x) then
        error("Dimensions do not match")
      end_if;
    end_if;
    a | (v[i] = x[i] $i=1..nops(v))
  end_proc;
  
  case type(S)
    of "_union" do
      return(map(S, s -> solvelib::substituteByVectorSet(a, v, s)))
    of DOM_SET do
      return(map(S, substituteVector))
  end_case;
  // default
  hold(solvelib::substituteBySet)(a, v, S)
end_proc:

solvelib::substituteBySet:= funcenv(solvelib::substituteBySet):
solvelib::substituteBySet::type:= "substituteBySet":