
/* The simplify attribute of coth

   Rules:
   1) coth(x)            -> apply simplify and stdlib::normalizesign to x
   2) coth(x + k*PI*I/2) -> (-1)^k * coth/tanh (x + frac(k)*PI*I/2)
                            if domtype(k) = DOM_RAT
   3) coth(x + k*PI*I/2) -> (-1)^k * coth/tanh (x) if is(k, Type::Residue(?,2))
   4) coth(x)            -> -coth(-x) if stdlib::hasmsign(x) = TRUE

Author: Juergen Gerhard, 14.4.00
*/

coth := slot(coth, "simplify", proc(a)
   name coth::simplify;
   local x, l, i, e, rest, integer_expo, prop, tmp, sgn;
begin
   // recursively simplify the argument
   /* the double simplify is a workaround for the following simplify bug:
      simplify((x+y)^2) -> (x+y)^2, but
      simplify(-(x+y)^2) -> x^2+2*x*y+y^2 */
   x := simplify(-simplify(-op(a)));
   x := _mult(op(stdlib::normalizesign(x))):

   /* final integer exponent of -1 */
   integer_expo := 0;
   // finally remaining arguments
   rest := 0;

   // l := list of summands
   if type(x) = "_plus" then
     l := [op(x)]
   else
     l := [x]
   end_if;

   // l := list of pairs [summand, summand*2/I/PI]
   l := map(l, proc(x) begin [x, x*2/I/PI] end_proc);

   /* check whether there is a summand with domtype(summand*2/I/PI) =
      DOM_RAT or DOM_INT (there can be at most one) */
   l := split(l, proc(x) begin
     contains({DOM_RAT, DOM_INT}, domtype(op(x, 2))) end_proc);
   if nops(l[1]) > 0 then
     // reduce the rational number modulo 1
     tmp := op(l, [1,1,2]);
     rest := frac(tmp)*I*PI/2;
     integer_expo := floor(tmp) mod 2;
   end_if;

   // select those summands with is(summand*2/I/PI, Type::Integer) = TRUE
   l := split(l[2], proc(x) begin is(op(x, 2), Type::Integer) end_proc);

   // rest := unsimplified arguments
   rest := _plus(op(map(l[2].l[3], op, 1)), rest);
 
   // process arguments of Type::Integer
   l := l[1];
   for i from 1 to nops(l) do
     e := op(l, [i, 2]);

     // simplify exponents that are known to be odd or even
     prop := property::_getprop(e, property::Residue);
     if type(prop) = "Residue"
        and domtype(prop::dom::modulus(prop) / 2) = DOM_INT then
       integer_expo := integer_expo + prop::dom::remainder(prop) mod 2;
     else
       rest := rest + op(l, [i, 1]);
     end_if
   end_for;

   /* extract a minus sign from rest if necessary */
   sgn := 1;
   if stdlib::hasmsign(rest) then
     rest := -rest;
     sgn := -1;
   end_if;

   if integer_expo = 0 then
     return(sgn * coth(rest))
   else // = 1
     // coth(x+I*PI/2) = tanh(x)
     return(sgn * tanh(rest))
   end_if
end_proc):
