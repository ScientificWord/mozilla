// $Date: 2005-12-02 14:23:46 +0100 (Fri, 02 Dec 2005) $ $Author: rensmann $ $Revision: 35361 $


/*

    Type::Set

    the type of set-theoretic formulas



*/

Type::Set:=
new(Type, "Set",
    proc(t, x)
      name Type::Set;
      option noDebug;
    begin
      if args(0) <> 2 then
        return(FALSE)
      end_if;

      case domtype(x)
        of stdlib::Universe do // universe is a set expression
        of DOM_SET do
        of DOM_INTERVAL do
        of RootOf do
        of solvelib::cartesianPower do  
          return(TRUE)
        of DOM_IDENT do
          return(not contains(Type::ConstantIdents, x))
        of DOM_EXPR do
          case type(x)
            of "_union" do
            of "_intersect" do
            of "_minus" do
              t:= map([op(x)], testtype, Type::Set);
              if contains(t, FALSE) > 0 then
                return(FALSE)
              elif contains(t, FAIL) > 0 then
                return(FAIL)
              else
                return(TRUE)
              end_if;
            of "evalAt" do
            of "_power" do
              return(testtype(op(x, 1), Type::Set))
	    of "_index" do
	      return(testtype(op(x, 1), Type::Set))
	      // also represents a set
            of "solve" do
            of "discont" do
            of "Union" do
            of "substituteBySet" do
            of "selectIndices" do    
              return(TRUE)
            otherwise
              return(FALSE)
          end_case
       end_case;
    
       if x::dom::hasProp(Cat::Set) = TRUE
         or x::dom::set2expr <> FAIL then
         TRUE
       else
         FALSE
       end_if

    end_proc,

    FALSE, FALSE

    ):
