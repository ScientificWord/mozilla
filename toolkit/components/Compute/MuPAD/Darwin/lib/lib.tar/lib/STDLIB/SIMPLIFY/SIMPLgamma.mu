
// simplification for expressions involving gamma
// we  just use combine
simplify::gamma:= combine::gamma:
