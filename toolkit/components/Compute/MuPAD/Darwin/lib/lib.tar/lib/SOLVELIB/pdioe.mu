solvelib::pdioe := proc(A,B,C,x)
local s,t,u,v,q,r,a,b,tmp,y,z,rest,dm,R;
begin
   if A::dom::pdioe <> FAIL then return(A::dom::pdioe(args())) end_if;
   if type(A)=DOM_POLY then 
      if {type(B),type(C)}<>{DOM_POLY} or
	op(A,2)<>op(B,2) or op(A,2)<>op(C,2) or
	nops(op(A,2))<>1 then error("invalid arguments")
      end_if;
      R:=op(A,3);
      if R=Expr then
      elif testtype(R,hold(IntMod)(Type::PosInt)) then
         if not isprime(op(R)) then
           error("coefficient domain should be a field") end_if
      elif R::hasProp(Cat::Field)<>TRUE then 
         error("coefficient domain should be a field") 
      end_if;
      a:=A; b:=B; rest:=C; dm:=op(A,2..3);
   else a:=poly(A,[x]); b:=poly(B,[x]); rest:=poly(C,[x]); dm:=[x];
   end_if;
   s:=poly(1,dm); t:=poly(0,dm); u:=t; v:=s; 
   y:=t; z:=t;
   /* loop invariant : a = s*A+t*B, b = u*A+v*B, C = y*A+z*B+rest */
   while not iszero(rest) do
      tmp:=divide(rest,a); q:=op(tmp,1); /* rest=q*a+op(tmp,2) */
      y:=y+q*s; z:=z+q*t;
      rest:=op(tmp,2);
      if iszero(rest) then break end_if;
      if iszero(b) then return(FAIL) end_if;
      tmp:=divide(a,b); q:=op(tmp,1); r:=op(tmp,2); a:=b; b:=r;
      tmp:=s; s:=u; u:=tmp-q*u;
      tmp:=t; t:=v; v:=tmp-q*v;
   end_while;
   if type(A)=DOM_POLY then y,z else expr(y),expr(z) end_if
end_proc:

/* end of file */

