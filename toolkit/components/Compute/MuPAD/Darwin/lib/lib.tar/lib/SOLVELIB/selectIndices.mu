
/*
selectIndices(S, indices)

S - a solution in vector format
indices - list of integers [i_1, ..., i_k]

applies the mapping [a_1, ..., a_n] -> [a_{i_1}, ..., a_{i_k}]



*/

solvelib::selectIndices:=
proc(S: Type::Set, indices: DOM_LIST): Type::Set
  local
  selectFromList: DOM_PROC, toFree: DOM_SET,
  i: DOM_INT, result, options: DOM_TABLE;
begin
  
  selectFromList:=
  proc(l: matrix)
    local i: DOM_INT;
  begin
    matrix([op(l, indices[i]) $i=1..nops(indices)])
  end_proc;


  case type(S)
    of piecewise do
      return(piecewise::extmap(S, solvelib::selectIndices, indices))
    of DOM_SET do
    of Dom::ImageSet do
    of solvelib::VectorImageSet do
      return(map(S, selectFromList))  
    of "_union" do
    of "_intersect" do
    of "_minus" do  
      return(map(S, solvelib::selectIndices, indices))
    of "Union" do
       return(eval(subsop(S, 1 = solvelib::selectIndices(op(S, 1), indices))))
    of "substituteBySet" do  
      return(eval(subsop(S, 1 = selectFromList(op(S, 1)))))
    of solvelib::cartesianPower do
      return(solvelib::cartesianPower(S::dom::base(S), nops(indices)))
    of "solve" do
      if type(op(S, 2)) <> DOM_LIST then
        error("solution does not represent a vector set")
      end_if;
      options:= solvelib::getOptions(op(S, 3..nops(S)));
      options["VectorFormat"]:= TRUE;
      toFree:= {$1..nops(op(S, 2))} minus {op(indices)};
      toFree:= {op(S, [2, i]) $i in toFree};
      result:= solve(op(S, 1), [op(S, [2, indices[i]]) $i=1..nops(indices)],
                     options);
      for i from 1 to nops(toFree) do
        result:= solvelib::Union(result, op(toFree, i), C_)
      end_for;
      return(result)
  end_case;

  // default
  procname(args())
end_proc:

solvelib::selectIndices:= funcenv(solvelib::selectIndices):
solvelib::selectIndices::type:= "selectIndices":