defint_patterns:=[
    [1/(x^2+1)^2, PI/8+1/4, [u=0, v=1]],
    [x^2/(x^2+1)^2, PI/8-1/4, [u=0, v=1]],

   // [1/(a*x+b), ln(1+a/b)/a, [u=0, v=1, a>0, b>0]],
   // [1/(x^2+a), (ln(sqrt(-a)-1)-ln(sqrt(-a)+1))/2/sqrt(-a), [u=0, v=1, a<-1]],

    [1/(a*x^2+b), arctan(sqrt(a/b))/sqrt(a*b), [u=0, v=1, a>0, b>0]],
    [x/(a*x^2+b), ln(1+a/b)/2/a, [u=0, v=1, a>0, b>0]],

    [1/(a+x)/(b+x^2), PI*a/2/sqrt(b)/(a^2+b)+ln(sqrt(b)/a)/(a^2+b), [u=0, v=infinity, a>0, b>0]],
    [1/(a+x^2)/(b+x^2)/(c+x^2), PI/2/sqrt(c)/(a-b)*(1/(b+sqrt(b)*sqrt(c))-1/a*(sqrt(a)*sqrt(c))), [u=0, v=infinity]],
    [x^2/(a+x^2)/(b+x^2)/(c+x^2), PI/2/(sqrt(a)+sqrt(b))/(sqrt(b)+sqrt(c))/(sqrt(c)+sqrt(a)), [u=0, v=infinity]],

    [1/sqrt(a+b*x^2), ln(sqrt(1+b/a)+sqrt(b/a))/sqrt(b), [u=0, v=1, a>0, b>0]],
    [x/sqrt(a+b*x^2), ln(sqrt(a+b)-sqrt(a))/b, [u=0, v=1, a>0, a+b>0]],
    [1/sqrt(x^2-1)/(a+b*x), 2/sqrt(a^2-b^2)*arctan(sqrt((a-b)/(a+b))), [u=1, v=infinity, b>0, a>b]],

    [(1-x^a)^b, PI/a/sin(PI/a), [u=0, v=1, a>1, a*b=-1]],

    [sqrt(a+b*x^2), sqrt(a+b)/2 + (ln(sqrt(a+b)+sqrt(b)) - ln(a)/2)*a/2/sqrt(b), [u=0, v=1, a>0, b>0]],

    // Dwight, Tables of integrals and other mathematical data
    [x^a*(1-x^b)^c, beta(c+1,(a+1)/b)/b, [u=0, v=1, Re(a)>-1, b>0, Re(c)>-1]], // 855.42

    [x^a/(b+x), PI*b^a/sin((a+1)*PI), [u=0, v=infinity, Re(a)<0, Re(a)>-1, not b<=0]],  // 856.04
    [1/(1+x^a), PI/a/sin(PI/a), [u=0, v=infinity, Re(a)>1]], // 856.05
    [x^a*(1+x)^b, beta(a+1,-1-a-b), [u=0, v=infinity, Re(a)>-1, Re(a+b)<-1]],  // 856.11
    [1/(x^2+a)/(x^2+b), PI/2/(a*sqrt(b)+b*sqrt(a)), [u=0, v=infinity, not a<=0, not b<=0]], // 856.31

    [sqrt(1-x)/(a*x-1), -2/a*(1-sqrt((1-a)/a)*arctan(sqrt(a/(1-a)))), [u=0, v=1, a>0, a<1]],
    [1/sqrt(1-x)/(a*x-1), -2/sqrt(a*(1-a))*arctan(a/(1-a)), [u=0, v=1, a>0, a<1]],

    [(-ln(x))^a, gamma(a+1), [u=0, v=1, Re(a)>-1]], // 863.01
    [x^a*ln(x), -1/(a+1)^2, [u=0, v=1, Re(a)>-1]],  // 863.02
    [ln(x)/(x^2-1), PI^2/8, [u=0, v=1]], // 863.31
    [x*ln(x)/(x^2-1), PI^2/24, [u=0, v=1]], // 863.32
    [x^2*ln(x)/(x^2-1), PI^2/8-1, [u=0, v=1]],  // 863.33
    [ln(x)/(x^2+1), -CATALAN, [u=0, v=1]],  // 863.34
    [ln(x)/(x^2+1)^2, -ln(2), [u=0, v=1]],  // 863.35
    [ln(x)/sqrt(1-x^2), -PI/2*ln(2), [u=0, v=1]], // 863.41
    [x*ln(x)/sqrt(1-x^2), ln(2)-1, [u=0, v=1]], // 863.42
    [x^2*ln(x)/sqrt(1-x^2), PI/8*(1-2*ln(2)), [u=0, v=1]],
    [ln(x)*sqrt(1-x^2), -PI/4*(ln(2)+1/2), [u=0, v=1]], // 863.43
    [(1-x^a)*(1-x^b)/ln(x), ln((a+b+1)/(a+1)/(b+1)), [u=0, v=1, a>-1, b>-1, a+b>-1]], // 863.54
    [x^n*ln(1-x), blockTransparent(-Sum::sum_fn(i -> 1/i, 1..(n+1))/(n+1)), [u=0, v=1]], // 863.73
    [ln(1-x)/(1+x^2), PI/8*ln(2)-CATALAN, [u=0, v=1]],  // 864.01
    [ln(1+x)/(1+x^2), PI/8*ln(2), [u=0, v=1]],  // 864.02
    [arctanh(x)/(1+x^2), CATALAN/2, [u=0, v=1]],
    [ln(1+x^2)/(1+x^2), PI/2*ln(2)-CATALAN, [u=0, v=1]],  // 864.04
    [ln(1-x^a)/x, -PI^2/6/a, [u=0, v=1, Re(a)>0]],  // 864.21
    [ln(1+x^a)/x, PI^2/12/a, [u=0, v=1, Re(a)>0]],  // 864.22
    [arctanh(x^a)/x, PI^2/8/a, [u=0, v=1, Re(a)>0]],
    [ln(1-x)/sqrt(1-x^2), -2*CATALAN-PI/2*ln(2), [u=0, v=1]], // 864.31
    [ln(1+x)/sqrt(1-x^2), 2*CATALAN-PI/2*ln(2), [u=0, v=1]],  // 864.32
    [arctanh(x)/sqrt(1-x^2), 2*CATALAN, [u=0, v=1]],
    [ln(x)/(x^2-1), PI^2/4, [u=0, v=infinity]],  // 864.53
    [ln(x)/(x^2+a), PI/4/sqrt(a)*ln(a), [u=0, v=infinity, a>0]], // 864.54
    [ln(1+x)/(1+x^2), PI/4*ln(2)+CATALAN, [u=0, v=infinity]],  // 864.61

    [ln(1+exp(-x)), PI^2/12, [u=0, v=infinity]],  // 865.81
    [ln(1-exp(-x)), PI^2/6, [u=0, v=infinity]], // 865.82

    [ln(x)*exp(a*x), (ln(-a)+EULER)/a, [u=0, v=infinity, Re(a)<0]], // 865.901
    [ln(x)/exp(a*x), -(ln(a)+EULER)/a, [u=0, v=infinity, Re(a)>0]],
    [x*ln(x)*exp(a*x), -(ln(-a)-1+EULER)/a^2, [u=0, v=infinity, Re(a)<0]], // 865.902
    [x*ln(x)/exp(a*x), -(ln(a)-1+EULER)/a^2, [u=0, v=infinity, Re(a)>0]],
    [x^2*ln(x)*exp(a*x), (ln(-a)-3/2+EULER)*2/a^3, [u=0, v=infinity, Re(a)<0]], // 865.903
    [x^2*ln(x)/exp(a*x), -(ln(a)-3/2+EULER)*2/a^3, [u=0, v=infinity, Re(a)>0]],
    [ln(x)*exp(a*x)/sqrt(x), sqrt(-PI/a)*(ln(-a)+ln(4)+EULER), [u=0, v=infinity, Re(a)<0]], // 865.904
    [ln(x)/exp(a*x)/sqrt(x), sqrt(PI/a)*(ln(a)+ln(4)+EULER), [u=0, v=infinity, Re(a)>0]], 
  
    // Gr�bner & Hofreiter, Integraltafel, 2. Teil
    [1/(a*x^2+b*x+c), (arctan((a+b/2)/sqrt(a*c-b^2/4))-arctan(b/sqrt(4*a*c-b^2)))/sqrt(a*c-b^2/4), [u=0, v=1, 4*a*c>b^2]], // 131.2a
    [1/(a+b*sqrt(x)), 2/b-2*a/b^2*ln(1+b/a), [u=0, v=1, a*(a+b)>0]],  // 211.1b
    [1/(a*x^2+b*x+c)/sqrt(x), PI/sqrt(2*c*(sqrt(a*c)+b)), [a>0, b>0, a*c>b^2, u=0, v=infinity]],  // 211.6a
    [1/(a*x^2+b*x+c)*sqrt(x), PI/sqrt(2*a*(sqrt(a*c)+b)), [a>0, b>0, a*c>b^2, u=0, v=infinity]],  // 211.6b
    [1/(a*x+b)/sqrt(x), PI/sqrt(a*b), [u=0, v=infinity, a>0, b>0]],  // 211.7
    [(-(x+c)*(x+d))^a, (v-u)^(2*a+1)/(2*a+1)!*gamma(a+1)^2, [c=-u, d=-v, blockTransparent(2*a in Dom::Integer)]], // 212.3
    [1/sqrt(x^2+a), ln(1+sqrt(2)), [u=0, v^2=a]], // 214.1b
    [x/sqrt(x^2+a), v*(sqrt(2)-1), [u=0, v^2=a]], // 214.1c
    [x^2/sqrt(x^2+a), v^2/2*(sqrt(2)-ln(1+sqrt(2))), [u=0, v^2=a]], // 214.1d
    [1/x/sqrt(x^2+a), PI/2/a, [u>0, v=infinity, a=-u^2]], // 215.2c
    [1/sqrt(a-x^2)/(x^2+c), PI/2/sqrt(c)/sqrt(c+a), [u=0, v^2=a, a>0, c>0]], // 216.8a
    [x/sqrt(a-x^2)/(x^2+c), 1/sqrt(a+c)*ln((sqrt(a)+sqrt(a+c))/sqrt(c)), [u=0, v^2=a, a>0, c>0]], // 216.8b
    [1/sqrt(a-x^2)/(x^2+c), -PI/2/sqrt(-c)/sqrt(-c-a), [u=0, v^2=a, a>0, -c>a]], // 216.9a
    [x/sqrt(a-x^2)/(x^2+c), -arcsin(sqrt(-a/c))/sqrt(-a-c), [u=0, v^2=a, a>0, -c>a]],  // 216.9b

    [x^n/(exp(a*x)-1), abs(bernoulli(n+1))/2/(n+1)*(2*PI/a)^(n+1), [u=0, v=infinity, a>0, n mod 2=1]],  // 313.9a
    [x^n/(exp(a*x)+1), (2^n-1)/(n+1)*abs(bernoulli(n+1))*(PI/a)^(n+1), [u=0, v=infinity, a>0, n mod 2=1]],  // 313.10a
    [x^a*exp(x^2)^b, gamma((a+1)/2)/(-b)^((a+1)/2)/2, [u=0, v=infinity, a>-1, b<0]],  // 314.2

    [ln(a*x^2+b)/(c*x^2+d), PI/sqrt(c*d)*ln((sqrt(a*d)+sqrt(b*c))/sqrt(c)), [u=0, v=infinity, a>0, b>0, c>0, d>0]],  // 325.18
    [ln(1+a*x^2)/sqrt(1-x^2), PI*ln((1+sqrt(1+a))/2), [u=0, v=1, a>=-1]], // 325.21b
 
    [ln(a*x), ln(a)-1, [u=0, v=1, a>0]],

    [arcsin(x), PI/2-1, [u=0, v=1]],
    [arccos(x), 1, [u=0, v=1]],

/// highly suspect,
/// inconsistent with numerical integration
/// and with Maple and Mathematica
///    [tan(x+a*I), PI*I, [u=0, v=infinity, Re(a)>0]],

    [arccot(x)^2, PI*ln(2), [u=0, v=infinity]],

    [x^a*ln(x)^b, gamma(b+1)/(-a-1)^(b+1), [u=1, v=infinity, a<-1, b>-1]],

    // Bronstein, Taschenbuch der Mathematik (1.1.3.4)
    [x^a*exp(b*x^2), gamma((a+1)/2)/2/(-b)^((a+1)/2), [Re(a)>-1, Re(b)<0, u=0, v=infinity]],
    [x^a/exp(b*x^2), gamma((a+1)/2)/2/b^((a+1)/2), [Re(a)>-1, Re(b)>0, u=0, v=infinity]],

    [cos(a*x)*exp(b*x^2), sqrt(-PI/b)/2*exp(a^2/4/b), [b<0, u=0, v=infinity]],
    [cos(a*x)/exp(b*x^2), sqrt(PI/b)/2*exp(-a^2/4/b), [b>0, u=0, v=infinity]],

    [sin(x)*exp(a*x)/x, arccot(-a), [a<0, u=0, v=infinity]],
    [sin(x)/exp(a*x)/x, arccot(a), [a>0, u=0, v=infinity]],

    // Gradshteyn, 3.311
    [exp(p*x)/(1+exp(-x)), (psi((1-p)/2)-psi(-p/2))/2,
     [u=0, v=infinity, Re(p)<0]],
    [exp(p*x)/(1+exp(q*x)), PI/q*csc(p/q*PI),
     [u=-infinity, v=infinity, q>p, p>0]],
    [exp(p*x)/(1+exp(q*x)), -PI/q*csc(p/q*PI),
     [u=-infinity, v=infinity, q<p, p<0]],
    [exp(p*x)/(1+a*exp(q*x)), 
      blockTransparent(Sum::sum_fn(k -> (-a)^k/(-p-k*q), 0..infinity)),
     [u=0, v=infinity, -1<a, a<0]],

    // Gradshteyn, 3.611
    [(1-cos(x))^n*sin(n*x), 0, [u=0, v=2*PI]],
    [(1-cos(x))^n*cos(n*x), (-1)^n*PI/(2^(n-1)), [u=0, v=2*PI]],

    // 3.613
    [cos(n0*x)/(1+a*cos(x)), (PI/sqrt(1-a^2))*((sqrt(1-a^2)-1)/a)^abs(n0), 
      [u=0, v=PI, not a<=-1, not a>=1]],
    [cos(n0*x)/(1+a*cos(x)+b), PI*(-a/2)^abs(n0)/(1-b),
      [u=0, v=PI, not a<=-2, not a>=2, b=a^2/4]],
    [cos(n0*x)/(1+a*cos(x)+b), PI/((b-1)*(-a/2)^abs(n0)),
      [u=0, v=PI, a<=-2 or a>=2, b=a^2/4]],
    [sin(n*x)*sin(x)/(1+a*cos(x)+b),
      (PI/2)*(-a/2)^(n-1),
      [u=0, v=PI, not a<=-2, not a>=2, b=a^2/4]],
    [sin(n0*x)*sin(x)/(1+a*cos(x)+b),
      sign(n0)*PI/(2*(-a/2)^(abs(n0)-1)),
      [u=0, v=PI, a<=-2 or a>=2, b=a^2/4]],
    [cos(n0*x)*cos(x)/(1+a*cos(x)+b),
      (PI/2)*((1+b)/(1-b))*(-a/2)^(abs(n0)-1),
      [u=0, v=PI, not a<=-2, not a>=2, b=a^2/4]],
    [cos(n0*x)*cos(x)/(1+a*cos(x)+b),
      PI/(2*(-a/2)^(abs(n0)-1))*((1+b)/(b-1)),
      [u=0, v=PI, a<=-2 or a>=2, b=a^2/4]],
    [cos(n0*x)*cos(x)/(1+a*cos(x)+b),
      PI*(-a/2)/(1-b),
      [u=0, v=PI, not a<=-2, not a>=2, b=a^2/4, n0<>0]],
    [cos(n0*x)*cos(x)/(1+a*cos(x)+b),
      PI/((-a/2)*(1-b)),
      [u=0, v=PI, a<=-2 or a>=2, b=a^2/4, n0<>0]],
    [sin(n1*x)*sin(x)/(1+a*cos(2*x)+b),
      sign(n1)*(PI/2)*(-a/2)^((abs(n1)+1)/2-1)/(1-a/2),
      [u=0, v=PI, not a<=-2, not a>=2, b=a^2/4]],
    [sin(n1*x)*sin(x)/(1+a*cos(2*x)+b),
      sign(n1)*(PI/2)*1/((-a/2)^((abs(n1)+1)/2)*(1-a/2)),
      [u=0, v=PI, a<=-2 or a>=2, b=a^2/4]],
    [cos(n1*x)*cos(x)/(1+a*cos(2*x)+b),
      (PI/2)*(-a/2)^((abs(n1)+1)/2-1)/(1+a/2),
      [u=0, v=PI, not a<=-2, not a>=2, b=a^2/4]],
    [cos(n1*x)*cos(x)/(1+a*cos(2*x)+b),
      (PI/2)*1/((-a/2)^((abs(n1)+1)/2)*(1+a/2)),
      [u=0, v=PI, a<=-2 or a>=2, b=a^2/4]],
    [sin(n*x)+c*sin(n0*x)*sin(m*x)/(1+a*cos(x)+b),
      0,
      [u=0, v=PI, m<n, b=a^2/4, c=a/2, n0=n-1]],
    [sin(n*x)+c*sin(n0*x)*sin(m*x)/(1+a*cos(x)+b),
      (PI/2)*a^(m-n),
      [u=0, v=PI, m>=n, a>-2, a<2, b=a^2/4, c=a/2, n0=n+1]],
    [cos(n*x)+c*cos(n0*x)*cos(m*x)/(1+a*cos(x)+b),
      (PI/2)*(a^(abs(m)-n)-1),
      [u=0, v=PI, a>-2, a<2, b=a^2/4, c=a/2, n0=n-1]],
    [sin(n*x)+c*sin(n0*x)/(1+a*cos(x)+b), 0,
      [u=0, v=PI, a>-2, a<2, a<2, b=a^2/4, c=a/2, n0=n+1]],
    [cos(n*x)+c*cos(n0*x)/(1+a*cos(x)+b),
      PI*a^n,
      [u=0, v=PI, a>-2, a<2, b=a^2/4, c=a/2, n0=n+1]],

    // 3.615
    [cos(n2*x)/(1+a*sin(x)^2),
      (-1)^(n2/2)*PI/(2*sqrt(1+a))*((1-sqrt(1+a))/sqrt(a))^n2,
      [u=0, v=PI, 0<a, a<1]],

    // 3.616
    [(1+a*cos(x)+b)^n*cos(n*x),
      (-1)^n*PI*(-a/2)^n,
      [u=0, v=PI, b=a^2/4]],
    [sin(n*x)/(1+a*cos(2*x)+b)^m, 0,
      [u=0, v=2*PI, b=a^2/4]],

    [cos(n2*x)/(a*cos(x)^2+b*sin(x)^2)^r,
      binomial(n2,n2/2)*PI*(b-a)^(n2/2)/(2*sqrt(a*b))^(n2+1),
      [u=0, v=PI/2, a>0, b>0, r=(n2+1)/2]],

    // 3.624
    [sin(x)^p/(cos(x)^q), 1/(p+1),
      [u=0, v=PI/4, p>-1, q=p+2]],
//    [sin(x)^p/cos(x)^q,
//      (1/2)*gamma(p/2)*gamma(3/2-p)/gamma(3/2-p/2) 
//      [u=0, v=PI/2, 0<Re(p)<3/2, q=2*p]],

    // 3.631
    [sin(x)^q*sin(p*x),
      (1/(1-p))*cos(p*PI/2)/2,
      [u=0, v=PI/2, Re(p)>1, q=p-2]],
    [sin(x)^p*sin(p*x),
      2^(-p)*PI*sin(p*PI/2),
      [u=0, v=PI, Re(p)>-1]],
    [sin(x)^n*sin(m2*x), 0,
      [u=0, v=PI]],
    [sin(x)^(n1)*sin(m1*x),
      (-1)^((m1-1)/2)*PI/2^n1*binomial(n1,(n1-m1)/2),
      [u=0, v=PI, n1>=m1]],
    [sin(x)^n1*sin(m1*x), 0,
      [u=0, v=PI, n1 < m1]],
    [sin(x)^n1*sin(m1*x),
      2*(-1)^((m1-1)/2)*PI/2^n1*binomial(n1,(n1-m1)/2),
      [u=0, v=PI/2, n1 >= m1]],
    [sin(x)^n1*sin(m1*x), 0,
      [u=0, v=PI/2, n1 < m1]],
    [sin(x)^n*cos(m1*x), 0,
      [u=0, v=PI]],

    [sin(x)^q*cos(p*x),
      sin(p*PI/2)/(p-1),
      [u=0, v=PI/2, Re(p)>1, q=p-2]],
    [sin(x)^p*cos(p*x),
      PI*cos(p*PI/2)/2^p,
      [u=0, v=PI, Re(p)>-1]],
    [sin(x)^n2*cos(m2*x),
      (-1)^(m2/2)*PI/2^n2*binomial(n2,(n2-m2)/2),
      [u=0, v=PI, n2>=m2]],
    [sin(x)^n2*cos(m2*x),
      (-1)^(m2/2)*PI/2^n2*binomial(n2,(n2-m2)/2)/2,
      [u=0, v=PI/2, n2>=m2]],
      
    [sin(x)^(n2)*cos(m2*x), 0,
      [u=0, v=PI, n2 < m2]],
    [sin(x)^(n2)*cos(m2*x), 0,
      [u=0, v=PI/2, n2 < m2]],

    [cos(x)^q*sin(p*x), 1/(p-1),
      [u=0, v=PI/2, Re(p)>1, q=p-2]],

    [cos(x)^n*sin(n*x),
      (1/2^(n+1))*sum(2^k/k,k=1..n),
      [u=0, v=PI/2]],

    [cos(x)^q*cos(p*x), 0,
      [u=0, v=PI/2, Re(p)>1, q=p-2]],
    [cos(x)^n*cos(n*x), PI/2^(n+1),
      [u=0, v=PI/2]],

    // 3.632
    [sin(x)^q*cos(a*(PI/2-x)),
      2^q*gamma((q+1-a)/2)*gamma((q+1+a)/2)*gamma(q+1)/
      (gamma(q+1-a)*gamma(q+1+a)),
      [u=0, v=PI, (q+1)^2<a^2]],
    [cos(x)^n*sin(n*x)*sin(m2*x),
      PI/2^(n+2)*binomial(n,m2/2),
      [u=0, v=PI/2]],
    [cos(x)^n*cos(n*x)*cos(m2*x),
      PI/2^(n+2)*binomial(n,m2/2),
      [u=0, v=PI/2]],
    [cos(x)^n*cos(n0*x)*cos(m2*x),
      PI/2^n0*binomial(n,m2/2-1),
      [u=0, v=PI/2, n+1>m2/2-1, n0=n+2]],
    [cos(x)^r*sin(p*x)*sin(q*x),
      (PI/2^(p+q+2))*sum(binomial(p,k)*binomial(q,k),k=1..infinity),
      [u=0, v=PI/2, p+q>-1, r=p+q]],

    // 3.634
    [cos(x)^q*sin(p*x)*cos(n*x)*sin(x),
      (PI/2^(p+n))*gamma(p+n-1)/((n-1)!*gamma(p)),
      [u=0, v=PI/2, p>-n-1, q=p+n-2]],

    // 3.635
    [cos(x)^q*sin(p*x)*tan(x),
      p*PI*gamma(q)/(2^(q+1)*gamma((q-p)/2+1)*gamma((q+p)/2+1)),
      [u=0, v=PI/2, q>0]],
    [cos(x)^n*sin(m*x)*cot(x), PI/2,
      [u=0, v=PI/2, m=n+2]],

    // 3.636
    [tan(x)^p/cos(x),
      gamma(p/2+1/2)*gamma(-p/2)/(2*sqrt(p/2)),
      [u=0, v=PI/2, -1<Re(p)<2]],
    [cot(x)^p/sin(x),
      gamma(p/2+1/2)*gamma(-p/2)/(2*sqrt(p/2)),
      [u=0, v=PI/2, -1<Re(p)<2]],

    // 3.638
    [sin(x)^p/(cos(2*x)^q*cos(x)),
      PI*sec(p/2*PI)/2,
      [u=0, v=PI/4, abs(Re(p))<1, q=p/2+1/2]],
    [sin(2*x)^q/(cos(2*x)^p*cos(x)),
      2*gamma(p+1/2)*gamma(1-p)*sin((2*p-1)*PI/4)/(sqrt(PI)*(2*p-1)),
      [u=0, v=PI/4, -1/2<Re(p)<1, q=p-1/2]],
    [cos(x)^q*sin(p*x)/sin(x), PI/2,
      [u=0, v=PI/2, p>0, q=p-1]],

    // Gradshteyn, pp. 408-419
    [sin(a*x^2), (1/2)*sqrt(PI/(2*a)),
      [u=0, v=infinity, a>0]],
    [sin(a*x^2)*cos(b*x),
      1/2*sqrt(PI/a)*cos(b^2/4/a+PI/4),
      [u=0, v=infinity, a>0, b>0]],
    [cos(a*x^2)*cos(b*x),
      1/2*sqrt(PI/(2*a))*(cos(b^2/4/a)+sin(b^2/4/a)),
      [u=0, v=infinity, a>0, b>0]],
    // 3.691
    [(cos(a*x)+sin(a*x))*sin(b*x^2),
      1/(2*sqrt(b))*sqrt(PI/2)*((1+2*fresnelC(sqrt(2/PI)*a/(2*sqrt(b))))*
      sin(a^2/(4*b))+(1-2*fresnelS(sqrt(2/PI)*a/(2*sqrt(b))))*cos(a^2/(4*b))),
      [u=0, v=infinity, a>0, b>0]],
    [(cos(a*x)+sin(a*x))*cos(b*x^2),
      (1/(2*sqrt(b)))*sqrt(PI/2)*((1+2*fresnelC(sqrt(2/PI)*a/(2*sqrt(b))))*
       cos(a^2/(4*b))+(1-2*fresnelS(sqrt(2/PI)*a/(2*sqrt(b))))*sin(a^2/(4*b))),
      [u=0, v=infinity, a>0, b>0]],

    [sin(a*x^2)*sin(b*x)*sin(c*x),
      sqrt(PI)*sin(b*c/2/a)*cos((b^2+c^2)/4/a-PI/4)/(2*sqrt(a)),
      [u=0, v=infinity, a>0, b>0, c>0]],
    [sin(a*x^2)*cos(b*x)*cos(c*x),
      sqrt(PI)*cos(b*c/2/a)*cos((b^2+c^2)/4/a+PI/4)/(2*sqrt(a)),
      [u=0, v=infinity, a>0, b>0, c>0]],
    [cos(a*x^2)*sin(b*x)*sin(c*x),
      sqrt(PI)*sin(b*c/2/a)*sin((b^2+c^2)/4/a-PI/4)/(2*sqrt(a)),
      [u=0, v=infinity, a>0, b>0, c>0]],
    [sin(a*x^2)*cos(b*x^2),
      (1/4)*sqrt(PI/2)*(1/sqrt(a+b)+1/sqrt(a-b)),
      [u=0, v=infinity, a>b, b>0]],
    [sin(a*x^2)*cos(b*x^2),
      (1/4)*sqrt(PI/2)*(1/sqrt(a+b)-1/sqrt(b-a)),
      [u=0, v=infinity, b>a, a>0]],
    [sin(a*x^2)^2-sin(b*x^2)^2,
      (1/8)*(sqrt(PI/b)-sqrt(PI/a)),
      [u=0,v=infinity,a>0,b>0]],
    [cos(a*x^2)^2-sin(b*x^2)^2,
      (1/8)*(sqrt(PI/b)+sqrt(PI/a)),
      [u=0, v=infinity, a>0, b>0]],
    [cos(a*x^2)^2-cos(b*x^2)^2,
      (1/8)*(sqrt(PI/a)-sqrt(PI/b)),
      [u=0, v=infinity, a>0, b>0]],
    [sin(a*x^2)^4-sin(b*x^2)^4,
      (1/64)*(8-sqrt(2))*(sqrt(PI/b)-sqrt(PI/a)),
      [u=0, v=infinity, a>0, b>0]],

    // Gradshteyn, p. 410
    [cos(a*x^2)^4-sin(b*x^2)^4,
      (1/8)*(sqrt(PI/a)+sqrt(PI/b))+
        (1/32)*(sqrt(PI/(2*a))-sqrt(PI/(2*b))),
      [u=0, v=infinity, a>0, b>0]],
    [cos(a*x^2)^4-cos(b*x^2)^4,
      (1/64)*(8+sqrt(2))*(sqrt(PI/a)-sqrt(PI/b)),
      [u=0, v=infinity, a>0,b>0]],
    [sin(a*x^2)^n2, infinity,
      [u=0, v=infinity, a<>0]],
    [cos(a*x^2)^n2, infinity,
      [u=0, v=infinity]],

    [sin(a*x^2)^n1,
      blockTransparent(Sum::sum_fn(k -> (-1)^((n1-1)/2+k)*binomial(n1,k)*
            sqrt(PI/(2*(n1-2*k)*a)), 0..(n1-1)/2)/2^n1),
      [u=0, v=infinity, a>0]],
    [cos(a*x^2)^(n1),
      blockTransparent(Sum::sum_fn(k -> binomial(n1,k)*
           sqrt(PI/(2*(n1-2*k)*a)), 0..(n1-1)/2)/2^n1),
      [u=0, v=infinity, a>0]],

    // 3.692
    [sin(a-x^2)+cos(a-x^2),
      sqrt(PI/a)*sin(a),
      [u=0, v=infinity]],
    [cos(x^2/2-PI/8)*cos(a*x),
      sqrt(PI/2)*cos(a^2/2-PI/8),
      [u=0, v=infinity, a>0]],
    [sin(a*(1-x^2))*cos(b*x),
      -(1/2)*sqrt(PI/a)*cos(a+b^2/(4*a)+PI/4),
      [u=0, v=infinity, a>0, b in R_]],
    [cos(a*(1-x^2))*cos(b*x),
      (1/2)*sqrt(PI/a)*sin(a+b^2/(4*a)+PI/4),
      [u=0, v=infinity, a>0, b in R_]],
    [sin(a*x^2+c)*cos(b*x),
      (1/2)*sqrt(PI/(2*a)),
      [u=0, v=infinity, a>0, b in R_, c=b^2/4/a]],
    [cos(a*x^2+c)*cos(b*x),
      (1/2)*sqrt(PI/(2*a)),
      [u=0, v=infinity, a>0, b in R_, c=b^2/4/a]],
    [cos(sqrt(x^2-1))-cos(sqrt(x^2+1)),
      blockTransparent(Sum::sum_fn(n -> PI/(2^(4*n+1)*
          ((2*n)!)^2*(n+1/2)), 0..infinity)),
      [u=-infinity, v=infinity]],
    
    // 3.698
    [sin(a/x^2)*sin(b*x^2),
      (1/(4*sqrt(b)))*sqrt(PI/2)*(sin(2*sqrt(a*b))-
       cos(2*sqrt(a*b))+exp(-2*sqrt(a*b))),
      [u=0, v=infinity, a>0, b>0]],
    [sin(a/x^2)*cos(b*x^2),
      (1/(4*sqrt(b)))*sqrt(PI/2)*(sin(2*sqrt(a*b))+
       cos(2*sqrt(a*b))-exp(-2*sqrt(a*b))),
      [u=0, v=infinity, a>0, b>0]],
    [cos(a/x^2)*sin(b*x^2),
      (1/(4*sqrt(b)))*sqrt(PI/2)*(sin(2*sqrt(a*b))+
       cos(2*sqrt(a*b))+exp(-2*sqrt(a*b))),
      [u=0, v=infinity, a>0, b>0]],
    [cos(a/x^2)*cos(b*x^2),
       (1/(4*sqrt(b)))*sqrt(PI/2)*(cos(2*sqrt(a*b))-
       sin(2*sqrt(a*b))+exp(-2*sqrt(a*b))),
      [u=0, v=infinity, a>0, b>0]],

    // 3.699
    [sin(a*x^2+b/x^2),
      sqrt(2*PI)*(cos(2*sqrt(a*b))+sin(2*sqrt(a*b)))/(4*sqrt(a)),
      [u=0, v=infinity, a>0, b>0]],
    [cos(a*x^2+b/x^2),
      sqrt(2*PI)*(cos(2*sqrt(a*b))-sin(2*sqrt(a*b)))/(4*sqrt(a)),
      [u=0, v=infinity, a>0, b>0]],
    [sin(a*x^2+b*x^2+c),
      sqrt(2*PI)/(4*sqrt(a)),
      [u=0, v=infinity, a>0, b>0, c=-2*sqrt(a*b)]],
    [cos(a*x^2+b*x^2+c),
      sqrt(2*PI)/(4*sqrt(a)),
      [u=0, v=infinity, a>0, b>0, c=-2*sqrt(a*b)]],
    [sin(a*x^2+b/x^2),
      (sqrt(2*PI)/(4*sqrt(a)))*exp(-2*sqrt(-a*b)),
      [a>0,b<0]],
    [cos(a*x^2+b/x^2),
      (sqrt(2*PI)/(4*sqrt(a)))*exp(-2*sqrt(-a*b)),
      [u=0, v=infinity, a>0, b<0]],

    // 3.716
    [cos(a*tan(x)), PI*exp(-a)/2,[a],
      [u=0, v=PI/2, a>=0]],
    [sin(a*tan(x))*sin(2*x), PI*a*exp(-a)/2,
      [u=0, v=PI/2, a>=0]],
    [cos(a*tan(x))*sin(x)^2, ((1-a)/4)*PI*exp(-a),
      [u=0, v=PI/2, a>=0]],
    [cos(a*tan(x))*cos(x)^2, ((1+a)/4)*PI*exp(-a),
      [u=0, v=PI/2, a>=0]],
    [sin(a*tan(x))*tan(x), PI*exp(-a)/2,
      [u=0, v=PI/2, a>0]],
    [sin(a*tan(x))*sin(x)^2*tan(x),
      ((2-a)/4)*PI*exp(-a),
      [u=0, v=PI/2, a>0]],
    [sin(a*tan(x))^2, PI*(1-exp(-2*a))/4,
      [u=0, v=PI/2, a>0]],
    [cos(a*tan(x))^2,PI*(1+exp(-2*a))/4,
      [u=0, v=PI/2, a>=0]],
    [sin(a*tan(x))^2*cot(x)^2,PI*(exp(-2*a)+2*a-1)/4,
      [u=0, v=PI/2, a>=0]],
    [sin(a*cot(x))*sin(2*x),a*PI*exp(-a)/2,
      [u=0, v=PI/2, a>=0]],

    // 3.718
    [sin(a*tan(x)+p*x)*sin(x)^q, 0,
      [u=0, v=PI/2, Re(p)<0,a>0, q=-p-2]],
    [sin(n*tan(x)+p*x)*cos(x)^q/sin(x), PI/2,
      [u=0, v=PI/2, Re(p)>0, q=p-1]],
    [cos(a*tan(x)+p*x)*cos(x)^q,
      PI*exp(-a)*a^(-p-1)/gamma(-p),
      [u=0, v=PI/2, a>0,Re(p)<-1, q=-p-2]],
    [cos(a*tan(x)+p*x)*cos(x)^p,
      2^(-p-1)*PI*exp(-a),
      [u=0, v=PI/2, a>=0, Re(p)>-1]],

    [(sin(n*x)-sin(n*x-a*tan(x)))*cos(x)^(n-1)/sin(x), PI/2,
      [u=0, v=PI/2, n=0,a>0]],
    [(sin(n*x)-sin(n*x-a*tan(x)))*cos(x)^(n-1)/sin(x), PI*(1-exp(-a)),
      [u=0, v=PI/2, n=1,a>=0]],

/* Combinations of trigonometric and rational functions */
    // 3.722
    [sin(a*x)/(x+b),
      Ci(a*b)*sin(a*b)-cos(a*b)*Si(a*b),
      [u=0, v=infinity, abs(arg(b))<PI,a>0]],
    [sin(a*x)/(x+b),
      PI*exp(I*a*b),
      [u=-infinity, v=infinity, a>0,Im(b)>0]],
    [cos(a*x)/(x+b),
      -sin(a*b)*Si(a*b)-cos(a*b)*Ci(a*b),
      [u=0, v=infinity, abs(arg(b))<PI, a>0]],
    [cos(a*x)/(x+b),
      -PI*exp(I*a*b),
      [u=-infinity, v=infinity, a>0, Im(b)>0]],
    [sin(a*x)/(-x+b),
      -PI*exp(I*a*b),
      [u=-infinity, v=infinity, a>0,Im(b)>0]],
    [cos(a*x)/(-x+b),
      -PI*exp(I*a*b),
      [u=-infinity, v=infinity, a>0,Im(b)>0]],

    // 3.723
    [sin(a*(b-x))/(c+x^2),
      PI*exp(-a*sqrt(c))*sin(a*b)/sqrt(c),
      [u=-infinity, v=infinity, a>0, b>0, c>0]],
    [cos(a*(b-x))/(c+x^2),
      PI*exp(-a*sqrt(c))*cos(a*b)/sqrt(c),
      [u=-infinity, v=infinity, a>0, b>0, c>0]],
    [sin(a*x)/(b-x^2),
      (sin(a*sqrt(b))*Ci(a*sqrt(b))-
       cos(a*sqrt(b))*(Si(a*sqrt(b))+PI/2))/sqrt(b),
      [u=0, v=infinity, a>0]],
    [cos(a*x)/(b-x^2),
      PI*sin(a*b)/(2*sqrt(b)),[a,b],
      [u=0, v=infinity, a>0, b>0]],
    [x*sin(a*x)/(b-x^2),
      -PI*cos(a*sqrt(b))/2,
      [u=0, v=infinity, a>0, b>=0]],
    [x*cos(a*x)/(b-x^2),
      cos(a*sqrt(b))*Ci(a*sqrt(b))+
      sin(a*sqrt(b))*(Si(a*sqrt(b))+PI/2),
      [u=0, v=infinity, a>0]],
    [sin(a*x)/(x*(x+b)),
      -PI*(cos(a*b)-1)/b,[a,b],
      [u=-infinity, v=infinity, a>0, b<0]],
    // 3.724
    [(b+c*x)/(p+q*x+x^2)*sin(a*x),
      PI*exp(-a*sqrt(p-q^2/4))*(((c*q/2-b)/sqrt(p-q^2/4))
      *sin(a*q/2)+c*cos(a*q/2)),
      [u=-infinity, v=infinity, a>0, p>q^2]],
    [(b+c*x)/(p+q*x+x^2)*cos(a*x),
      PI*exp(-a*sqrt(p-q^2/4))*(((b-c*q/2)/sqrt(p-q^2/4))
        *cos(a*q/2)+c*sin(a*q/2)),
      [u=-infinity, v=infinity, a>0, p>q^2]],
    [(cos(c)-x*cos(b))*cos(a*x)/(1-2*x*cos(t)+x^2),
      PI*exp(-a*sin(t))*sin(b+a*cos(t)),
      [u=-infinity, v=infinity, a>0, t^2<PI^2, c=b-t]],

    // Page 419 equation 3.725
    [sin(a*x)/(x*(b+x^2)),
      PI*(1-exp(-a*sqrt(b)))/(2*b),
      [u=0, v=infinity, a>0, abs(arg(b))<PI]],
    [sin(a*x)/(x*(b-x^2)),
      PI*(1-cos(a*sqrt(b)))/(2*b),
      [u=0, v=infinity, a>0, b>0]],
    [sin(a*x)*cos(b*x)/(x*(x^2+c)),
      PI*E^(sqrt(c)*b)*sinh(a*sqrt(c))/(2*c),
      [u=0, v=infinity, 0<a, a<b]],
    [sin(a*x)*cos(b*x)/(x*(x^2+c)),
      -PI*exp(-a*sqrt(c))*cosh(b*sqrt(c))/(2*c)+PI/(2*c),
      [u=0, v=infinity, a>b, b>0]],

    // 3.727
    [x*sin(a*x)/(b+x^4),
      PI*exp(-a*b^(1/4)/sqrt(2))*sin(a*b^(1/4)/sqrt(2))/(2*sqrt(b)),
      [u=0, v=infinity, a>0, b>0]],
    [x*sin(a*x)/(b-x^4),
      PI*(E^(-a*b^(1/4))-cos(a*b^(1/4)))/(4*sqrt(b)),
      [u=0, v=infinity, a>0, b>0]],

    /* Page 420-429
       Topic: Trig function */

    [x^2*cos(a*x)/(b+x^4),
      PI*sqrt(2)*exp(-a*b^(1/4)/sqrt(2))*(cos(a*b^(1/4)/sqrt(2))
       -sin(a*b^(1/4)/sqrt(2)))/(4*b^(1/4)),
      [u=0, v=infinity, a>0, b>0]],
    [x^2*cos(a*x)/(b-x^4),
      PI*(sin(a*b^(1/4))-exp(-a*b^(1/4)))/(4*b^(1/4)),
      [u=0, v=infinity, a>0, b>0]],
    [x^3*sin(a*x)/(b+x^4),
      (PI/2)*exp(-a*b^(1/4)/sqrt(2))*cos(a*b^(1/4)/sqrt(2)),
      [u=0, v=infinity, a>0, b>0]],
    [x^3*sin(a*x)/(b-x^4),
      (-PI/4)*(exp(-a*b^(1/4))-cos(a*b^(1/4))),
      [u=0, v=infinity, a>0, b>0]],
    [x^3*sin(a*x)/(x^2+b)^3,
      PI*exp(-a*sqrt(b))*(3*a-sqrt(b)*a^2)/(16*sqrt(b)),
      [u=0, v=infinity, b>0]],
    [x^3*sin(a*x)/(x^2+b^2)^4,
      PI*exp(-a*sqrt(b))*(3+3*a*sqrt(b)-a^2*b)/(96*b^(3/2)),
      [u=0, v=infinity, b>0]],

    // 3.728
    [x*sin(a*x)/((b+x^2)*(y+x^2)),
      PI*(exp(-a*sqrt(b))-exp(-a*sqrt(y)))/
        (2*sqrt(b)*y*(b-y)),
      [u=0, v=infinity, a>0,Re(b)>0,Re(y)>0]],

    /* Begin page 421 */
    [x^3*sin(a*x)/((b+x^2)*(y^2+x^2)),
      PI*(b*exp(-a*sqrt(b))-y^2*exp(-a*y))/(2*(b-y^2)),
      [u=0, v=infinity, a>0, abs(arg(b)) < PI, Re(y)>0]],
    [cos(a*x)/((b-x^2)*(c-x^2)),
      PI*(sqrt(b)*sin(a*sqrt(c))-sqrt(c)*sin(a*sqrt(b)))
        /(2*sqrt(b*c)*(b-c)),
      [u=0, v=infinity, a>0, b>0, c>0]],
    [x*sin(a*x)/((b-x^2)*(c-x^2)),
      PI*(cos(a*sqrt(b))-cos(a*sqrt(c)))/(2*(b-c)),
      [u=0, v=infinity, a>0, b>=0, c>=0]],
    [x^2*cos(a*x)/((b-x^2)*(c-x^2)),
      PI*(sqrt(c)*sin(a*sqrt(c))-sqrt(b)*sin(a*sqrt(b)))/
         (2*(b-c)),
      [u=0, v=infinity, a>0, b>0, c>0]],
    [x^3*sin(a*x)/((b-x^2)*(c-x^2)),
      PI*(b*cos(a*sqrt(b))-c*cos(a*sqrt(c)))/
         (2*(b-c)),
      [u=0, v=infinity, a>0, b>0, c>0]],
    [x*sin(a*x)/((b-x^2)*(c+x^2)),
      (PI/2)*(exp(-a*sqrt(c))-cos(sqrt(b)*a))/(a^2+c),
      [u=0, v=infinity, a>0, b>0, c>0]],

    // 3.729 
    [x*sin(a*x)/(b+x^2)^2,
      PI*a*exp(-a*sqrt(b))/(4*sqrt(b)),
      [u=0, v=infinity, a>0, b>0]],
    [x^3*sin(a*x)/(b+x^2)^2,
      (PI/4)*(2-a*sqrt(b))*E^(-a*sqrt(b)),
      [u=0, v=infinity, a>0, b>0]],

    // 3.372 
    [(1/(b+(y-x)^2)+1/(b+(y+x)^2))*cos(a*x),
      (PI/sqrt(b))*exp(-a*sqrt(b))*cos(a*y),
      [u=0, v=infinity, a>0,abs(Im(y))<Re(sqrt(b))]],
    [((y-x)/(b+(y-x)^2)+(y+x)/(b+(y+x)^2))*cos(a*x),
      PI*exp(-a*sqrt(b))*sin(a*y),
      [u=0, v=infinity, a>0, abs(Im(a))<Re(sqrt(b))]],

    // 3.733
    [cos(a*x)/(x^4+b*x^2*cos(t)+c),
      PI*exp(-a*sqrt(b/2)*cos(t/2))*
      sin(t/2+a*sqrt(b/2)*sin(t/2))/(2*sqrt(b/2)^3*sin(t)),
      [u=0, v=infinity, a>0, b>0, abs(t)<PI,c=b^2/4]],
    [x*sin(a*x)/(x^4+b*x^2*cos(t)+c),
      PI*exp(-a*sqrt(b/2)*cos(t/2))*sin(a*sqrt(b/2)*sin(t/2))/
        (b*sin(t)),
      [u=0, v=infinity, a>0, b>0, abs(t)<PI, c=b^2/4]],
    [x^2*cos(a*x)/(x^4+b*x^2*cos(t)+c),
      PI*exp(-a*sqrt(b/2)*cos(t/2))*
       sin(t/2-a*sqrt(b/2)*sin(t/2))/(2*sqrt(b/2)*sin(t)),
      [u=0, v=infinity, a>0, b>0, abs(t)<PI, c=b^2/4]],
    [x^3*sin(a*x)/(x^4+b*x^2*cos(t)+c),
      PI*exp(-a*sqrt(b/2)*cos(t/2))*
        sin(t-a*sqrt(b/2)*sin(t/2))/(2*sin(t)),
      [u=0, v=infinity, a>0, b>0, abs(t)<PI, c=b^2/4]],
    [sin(a*x)/(x*(x^4+b*x^2*cos(t)+b^2/4)),
      (PI/(b^2/2))*(1-exp(-a*sqrt(b/2)*cos(t/2))*
        sin(t+a*sqrt(b/2)*sin(t/2))/sin(t)),
      [u=0, v=infinity, a>0, b>0, abs(t)<PI]],
    // 3.734
    [sin(a*x)/(x*(b+x^4)),
      (PI/(2*b))*(1-exp(-a*b^(1/4)/sqrt(2))*cos(a*b^(1/4)/sqrt(2))),
      [u=0, v=infinity, a>0, b>0]],
    [sin(a*x)/(x*(b-x^4)),
      (PI/(4*b))*(2-exp(-a*b^(1/4))*cos(a*b^(1/4))),
      [u=0, v=infinity, a>0, b>0]],

    // 3.735
    [sin(a*x)/(x*(b+x^2)^2),
      (PI/(2*b^2))*(1-(2+a*sqrt(b))/2*exp(-a*sqrt(b))),
      [u=0, v=infinity, a>0, b>0]],

    // 3.736
    [cos(a*x)/((b+x^2)*(c-x^4)),
      (PI/(8*b^(5/2)))*(sin(a*sqrt(b))+
        (2+a*sqrt(b))*exp(-a*sqrt(b))),
      [u=0, v=infinity, a>0, b>0, c=b^2]],
    [x*sin(a*x)/((b+x^2)*(c-x^4)),
      (PI/(8*b^2))*((1+a*sqrt(b))*exp(-a*sqrt(b))
        -cos(a*sqrt(b))),
      [u=0, v=infinity, a>0, b>0, c=b^2]],
    [x^2*cos(a*x)/((b+x^2)*(c-x^4)),
      (PI/(8*b^(3/2)))*(sin(a*sqrt(b))
        -a*sqrt(b)*exp(-a*sqrt(b))),
      [u=0, v=infinity, a>0, b>0, c=b^2]],
    [x^3*sin(a*x)/((b+x^2)*(c-x^4)),
      (PI/(8*b))*((1-a*sqrt(b))*exp(-a*sqrt(b))
        -cos(a*sqrt(b))),
      [u=0, v=infinity, a>0, b>0, c=b^2]],
    [x^4*cos(a*x)/((b+x^2)*(c-x^4)),
      (PI/(8*sqrt(b)))*(sin(a*sqrt(b))
        +(a*sqrt(b)-2)*exp(-a*sqrt(b))),
      [u=0, v=infinity, a>0, b>0, c=b^2]],
    [x^5*sin(a*x)/((b+x^2)*(c-x^4)),
      PI/8*((-3+a*sqrt(b))*exp(-a*sqrt(b))-cos(a*sqrt(b))),
      [u=0, v=infinity, a>0, b>0, c=b^2]],
    /* begin 3.737 
    Skip 1 2 3 because MUpad can't handle it*/
    [x*sin(a*x)/(b+x^2)^3,
      PI*a*(1+a*sqrt(b))*exp(-a*sqrt(b))/(16*b^(3/2)),
      [u=0, v=infinity, a>0, b>0]],
    [x*sin(a*x)/(b+x^2)^4,
      PI*a*(3+3*a*sqrt(b)+a^2*b)*exp(-a*sqrt(b))/(95*b^(5/2)),
      [u=0, v=infinity, a>0, b>0]],

    // 3.741
    [sin(a*x)*sin(b*x)/x,
      1/4*ln(((a+b)/(a-b))^2),
      [u=0, v=infinity, a>0, b>0]],
    [sin(a*x)*cos(b*x)/x, PI/2,
      [u=0, v=infinity, a>b, b>=0]],
    [sin(a*x)*cos(b*x)/x, PI/4,
      [u=0, v=infinity, a=b, b>0]],
    [sin(a*x)*cos(b*x)/x, 0,
      [u=0, v=infinity, b>a, a>=0]],
    [sin(a*x)*sin(b*x^2)/x, a*PI/2,
      [u=0, v=infinity, 0<a, a<=b]],
    [sin(a*x)*sin(b*x^2)/x, b*PI/2,
      [u=0, v=infinity, 0<b, b<=a]],

    // 3.742
    [sin(a*x)*sin(b*x)/(c+x^2),
      PI*(exp(-abs(a-b)*sqrt(c))-exp(-abs(a+b)*sqrt(c)))/(4*sqrt(c)),
      [u=0, v=infinity, a>0, b>0, Re(sqrt(c))>0]],
    [sin(a*x)*sin(b*x)/(c+x^2),
      PI*(exp(-a*sqrt(c))*sinh(b*sqrt(c)))/(2*sqrt(c)),
      [u=0, v=infinity, c>0, a>=b, b>=0]],
    [sin(a*x)*sin(b*x)/(c+x^2),
      PI*(exp(-b*sqrt(c))*sinh(a*sqrt(c)))/(2*sqrt(c)),
      [u=0, v=infinity, c>0, b>=a, a>=0]],
    [sin(a*x)*cos(b*x)/(c+x^2),
      (exp(-a*sqrt(c))/(4*sqrt(c)))*(exp(b*sqrt(c))*Ei(sqrt(c)*(a-b))
        +exp(-b*sqrt(c))*Ei(sqrt(c)*(a+b)))
        -(exp(a*sqrt(c))/(4*sqrt(c)))*(exp(b*sqrt(c))*Ei(-sqrt(c)*(a+b))
          +exp(-b*sqrt(c))*Ei(sqrt(c)*(b-a))),
      [u=0, v=infinity, c>0]],

    [cos(a*x)*cos(b*x)/(c+x^2),
      PI*(exp(-abs(a-b)*sqrt(c))+exp(-abs(a+b)*sqrt(c)))/(4*sqrt(c)),
      [u=0, v=infinity, a>0, b>0, Re(sqrt(c))>0]],
    [cos(a*x)*cos(b*x)/(c+x^2),
      PI*(exp(-a*sqrt(c))*cosh(b*sqrt(c)))/(2*sqrt(c)),
      [u=0, v=infinity, c>0,a>=b, b>=0]],
    [cos(a*x)*cos(b*x)/(c+x^2),
      PI*(exp(-b*sqrt(c))*cosh(a*sqrt(c)))/(2*sqrt(c)),
      [u=0, v=infinity, c>0,b>=a>=0]],
    [x*sin(a*x)*cos(b*x)/(x^2+c),
      PI*exp(-a*sqrt(c))*cosh(b*sqrt(c))/2,
      [u=0, v=infinity, 0<b, b<a]],
    [x*sin(a*x)*cos(b*x)/(x^2+c),
      PI*exp(-2*a*sqrt(c))/4,
      [u=0, v=infinity, 0<b, b=a]],
    [x*sin(a*x)*cos(b*x)/(x^2+c),
      -PI*exp(-b*sqrt(c))*sinh(a*sqrt(c))/2,
      [u=0, v=infinity, 0<a, a<b]],

    [sin(a*x)*sin(b*x)/(p-x^2),
      -PI*cos(a*sqrt(p))*sin(b*sqrt(p))/(2*sqrt(p)),
      [u=0, v=infinity, a>b, b>0]],
    [sin(a*x)*sin(b*x)/(p-x^2),
      -PI*sin(2*a*sqrt(p))/(4*sqrt(p)),
      [u=0, v=infinity, a=b, b>0]],
    [sin(a*x)*sin(b*x)/(p-x^2),
      -PI*sin(a*sqrt(p))*cos(b*sqrt(p))/(2*sqrt(p)),
      [u=0, v=infinity, b>a, a>0]],

    [sin(a*x)*cos(b*x)/(p-x^2),
      -PI*cos(a*sqrt(p))*cos(b*sqrt(p))/2,
      [u=0, v=infinity, a>b>0]],
    [sin(a*x)*cos(b*x)/(p-x^2),
      -PI*cos(2*a*sqrt(p))/4,
      [u=0, v=infinity, a=b, b>0]],
    [sin(a*x)*cos(b*x)/(p-x^2),
      PI*sin(a*sqrt(p))*sin(b*sqrt(p))/2,
      [u=0, v=infinity, b>a, a>0]],

    [cos(a*x)*cos(b*x)/(p-x^2),
      PI*sin(a*sqrt(p))*cos(b*sqrt(p))/(2*sqrt(p)),
      [u=0, v=infinity, a>b, b>0]],
    [cos(a*x)*cos(b*x)/(p-x^2),
      PI*sin(2*a*sqrt(p))/(4*sqrt(p)),
      [u=0, v=infinity, a=b, b>0]],
    [cos(a*x)*cos(b*x)/(p-x^2),
      PI*cos(a*sqrt(p))*sin(b*sqrt(p))/(2*sqrt(p)),
      [u=0, v=infinity, b>a, a>0]],

    // 3.743
    [sin(a*x)/(sin(b*x)*(x^2+c)),
      PI*sinh(a*sqrt(c))/(2*sqrt(c)*sinh(b*sqrt(c))),
      [u=0, v=infinity, 0<a, a<b, Re(sqrt(c))>0]],

    [sin(a*x)*x/(cos(b*x)*(x^2+c)),
      -PI*sinh(a*sqrt(c))/(2*cosh(b*sqrt(c))),
      [u=0, v=infinity, 0<a, a<b,Re(sqrt(c))>0]],
    [cos(a*x)*x/(sin(b*x)*(x^2+c)),
      PI*cosh(a*sqrt(c))/(2*sinh(b*sqrt(c))),
      [u=0, v=infinity, 0<a, a<b, Re(sqrt(c))>0]],
    [cos(a*x)/(cos(b*x)*(x^2+c)),
      PI*cosh(a*sqrt(c))/(2*sqrt(c)*cosh(b*sqrt(c))),
      [u=0, v=infinity, 0<a, a<b, Re(sqrt(c))>0]],

    // 3.744
    [sin(a*x)/(cos(b*x)*x*(x^2+c)),
      PI*sinh(a*sqrt(c))/(2*c*cosh(b*sqrt(c))),
      [u=0, v=infinity, 0<a, a<b,Re(sqrt(c))>0]],
    // 3.745
    [sin(a*x)/(cos(b*x)*x*(c-x^2)),
      0,
      [u=0, v=infinity, 0<a, a<b, c>0]],

    /*Begin 3.75
      Combination of trigonometric and algebraic functions 
      Begin 3.751*/
    [sin(a*x)/sqrt(x+b),
      sqrt(PI/(2*a))*(cos(a*b)-sin(a*b)+2*Ci(sqrt(a*b))*sin(a*b)
        -2*Si(sqrt(a*b))*cos(a*b)),
      [u=0, v=infinity, a>0,abs(arg(b))<PI]],
    [cos(a*x)/sqrt(x+b),
      sqrt(PI/(2*a))*(cos(a*b)+sin(a*b)-2*Ci(sqrt(a*b))*cos(a*b)
        -2*Si(sqrt(a*b))*sin(a*b)),
      [u=0, v=infinity, a>0, abs(arg(b))<PI]],
    [sin(a*x)/sqrt(x-u),
      sqrt(PI/(2*a))*(sin(a*u)+cos(a*u)),
      [v=infinity, a>0, u>0]],
    [cos(a*x)/sqrt(x-u),
      sqrt(PI/(2*a))*(cos(a*u)-sin(a*u)),
      [v=infinity, a>0, u>0]],

    // 3.752
    [sin(a*x)*sqrt(1-x^2),
      sum((-1)^k*a^(2*k+1)/((2*k+1)!!*(2*k+3)!!), k=0..infinity),
      [u=0, v=1, a>0]],
    [cos(a*x)*sqrt(1-x^2),
      PI/(2*a)*besselJ(1, a),
      [u=0, v=1]],

    // 3.757
    [sin(a*x)/sqrt(x),
      sqrt(PI/(2*a)),
      [u=0, v=infinity]],
    [cos(a*x)/sqrt(x),
      sqrt(PI/(2*a)),
      [u=0, v=infinity]],

    // 3.763
    [sin(a*x)*sin(b*x)*sin(c*x)/x,
      0,
      [u=0, v=infinity, c<a-b,c>a+b]],
    [sin(a*x)*sin(b*x)*sin(c*x)/x,
      PI/8,
      [u=0, v=infinity, c=a-b, c=a+b]],
    [sin(a*x)*sin(b*x)*sin(c*x)/x,
      PI/4,
      [u=0, v=infinity, a-b<c, c<a+b, a>=b, b>0, c>0]],
    [sin(a*x)*sin(b*x)*sin(c*x)/x^2,
      (c+a+b)*ln(c+a+b)/4-(c+a-b)*ln(c+a-b)/4
        -abs(c-a-b)*ln(abs(c-a-b))*sign(a+b-c)/4
        +abs(c-a+b)*ln(abs(a-b-c))*sign(a-b-c)/4,
      [u=0, v=infinity, a>=b, b>0, c>0]],
    [sin(a*x)*sin(b*x)*sin(c*x)/x^3,
      PI*b*c/2,
      [u=0, v=infinity, 0<c, c<a-b, c>a+b]],
    [sin(a*x)*sin(b*x)*sin(c*x)/x^3,
      PI*b*c/2-PI*(a-b-c)^2/8,
      [u=0, v=infinity, a-b<c, c<a+b,a>=b, b>0,c>0]],

    // 3.764
    [x^p*sin(a*x+b),
      gamma(1+p)*cos(b+p*PI/2)/a^(p+1),
      [u=0, v=infinity, a>0, -1<p, p<0]],
    [x^p*cos(a*x+b),
      -gamma(1+p)*sin(b+p*PI/2)/a^(p+1),
      [u=0, v=infinity, a>0, -1<p, p<0]],

    // 3.767
    [x^c*sin(a*x+b)/(y+x^2),
      -(PI/2)*y^((c-1)/2)*exp(-a*sqrt(y)),
      [u=0, v=infinity, a>0,Re(sqrt(y))>0,abs(Re(c))<1, c=-b/(PI/2)-1]],
    [x^b*cos(a*x+c)/(y+x^2),
      (PI/2)*y^((b-1)/2)*exp(-a*sqrt(y)),
      [u=0, v=infinity, a>0, Re(sqrt(y))>0, Re(sqrt(y))<1, c=-b*PI/2]],
    [x^c*sin(a*x+d)/(x^2-b),
      (PI/2)*b^((c-1)/2)*cos(a*sqrt(b)+d),
      [u=0, v=infinity, a>0, b>0, -1<Re(c)<0, d=-(c+1)*PI/2]],
    [x^c*cos(a*x+d)/(x^2-b^2),
      -(PI/2)*b^(c-2)*sin(a*b-PI*c/2),
      [u=0, v=infinity, a>0, b>0, abs(Re(c))<1, d=-c*PI/2]],

    // 3.678
    [(x-u)^b*sin(a*x),
      gamma(b+1)*sin(a*u+(b+1)*PI/2)/a^(b+1),
      [v=infinity, a>0, -1<Re(b)<0]],
    [(x-u)^b*cos(a*x),
      gamma(b+1)*cos(a*u+(b+1)*PI/2)/a^(b+1),
      [v=infinity, a>0,0<Re(b)<1]],

    // 3.776
// TODO: Questionable. Should that have been (c*(b+x)^(2+p*q))?
    [(c*(b+x)^2+p*q)*sin(a*x)/(b+x)^r,
      a/b^p,
      [u=0, v=infinity, a>0, b>0, p>0, c=a^2, q=p+1, r=p+2]],
    [(a^2*(b+x)^2+p*q)*cos(a*x)/(b+x)^r,
      a/b^(p+1),
      [u=0, v=infinity, a>0, b>0, p>0, q=p+1, r=p+2]],

    // 3.784
    [(sin(a*x)-a*x*cos(a*x))/x^3,
      PI*a^2*sign(a)/4,
      [u=0, v=infinity]],
    [(cos(a*x)-cos(b*x))/(x^2*(x^2+c)),
      PI*((b-a)*sqrt(c)+E^(-b*sqrt(c))-E^(-a*sqrt(c)))/(2*c^(3/2)),
      [u=0, v=infinity, a>0, b>0]],

    // 3.786 
    [(1-cos(a*x))*sin(b*x)/x^2,
      (b/2)*ln((b^2-a^2)/b^2)+(a/2)*ln((a+b)/(a-b)),
      [u=0, v=infinity, a>0, b>0]],
    [(1-cos(a*x))*cos(b*x)/x,
      ln(sqrt(abs(a^2-b^2))/b),
      [u=0, v=infinity, a>0, b>0]],
    [(1-cos(a*x))*cos(b*x)/x^2,
      PI*(a-b)/2,[a,b],
      [u=0, v=infinity, 0<b, b<=a]],

    [(1-cos(a*x))*cos(b*x)/x^2,
      0,
      [u=0, v=infinity, 0<b, b<=a]],

    // 3.787
    [(sin(a*x)^2-sin(b*x)^2)/x,
      ln(a/b)/2,
      [u=0, v=infinity, a>0,b>0]],
    [(x^3-sin(x)^3)/x^5,
      13*PI/32,
      [u=0, v=infinity]],
    // TODO: check condition
    [(3-4*sin(a*x)^2)*sin(a*x)^2/x,
      ln(2)/2,
      [u=0, v=infinity, Re(a)>0]],
    [(4*sin(a*x)^2-3)*sin(a*x)^2/x,
      -ln(2)/2,
      [u=0, v=infinity, Re(a)>0]],

    // 3.789
    [(4*x^2*cos(x)+(PI-x)*x)/sin(x),
      PI^2*ln(2),
      [u=0, v=PI/2]],

    // 3.792
    [1/(1+a*cos(x)+b),
      (v-u)/(1-b),
      [bl(testtype((v-u)/2*PI, Type::Integer)), b=a^2/4, b<1]],
    [x*cos(x)/(1+a*sin(x)+b),
      PI*ln(1+a/2)/a
        - blockTransparent(Sum::sum_fn(k -> 
             (-1)^k*b^k/(2*k+1)^2, 0..infinity)),
      [u=0, v=PI/2, b=a^2/4, b<1]],

    [1/((1+a*cos(b*x)+d)*(c+x^2)),
      PI*(1-a/2*exp(-b*sqrt(c)))/
        (2*sqrt(c)*(1-d)*(1+a/2*exp(-b*sqrt(c)))),
      [u=0, v=infinity, d=a^2/4, d<1, b>=0]],
    [1/((1+a*cos(b*x)+c)*(d-x^2)),
      a*PI*sin(b*sqrt(d))/
         (sqrt(d)*(1-c)*(1+a*cos(b*sqrt(d))+c)),
      [u=0, v=infinity, c=a^2/4, c<1, b>0]],
    [sin(c*x)*x/((1+a*cos(b*x)+d)*(e+x^2)),
      (PI/2)*(exp(-sqrt(e)*c)+(a/2)^(c/b))/
        ((1+a/2*exp(-b*sqrt(e)))*(1+a/2*exp(b*sqrt(e)))),
      [u=0, v=infinity, d=a^2, d<1, b>0, c>0]],
    [sin(b*x)*x/((1+a*cos(b*x)+c)*(d+x^2)),
      PI/(2*(exp(b*sqrt(d))+a/2)),
      [u=0, v=infinity, c=a^2/4, c<1, b>0]],

    [sin(c*x)*x/((1+a*cos(b*x)+d)*(e-x^2)),
      PI*((-a/2)^(c/b)-cos(sqrt(e)*c))/(2*(1+a*cos(b*sqrt(e))+d)),
      [u=0, v=infinity, d=a^2/4, d<1, b>0, c>0]],
    [cos(c*x)/((1+a*cos(b*x)+d)*(e-x^2)),
      (PI/(2*sqrt(e)*(1-d)))*(((1-d)*sin(sqrt(e)*c)
           +2*(-a/2)^(c/b+1)*sin(sqrt(e)*b))/
      (1+a*cos(sqrt(e)*b)+d)),
      [u=0, v=infinity, d=a^2/4, d<1, b>0, c>0]],
    [(1+d*cos(b*x))/((1+a*cos(b*x)+c)*(1+x^2)),
      PI*exp(b)/(2*exp(b)+a),
      [u=0, v=infinity, c=a^2/4, c<1, b>0, d=2*a]],




    // FIXME: pattern for ln(x)^n*exp(-x^2) ???
    [ln(x)*exp(-x^2), -sqrt(PI)/4*(EULER+ln(4)), [u=0, v=infinity]],
    [ln(x)/exp(x^2), -sqrt(PI)/4*(EULER+ln(4)), [u=0, v=infinity]],
    [ln(x)^2*exp(-x^2), sqrt(PI)/8*((EULER+ln(4))^2+PI^2/2), [u=0, v=infinity]],
    [ln(x)^2/exp(x^2), sqrt(PI)/8*((EULER+ln(4))^2+PI^2/2), [u=0, v=infinity]],

    // Gradshteyn, 4.222
    [ln((x^2+a)/(x^2+b)),
      (sqrt(a)-sqrt(b))*PI,
      [u=0, v=infinity, a>0, b>0]],
    [ln(x)*ln((x^2+a)/(x^2+b)),
      (sqrt(b)-sqrt(a))*PI + PI*ln(sqrt(a)^sqrt(a)/sqrt(b)^sqrt(b)),
      [u=0, v=infinity, a>0, b>0]],
    [ln(x)*ln(1+b/x^2),
      PI*sqrt(b)*ln(sqrt(b)-1),
      [u=0, v=infinity, b>0]],

    // Gradshteyn, 8.411
    [exp(-n*I*x+I*z*sin(x)), 2*PI*besselJ(n, z),
      [v-u=2*PI]],
    [exp(I*z*sin(x)), 2*PI*besselJ(0, z),
      [v-u=2*PI]],
    [cos(n*x+z*sin(x)), PI*besselJ(n, -z),
      [u=0, v=PI]],
    [cos(z*sin(x)), PI*besselJ(0, z),
      [u=0, v=PI]],
    [cos(n2*x)*cos(z*sin(x)), PI*besselJ(n2, z),
      [u=0, v=PI]],
    [cos(z*sin(x)), PI*besselJ(0, z),
      [u=0, v=PI]],
    [cos(n2*x)*cos(z*sin(x)), PI/2*besselJ(n2, z),
      [u=0, v=PI/2]],
    [cos(z*sin(x)), PI/2*besselJ(0, z),
      [u=0, v=PI/2]],

    [sin(n1*x)*sin(z*sin(x)), PI*besselJ(n1, z),
      [u=0, v=PI]],
    [sin(n1*x)*sin(z*sin(x)), PI/2*besselJ(n1, z),
      [u=0, v=PI/2]],

  // rather use indefinite integrals for these
    [sin(a*x)/x, PI/2, [a>0, u=0, v=infinity]],
    [sin(a*x)/x, -PI/2, [a<0, u=0, v=infinity]],
    [(cos(a*x)-cos(b*x))/x, ln(b/a), [u=0, v=infinity]],

    // TODO: sin(x)*cos(a*x)/x

    [sin(x)/sqrt(x), sqrt(PI/2), [u=0, v=infinity]],
    [x*sin(b*x)/(x^2+a), PI/2*exp(-sqrt(a)*b), [a>0, b>0, u=0, v=infinity]],
    [x*sin(b*x)/(x^2+a), -PI/2*exp(sqrt(a)*b), [a>0, b<0, u=0, v=infinity]],
    
    [cos(a*x)/(x^2+1), PI/2*exp(-a), [a>0, u=0, v=infinity]],
    [cos(a*x)/(x^2+1), PI/2*exp(a), [a<0, u=0, v=infinity]],
    [sin(a*x)^2/x^2, PI/2*abs(a), [a in R_, u=0, v=infinity]],

    [1/sqrt(1+a*x^2), arcsin(sqrt(-a))/sqrt(-a), [not a<=-1, u=0, v=1]],
    [x/sqrt(1-x^2)/sqrt(1+a*x^2), 1/4/sqrt(-a)*arctanh(sqrt(-a)), [not a<=-1, u=0, v=1]],

    [ln(x)/(x-1), PI^2/6, [u=0, v=1]],
    [ln(x)/(x+1), -PI^2/12, [u=0, v=1]],

    // dauert lange bis es gefunden wird, da int zun�chst die Summe im Z�hler zerlegt
    [(x^a-1)*(x^b-1)/(x-1)/ln(x), -ln(gamma(a+1)*gamma(b+1)/gamma(a+b+1)), [a>-1, b>-1, a+b>-1, u=0, v=1]],

    [ln(1/x)^a, gamma(a+1), [a>-1, u=0, v=1]],

    [x*ln(sin(x)), -PI^2*ln(2)/2, [u=0, v=PI]],
    [sin(x)/x*ln(x), -PI/2*EULER, [u=0, v=infinity]],
    [sin(x)/x*ln(x)^2, PI/2*EULER^2+PI^3/24, [u=0, v=infinity]],

    [ln(a+b*cos(x)), PI*ln((a+sqrt(a^2-b^2))/2), [a>=b or a>=-b, u=0, v=PI]],

    [ln(x/sqrt(1-x^2))/sqrt(1-x^2), 0, [u=0, v=1]],  // int(ln(tan(x)), x=0..PI/2)
    [ln(1+tan(x)), PI/8*ln(2), [u=0, v=PI/4]],

    // Gradshteyn, Table of Integrals, Series and Products
    [ln(1+a*x)*x/sqrt(1-x^2), -1+PI/2/a+sqrt(1-a^2)/a*(arcsin(a)-PI/2), [not a<-1, u=0, v=1]],  // 4.292.4
    [arctanh(a*x)*x/sqrt(1-x^2), PI/2/a*(1-sqrt(1-a^2)), [not a<-1, not a>1, u=0, v=1]],
    [ln(1+a*x)/x/sqrt(1-x^2), PI^2/8-arccos(a)^2/2, [not a<-1, u=0, v=1]],  // 4.292.5
    [arctanh(a*x)/x/sqrt(1-x^2), PI^2/4-PI/2*arccos(a), [not a<-1, not a>1, u=0, v=1]],

    // integral representations of special functions
    [exp(-x^2)/x*sin(a*x), erf(a/2)*PI/2, [a in R_, u=0, v=infinity]],

    [exp(a*x)/x, Ei(-a), [Re(a)<0, u=1, v=infinity]],

    // keep this as long as indefinite integration cannot handle it:
    [(cos(x)-1)/x, Ci(v)-ln(v)-EULER, [u=0]],

    [1/sqrt(1+a*x^2)/sqrt(1-x^2), ellipticF(arcsin(v), -a), [u=0, v>=-1, v<=1]],
    [sqrt(1+a*x^2)/sqrt(1-x^2), ellipticE(arcsin(v), -a), [u=0, v>=-1, v<=1]],
    [1/sqrt(1+a*x^2)/(b+c*x^2)/sqrt(1-x^2), ellipticPi(-c/b, arcsin(v), -a)/b, [u=0, v>=-1, v<=1]],

    [x^a*(x+d)^b*exp(c*x), gamma(a+1)*kummerU(a+1,a+b+2,-c*d)*d^(a+b+1), [Re(a)>-1, Re(c)<0, d>0, u=0, v=infinity]],
    [x^a*(x+d)^b/exp(c*x), gamma(a+1)*kummerU(a+1,a+b+2,c*d)*d^(a+b+1), [Re(a)>-1, Re(c)>0, d>0, u=0, v=infinity]],

    [x^n/(exp(x)+a), -polylog(n+1,-a)*gamma(n+1)/a, [not a<=-1, u=0, v=infinity]],

    [x^a*(1-x)^b*exp(c*x), hypergeom([a+1],[a+b+2],c)*beta(a+1,b+1), [Re(a)>-1, Re(b)>-1, u=0, v=1]],

    [x^a/(exp(x)+1), zeta(a+1)*gamma(a+1)*(1-2^(-a)), [Re(a)>-1, u=0, v=infinity]],
    [x^a/(exp(x)-1), zeta(a+1)*gamma(a+1), [Re(a)>0, u=0, v=infinity]],

    // integral representations for CATALAN
    [x*exp(x/2)/(exp(x)+1), 4*CATALAN, [u=0, v=infinity]],
    [x/cosh(x), 2*CATALAN, [u=0, v=infinity]],
    [arctan(x)/x, CATALAN, [u=0, v=1]],
    [ellipticK(x)/sqrt(x), 4*CATALAN, [u=0, v=1]],
    [ellipticK(x^2), 2*CATALAN, [u=0, v=1]],
    [ellipticE(x^2), CATALAN+1/2, [u=0, v=1]],
    [arctan(x)^2, PI^2/16+PI/4*ln(2)-CATALAN, [u=0, v=1]],

    // integral representations for EULER
    [ln(-ln(x)), -EULER, [u=0, v=1]],
    [ln(ln(1/x)), -EULER, [u=0, v=1]],

    // integrals involving special functions
    [besselJ(a,x), 1, [Re(a)>0, u=0, v=infinity]],
    [besselJ(a,x)^2/x, 1/2/a, [Re(a)>0, u=0, v=infinity]],
    [besselY(a,x), -tan(a*PI/2), [Re(a)<1, Re(a)>-1, u=0, v=infinity]],

    [ellipticK(a*x^2)*x/sqrt(1-x^2), (PI^2/4-PI/2*arccos(sqrt(a)))/sqrt(a), [u=0, v=1]],

    // misc patterns
    [1/sqrt(a/x+b), PI*a/(-b)^(3/2)/2, [b<0, u=0, v*b=-a]],

    null()
]:


cauchy_patterns := [
  // Gradshteyn, 3.748
  [x*tan(x), -PI*ln(2),
    [u=0, v=PI]],

  // 3.749
  [x*tan(a*x)/(x^2+b),
    PI/(exp(2*a*sqrt(b))+1),
    [u=0, v=infinity, a>0, b>0]],
  [x*cot(a*x)/(x^2+b),
    PI/(exp(2*a*sqrt(b))-1),
    [u=0, v=infinity, a>0, b>0]],
  [x*tan(a*x)/(b-x^2), infinity,
    [u=0, v=infinity, b>0]],
  [x*tan(a*x)/(b+x^2), -infinity,
    [u=0, v=infinity, b<0]],
  [x*cot(a*x)/(b-x^2), infinity,
    [u=0, v=infinity, b>0]],
  [x*cot(a*x)/(b+x^2), -infinity,
    [u=0, v=infinity, b<0]],
  [x*csc(a*x)/(b-x^2), infinity,
    [u=0, v=infinity, b>0]],
  [x*csc(a*x)/(b+x^2), -infinity,
    [u=0, v=infinity, b<0]],


  [tan(a*x)/x, PI/2, [a>0, u=0, v=infinity]],
  [tan(a*x)/x, -PI/2, [a<0, u=0, v=infinity]],

  null()
]:
