// $Date: 2006-06-08 13:28:36 +0200 (Thu, 08 Jun 2006) $ $Author: stefanw $ $Revision: 39563 $ 
/*--
intlib::algred(f,n) - reduces f modulo the polynomials in _global_k_alg and returns 
numerator and denominator.
--*/
intlib::algred:=
proc(f,n)
  local i, numf, denomf;
begin
  if n<2 or (map({op(_global_k_alg)},domtype) minus {DOM_INT}={})
    then
    return(normal(f));
  end_if;
  for i from n downto 2 do
    if domtype(_global_k_alg[i])=DOM_POLY then
      [numf, denomf]:= normal(f, List);
      f:= expr(intlib::sim
               (divide(poly(numf,[_global_k_sub[i]])*
                       intlib::pdioe(divide(poly(denomf,[_global_k_sub[i]]),
                                            _global_k_alg[i],Rem),
                                     _global_k_alg[i],
                                     poly(1,[_global_k_sub[i]]))[1],
                       _global_k_alg[i],Rem)))
    else
      next
    end_if;
  end_for;
  normal(f)
end_proc:
