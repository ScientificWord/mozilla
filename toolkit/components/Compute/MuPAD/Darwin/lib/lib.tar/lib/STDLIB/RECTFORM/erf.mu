erf::rectform:=
proc(xx)
  local a, x;
begin
  x := rectform::new(xx);
  if extop(x, 3) <> 0 or not iszero(extop(x, 2)) then
    new(rectform, 0, 0, hold(erf)(xx))
  else
    a := extop(x, 1);
    if domtype(a) = DOM_FLOAT then
      rectform::new(erf(a))
    else
      new(rectform, erf(a), 0, 0)
    end_if
  end_if
end_proc:
