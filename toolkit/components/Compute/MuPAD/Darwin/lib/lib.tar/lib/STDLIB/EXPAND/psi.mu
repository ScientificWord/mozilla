// $Date: 2002-04-17 15:41:33 +0200 (Wed, 17 Apr 2002) $ $Author: tonner $ $Revision: 18020 $ 

/*--
	psi/expand -- the function attribut "expand" for psi

        implements the following rules for
        a of Type::Real and b of Type::PosInt:

0) psi(b, n) = psi(1, n) + (-1)^n*n!*(1 + 2^(-n-1) + ... + (b-1)^(-n-1))

1) psi(x + a, n) = psi(x + frac(a), n) + (-1)^n*n!*
                    ((x + frac(a))^(-n-1) +...+ (x + a - 1)^(-n-1)) if a > 0,
   psi(x + a, n) = psi(x + frac(a), n) - (-1)^n*n!*
                    ((x + frac(a) - 1)^(-n-1) +...+ (x + a)^(-n-1)) if a < 0,
   (also for x = 0 or x of Type::Imaginary)
   
2) psi(b*x)    = ln(b) + (psi(x)    + ... + psi(x + (b - 1)/b))/b
   psi(b*x, n) = (psi(x, n) + ... + psi(x + (b - 1)/b, n))b^(n+1) if n > 0
   (also for x = I)

3) psi(-x)    =           psi(x)    + 1/x               + PI*cot(PI*x)
   psi(-x, n) = (-1)^n * (psi(x, n) + (-1)^n*n!/x^(n+1)
                          + PI^(n+1)*D([1 $ n], cot)(PI*x))

Author: jngerhar (26.09.01)

--*/
psi::expand := proc(e, n = 0)
   local a, fa, b, r, j;
begin
   // recursively expand the argument
   e := expand(e);

   if domtype(e) = DOM_INT then // rule 0)
      if e > 0 then
        return(psi(1, n) + (-1)^n*fact(n)*_plus(j^(-n-1) $ j = 1 .. (e - 1)))
      else // should not happen, since already done in SPECFUNC/psi.mu
        error("singularity")
      end_if
   end_if;

   r := 0;
   if type(e) = "_plus" or testtype(e, Type::Numeric) then // rule 1)
      if type(e) = "_plus" then
        a := select(e, testtype, Type::Numeric);
      else
        a := e;
      end_if;
      fa := floor(Re(a));
      e := e - fa;
      if fa >= 0 then
        r :=  (-1)^n*fact(n)*_plus((e + j)^(-n-1) $ j = 0 .. (fa - 1))
      else // fa < 0
        r := -(-1)^n*fact(n)*_plus((e + j)^(-n-1) $ j = fa .. -1)
      end_if;
   end_if;

   if type(e) = "_mult" or domtype(e/I) = DOM_INT then // rule 2)
      if type(e) = "_mult" then
        b := select(e, testtype, Type::Numeric);
      else
        b := e;
      end_if;
      if domtype(b/I) = DOM_INT then
        b := b/I;
      elif domtype(b) <> DOM_INT then
        b := 1;
      end_if;
      e := e/b;
      if b > 0 then /* r + psi(b*e, n) */
        r + if n = 0 then ln(b) else null() end_if
          + b^(-n-1)*_plus(psi(e + j/b, n) $ j = 0 .. (b - 1))
      else // b < 0, rule 3)
        r + fact(n)*(-b)^(-n-1)*e^(-n-1)
          + expand((-1)^n*PI^(n+1) * D([1 $ n], cot))(-b*e*PI)
          + (-1)^n * /* psi(-b*e, n) */
                     (if n = 0 then ln(-b) else null() end_if
                      + (-b)^(-n-1)*_plus(psi(e - j/b, n) $ j = 0 .. (-b - 1)))
      end_if;
   else
      r + psi(e, n)
   end_if
end_proc:   

/*psi:= slot( psi, "expand", proc(x,n) local i,j,t,rng,N;
begin
   if args(0)=1 then n:=0; N:=null() else N:=n end_if;
   if testtype(x, Type::Numeric)
   then if domtype(x) = DOM_COMPLEX then
           i:= floor(op(x,1));
           if i>=0
           then return(psi(x-i,N)+(-1)^n*fact(n)*_plus(1/(x-j)^(n+1) $ j=1..i))
           else return(psi(x-i,N)-(-1)^n*fact(n)*_plus(1/(x+j)^(n+1) $ j=0..(-i-1)))
           end_if;
        end_if;
        if domtype(x) = DOM_RAT then
           i:= floor(x);
           if i>=0
           then return(psi(x-i,N)+(-1)^n*fact(n)*_plus(1/(x-j)^(n+1) $ j=1..i))
           else return(psi(x-i,N)-(-1)^n*fact(n)*_plus(1/(x+j)^(n+1) $ j=0..(-i-1)))
           end_if;
        end_if;
        if domtype(x) = DOM_INT then
           if x>0 
           then return(psi(1,N) + (-1)^n*fact(n)*_plus(1/j^(n+1) $ j=1..x-1));
           else error("singularity")
           end_if;
        end_if;
   end_if;
   // arguments such as x = y + 5:
   i := 0;
   if type(x) = "_plus" then
     i := select(x, testtype, DOM_INT);
   end_if;
   if i <> 0
   then x:=x-i;
        if i<0 then rng:=i..-1 else rng:=0..i-1 end_if;
        t:=_plus(1/(x+j)^(n+1) $ j=rng);
        return(hold(psi)(x,N)+sign(i)*(-1)^n*fact(n)*t)
   else return(hold(psi)(x,N))
   end_if
end_proc):*/
