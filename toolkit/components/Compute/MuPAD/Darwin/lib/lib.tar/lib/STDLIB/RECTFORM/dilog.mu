/*
   dilog::rectform

   implements dilog(x) in R_  for x>=0

*/

dilog::rectform:=
proc(x)
  local a;
begin
  x:= rectform(x);
  if extop(x,3) <> 0 or not iszero(extop(x,2)) or
    is(extop(x, 1) >= 0) <> TRUE then
    new(rectform,0,0,hold(dilog)(rectform::expr(x)))
  else
    a:= extop(x, 1);
    if domtype(a) = DOM_FLOAT then
      rectform::new(dilog(a))
    else
      new(rectform, dilog(a),0,0)
    end_if
  end_if
end_proc: