
/* vectorSetToNumberSet(S)

   S - set of one-dimensional vectors

   returns a set of numbers

*/

solvelib::vectorSetToNumberSet:=
proc(S)
  local i: DOM_INT;
begin
  case type(S)
    of piecewise do
      return(piecewise::extmap(S, solvelib::vectorSetToNumberSet))
    of "_union" do
    of "_intersect" do
    of "_minus" do
      return(map(S, solvelib::vectorSetToNumberSet))
    of "Union" do
      return(subsop(S, 1 = solvelib::vectorSetToNumberSet(op(S, 1))))
    of DOM_SET do
      return(map(S, op, 1))
    of solvelib::VectorImageSet do
      return(map(S, op, 1))
    of solvelib::cartesianPower do
      if op(S, 2) <>1 then
        error("not a one-dimensional set")
      end_if;
      return(op(S, 1))
    of "solve" do
      if nops(op(S,2)) <> 1 then
        error("not a one-dimensional set")
      end_if;
      assert(type(op(S, 1)) = DOM_LIST);
      return(_intersect(solve(op(S, [1, i]), op(S, [2, 1]))
             $i=1..nops(op(S, 1))))
  end_case;

  
  error("Unknown type of vector set ".expr2text(type(S)))
end_proc: