// $Date: 2003-11-11 17:59:22 +0100 (Tue, 11 Nov 2003) $ $Author: stefanw $ $Revision: 25850 $ 

/*--
	abs/rectform -- the function attribut "rectform" for abs
--*/

abs::rectform:=
proc(xx)
  local x;
begin
  x:= rectform(xx);
  if not iszero(op(x, 3)) or iszero(op(x, 2)) or iszero(op(x, 1)) then 
    new(rectform, abs(expr(x)), 0, 0)
  else
    new(rectform, sqrt(op(x,1)^2 + op(x, 2)^2), 0, 0)
  end_if
end_proc:

// end of file 
