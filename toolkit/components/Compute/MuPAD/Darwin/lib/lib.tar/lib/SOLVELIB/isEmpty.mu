
/* solvelib::isEmpty(S)

   returns a logic expression that is equivalent to S={}

*/


solvelib::isEmpty:=
proc(S)
  local i: DOM_INT, l, intervals, others, dummy, left, right;
begin
  if S::dom::isEmpty <> FAIL then
    return(S::dom::isEmpty(S))
  end_if;

  
  case type(S)
    of DOM_SET do
      return(bool(S={}))
    of RootOf do
      return(bool(degree(op(S, 1), [op(S, 2)]) > 0))
    of "_union" do
      return(_and(solvelib::isEmpty(op(S, i)) $i=1..nops(S)))
    of "_intersect" do
      l:= {op(S)};
      [intervals, others, dummy]:= split(l, x -> type(x) = Dom::Interval);
      assert(dummy = {});
      if others = {Z_} then
        left:= max(map(intervals, iv -> iv::dom::left(iv)));
        right:= min(map(intervals, iv -> iv::dom::right(iv)));
        if is(left > right) = TRUE then
          return(TRUE)
        end_if;
        if right = infinity or left = -infinity or is(right - left > 1) = TRUE then
          return(FALSE)
        end_if;
      end_if;
      break
    of "_minus" do
      return(op(S, 1) subset op(S, 2) )
  end_case;
  
  procname(args())
  
end_proc:

solvelib::isEmpty:= funcenv(solvelib::isEmpty):

solvelib::isEmpty::type:= "isEmpty":