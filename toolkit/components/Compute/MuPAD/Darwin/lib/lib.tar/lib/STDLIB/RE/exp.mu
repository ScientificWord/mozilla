// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	exp/Re -- the function attribut "Re" for exp
--*/

exp := slot( exp, "Re", proc(x)
        local r, s;
    begin
        r := Re(x);
        if r = x then 
            return( exp(x) )
        elif not has(r,{hold(Re),hold(Im)}) then
            s := Im(x);
            if not has(s,{hold(Re),hold(Im)}) then
                return( exp(r)*cos(s) )
            end_if
        end_if;
        return( FAIL )
    end_proc
):

// end of file 
