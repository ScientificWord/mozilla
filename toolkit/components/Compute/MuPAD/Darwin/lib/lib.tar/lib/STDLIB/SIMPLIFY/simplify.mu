//
// $Date: 2006-03-22 15:38:30 +0100 (Wed, 22 Mar 2006) $ $Author: stefanw $ $Revision: 37972 $

/****************************************************************

simplify  - the MuPAD simplifier

simplify(e <, f>)

e - any object
f - identifier or function


If a second argument f is given, just simplify::f is called.


simplify(e) returns e for atomic objects, and maps simplify to e for
non-atomic objects that are not expressions.


For expressions e, simplify calls the following simplification methods

- simplify::f with argument e for every type f appearing in the
  expression (context - sensitive simplifications)
- f::simplify with argument e if e is of type f
- a function that maps simplify to the operands of e

repeatedly, until no further simplifications happen.


simplify uses a double remember mechanism. Firstly, each simplification
method has option remember, where all recursive calls for subexpressions share
the same remember table. Secondly, calls to the same method with the same input
are prevented if they occur within the same recursive call to the main program
of simplify.

****************************************************************/



simplify :=
proc(e, f)
  local
  g: DOM_STRING,
  rememberTable: DOM_TABLE,
  checkSlot1: DOM_PROC,
  checkSlot2: DOM_PROC,
  localSimplifications: DOM_PROC,
  simplifyExpr: DOM_PROC,
  units; // check for units in the expression

begin

// local methods

  checkSlot1:=
  proc(e)
    option remember;
    local p, _t;
  begin
    for _t in sort([op(map(indets(e, All), expr2text))]) do
      if (p:= slot(simplify, _t)) <> FAIL then
        return(p( e ))
      end_if;
    end_for;
    e
  end_proc;

  checkSlot2:=
  proc(e)
    option remember;
    local s, _t;
    begin
      _t := eval(op(e,0));
      if domtype(_t) = DOM_FUNC_ENV and
        (s:= slot(_t,"simplify")) <> FAIL
        then
        s(e)
      else
        e
      end_if
  end_proc;

  localSimplifications:=
  proc(e)
    option remember;
  begin
    map(e, simplifyExpr)
  end_proc;

  // main method of simplify
  // note that its rememberTable is local, while the tables
  // created by option remember above are the same for every
  // instance


  units:= {}: // storage for the units in the expression

  simplifyExpr:=
  proc(e)
    option remember;
    local
    _e,
    n: DOM_INT,
    resultsSoFar: DOM_SET,
    f: DOM_PROC;


  begin
    if domtype(e) <> DOM_EXPR then
       if domtype(e) = unit then
          units:= units union {e};
       end_if;
      return(e)
    end_if;

    resultsSoFar:= {e};


      // try some simplification methods, as long as new results emerge
    repeat

      n:= nops(resultsSoFar);

      for f in [checkSlot1, checkSlot2, localSimplifications] do


        if not contains(rememberTable[f], e) then

          rememberTable[f]:= rememberTable[f] union {e};
          _e:= e;

          e:= f(e);

          if testtype( e,Type::Numeric ) then
            return( e )
          end_if;

          if contains(resultsSoFar, e) then
            // we have to resolve a conflict between two simplification
            // methods f and g with f(_e) = e and g(e) = _e .
            // use Simplify::defaultValuation to do this
            userinfo(5, "Contradicting simplification methods");
            userinfo(5, "Using simpler result");
            if Simplify::defaultValuation(_e) <= Simplify::defaultValuation(e) then
              e:= _e
            end_if;
          else
            resultsSoFar:= resultsSoFar union {e};
            if e <> _e then
              break
            end_if;
          end_if;


        end_if;

      end_for;

    until n = nops(resultsSoFar) end_repeat;

    if nops(units) > 1 then
       e:= unit::simplify(e);
    end_if;

    e

  end_proc;



  //////////////////////////////////////////////
  //  m a i n   p r o g r a m  o f  s i m p l i f y
  //////////////////////////////////////////////


  if args(0) = 0 then
    error("simplify called without arguments")
  end_if;

    // is overloaded ?
  if e::dom::simplify<>FAIL then
    return(e::dom::simplify(args()))
  end_if;

  case args(0)
    of 2 do
      g:= slot(simplify, expr2text(f));
      if g <> FAIL then
        return( g(args()) )
      else
        error("invalid second argument");
      end_if;
    of 1 do
      break;
    otherwise
      error("wrong no of args")
  end_case;

  case domtype(e)
    of DOM_INT     do
    of DOM_RAT     do
    of DOM_FLOAT   do
    of DOM_COMPLEX do
      return( e )
    of DOM_POLY	   do
      return( mapcoeffs(e,simplify) )
    of DOM_LIST    do
    of DOM_ARRAY   do
    of DOM_SET     do
      return( map(e,simplify) )
    of DOM_EXPR    do
      rememberTable:= table();
      for f in [checkSlot1, checkSlot2, localSimplifications] do
        rememberTable[f] := {}
      end_for;
      return(simplifyExpr(e))
  end_case;
  e
end_proc:

DOM_NIL::simplify:=proc() begin NIL end_proc :

simplify:=funcenv(simplify):

//---- units -----
simplify::unit:= X -> unit::simplify(X):


//---- trigonometric functions -----
simplify:= slot(simplify,"sin",
    loadproc(slot(simplify,"sin"),pathname("STDLIB","SIMPLIFY"),
        "SIMPLsin")
):
simplify:= slot(simplify,"cos",
    loadproc(slot(simplify,"cos"),pathname("STDLIB","SIMPLIFY"),
        "SIMPLcos")
):

simplify:= slot(simplify,"sinh",
    loadproc(slot(simplify,"sinh"),pathname("STDLIB","SIMPLIFY"),
        "SIMPLsinh")
):
simplify:= slot(simplify,"cosh",
    loadproc(slot(simplify,"cosh"),pathname("STDLIB","SIMPLIFY"),
        "SIMPLcosh")
):


//---- sqrt -----
simplify:=slot(simplify,"sqrt",radsimp):

//---- exp -----
simplify:=slot(simplify,"exp",
    loadproc(slot(simplify,"exp"),pathname("STDLIB","SIMPLIFY"),
        "SIMPLexp")
):

//---- logarithms -----
simplify:=slot(simplify,"ln",
    loadproc(slot(simplify,"ln"),pathname("STDLIB","SIMPLIFY"),
        "Sln")
):

simplify:=slot(simplify,"log",
    loadproc(slot(simplify,"log"),pathname("STDLIB","SIMPLIFY"),
        "Slog")
):

simplify:=slot(simplify,"gamma",
    loadproc(slot(simplify,"gamma"),pathname("STDLIB","SIMPLIFY"),
        "SIMPLgamma")
):

//---------------------------------
_power:= slot(_power,"simplify",
    loadproc(slot(_power,"simplify"),pathname("STDLIB","SIMPLIFY"),
        "_power")
):

_mult:= slot(_mult,"simplify",
    loadproc(slot(_mult,"simplify"),pathname("STDLIB","SIMPLIFY"),
        "_mult")
):

simplify::logic :=
loadproc(simplify::logic, pathname("STDLIB","SIMPLIFY", "LOGIC"),"simplify"):

simplify::relation :=
loadproc(simplify::relation, pathname("STDLIB","SIMPLIFY"), "relation"):


_plus:= slot(_plus,"simplify",
    loadproc(slot(_plus,"simplify"),pathname("STDLIB","SIMPLIFY"),
        "_plus")
):

_fconcat:= slot(_fconcat, "simplify",
    loadproc(slot(_fconcat, "simplify"), pathname("STDLIB","SIMPLIFY"),
	"_fconcat")
):

/* STDLIB/SIMPLIFY/int.mu, STDLIB/SIMPLIFY/maxmu, STDLIB/SIMPLIFY/min.mu  and STDLIB/SIMPLIFY/sum.mu
 * are now defined in their function environment */

simplify::simplifySets := loadproc( slot(simplify,"simplifySets" ), pathname("STDLIB", "SIMPLIFY"), "simplifySets"):
simplify::simplifyCondition := loadproc( slot(simplify,"simplifyCondition" ), pathname("STDLIB", "SIMPLIFY"), "simplifyCondition"):
simplify::simplifyLogic := loadproc( slot(simplify,"simplifyLogic" ), pathname("STDLIB", "SIMPLIFY"), "simplifyLogic"):

simplify::condition:= simplify::simplifyCondition:

simplify::normal := X->normal(X):
simplify::print:= "simplify":

// end of file

