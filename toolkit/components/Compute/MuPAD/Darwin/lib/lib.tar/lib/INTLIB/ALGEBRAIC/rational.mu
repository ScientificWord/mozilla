// integration of rational functions
//
// Uses the Horowitz-Ostrogradsky algorithm to compute the rational part
// of the integral

intlib::algebraic::rational := funcenv(
proc(ex, x)
  local f, p, a, d, integral, sol;
begin
  assert(testtype(ex, Type::RatExpr(x, Type::IndepOf(x))));
  
  if type(ex) = "_plus" then
    f := poly(ex, [x]);
    if f <> FAIL then
      return(expr(intlib::algebraic::rational::polynomial(f)));
    else
      // faster than normalizing first, and the summands
      // are integrable in any case
      return(map(ex, intlib::algebraic::rational, x));
    end_if;
  end_if;
  
  f := intlib::algebraic::normal(ex, [x]);
  d := f[2];
  [p, a] := [divide(f[1], d)];
  integral := expr(intlib::algebraic::rational::polynomial(p));
  if iszero(a) then return(integral); end_if;
  // normalize a/d
  p := gcd(a, d);
  a := divide(a, p, Exact);
  d := divide(d, p, Exact);
  
  [sol, a, d] := intlib::algebraic::rational::rationalPart(a, d);
  integral := integral + sol;
  
  // yet to integrate: a/d, d is squarefree
  integral + intlib::algebraic::rational::logPart(a, d);
end):


intlib::algebraic::rational::polynomial :=
proc(p)
  local l;
begin
  l := poly2list(p);
  l := map(l, t -> [t[1]/(t[2]+1), t[2]+1]);
  poly(l, op(p, 2..3));
end_proc:

// Horowitz-Ostrogradsky, following Bronstein, Symbolic Integration I, p.46
intlib::algebraic::rational::rationalPart :=
proc(a, d)
  local x, dBar, dAst, t, m, n, b, c, H, sol;
begin
  x := op(op(a, 2));
  dBar := gcd(d, d');
  dAst := divide(d, dBar, Exact);
  m := degree(dAst)-1;
  n := degree(dBar)-1;
  t := solvelib::getIdent(Any, indets({coeff(a), coeff(d), x}));
  b := poly([[t[i], i] $ i = 0..n], [x]);
  c := poly([[t[i+n+1], i] $ i = 0..m], [x]);
  H := a - b'*dAst + divide(b*dAst*dBar', dBar, Exact) - c*dBar;
  sol := intlib::algebraic::linsolve([coeff(H, i) $ i = 0..degree(d)], [t[i] $ i = 0..m+n+1]);
  [expr(subs(b, sol))/expr(dBar), subs(c, sol), dAst];
end:

// Lazard-Rioboo-Trager algorithm,
// following Bronstein, Symbolic Integration I, p. 51

/*

 Notes: In some examples, the code below returns expressions
  considerably more complex than other algorithms would.
  E.g., for an irreducible denominator as in
  int(1/(y^15+a*y+b), y), Maple returns its equivalent of
  sum(ln(y-z)/(15*z^14+a), z in RootOf(y^15+a^y+b, y))

*/

intlib::algebraic::rational::logPart :=
proc(a, d)
  local x, t, R, q, i, j, m, s, degR, integral, A, B, z, tmp, b, c, sq;
begin
  if iszero(a) then return(0); end_if;
  x := op(op(a, 2));
  t := solvelib::getIdent(Any, indets({coeff(a), coeff(d), x}));
  z := solvelib::getIdent(Any, indets({coeff(a), coeff(d), x, t}));
//  R := intlib::algebraic::subresultant(poly(d, [x, t]),
//         poly(a, [x, t])-poly(t, [x, t])*poly(d',[x,t]), x);
//  degR := map(R[2], degree, x);
// //  q := coerce(polylib::sqrfree(R[1]), DOM_LIST);
//   q := coerce(factor(R[1]), DOM_LIST);
  R := intlib::subres(d, poly(expr(a-t*d'), [x]));
//  q := coerce(factor(poly(R[0], [t])), DOM_LIST);
  q := coerce(polylib::sqrfree(poly(R[0], [t])), DOM_LIST);
  integral := 0;
  for i from 2 to nops(q)-1 step 2 do
    if q[i+1] = degree(d) then
      s := poly(d, [t]);
    else
//      m := contains(degR, q[i+1]);
//      assert(m > 0);
//      s := R[2][m];
      s := R[q[i+1]];
      assert(s <> 0);
      A := coerce(polylib::sqrfree(poly(lcoeff(expr(s), [x]), [t])), DOM_LIST);
      for j from 2 to nops(A)-1 step 2 do
        s := multcoeffs(s, 1/expr(gcd(A[j], q[i])^A[j+1]));
      end_for;
      s := mapcoeffs(s, normal);
      s := poly(s, [t]);
    end_if;
    case degree(expr(q[i]), t)
    of 1 do
      tmp := poly(expr(q[i]), [t]);
      tmp := -coeff(tmp, 0)/coeff(tmp, 1);
      integral := integral + tmp*ln(s(tmp));
      break;
    of 2 do
//      if degree(expr(s), [t]) = 1 then
        tmp := poly(expr(q[i]), [t]);
        tmp := multcoeffs(tmp, 1/lcoeff(tmp));
        b := coeff(tmp, 1)/2;
        c := coeff(tmp, 0);
        sq := normal(c-b^2);
        sq := [numer(sq), denom(sq)];
        if generate::isNeg(sq[1]) then
          sq := map(sq, _negate);
        end_if;
        sq := sqrt(sq[1])/sqrt(sq[2]);
        A := s(-b+I*sq);
        B := s(-b-I*sq);
        A := poly(subs(poly(subs(A, I=z), [z])(I), I=z), [z]);
        B := poly(subs(poly(subs(B, I=z), [z])(I), I=z), [z]);
        if degree(A) = 1 and degree(B) = 1 and
           coeff(A, 0) = coeff(B, 0) and
           coeff(A, 1) = -coeff(B, 1) then
          B := coeff(A, 1);
          A := coeff(A, 0);
          integral := integral - b * ln(s(-b+sqrt(b^2-c)) * s(-b-sqrt(b^2-c)))
            + sq*intlib::algebraic::rational::logToArctan
              (poly(A, [x]), poly(B, [x]));
//            +I*sq*ln((A+I*B)/(A-I*B));
          break;
        end_if;
//      end_if;
    otherwise
      tmp := solve(expr(q[i]), t, IgnoreSpecialCases);
      if domtype(tmp) = DOM_SET then
        integral := _plus(integral, op(map(tmp, z -> z*ln(s(z)))));
      elif type(tmp) = "_union" and
         map({op(tmp)}, domtype) minus {DOM_SET, RootOf} = {} then
/*
 Note: Here, we could replace s by divide(s, <poly in br>, Rem).
*/
        integral := _plus(integral,
          op(map([op(tmp)], br -> hold(sum)(z*ln(s(z)), z in br))));
      else
/*
 Note: Here, we could replace s by divide(s, q[i], Rem).
*/
        integral := integral + hold(sum)(z*ln(s(z)), z in RootOf(expr(q[i]), t));
      end_if;
    end_case;
  end_for;
  integral;
end:

// Rioboo's conversion of complex logarithms to real arc-tangents,
// cf. Bronstein, Symblic Integration I, p. 63
intlib::algebraic::rational::logToArctan :=
proc(A, B)
  local g, c, d;
begin
  if iszero(divide(A, B, Rem)) then
    return(2*arctan(expr(A)/expr(B)));
  end_if;
  if degree(A) < degree(B) then
    return(intlib::algebraic::rational::logToArctan(-B, A));
  end_if;
  [g, d, c] := [gcdex(B, -A)]; // B*d - A*c = g
  assert(iszero(mapcoeffs(B*d-A*c-g, Simplify)));
  d := mapcoeffs(d, Simplify);
  c := mapcoeffs(c, Simplify);
  return(2*arctan(expr(A*d+B*c)/expr(g)) +
         intlib::algebraic::rational::logToArctan(d, c));
end:

