// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ 

/*++
Sequence -- returns type expression to test expression sequences

Sequence(T1, T2,...)

T1, T2 - types

The type expression created returns TRUE if an expression is an expression
sequence where element ei has type Ti.
++*/

Type::Sequence:=
  proc()
    option noDebug;
    local i;
  begin
    if testargs() then
      if args(0) < 1 then error("wrong no of args") end_if;
      for i from 1 to args(0) do
        if Type::isSeqType(args(i)) then
          error("can't test for sequences")
        end_if
      end_for
    end_if;
    
    new(Type,
        //"Sequence(".expr2text(args()).")",
        "Sequence",
        proc(t)
	  name Type::Sequence;
          option noDebug;
          local i1, i2, n, l, r;
        begin
          l:= nops(t); n:= 0;
          i1:= 0; i2:= 1; r:= TRUE;
          while i1 < nops(t) do
            i1:= i1 + 1;
            if i2 >= args(0) then
              if testtype(op(t, i1..nops(t)), Type::SequenceOf(DOM_LIST)) then
                return(TRUE)
              else
                userinfo(Text, 2, "input too short");
                return(FALSE) // input too short
              end_if
            end_if;
            if type(op(t, i1)) = DOM_LIST then
              if testtype(eval(args(i2 + 1)), op(t, [i1, 1])) = TRUE then
                n:= n + 1;
                i2:= i2 + 1
              end_if
            else
              r:= testtype(eval(args(i2 + 1)), op(t, i1));
              i2:= i2 + 1
            end_if;
            if r = FALSE then
              if n > 0 then // fallback
                n:= 0
              else
                return(FALSE)
              end_if
            end_if;
            if i2 > l then
              break
            end_if
          end_while;
          if i2 < args(0) then
            return(FALSE)
          end_if;
          r
        end_proc,
        [ args() ], TRUE)
  end_proc:
