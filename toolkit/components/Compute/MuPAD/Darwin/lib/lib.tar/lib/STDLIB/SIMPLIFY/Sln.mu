// $Date: 2006-03-13 14:17:14 +0100 (Mon, 13 Mar 2006) $ $Author: stefanw $ $Revision: 37638 $ 

/*--
	simplify/ln -- the function attribut "ln" for simplify
--*/

simplify::ln:=
proc(a)
  name simplify::ln;
begin
  case type(a)
    of "ln" do
      slot( ln,"simplify" )(a);
      break
    of "_plus" do
      combine(a, ln);
      break
    otherwise
      a
  end_case;
end_proc:

// end of file 
