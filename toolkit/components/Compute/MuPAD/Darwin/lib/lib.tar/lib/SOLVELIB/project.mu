// $Date: 2003-04-08 15:24:08 +0200 (Tue, 08 Apr 2003) $ $Author: stefanw $ $Revision: 22542 $


/*
     solvelib::project(sol, x, free)

     projection to a coordinate

      sol  - solution produced by the system solver
        x  - variable
     free  - set of all free parameters of the solution

     return the set of all x_0 such that sol contains
     a tuple with x = x_0

     returns FAIL if sol cannot be handled

     all idents in sol that are not free are considered
     to be coordinates

*/



solvelib::project:=
proc(sol, x:DOM_IDENT, free={}:DOM_SET)
  local
  extractsolfromlist:DOM_PROC,
  bound2TRUE:DOM_PROC,
  newconds: DOM_LIST,
  i: DOM_INT;
  
begin

  // local procedure extractsolfromlist(l)
  // l - list
  
  extractsolfromlist:=
  proc(l:DOM_LIST)
    local
    constraints:DOM_LIST, // condition that must be satisfied by the free
                          // parameters
    i:DOM_INT,
    eq:"_equal",
    paramsInResult:DOM_LIST,
    setsInResult:DOM_LIST,
    result;
    
  begin
    constraints:= TRUE;
    // if no assignments of the kind x=... are necesaary,
    // all complex numbers are a solution for x
    result:= C_;
    for i from 1 to nops(l) do
      eq:= l[i];
      if op(eq,1)=x then
        // the system solver still outputs solutions
        // of the form {...,[...,x=RootOf(...),...],...}
        // so we have to take care
        if testtype(op(eq,2), Type::Set) = TRUE then
          result:=op(eq,2)
        else
          result:={op(eq,2)}
        end_if;
      elif contains(free, op(eq,1)) then
        constraints:= constraints and eq
      // op(eq,1) is another coordinate
      // then it does not matter, unless the solution for x
      // contains that coordinate
      // the latter   
      // should not happen if BackSubstitution has been applied
      end_if
    end_for;

    // substitute coordinates in the result

    paramsInResult:= [op(indets(result)
                         minus Type::ConstantIdents minus free)];
    if contains(paramsInResult, x)>0 then
      // should not happen 
      return(FAIL)
    end_if;

    setsInResult:= map(paramsInResult,
                       proc(var)
                         local i;
                       begin
                         i:=contains(map(l, op, 1), var);
                         if i=0 then
                           // there are no constraints on var
                           C_
                         else
                           // l[i] is of the form var=...
                           op(l[i],2);
                           if type(%)=RootOf then
                             %
                           else
                             {%}
                           end_if;
                       end_if
                       end_proc
                         );

    if paramsInResult=[] then
      piecewise([constraints, result], [not constraints, {}])
    elif type(result)=DOM_SET then
      piecewise([constraints,
                 simplify(Dom::ImageSet
                          (op(result), paramsInResult, setsInResult))],
                [not constraints, {}])
    else // type(result) is RootOf
      if nops(paramsInResult)>1 then
        FAIL
      else
        piecewise([constraints,
                   solvelib::Union(result, paramsInResult[1],
                                   setsInResult[1])],
                  [not constraints, {}])
      end_if
    end_if
  end_proc;


  // local method
  // bound2TRUE(cond) - replace any atom in cond that contains
  // a non-free variable by TRUE


  bound2TRUE:=
  proc(cond)
  begin
    case type(cond)
      of "_and" do
      of "_or"  do
      // exclude "_not" !  
        map(cond, bound2TRUE); break
      otherwise
        if indets(cond) minus Type::ConstantIdents minus free <> {} then
          TRUE
        else
          cond
        end_if
    end_case
  end_proc;
        


  
  // main program
  
  if sol::dom::project <> FAIL then
    return(sol::dom::project(args()))
  end_if;

  case type(sol)
    of DOM_SET do
      // work on set-of-lists format
      if sol={} then
        return({})
      elif map(sol, domtype)<>{DOM_LIST} then
        return(FAIL)
      else
        map(sol, extractsolfromlist);
        if has(%, FAIL) then
          return(FAIL)
        else
          return(_union(op(%)))
        end_if
      end_if
    of piecewise do
      sol:= piecewise::extmap(sol, solvelib::project, x, free);
      if has(%, FAIL) then
        return(FAIL)
      end_if;
      
      // eliminate conditions with non-free parameters
      // (should not occur --- conditions should contain
      // free parameters only)
      if indets(sol) minus Type::ConstantIdents minus free <> {} then
        newconds:= map([piecewise::condition(sol, i) $i=1..nops(sol)],
                       bound2TRUE);
        sol:=_union(piecewise([newconds[i], piecewise::expression(sol,i)],
                              [not newconds[i], {}]) $i=1..nops(newconds));
      end_if;
      return(sol)
  end_case;
      
  FAIL
end_proc:

     

