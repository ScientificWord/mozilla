// $Date: 2000-06-16 09:34:55 +0200 (Fri, 16 Jun 2000) $  $Author: tonner $  $Revision: 8661 $

/*
           irem(b,a) liefert bei Eingabe zweier ganzer Zahlen a und b
           den ganzzahligen (natuerlichen) Rest bei Division von b durch a.
*/
irem:= proc(b,a)
begin
    if args(0) <> 2 then
        error("expecting two arguments")
    end_if;
    if domtype(b) = DOM_INT then
        if domtype(a) = DOM_INT then
            return( b - a*specfunc::trunc(b/a) )
        elif testtype( a,Type::Numeric ) then
            error("Integer expected")
        else
            return( procname(b,a) )
        end_if
    elif testtype( b,Type::Numeric ) or domtype(a) <> DOM_INT and testtype(a,Type::Numeric) then
        error("Integer expected")
    else
        return( procname(b,a) )
    end_if
end_proc:

