// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ #

// Rational -- expression to test for rational integers

Type::Rational:=
    new(property::NRange,
	"Rational",
	proc(t,x)
	  name Type::Rational;
	  option noDebug;
	begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_INT, DOM_RAT}, domtype(x)) then
		TRUE
	    else
		FAIL
	    end_if;
	end_proc,
	FALSE, FALSE,
	["Rational", property::Null]):
