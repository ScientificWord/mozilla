// $Date: 2001-11-20 18:26:30 +0100 (Tue, 20 Nov 2001) $ $Author: stefanw $ $Revision: 15762 $

// realDiscont = {} is assigned in arccos.mu already
arccos::complexDiscont:= 
hold(_union)(Dom::Interval(-infinity, -1), Dom::Interval(1, infinity)):

