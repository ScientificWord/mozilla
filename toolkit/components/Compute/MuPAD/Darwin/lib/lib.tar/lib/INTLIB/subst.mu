// $Date: 2002-02-04 11:33:08 +0100 (Mon, 04 Feb 2002) $ $Author: walter $ $Revision: 17102 $ 
/*--
intlib::subst(f,opt) - substitutes the functions sin,cos,.. in f
It uses the remember table sub
--*/
intlib::subst:=proc(f, opt)
  local  L,i;
  save _global_notnagel_f;
/* global opt; now removed !!
  global _global_notnagel_f introduced instead of global used f */
begin
  if type(f)=DOM_PROC then return(FAIL) end_if;
  _global_notnagel_f:=f;
  L:=null();
  for i in f do
    if op(i,0) = FAIL 
      then L:=L,i;
      else L:=L,intlib::subst(i,opt);
    end_if; 
  end_for;
  intlib::sub(op(f,0),opt)(L);
end_proc:
