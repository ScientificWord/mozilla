

// simplify - slot for sum

// simplify both the expression and the range 

sum:= slot(sum, "simplify", S -> eval(map(S, simplify, args(2..args(0))))):