//alias(_pattern = intlib::_pattern): geht nicht!

intlib::lookupcos:=proc(f) save a,m,g,xx,k,b,c;
                     local res;
begin
   delete a,m,g,xx,k,b,c;
   if type(f)="_mult" then
      // case g*cos(a*x) 
      if intlib::matchassign(f,_pattern(g)*cos(_pattern(a,not has,_X)*_X)) then
	 // case x^m*cos(a*x) 
	 if intlib::matchassign(g,_X^_pattern(m,not has,_X)) then
	    if m=-1 then return(Ci(a*_X))
	    elif is(m,Type::PosInt)=TRUE then
	       sin(a*_X); cos(a*_X);
	       return(subs(intlib::lookupsin(_X^m*%2),[%2=%,%=-%2]))
	    end_if
	 elif not has((b:=subs(g,cos(a*_X)^2=1-xx^2,sin(a*_X)=xx)/a),_X) then
      res := intlib::int(b,xx);
      if type(res) <> "int" then
        return(subs(res,xx=sin(a*_X)))
      else
        return(FAIL)
      end_if
	 end_if
      end_if;
      break;
   elif type(f)="_power" then return((
      // case cos(x)^m with m even 
      if op(f,1)=cos(_X) and is((m:=op(f,2))/2,Type::NonNegInt)=TRUE then
         binomial(m,m/2)/4^(m/2)*_X+sum(sin((m-2*k)*_X)*
		binomial(m,k)/(m-2*k),k=0..m/2-1)*2^(1-m)
      // case cos(x)^(2*m+1) 
      elif op(f,1)=cos(_X) and is((m:=(op(f,2)-1)/2),Type::NonNegInt)=TRUE then
         sum((-1)^k*binomial(m,k)*sin(_X)^(2*k+1)/(2*k+1),k=0..m)
      // case sqrt(1+b*cos(a*x)) 
      elif op(f,2)=1/2 and intlib::matchassign(op(f,1),1+_pattern(b,not has,_X)
	*cos(_pattern(a,not has,_X)*_X)) then
	 if b=1 or b=-1 then 2*b*sin(a*_X)/f/a else FAIL end_if
      // case 1/(a*cos(g*x)^2+2*b*cos(g*x)*sin(g*x)+c*sin(g*x)^2) 
      elif op(f,2)=-1 and intlib::matchassign(op(f,1),_pattern(a,not has,_X)*
	cos(_pattern(g,not has,_X)*_X)^2+_pattern(b,not has,_X)*
	cos(_pattern(g)*_X)*sin(_pattern(g)*_X)+
	_pattern(c,not has,_X)*sin(_pattern(g)*_X)^2) then
         b:=b/2;
         (b^2-a*c)^(1/2);
         if %=0 then -1/(b+c*tan(g*_X))/g else
	    1/2/%*ln((b+c*tan(g*_X)-%)/(b+c*tan(g*_X)+%))/g
         end_if
      else FAIL end_if))
   end_if;
   intlib::lookupsin; // to load intlib::lookupsincos 
   intlib::lookupsincos(f)
end_proc:
intlib::lookupcos((1-cos(_X))^(-1/2)):=-2^(1/2)*arctanh(((1+cos(_X))/2)^(1/2))
	*sin(_X)/(sin(_X)^2)^(1/2):
intlib::lookupcos((1+cos(_X))^(-1/2)):=2^(1/2)*arcsinh(sin(_X)/(1+cos(_X))):
intlib::lookupcos((1-cos(_X)^2)^(1/2)):=-cos(_X)/sin(_X)*(sin(_X)^2)^(1/2):
intlib::lookupcos(1/(2+cos(_X))):=sqrt(3)/3*_X-
				 2*sqrt(3)/3*arctan(sin(_X)/(cos(_X)+sqrt(3)+2)):
intlib::lookupcos(cos(_X^(1/2))) := 2*cos(sqrt(_X))+2*sqrt(_X)*sin(sqrt(_X)):
