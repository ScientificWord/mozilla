// $Id: rational.mu 42313 2007-01-11 09:42:30Z Christopher Creutzig $

// intlib::rational: integrate a rational expression

intlib::rational :=
proc(_f_, _x_, options=table())
  local integral, int2;
begin
  // look for user-defined patterns first
  if calledFromWithinDefInt <> TRUE then
    integral := intlib::lookup(_f_, _x_, options, []);
    if integral <> FAIL then
      return(integral);
    end_if;
  end_if;
  integral:=intlib::rischInt(_f_,_x_);
  if integral = FAIL or hastype(integral, RootOf) then
  // if Risch's algorithm can't integrate a rational,
  // the only chance is integration by terms.
    // likewise, integration by terms is sometimes able
    // to avoid sums over RootOf, cf. Bug #1126
    userinfo(2,"try to integrate term by term");
    int2:=intlib::expandExp(intlib::termByTerm(_f_,_x_, options));
    if integral=FAIL or
       not hastype(int2, RootOf) and int2 <> FAIL then
      integral := int2;
    end_if;
  else
	// solveable, try to get nicer form
	// as a mild example, compare
	// intlib::rischInt((2*x+3)^3/(3*x+4)^3, x)
	// intlib::lookup((2*x+3)^3/(3*x+4)^3, x)
	// or
	// intlib::rischInt((2*x+3)^3/(3*x+4)^6, x)
	// intlib::lookup((2*x+3)^3/(3*x+4)^6, x)
    integral := intlib::expandExp(integral);
    /*
    userinfo(2,"trying lookup method for nicer representation");
    int2 := intlib::lookup(_f_, _x_, options, [RatExpr]);
    if int2 <> FAIL then integral := int2; end_if;
     */
  end_if;
  return(integral);
end_proc:
