// $Date: 2005-12-02 14:50:38 +0100 (Fri, 02 Dec 2005) $ $Author: rensmann $ $Revision: 35365 $ 

/*--
	_power/simplify -- the function attribut "simplify" for _power
--*/

_power::simplify:=
proc(e)
  name _power::simplify;
  local A, B, c,q,l,i,p,t,aa,_a,_aa, complexpart, b,br,br1,
  reduceMod2: DOM_PROC;
begin
  _a:= op(e,1); b:= op(e,2);

  /* only simplify if _a is arithmetical */
  if not testtype( _a, Type::Arithmetical ) then return( e ); end_if;

  // quick exit
  if domtype(b) = stdlib::Infinity then
    return(e)
  end_if;
  
  A:= _a; // save simplified _a and original b
  B:=  b; // for final output at the end of the routine
   // This case must be treated before sign(b)=-1, because 
   // we want to simplify exp(x)^(-y) -> exp(x*(-y))       
  if testtype(_a, "exp") then
     // rewrite exp(x)^b = exp(xb) if -PI < Im(x) <= PI or b in Z
    if is(op(_a), Type::Real) = TRUE or
      (is(-PI < Im(op(_a))) = TRUE and is(Im(op(_a)) <= PI) = TRUE) or
      is(b, Type::Integer) = TRUE then
      return(exp(op(_a)*b))
    end_if;
  end_if;

  if domtype(_a) <> DOM_INT and domtype(_a) <> DOM_RAT then
    // extract content
    c:= content(_a);
    // this should be a rational number or FAIL
    assert(domtype(c) = DOM_INT or domtype(c) = DOM_RAT or c = FAIL);
    if c <> FAIL then
      if c <> 1 and c <> -1 then
        c:= abs(c);
        return((_a/c)^b * c^b)
      end_if;
    end_if;
  end_if;

  
   // (NonNegative^Rational)^Rational
//    if type(_a) = "_power" and is(b, Type::Rational) = TRUE then
//      if is(op(_a, 1), Type::NonNegative) = TRUE then
//        return(simplify(op(_a, 1)^(op(_a, 2)*b)))
//      end_if
//    end_if;

 // implement (-a)^n = a^n if n is an even integer
  if is(b, Type::Even) = TRUE then
    t:= stdlib::normalizesign(_a)[2]:
    if t <> _a and t <> op(e, 1) and e <> t^b then // prevent infinite recursions!
      return(t^b);
    end_if;
  end_if;

  // another recursive call that is necessary, since the kernel
  // would "simplify" (a^(-b))^(-1) to the original result
  // if sign(b)=-1 then
  //  return(simplify(_a^(-b))^(-1))
  // end_if;
   // now b cannot be negative 
 
 // beginning of extension from Francois Maltey 
  if (br:=stdlib::radsimp_matchsqrt (e))<> FAIL
    and (br1 := stdlib::radsimp_match2sqrt (br)) <> FAIL
    // returns a b r
    and is(br1[1] > 0) = TRUE
    and is(br1[2] > 0) = TRUE
    and is((br := br1[1]^2 - br1[2]^2 * br1[3]) >= 0) = TRUE
    // Delta here a^2 - b^2 r
    and ((type ((br := sqrt (br))) = DOM_INT) or (type (br) = DOM_RAT))
    then
    return (sqrt ((br1[1] + br) / 2) + sqrt ((br1[1] - br) / 2)) ;
    // end of 1st case : sqrt x + sqrt y
    // beginning of 2nd case : sqrt x - sqrt y
  elif (br:=stdlib::radsimp_matchsqrt (e))<> FAIL
    and (br1 := stdlib::radsimp_match2sqrt (br)) <> FAIL // returns a b r
    and is(br1[1] > 0) = TRUE
    and is(br1[2] < 0) = TRUE
    and is((br := br1[1]^2 - br1[2]^2 * br1[3]) >= 0) = TRUE
    // here a^2 - b^2 r
    and ((type ((br := sqrt (br))) = DOM_INT) or (type (br) = DOM_RAT))
    then
    return (sqrt ((br1[1] + br) / 2) - sqrt ((br1[1] - br) / 2)) ;
    // end of 2nd case : sqrt x - sqrt y
    // end of extension from Francois Maltey
  end_if;

  if type(_a) = DOM_COMPLEX and iszero(op(_a, 1)) then
    if op(_a, 2) > 0 then
      return(op(_a, 2)^b * (-1)^(b/2))
    else
      return(- op(_a, 2)^b * (-1)^(b/2))
    end_if
  end_if;
             
  if type(_a) = "_mult" then
    if is(b, Type::Integer) = TRUE then
      return(map(_a, _power, b))
    elif type(b) = DOM_RAT then
      c := op(_a, nops(_a));
      if testtype(c, Type::Numeric) then
        if testtype(c, Type::Real) and c < 0 then
          t := trunc(b);
          if (t <> 0) then
            return(_a^t*_a^(b-t))
          end_if;
        end_if;
      end_if;
    end_if;

    p := 1;
    aa := 1;
    complexpart :=1;
    for q in _a do
      if is(q >= 0) = TRUE then
        _aa := q^b;
        p := p*_aa
      elif is(q <= 0) = TRUE then
        // extract (-q)^b
        _aa := (-q)^b;
        p:= p*_aa;
        aa:= -aa;
      elif is(Re(q) > 0) = TRUE and is(Re(complexpart) > 0) = TRUE then
        // use the rule a^n * b^n = (a*b)^n as long as a, b are known
        // to satisfy Re(a), Re(b) > 0
        complexpart:= complexpart * q;
        p:= p* q^b
      else
        aa := aa*q
      end_if;
    end_for;   
    return(p*aa^b)  
  end_if;

  // special case

  if _a = -1 then

    // symmetric reduction modulo 2
    reduceMod2:=
    proc(b)
    begin
      case type(b)
        of DOM_INT do
          return(b mod 2)
        of DOM_RAT do
          return(frac(1/2 + b/2)*2 - 1)
        of DOM_COMPLEX do
          p:= op(b, 1);
          q:= op(b, 2);
          // reduce p modulo 2
          return(reduceMod2(op(b, 1)) + op(b, 2)*I)
        of "_plus" do
          return(map(b, reduceMod2))
      end_case;
      if is(b, Type::Integer)=TRUE and stdlib::hasmsign(b) then
        -b
      else  
        b
      end_if
    end_proc;

    b:= reduceMod2(b);

    if type(b) = DOM_RAT and b<0 then
      return(- (-1)^(b+1))
    else
      return((-1)^b)
    end_if
  end_if;



  if type(_a) = DOM_INT and (q:= numlib::ispower(_a)) <> FALSE then
    b:= b*op(q, 2);
    _a:= op(q, 1);
    if type(b) = DOM_INT then
      return(_a^b)
    end_if
  end_if;
    
  
  
  if type(_a) = DOM_INT and type(b) = DOM_RAT then
    if _a < 0 then
      return( (-1)^b * (-_a)^b )
    end_if;
    


     // extract factors of the form n^q

    q:=denom(b);
    p:=numer(b);
    l:=stdlib::ifactor(_a, UsePrimeTab);
     // l[1] is known to be 1, since _a is positive
     // get all pairs l[2*i],l[2*i+1] according to whether
     // q >= l[2*i+1]

    br:=1;
     // loop invariant is _a^(p/q) * br
    for i from 2 to nops(l) step 2 do
      if l[i+1] >= q then
         // if l[i+1]= s*q +t, the power (l[i]^l[i+1])^(p/q) can be simplified
         // to l[i]^(ps) * l[i]^(pt/q)
         // divide _a by l[i]^s
        _a := _a / l[i]^ (q*(l[i+1] div q));
        br:= br* l[i] ^ (p*(l[i+1] div q))
      end_if
    end_for;
    return(_a^(p/q)*br)
  end_if;



  if domtype(_a) = DOM_RAT and domtype(b) = DOM_RAT then

    if _a < 0 then
      return((-1)^b * (-_a)^b )
    end_if;
    
    if op(_a, 1) = 1 or _a > 0 and b < 0 then
      // (1/n)^(p/q) -> n^(-p/q)
      //  1 / (5/3)^(1/2) -> (3/5)^(1/2)
      return((1/_a)^(-b))
    end_if;

        
    
    
    // extract powers
    // do the same as in the case type(_a) = DOM_INT,
    // but separately for numerator and denominator
    q:=denom(b);
    p:=numer(b);
    br:= 1;
    l:=stdlib::ifactor(op(_a, 1), UsePrimeTab);
    for i from 2 to nops(l) step 2 do
      if l[i+1] >= q then
        _a := _a / l[i]^ (q*(l[i+1] div q));
        br:= br* l[i] ^ (p*(l[i+1] div q))
      end_if
    end_for;
    // by diving off factors from _a, _a should still be rational
    assert(domtype(_a) = DOM_RAT);
     l:=stdlib::ifactor(op(_a, 2), UsePrimeTab);
    for i from 2 to nops(l) step 2 do
      if l[i+1] >= q then
        _a := _a * l[i]^ (q*(l[i+1] div q));
        br:= br/ l[i] ^ (p*(l[i+1] div q))
      end_if
    end_for;
    
    return(_a^(p/q)*br)

  end_if;
  

  // currently, we do not want (5/2)^(1/2) -> 5^(1/2)/2^(1/2)
  /*
  if type(_a) = DOM_RAT then
    return(op(_a, 1)^b / op(_a, 2)^b)
  end_if;
  */



  // try whether a^(p/q) can be expressed as (a^p)^(1/q)

  if type(b) = DOM_RAT and specfunc::abs(op(b, 1)) > 1 and 
    testtype(_a, Type::Constant) and
    is(arg(_a) < PI/abs(op(b, 1))) = TRUE and
    is(arg(_a) > -PI/abs(op(b, 1))) = TRUE
    then
      l:= expand(_a ^ (op(b, 1)));
      if property::complexity(l) <= property::complexity(_a) then
        return(l^(1/op(b, 2)))
      end_if
  end_if;

  
  if testtype(_a,hold(_power)(Type::AnyType,Type::Rational))
    and type(b)=DOM_RAT then // (x^r)^(j/k)
    p:=op(_a,1)^(op(_a,2)*b);
    if is(p>=0)=TRUE then
      return(p)
    elif b=1/2 then
      if is(p,Type::Real)=TRUE then
        //return(abs(p))
        return(p*sign(p))
      elif is(Re(_a)>0)=TRUE
        or is (Im(_a)<>0)=TRUE
        or (is(op(_a,2), Type::Even) = TRUE
            and is(Re(op(_a,1)^(op(_a,2)/2)) > 0) = TRUE )
        then
        return(p)
      end_if
    end_if;
  end_if;

  // x ^ log(x, y) = y
  // a is assumed to be positive real and > 1
  if type(b) = "log" and op(b, 1) = _a then
    if is(op(b, 2), Type::Real) = TRUE then
      return(op(b, 2))
    end_if
  end_if;
  
  // return(A^B);
  return(_a^b)
  
end_proc:

// end of file 
