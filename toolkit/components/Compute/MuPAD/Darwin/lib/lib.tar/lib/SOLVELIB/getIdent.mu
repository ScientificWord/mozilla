// $Date: 2006-01-13 16:16:11 +0100 (Fri, 13 Jan 2006) $ $Author: ccr $ $Revision: 36309 $
/*
    solvelib::getIdent(S, Forbidden)

    returns an identifier X suitable for ranging over S as a bound identifier
    in expressions like {f(X); X in S}

    X satisfies:
    - it has no value
    - it has no properties, or the property of being in S
    - it is not in the set Forbidden
    - it is no free identifier of S

    among all identifiers eligible according to this criteria,
    that one first appearing in the list of preferred identifiers is chosen;
    if no identifier in that list can be used, a new identifier with preferred
    prefix is created

*/


solvelib::getIdent:=
proc(S, Forbidden = {}: DOM_SET)
  local
  identlist: DOM_LIST,
  i: DOM_INT,
  suitable: DOM_PROC,
  prefix: DOM_IDENT;
  
begin
  // local method
  suitable:=
  proc(X): DOM_BOOL
  begin
    _lazy_and(type(X) = DOM_IDENT,
              eval(hold(val)(X)) = X,
              _lazy_or(getprop(X) = X,
                       getprop(X) = getprop(), // global property has been set
                       getprop(X) = solvelib::set2prop(S, Exact)
                       ),
              not contains(Forbidden, X))
  end_proc;
  
  case type(S)
    of "_minus" do
    of "_intersect" do
      return(solvelib::getIdent(op(S, 1), Forbidden union
                                indets([op(S, 2..nops(S))])))
    of Dom::Interval do
      return(solvelib::getIdent(R_, indets(S) union Forbidden))
    of solvelib::BasicSet do
      break;
    otherwise
      Forbidden:= Forbidden union indets(S);
      S:= C_
  end_case;

  // default: search the list of preferred identifiers
  identlist:= solvelib::preferredIdents[S];
  for i from 1 to nops(identlist) do
    if suitable(identlist[i]) then
      return(identlist[i])
    end_if
  end_for;

  // if this did not succeed, choose an identifier with preferred prefix:
  prefix:= solvelib::preferredPrefixes[S];
  i:= 1;
  while not suitable(prefix.i) do
    i:= i+1
  end_while;
  prefix.i
end_proc:

solvelib::preferredIdents:=
table(
      Z_ = [k, l, m, n],
      R_ = [x, y, u, v, w],
      Q_ = [p, q],
      C_ = [z],
      Any = [a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z]
      ):

solvelib::preferredPrefixes:=
table(
      Z_ = hold(k),
      Q_ = hold(q),
      R_ = hold(x),
      C_ = hold(z),
      Any = hold(t)
      ):

solvelib::setPreferredIdents:=
proc(S, l: DOM_LIST)
begin
  sysassign(solvelib::preferredIdents[S], l)
end_proc:

solvelib::setPreferredPrefix:=
proc(S, x: DOM_IDENT)
begin
  sysassign(solvelib::preferredPrefixes[S], x)
end_proc: