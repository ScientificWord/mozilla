//alias(_pattern = intlib::_pattern): geht nicht!

intlib::lookuptan := proc(f) local n;
save a,b,c,i;		       
begin
   delete a,b,c,i;	       
   if type(f)="tan" then
      // case tan(b*x) 
      if not has((b:=op(f,1)/_X),_X) then return(-ln(cos(b*_X))/b) end_if
   elif type(f)="_power" then
      // case tan(x)^n 
      if op(f,1)=tan(_X) and is((n:=op(f,2)),Type::NonNegInt)=TRUE then
         return((
	    iquo(n-2,2);
	    sum((-1)^i/(n-1-2*i)*tan(_X)^(n-1-2*i),i=0..%)
	   +(-1)^%*((n-2*iquo(n,2))*(ln(cos(_X))+_X)-_X)))
      // case 1/sqrt(b*tan(c*x)^2+a) 
      elif op(f,2)=-1/2 and intlib::matchassign(op(f,1),_pattern(b,not has,_X)
	*tan(_pattern(c,not has,_X)*_X)^2+_pattern(a,not has,_X)) then
         return((if a=1 then
	    if b=1 then tan(c*_X)*f/c
	    else (-b^4*(b-1))^(1/2);-b^2*arctan(b^2*(b-1)*tan(c*_X)/%*f)/%/c
	    end_if
         else (a-b)^(1/2); arctan(tan(c*_X)*%*f)/%/c
         end_if))
      elif op(f,2)=-1 then
         // case 1/(tan(b*x)^2+1) 
         if intlib::matchassign(op(f,1),tan(_pattern(b,not has,_X)*_X)^2+1)
	    then return(_X/2+sin(2*b*_X)/4/b)
         // case 1/(tan(b*x)^3+1) 
         elif intlib::matchassign(op(f,1),tan(_pattern(b,not has,_X)*_X)^3+1)
            then return(_X/2+(ln(cos(b*_X)+sin(b*_X))/6-ln(sin(2*b*_X)-2)/3)/b)
         end_if
      elif op(f,2)=1/2 then
        if intlib::matchassign(op(f,1), tan(_pattern(b, not has,_X)*_X
                                            +_pattern(c,not has, _X))) then
          // sqrt(tan(b*x+c))
          return(-1/4/b*(2^(1/2)*ln(2^(1/2)*tan(c + b*_X)^(1/2) + tan(c + b*_X) + 1)
                         - 2^(1/2)*ln(tan(c + b*_X) - 2^(1/2)*tan(c + b*_X)^(1/2) + 1)
                         + 2*2^(1/2)*PI - 2*2^(1/2)*arctan(2^(1/2)
                                                           *tan(c + b*_X)^(1/2) + 1)
                         + 2*2^(1/2)*arctan(1 - 2^(1/2)*tan(c + b*_X)^(1/2))));
        end_if
      end_if
   elif type(f)="_mult" then
      // case tan(b*x)/(1+sin(b*x)) 
      c:=_pattern(b,not has,_X);
      if intlib::matchassign(f,tan(c*_X)/(1+sin(c*_X))) then
         return(1/2*ln(1+tan(b*_X/2))/b
        -1/2*ln(tan(b*_X/2)-1)/b-tan(b*_X/2)/(1+tan(b*_X/2))^2/b)
      end_if
   end_if;
   FAIL
end_proc:
intlib::lookuptan(_X*tan(_X)):=
1/2*I*(_X^2-2*PI*arctan(exp(I*_X))-2*dilog(-I*exp(I*_X))-2*dilog(I*exp(I*_X))):
