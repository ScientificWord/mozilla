// get the numerator and denominator of an expression known to be rational in a list of indets,
// without explicitly calling normal() (which would call rationalize etc.).
// Note: 


intlib::algebraic::normal :=
proc(ex, ts, lvl=0)
  local parts, num, den, g, u, v, i;
begin
  if not has(ex, ts) then
    return([poly(ex, ts), poly(1, ts)]);
  end_if;
  case type(ex)
  of "_plus" do
    // first, try if any fractions are in there
    u := poly(ex, ts);
    if u <> FAIL then
      return([u, poly(1, ts)]);
    end_if;
    // yes, there are
    parts := map([op(ex)], intlib::algebraic::normal, ts, lvl+1);
    [num, den] := parts[1];
    for i from 2 to nops(parts) do
      g := gcd(den, parts[i][2]);
      u := divide(den, g, Exact);
      v := divide(parts[i][2], g, Exact);
      num := v*num + u*parts[i][1];
      den := den*v;
    end_for;
    if iszero(lvl mod 5) then
      g := gcd(num, den);
      num := divide(num, g, Exact);
      den := divide(den, g, Exact);
    end_if;
    return([num, den]);
    break;
  of "_mult" do
    parts := map([op(ex)], intlib::algebraic::normal, ts, lvl+1);
    num := _mult(op(map(parts, op, 1)));
    den := _mult(op(map(parts, op, 2)));
    if iszero(lvl mod 5) then
      g := gcd(num, den);
      num := divide(num, g, Exact);
      den := divide(den, g, Exact);
    end_if;
    return([num, den]);
    break;
  of "_power" do
    parts := intlib::algebraic::normal(op(ex, 1), ts, lvl+1);
    if op(ex, 2) < 0 then
      return([parts[2]^-op(ex,2), parts[1]^-op(ex,2)]);
    else
      return([parts[1]^op(ex, 2), parts[2]^op(ex, 2)]);
    end_if;
    break;
  end_case;
  [poly(ex, ts), poly(1, ts)];
end:

