psi::rectform:=
proc(xx, n = null())
  local x, a;
begin
  x:= rectform(xx);
  if extop(x, 3) <> 0 or not iszero(extop(x, 2)) then
    new(rectform, 0, 0, hold(psi)(rectform::expr(x), n))
  else
    a := extop(x, 1);
    if domtype(a) = DOM_FLOAT then
      rectform::new(psi(a, n))
    else
      new(rectform, psi(a, n), 0, 0)
    end_if
  end_if
end_proc:
