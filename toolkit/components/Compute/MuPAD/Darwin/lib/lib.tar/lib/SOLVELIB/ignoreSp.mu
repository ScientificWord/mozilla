// $Date: 2006-05-02 18:13:00 +0200 (Tue, 02 May 2006) $ $Author: stefanw $ $Revision: 38756 $


// solvelib::ignoreSpecialCases

/* filters the input to a piecewise such
   that all equalities are considered FALSE unless they
   are provably TRUE */

solvelib::ignoreSpecialCases:=
proc()
  option hold;
  local argv, argv1, removeEquals, u, cond, result, discarded;
  
begin
  removeEquals:=
  proc(cond)
  begin
    case type(cond)
      of "_equal" do
        FALSE;
        break
      of "_unequal" do
        TRUE;
        break
      of "_in" do
        if type(op(cond, 2)) = DOM_SET then
          return(FALSE)
        elif type(op(cond, 2)) = "_minus" and
          op(cond, [2, 1]) = C_ and
          type(op(cond, [2, 2])) = DOM_SET then
          return(TRUE)
        else
          return(cond)
        end_if;
      of "_or" do
      of "_and" do
      of "_not" do  
        map(cond, removeEquals);
        break
      otherwise
        cond
    end_case;
  end_proc;

     // flatten first ? Not necessary if solver does not pass exprseqs 

  argv1:= context(hold(val)([args()]));

  discarded:= [];
  argv:=[];
  for u in argv1 do
    if type(u)<>DOM_LIST then
      error("Argument is not a list")
    end_if;
    cond:= removeEquals(simplify::simplifyCondition(context(u[1])));
    case cond
      of TRUE do
        if traperror((result:= context(u[2]))) = 0 then
          return(result)
        else
          break
        end_if
      of FALSE do
        discarded:= discarded.[u];
        break
      otherwise
        if traperror((result:= context(u[2]))) = 0 then
          argv:=append(argv, [cond, result])
        end_if;
    end_case
  end_for;
  if nops(argv) > 1 then
    piecewise(op(argv))
  elif nops(argv) = 1 then
    // omit condition
    op(argv, [1, 2])
  else
    // no branches have survived; let us use the discarded branches
    userinfo(10, "Ignoring special cases would leave no valid branch");
    piecewise(op(map(discarded, context)))
  end_if
end_proc:
  
