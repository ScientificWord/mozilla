// The problem is to numerically integrate f for x = 0..b to accuracy	
// eps. However, f has a singularity at the left endpoint x=0.		
//									
// The general series expansion of f at x=0+ is computed.		
// An attempt is made to find a transformation such that the new		
// integrand is analytic at x = 0.					
// If no such transformation is found, then the method used is to 	
// integrate the general series expansion beyond the singular point.	

intlib::singleft := proc(f,x,b,eps)
   local ord,s,t,newf,newa,newb;
begin

// Compute the general series expansion of f at x=0. 

ord := trunc(-ln(float(eps)));
s := series(f, x=0, ord);
if type(s)<>"series" and testtype(s,Type::Series(Laurent)) and not testtype(s,Type::Series(Taylor)) then
   error("integrand has a pole on the interval") 
end_if;

// Search for a transformation of f. 

t := intlib::transform(f, x, 0, expr(s));

if t = FAIL then
   // Integrate the general series beyond the singular point. 
   // Not implemented yet. Try definite integration.	     
   t := int(f,x=0..b);
   if testtype(t, "int") then
      return(FAIL);
   else
      return(float(t));
   end_if
elif t[1] = "subtract off" then
     userinfo(1, "splitting integrand into two by subtracting off ".expr2text(t[2]));
     return(intlib::control(f-t[2],x,0,b,eps/2) 
            + intlib::control(t[2],x,0,b,eps/2))
else
    userinfo(1, "applying transformation ".expr2text(x)." = ".expr2text(t[1]));
    newf := normal( subs(f, x=t[1]) * diff(t[1],x) );
    newa := limit(t[2], x=0,Right);
    newb := limit(t[2], x=b,Left);
    userinfo(1, "interval is ".expr2text(newa)." .. ".expr2text(newb)." for the function: ".expr2text(newf));
    if has({newa,newb}, infinity) then
       return(intlib::improper(newf,x,newa,newb,eps))
    else
    	if testtype(float(newa),Type::Numeric) and testtype(float(newb),Type::Numeric) then
	    return(intlib::control(newf,x,newa,newb,eps))
        else
            // Perhaps there is a sign problem (such as sqrt(negative)). 
	    // Not implemented yet.					
	end_if
    end_if
end_if;
FAIL
end_proc:
