// $Date: 2005-08-03 13:58:24 +0200 (Wed, 03 Aug 2005) $  $Author: nthiery $  $Revision: 32470 $ 

/*++
Enumeration - returns type expression to test enumeration types

Enumeration(e1,e2,e3,...)

e - expression defining the singleton type, may NOT be an
    expression sequence

An enumeration type is a type consisting of a fixed list of elements,
e1, e2, e3, ...
++*/

Type::Enumeration:=
    proc()
      option noDebug;
    begin
      new(Type,
	  "Enumeration",
	  proc(t: DOM_SET, x)
	    name Type::Enumeration;
	    option noDebug;
	  begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    bool(contains(t, x));
	  end_proc,
	  { args() }, FALSE)
    end_proc:

// end of file 
