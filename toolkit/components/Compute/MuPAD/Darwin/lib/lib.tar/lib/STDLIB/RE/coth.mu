// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	coth/Re -- the function attribut "Re" for coth
--*/

coth := slot( coth, "Re", proc(x)
        local r, s;
    begin
        r := Re(x);
        if r = x then 
            return( coth(x) )
        elif not has(r,{hold(Re),hold(Im)}) then
            s := Im(x);
            if not has(s,{hold(Re),hold(Im)}) then
                return( sinh(r)*cosh(r) / (sinh(r)^2+sin(s)^2) )
            end_if
        end_if;
        return( FAIL )
    end_proc
):

// end of file 
