// $Date: 2003-04-16 13:33:33 +0200 (Wed, 16 Apr 2003) $ $Author: walter $ $Revision: 22615 $

// /*sparse*/matrix is just an abbreviation for the domain 'Dom::/*Sparse*/Matrix()':
/*sparse*/matrix:= Dom::/*Sparse*/Matrix():

