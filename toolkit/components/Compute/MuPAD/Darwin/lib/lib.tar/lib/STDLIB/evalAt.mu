// $Date: 2006-08-08 21:08:27 +0200 (Tue, 08 Aug 2006) $ $Author: walter $ $Revision: 40219 $
/*
      evalAt(f, x1=a1, .., xn=an)

      (or: f | (x1=a1, ..., xn=an) )

      substitutes x1=a1, .., xn=an in f

      f may also be a sequence


*/



evalAt:=
proc(f, subst)
  option hold;
  local i, g, noSetsOrLists: DOM_BOOL;
begin
  f:= context(f);
  subst:= {context(subst)};

  // denest
  repeat
    noSetsOrLists:= TRUE;
    subst:= map(subst,
                proc(eq)
                begin
                  case type(eq)
                    of "_equal" do
                      return(eq)
                    of DOM_SET do
                    of DOM_LIST do
                      noSetsOrLists:= FALSE;
                      return(op(eq))
                    otherwise
                      error("Equation expected")
                  end_case
                end_proc
                )
  until noSetsOrLists end_repeat;


  // overloading by domains
  if f::dom::evalAt <> FAIL then
    return(f::dom::evalAt(f, subst))
  end_if;

  // overloading by function environments
  if domtype((g:= eval(op(f, 0)))) = DOM_FUNC_ENV and
    g::evalAt <> FAIL then
    return(g::evalAt(f, subst))
  end_if;

  case domtype(f)
      // constant objects
    of DOM_INT do
    of DOM_RAT do
    of DOM_COMPLEX do
      return(f)
    of DOM_ARRAY do
    of DOM_TABLE do
    of DOM_LIST do  
      return(map(f, evalAt, subst))
    of DOM_POLY do
      return(evalp(mapcoeffs(f, evalAt, subst), op(subst)))
    // expressions
    of DOM_EXPR do
      // take care that the sequence of operands is flattened, such
      // that the expected number of arguments is passed to op(f, 0) 
      // Further, before stepping into indexed expressions, we check
      // whether the whole expression should be substituted. For this
      // reason, we check contains(map(subst, op, 1), f):
      if contains(map(subst, op, 1), f) then
         return(eval(subs(f, subst, Unsimplified)))
      else
         return(eval( hold(evalAt(op(f, 0), subst))
                      (evalAt(op(f, i), subst) $i=1..nops(f))
                     ));
      end_if;
  end_case;
  
  // default
  eval(subs(f, subst, Unsimplified))
end_proc:

evalAt := funcenv(evalAt,
                  proc(f)
                    local Args, nargs, str, str1, str2, stripStr;
                  begin
                    stripStr := proc(str)
                                begin
                                  if str[2] = str[4] then
                                    if str[1][1] = "\n" then
                                      str[1] := str[1][2..-1];
                                      str[6] := str[6] - 1
                                    elif str[1][1..2] = "\r\n" then
                                      str[1] := str[1][3..-1];
                                      str[6] := str[6] - 1
                                    end_if;
                                    str;
                                  else
                                    FAIL
                                  end_if
                                end:
                  
                    Args := [op(f)];
                    if FALSE and nops(f) = 2 and
                      // can be done, but output should reflect the internals
                      contains({DOM_LIST, DOM_SET}, domtype(Args[2])) then
                      Args := [Args[1], op(Args[2])];
                    end_if;
                    nargs := nops(Args);
                    if PRETTYPRINT then                      
                      if nargs < 2 then
                        str := stripStr(strprint(All, op(Args)));
                        if str = FAIL then
                          FAIL
                        else
                          _outputSequence(stdlib::Exposed("evalAt"),
                                          stdlib::Exposed(
                                             output::fence("(", ")",
                                                        str[1], str[3], str[6])))
                        end_if;
                      elif nargs = 2 then
                        str1 := stripStr(strprint(All, Args[1]));
                        str2 := stripStr(strprint(All, Args[2]));
                        if str1 = FAIL or str2 = FAIL then
                          FAIL
                        else
                         _outputSequence(stdlib::Exposed(str1[1]),
                                         stdlib::Exposed(" | "),
                                         stdlib::Exposed(str2[1]))
                        end_if;
                      else
                        str1 := stripStr(strprint(All, Args[1]));
                        str2 := stripStr(strprint(All, op(Args[2..nargs])));
                        if str1 = FAIL or str2 = FAIL then
                          FAIL
                        else
                         _outputSequence(stdlib::Exposed(str1[1]),
                                         stdlib::Exposed(" | "),
                                         stdlib::Exposed(
                                             output::fence("(", ")",
                                                 str2[1], str2[3], str2[6])))
                        end_if;
                      end_if;
                    else
                      // PRETTYPRINT = FALSE
                      if nargs < 2 then
                        "evalAt(".expr2text(op(Args)).")"
                      elif nargs = 2 then
                        expr2text(Args[1])." | ".expr2text(Args[2])
                      else
                        expr2text(Args[1])." | (".
                        expr2text(op(Args[2..nargs])).")"
                      end_if;
                    end_if
                  end):
evalAt::Content := (Out, x) ->
                   if nops(x) < 2 then
                     Out::stdFunc(x)
                   else
                     Out::Capply(Out::CevalAt, Out(op(x, 1)),
                                 Out(op(x, 2..nops(x)))):
                   end_if:


evalAt::type:= "evalAt":

diff::evalAt:=
proc(f:"diff", subst)
  local vars, dontsubst, dummy;
begin
  vars:= {op(f, 2..nops(f))};
  [subst, dontsubst, dummy]:= split(subst,
                                    equ -> not contains(vars, op(equ, 1)));
  assert(dummy = {});
  if dontsubst = {} then
    eval(subs(f, subst, Unsimplified))
  else
    hold(evalAt)(eval(subs(f, subst, Unsimplified)), dontsubst)
  end_if
end_proc:


