//alias(_pattern = intlib::_pattern): geht nicht!

intlib::lookuparccos:=proc(f) save a,g,b;
begin
  delete a,g,b;
  case type(f) of "_mult" do
      // case g(x)*arccos(a*x^b) 
      if intlib::matchassign(f,_pattern(g)*arccos(_pattern(a,not has,_X)*
	_X^_pattern(b,not has,_X))) then return((
         if g=_X and b=1 then
            (-a*_X*(1-a^2*_X^2)^(1/2)+(2*a^2*_X^2-1)*arccos(a*_X))/4/a^2
         elif g=_X and b=-1 then _X/2*(f-a*(1-a^2/_X^2)^(1/2))
	 elif g=1/_X^2 and b=1 then -f*_X+a*arctanh((1-a^2*_X^2)^(-1/2))
         elif g=1/_X^2 and b=-1 then -f*_X+(1-a^2/_X^2)^(1/2)/a
         else FAIL end_if))
      end_if;
      break;
   of "arccos" do
      return((if not has((a:=op(f,1)/_X),_X) then _X*f-(1-a^2*_X^2)^(1/2)/a
      elif not has((a:=op(f,1)*_X),_X) then _X*f-a*arctanh((1-a^2/_X^2)^(-1/2))
      else FAIL end_if));
      break;
   of "_power" do
      // case arccos(a*x)^n 
      if is(op(f,2),Type::PosInt)=TRUE and type(op(f,1))="arccos" and not 
	has((a:=op(f,[1,1])/_X),_X) then
	(1-a^2*_X^2)^(1/2);
        return(subs(intlib::lookuparcsin(arcsin(a*_X)^op(f,2)),%=-%,arcsin(a*_X)=
		arccos(a*_X)))
      end_if;
      break;
   end_case;
   FAIL
end_proc:
