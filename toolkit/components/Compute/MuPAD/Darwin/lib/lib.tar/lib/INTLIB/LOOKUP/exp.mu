// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

intlib::lookupexp:=proc(f)
  local f0,F;
  save a,b;
begin
   delete a,b;
   f0:=f;
   if type(f)="_mult" then
      // case x^a*exp(b*x) 
      if intlib::matchassign(f,_X^_pattern(a,not has,_X)
	*exp(_pattern(b,not has,_X)*_X)) then
		return(igamma(a+1,-b*_X)/(-b)^a/b)
      // case erf(b*x)*exp(-b^2*x^2) 
      elif intlib::matchassign(f,erf(_pattern(b,not has,_X)*_X)*exp(-
	_pattern(b)^2*_X^2)) then return(PI^(1/2)/4/b*erf(b*_X)^2)
      else
         f:=subs(expand(f),exp(_X)=b);
         if not has(f,_X) then
           F:=intlib::int(f/b,b);
           if type(F)<>"int" then
            return(eval(subs(F,b=exp(_X))))
           end_if
         end_if
      end_if
   end_if;
   // try Gaussian integrals 
   F:=intlib::gaussian(f0,_X);
   if not has(F,FAIL) then simplify(F) else FAIL end_if
end_proc:


