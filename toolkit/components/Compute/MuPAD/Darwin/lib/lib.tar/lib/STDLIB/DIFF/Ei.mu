// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	Ei/diff -- the function attribut "diff" for Ei
--*/

Ei:= slot(Ei,"diff",proc(xx)
local i,x;
begin
    x := op(xx,1);
    if args(0) = 1 then hold(Ei)(x)
    elif has(x,args(2)) then
        if args(0) > 2 then
            -diff(exp(-x)/x,args(i) $ i=3..args(0))
        else
            -exp(-x)/x*diff(x,args(2))
        end_if
    else
        0
    end_if
end_proc):

// end of file 
