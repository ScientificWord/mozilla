// $Date: 2004-06-21 14:51:24 +0200 (Mon, 21 Jun 2004) $ $Author: tonner $ $Revision: 27732 $ 

// kg, 13/01/95 

/*++
unalias -- un-define alias name

unalias([expr,...])

expr - alias name to un-define

unalias(e1,...,en) un-defines the alias names ei.
unalias() un-defines all alias names.
++*/

unalias:=
proc()
  option hold, noDebug;
  local i, at, global, Args;
begin
  global := null();
  Args := [[args(i)] $ i = 1..args(0)]:
  if  (i := contains(Args, [Global])) <> 0 then
    global := Global;
    Args[i]:= null();
  end_if;
  
  at:= _parser_config(global);
  if at = null() then return(null()) end_if;
    
  if nops(Args) = 0 then
    // remove all aliases
    _parser_config(global, [table(), table(), table(), at[4]]);
    return(null())
  end_if;

  // remove from alias tables
  for i in Args do
    if contains(at[2], op(i)) then
      delete at[1][at[2][op(i)]];
      delete at[2][op(i)]
    else
      delete at[3][op(i)]
    end_if
  end_for;
  _parser_config(global, at);
  null()
end_proc:

// end of file 
