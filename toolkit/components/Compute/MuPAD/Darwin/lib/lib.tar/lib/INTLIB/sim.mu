// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 
/*--
intlib::sim(P1,...,Pm) - simplifies the coefficients of a sequence of
polynomials P1,...,Pm.
--*/
intlib::sim:=proc()
  local i;
begin
  return(mapcoeffs(args(i),normal) $ i=1..args(0));
end_proc:
