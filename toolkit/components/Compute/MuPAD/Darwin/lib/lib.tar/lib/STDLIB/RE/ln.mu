// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	ln/Re -- the function attribut "Re" for ln
--*/

ln := slot( ln, "Re", proc(x) 
    local s;
begin 
    s:= sign(x);
    if s = 1 then 
        return( ln(x) )
    elif s = -1 then 
        return( ln(-x) )
    elif iszero(s) then 
        error("singularity")
    elif domtype(x) = DOM_COMPLEX then
        s:= abs(x);
        if domtype(s) = DOM_EXPR then 1/2*ln(s^2) else ln(s) end_if
    else
        return( ln(abs(x)) )
    end_if
 end_proc  ):

// end of file 
