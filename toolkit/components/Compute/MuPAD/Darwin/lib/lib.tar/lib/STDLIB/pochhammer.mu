// $Id: pochhammer.mu 37921 2006-03-21 15:52:09Z ccr $

// undocumented pochhammer function, for Simplify::hypergeom etc.
// 21.03.2006: added some functionality
//             Torsten Sprenger, sprenger@mathematik.uni-kassel.de
//             Peter Horn, hornp@xinit.org

stdlib::pochhammer := funcenv(
  /* defines the pochhammer symbol */
  proc(n,k)
  local j;
  begin
    if testtype(k,Type::NonNegInt) and testtype(n,Type::NonNegInt) then 
      // k and n postive integers
      return(_mult(n+j $ j=0..k-1));
    elif testtype(k,Type::NegInt) and testtype(n,Type::NonNegInt) then
      // k negative, n positive integer
      return(1/stdlib::pochhammer(n+k,-k));
    elif testtype(n, Type::Numeric) and testtype(k, Type::Numeric) then
      // n, k numbers but not integers
      return(gamma(n+k)/gamma(n));
    else 
      return(procname(args()))
    end_if;
  end_proc,
  /* output */
  (x)->"stdlib::pochhammer(".expr2text(op(x,1)).",".expr2text(op(x,2)).")",
  /* other entries */
  table(
  "expand" = (proc(n,k) 
    local j; 
    begin
      if testtype(k,Type::NonNegInt)  then return(_mult(n+j $ j=0..k-1))
      elif testtype(n,Type::PosInt)   then return((k+n-1)!/(n-1)!)
      elif testtype(n,Type::Rational) then 
        if denom(n)=2 then 
          if n=1/2 then 
            return((2*k)!/(4^k*k!))
          else 
            return(simplify(expand(stdlib::pochhammer::expand(1/2,_div(numer(n),2)+k)/stdlib::pochhammer::expand(1/2,_div(numer(n),2)))))
          end_if;
        else return(gamma(n+k)/gamma(n))
        end_if;
      end_if;
      gamma(args(1)+args(2))/gamma(args(1))
    end_proc),
  "TeX"   = ((fn, ex, prio) -> "\\left(".generate::TeX(op(ex,1))."\\right)_{".
		  generate::TeX(op(ex, 2))."} "),
  "float" = ((n,k) -> float(stdlib::pochhammer::expand(float(n),float(k)))),
  "type"  = "stdlib::pochhammer",
  "print" = "stdlib::pochhammer"
  )
):

stdlib::pochhammer::Content := (Out, data) -> Out::Capply(Out::Cpochhammer, op(data)):

