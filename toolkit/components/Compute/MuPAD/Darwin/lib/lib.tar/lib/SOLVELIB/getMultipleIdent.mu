
/*
    solvelib::getMultipleIdent(S, n, Forbidden)

    returns a list of n different identifiers representing elements of S,
    none of the being element of Forbidden

*/


solvelib::getMultipleIdent:=
proc(S: Type::Set, n: DOM_INT, Forbidden = {}: DOM_SET): DOM_LIST
  local
  i: DOM_INT,
  result: DOM_LIST;
begin
  result:= [FAIL $n];
  for i from 1 to n do
    result[i]:= solvelib::getIdent(S, Forbidden);
    Forbidden:= Forbidden union {result[i]}
  end_for;
  result
end_proc:

  