// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	tan/rectform -- the function attribut "rectform" for tan
--*/

tan:= slot( tan, "rectform", proc(xx)
        local a, b, t, x;
    begin
        x:= rectform::new(xx);

        if extop(x,3) <> 0 then
            new(rectform,0,0,hold(tan)(rectform::expr(x)))
        else
            a:= extop(x,1);
            b:= extop(x,2);
            if domtype(a+I*b) = DOM_COMPLEX
            and (domtype(a) = DOM_FLOAT or domtype(b) = DOM_FLOAT)
            then
                rectform::new(tan(a+I*b))
            elif iszero(b) then
                new(rectform,tan(a),0,0)
            else
                t:= cos(2*a)+cosh(2*b);
                new(rectform,sin(2*a)/t,sinh(2*b)/t,0)
            end_if
        end_if
    end_proc
):

// end of file 
