// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ #

// NonNegInt -- expression to test for non-negative integers

Type::NonNegInt:=
    new(property::NRange,
	"NonNegInt",
	proc(t,x)
	  name Type::NonNegInt;
	  option noDebug;
         begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if domtype(x) = DOM_INT then
		return(bool(x >= 0))
	    end_if;
	    FAIL
	end_proc,
	FALSE, FALSE,
	["NonNegInt", property::Null]):
