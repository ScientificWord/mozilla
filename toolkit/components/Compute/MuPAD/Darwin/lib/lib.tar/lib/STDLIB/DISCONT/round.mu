
genident("n"):
round::realDiscont:= Dom::ImageSet(%+1/2, %, Z_):
