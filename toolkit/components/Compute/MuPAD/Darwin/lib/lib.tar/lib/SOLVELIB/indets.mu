// $Date: 2005-08-24 14:05:33 +0200 (Wed, 24 Aug 2005) $ $Author: stefanw $ $Revision: 32954 $
/* solvelib::indets - extract the indeterminates of an expression
                     or set of expressions


   solvelib::indets(eq)

   eq - any object

   returns a set


   we cannot use indets, since we want X[1] to be a suitable variable
   for the solver, too 

*/

solvelib::indets:=
proc(eq)
  local i;
begin
  if eq::dom::indets <> FAIL then
    return(eq::dom::indets(eq))
  end_if;
  case type(eq)
    of DOM_SET do
      return(_union(op(map(eq, solvelib::indets))))
    of DOM_LIST do
      return(_union(op(map([op(eq)], solvelib::indets))))
    of DOM_POLY do
      return({op(op(eq,2))})
    of piecewise do
      _union(solvelib::indets(piecewise::expression(eq, i)) $i=1..extnops(eq))
    of DOM_IDENT do
      if contains(Type::ConstantIdents, eq) then
        return({})
      else  
        return({eq})
      end_if
    of "_index" do
      if type(op(eq,1))=DOM_IDENT then
        return({eq})
      else
        return({})
      end_if
      // avoid finding bound indets
    of "sum" do
    of "int" do
      if type(op(eq, 2)) = "_equal" then
        // in sum(f(n), n=a..b), do not return n
        return(select(solvelib::indets(op(eq, 1)) union
               solvelib::indets(op(eq, [2, 2])),
                      x -> not has(x, op(eq, [2, 1])))
               )
      else
        // in sum(f(n), n), n is free
        return(solvelib::indets(op(eq, 1))
               union
               solvelib::indets(op(eq, 2))
               )
      end_if
    of "limit" do
      return(select(solvelib::indets(op(eq, 1)) union
                    solvelib::indets(op(eq, [2, 2])),
                    x -> not has(x, op(eq, [2, 1])))
             )
    otherwise
      if nops(eq)=1 and op(eq,0)=FAIL then
        return({})
      else
        return(_union(op(map([op(eq)], solvelib::indets))))
      end_if;
  end_case
end_proc: