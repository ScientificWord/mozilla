/* $Date: 2006-05-31 17:23:29 +0200 (Wed, 31 May 2006) $ $Author: stefanw $ $Revision: 39420 $ */

// solvelib::getOptions

// return a table of options

// if a table is given as first argument, return this table
// if no argument is given, return the default options
// if some arguments are given, return these as options



solvelib::getOptions:=
proc()
local options,i, optname;
  
begin
  if args(0)>=1 and type(args(1))=DOM_TABLE then
    return(args(1))
  end_if;
  
  options:=solvelib::defaultOptions;
   /* get options */
   /* only preliminary, until the final option concept is finished */
   for i from 1 to args(0) do
     case type(args(i))
       of DOM_IDENT do
         optname := expr2text(args(i));
         if contains(options, optname) then
           if testtype(TRUE, solvelib::optionType[optname]) <> TRUE then
             error("Right hand side of option missing")
           else
             options[optname] := TRUE
           end_if
         else
           error("Unknown option ".expr2text(args(i)))
         end_if;
         break
       of DOM_INT do
/* for compatibility reasons, "MaxDegree=" may
    be left out */
         options["MaxDegree"]:= args(i);
         break
       of "_equal" do
         optname:= expr2text(op(args(i),1));
         if contains(options, optname) then
           if testtype(op(args(i), 2),
                       solvelib::optionType[optname]) <> TRUE then
             error("Right hand side of option has wrong type")
           else
             options[optname] := op(args(i), 2)
           end_if
         else  
           error("Unknown option ".expr2text(args(i)))
         end_if;
         break
       otherwise
         error("Unknown option ".expr2text(args(i)))
     end_case
   end_for;

  userinfo(10, "Options used: ".expr2text(options));
   
  options

end_proc:

solvelib::defaultOptions:=
solvelib::originalDefaultOptions:=
table(
   "MaxDegree"=2,
   "Multiple"=FALSE,
   "PrincipalValue"=FALSE,
   "BackSubstitution"=TRUE,
   "VectorFormat"=FALSE,    
   "Domain"= hold(Expr),
   "IgnoreProperties"=FALSE,
   "IgnoreSpecialCases"= FALSE,
   "DontRewriteBySystem"= FALSE,
   "MaxRecLevel" = 30,
   "NoWarning" = FALSE,
   "Real" = FALSE
):



solvelib::optionType:=
table(
      "MaxDegree"= DOM_INT,
      "Multiple"= DOM_BOOL,
      "PrincipalValue"= DOM_BOOL,
      "BackSubstitution"= DOM_BOOL,
      "VectorFormat"= DOM_BOOL,
      "Domain"= Type::AnyType,
      "IgnoreProperties"= DOM_BOOL,
      "IgnoreSpecialCases"= DOM_BOOL,
      "DontRewriteBySystem"= DOM_BOOL,
      "MaxRecLevel" = DOM_INT,
      "NoWarning" = DOM_BOOL,
      "Real" = DOM_BOOL
):

solvelib::nonDefaultOptions:=
proc(t : DOM_TABLE)
  local s : DOM_LIST,
  DONTDISPLAY: DOM_SET;
begin
  DONTDISPLAY:= {"DontRewriteBySystem", "MaxRecLevel", "NoWarning",
                 "IgnoreProperties", "IgnoreSpecialCases"};
  s:= select([op(t)], eq -> not contains(DONTDISPLAY, op(eq, 1))
             and solvelib::defaultOptions[op(eq,1)]<>op(eq,2));
  op(map(s, eq -> text2expr(op(eq,1)) = op(eq,2) ))
end_proc:


solvelib::setOptions:=
proc()
begin
  sysassign(solvelib::defaultOptions, solvelib::getOptions(args())) 
end_proc:

solvelib::restoreDefaultOptions:=
proc()
begin
 sysassign(solvelib::defaultOptions, solvelib::originalDefaultOptions)
end_proc: