// solve a very sparse system of linear equations, where usually
// the result vector is also very sparse
intlib::algebraic::linsolve :=
proc(eqs, ts)
  local zeroes, t;
begin
  // terms which are not sums are linear
  // in one indet., which is therefore zero
  eqs := select(eqs, _not@iszero);
  if select(eqs, _not@has, ts) <> [] then
    // equation not zero, but does not depend on vars to solve for?
    return(FAIL);
  end_if;
  zeroes := {};
  while ((t := select(eqs, _not@hastype, "_plus"))) <> [] do
    t := map(t, eq -> numeric::indets(eq) intersect {op(ts)});
    t := select(t, e -> nops(e)=1);
    if nops(t) = 0 then break; end_if;
    t := map(t, e -> op(e)=0);
    zeroes := zeroes union {op(t)};
    eqs := subs(eqs, zeroes);
    eqs := select(eqs, _not@iszero);
    if select(eqs, _not@has, ts) <> [] then
      // equation not zero, but does not depend on vars to solve for?
      return(FAIL);
    end_if;
  end_while;
  [op(zeroes)].numeric::linsolve(eqs, select(ts, t -> not has(zeroes, t)), 
                           Symbolic, NoWarning);
end:

