
genident("n"):
tanh::complexDiscont:=
 Dom::ImageSet((2*%+1)*PI*I/2, %,
                          solvelib::BasicSet(Dom::Integer)): 

genident("n"):
tanh::undefined:=
 Dom::ImageSet((2*%+1)*PI*I/2, %,
                          solvelib::BasicSet(Dom::Integer)): 


