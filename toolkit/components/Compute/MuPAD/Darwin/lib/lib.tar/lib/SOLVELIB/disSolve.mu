// $Date: 2004-11-19 18:50:25 +0100 (Fri, 19 Nov 2004) $ $Author: stefanw $ $Revision: 29372 $ 

/*++ ---------------- disSolve.mu ---------------------

Author: Winfried Fakler,  University of Paderborn
Date Created: 17 June     1999

Description:
This file contains functions for restricted equation solving, i.e.
it is checked if there are finite many discrete solutions.
In some sense this is closed to MuPAD's solver up to version 1.4.2.
               
++*/



solvelib::sloppySolve:=
  proc()
    local r;
  begin
    r:=solvelib::discreteSolve(args());
    if r=FAIL then hold(solve)(args()) else r end_if;
  end_proc:

solvelib::discreteSolve:=
proc()
  local s, e, res,checkResult,chooseSet,hres,lres, i:DOM_INT;
begin
  // local check function of solve's result
  checkResult:=
  proc(s)
    local res,lres;
  begin
    case type(s)
      of piecewise do
        res:=chooseSet(s);
        if res<>{} then
          return(res)
        else
          return(FAIL)
        end_if;
        break;
      of Dom::Multiset do
      of RootOf do 
      of "solve" do 
      of DOM_SET do
        return(s);
        break;
      of "_minus" do
        if domtype(op(s)[1])=RootOf then
          return({op(s)[1]})
        elif type(op(s)[1])="_intersect" or type(op(s)[1])="_minus" then
          return(op(op(s)[1])[1])
        elif type(op(s)[1])=Dom::ImageSet then
          res:=solvelib::getElement(op(s)[1]);
          if has([res],FAIL) then
            res:=FAIL
          else
            res:={res}
          end_if;
          return(res);
          break
        else
          return(op(s)[1])
        end_if;
        break;
      of Dom::ImageSet do
      of solvelib::VectorImageSet do  
        res:=solvelib::getElement(s);
        if has([res],FAIL) then
          res:=FAIL
        else res:={res}
        end_if;
        return(res);
        break;
      of "_union" do //res:=solvelib::getElement(s);
          // I do here a map, since otherwise I could loose solutions
        lres:=map([op(s)],solvelib::getElement);
        res:=_union(op(map(lres,e->if e=FAIL then null()
                                   elif type(e)<>DOM_SET
                                     then {e} else e
                                   end_if)));
        if res<>{} then return(res) else return(FAIL) end_if; break;
      of "_minus" do
        lres:=extop(s)[1];
        if type(lres)="_intersect" then
          return(extop(lres)[1])
        else
          return(FAIL)
        end_if;
        break;
      otherwise
        return(FAIL);
    end_case;
  end_proc;

  // heuristic to extract from piecewise 
  chooseSet:=  
    proc(pw: piecewise)
      local i,s,cmp,r;
    begin
      s:=select([piecewise::expression(pw,i) $ i=1..extnops(pw)],
          e->if domtype(e)=DOM_SET and e<>{} or domtype(e)=Dom::ImageSet
             or type(e)="solve" or hastype(e, RootOf) then TRUE else FALSE
                end_if);
      if nops(s)>1 then
        cmp:=(a,b)->bool(nops(a)<nops(b)) or has({op(a)}, {C_,R_,Q_,Z_});
        s:=sort(s,not cmp);
      end_if;
      if nops(s)=0 then
        r:={}
      elif domtype(s[1])=Dom::ImageSet then
        r:={solvelib::getElement(s[1])}
      elif type(s[1])="_minus" then
        r:=op(s[1], 1)
      else
        r:=s[1]
      end_if;
      if has([r],FAIL) then
        FAIL
      else
        r
      end_if;
    end_proc;
           
  userinfo(5, "...entering discreteSolve with arguments",args());

  s:=solve(args(), IgnoreProperties, IgnoreSpecialCases);
  userinfo(5, "solve returns ",s);
  case type(s)
    of RootOf do
      res:={s}; // putting {} is not consistant with solve, so :
//      res:=s;
      break; // do not remove, otherwise one
                                    // run into trouble with ode library!!!
    of piecewise do
      res:=checkResult(piecewise::disregardPoints(s)); break;
//      res:=checkResult(s); break;
    of Dom::Multiset do;
    of "solve" do ;
    of DOM_SET do
      res:=s; break;
    of "_minus" do
      if domtype(op(s)[1])=RootOf then
        res:={op(s)[1]}
      elif type(op(s)[1])="_union" then
        res:=op(op(s)[1], 1) minus op(s)[2] union op(op(s)[1], 2);
        if type(res)<>"solve" then
          res:=checkResult(op(s)[1])
        end_if:
      else
        res:=checkResult(op(s)[1])
      end_if; break;
    of "_in" do
      res:=eval(s);
      case type(res)
        of "_equal" do
          res:={[res]}; break;
        of piecewise do
          res:=piecewise::disregardPoints(res);
          if type(res)="_equal" then
            res:={[res]}; break;
          end_if
        otherwise
          res:=checkResult(op(s,2));
 //         if type(res)=DOM_SET and nops(res)=1
          if type(res)=DOM_SET
            then
 //           res:={[op(s,1)=op(res)]}
            res:={[op(s,[1, i])=op(e, i) $i=1..nops(op(s, 1))] $ e in res}
          else
            res:=FAIL
          end_if;
      end_case; break;
    // I am not sure if the following is always correct, but I still hope so
    of "_union" do
      // first treat piecewise
      lres:=map([op(s)], e->if type(e)=piecewise
                              then piecewise::disregardPoints(e)
                            else
                              e
                            end_if);
      // check any single result separately
      lres:=map(lres,checkResult);
      // sorry, but only extract elements of type DOM_SET and RootOf
      res:=_union(op(map(lres,e->case domtype(e)
                                   of RootOf do {e}; break;
                                   of DOM_SET do e; break;
                                   otherwise null()
                                 end_case)));
      if res={} then
        res:=FAIL
      end_if; break;
    of "Union" do
//      O.C. : the following is quite artificial .....
      // first treat piecewise
      if type(op(s)[1])=piecewise then
        lres:=[piecewise::disregardPoints(op(s)[1])]
      else
        lres:=[op(s)[1]]
      end_if;
      // check any single result separately
      lres:=map(lres,checkResult);
      // sorry, but only extract elements of type DOM_SET and RootOf
      res:=_union(op(map(lres,
                         e->
                         case domtype(e)
                           of RootOf do
                             {e};
                             break;
                           of DOM_SET do
                             e;
                             break;
                           otherwise
                             null()
                         end_case))
                  );
      if res={} then
        res:=FAIL
      end_if;
      break;
    of Dom::ImageSet do
      res:=solvelib::getElement(s);
      //if res<>FAIL then res:={res} end_if; break;
      if has([res],FAIL) then
        res:=FAIL
      else
        res:={res}
      end_if;
      break;
    otherwise
      res:=FAIL;
  end_case;
  //res;

  // a first try to improve result
  if type(res)="solve" and type(op(res,2))=DOM_IDENT
     // if solve was called with some options, not always a equation as
     // first argument is returned
     and type(op(res,1))="_equal" then
    hres:=solvelib::heuristicSolve(lhs(op(res,1)),rhs(op(res,1)),op(res,2));
    if hres<>FAIL then
      hres
    else
      res
    end_if;
  else
    res
  end_if;
end_proc:

      
solvelib::heuristicSolve:=  // only univariate case is treated!
  proc(ls,rs,x)
    local fn,res;
  begin
    if has(rs,x) then return(FAIL) end_if;

    if type(ls)="_plus" then
      for fn in ["ln", "exp", "arctan", "sincos", "sinhcosh","_power"] do
        if hastype(ls,fn) then
          res:=slot(solvelib,"combine".fn)(ls,text2expr(fn));
          if not contains({"_plus","_mult"}, type(res)) then
//            return(solvelib::discreteSolve(res=rs,x)) //infinite loop possible?
            return(solvelib::discreteSolve(res-rs,x))
          end_if;
        end_if;
      end_for;
      res:=slot(solvelib,"combinesqrt")(ls,sqrt);
      if not contains({"_plus","_mult"}, type(res)) then
        return(solvelib::discreteSolve(res=rs,x)) //infinite loop possible?
      end_if;
    end_if;
    FAIL
  end_proc:


/* ln(a)+ln(b) ==> ln(a*b)
  k*ln(a) ==> ln(a^k) */
solvelib::combineln:=
  proc(e)
    local f;
  begin
    case type(e)
      of "_plus" do
        e:=map(e,solvelib::combineln);
        f:=select(e,testtype,"ln");
        if type(f)="_plus" then
          return((e-f)+ln(map(subsop(f,0=_mult),op)))
        end_if; break
      of "_mult" do
        e:=map(e,solvelib::combineln);
        f:=select(e,testtype,"ln");
        if type(f)="ln" then // only one factor ln(..) 
          return(ln(op(f)^(e/f)))
        end_if; break
    end_case;
    e
  end_proc:

/* exp(a)*exp(b) ==> exp(a+b)
  exp(a)^b      ==> exp(a*b) */
solvelib::combineexp:=  // combine::exp
  proc(e)
    local f;
  begin
    case type(e)
      of "_plus" do return(map(e,solvelib::combineexp))
      of "_mult" do
        e:=map(e,solvelib::combineexp);
        if type(e)="_mult" then
          f:=select(e,testtype,"exp");
          if type(f)="_mult" then
            return(e/f*exp(_plus(map(op(f),op))))
          end_if
        end_if; break
      of "_power" do
        if type((f:=op(e,1)))="exp" then return(exp(op(f)*op(e,2))) end_if;
        break
    end_case;
    e
  end_proc:

solvelib::combinearctan:=combine::arctan:

solvelib::combinesincos:=combine::sincos:

solvelib::combinesinhcosh:=combine::sinhcosh:

solvelib::combine_power:=combine::_power:

solvelib::combinesqrt:=combine::sqrt:


//solve(ln(y - 1) - ln(y + 4) = 5*z + 5*C7, y);
//solve(ln((y - 1)*(y + 4)^(-1))=5*z + 5*C7, y);

/* 1.4.2:solve(ln((y - 1)*(y + 4)^(-1))=5*z + 5*C7, y);

                       {   - 4 exp(5 z + 5 C7) - 1 }
                       { - ----------------------- }
                       {     1 - exp(5 z + 5 C7)   }

*/

//solvelib::discreteSolve(exp(z)-p10-2*y*exp(z)+y^2+exp(2*z),z);


