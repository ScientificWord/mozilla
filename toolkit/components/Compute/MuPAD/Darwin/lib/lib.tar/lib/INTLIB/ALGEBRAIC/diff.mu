// intlib::algebraic::diff -- differentiate in a differential field

// the field is a transcendental extension of the reals,
// specified by a list of variables and their derivatives.

// the input expression is assumed to be a rational function

intlib::algebraic::diff :=
proc(f, vars, diffs)
  local i;
begin
  // this does not work, because a.t.m. Type::Rational is only for univariate expressions
  if FALSE and testargs() then
    if not testtype(f, Type::Rational(vars, Type::IndepOf(vars))) then
      error("input is not a rational function");
    end_if;
  end_if;

  _plus(diffs[i]*diff(f, vars[i]) $ i = 1..nops(vars));
end_proc:
