// $Date: 2006-10-19 13:26:33 +0200 (Thu, 19 Oct 2006) $ $Author: Christopher Creutzig $ $Revision: 41152 $ 

/* zimmerma, 01/08/95 */

/*

	discont  --  determines the discontinuities of a function


	discont(f,x, F) returns a set of (possible) discontinuities 
	of f, where f is regarded as a function over F.

	discont(f,x=a..b, F) returns the discontinuities in a..b, where a<=b.

   F may be either Dom::Real or Dom::Complex.

   If F is not given, Dom::Complex is used unless is(Global,
   Type::Real) is true. 


	discont looks for an attribute "realDiscont" (or "complexDiscont",
   respectively) of the operator of f in order
   to determine the discontinuities of f viewed as a real
(resp. complex) function. 
    

	For example to say that the only 
	discontinuity of dirac is in 0, you write 
	dirac:=slot(dirac,"realDiscont",{0})


   discont(f, x, Undefined), or discont(f, x=a..b, Undefined)
   returns the set of all complex numbers (or all numbers
   in the interval [a,b], respectively) for which f is undefined.

   In this case, discont looks for an attribute "undefined" of the operator.
   


*/


discont :=
proc(f,x)
  local i, s, r, iv, argv, F, specialoptions, options;
  save MAXEFFORT;
begin

  //  overloading for domains 
  if f::dom::discont <> FAIL then
    return(f::dom::discont(args()))
  end_if;

  /* main */

  if testargs() then
    if args(0)<2 then
      error("Two or three arguments expected")
    end_if;
    case type(x)
      of DOM_IDENT do break; // ok 
      of "_equal" do
        if map(x,type)<>(DOM_IDENT="_range") then
          error("x=a..b expected as 2nd argument")
        end_if;
        break
      otherwise
        if not testtype(x, Type::Arithmetical) then
          error("invalid second argument")
        end_if
    end_case;
  end_if;

  argv:= {args(3..args(0))};
  specialoptions:= argv intersect
                   {undefined, hold(Undefined),
                    Dom::Real, Dom::Complex, C_, R_};

  
  case nops(specialoptions)
    of 1 do
      F:= op(specialoptions, 1);
      case F
        of undefined do
          F:= hold(Undefined);
          break
        of hold(Undefined) do
        of Dom::Real do
        of Dom::Complex do
          break;
        of R_ do
          F:= Dom::Real;
          break
        of C_ do
          F:= Dom::Complex;
          break
        otherwise
          error("Third argument must be Dom::Real or Dom::Complex")
      end_case;
      break;
    of 0 do
      // F not specified
      if is(hold(Global), Type::Real)=TRUE then
        F:=Dom::Real
      else
        F:=Dom::Complex
      end_if;
      break
    otherwise
      error("Inconsistent options")
  end_case;

  options:= solvelib::getOptions(op(argv minus specialoptions));

  if type(x) = "_equal" then
    if type(op(x, 1)) <> DOM_IDENT then
      r:= genident();
      return(subs(discont(subs(f, op(x, 1) = r), r = op(x, 2), F),
                  r = op(x, 1)))
    end_if
  elif type(x) <> DOM_IDENT then
    r:= genident();
    return(subs(discont(subs(f, x = r), r, F), r = op(x, 1)))
  end_if;
  
  if F= Dom::Real then
    // implicit assumption
    save op(x, 1);
    assume(op(x, 1), Type::Real, _and)
  end_if;
  
  // handle case that a certain range is given
  
  if type(x)="_equal" then
    r:=op(x,2);
    save op(x, 1);
    iv:= Dom::Interval([op(r, 1), op(r, 2)]);
    if iv = {} then
      return({})
    end_if;
    if traperror(assume(op(x, 1) in iv, _and)) <> 0 then
      if getlasterror()[2][1..29] = "Error: assumption impossible " then
        // can't be in this range, therefore no discontinuities here
        return({});
      end;
      lasterror();
    end;
    // spend half of the time on recursive discont,
    // half on set operations
    MAXEFFORT:= MAXEFFORT/2;
    case type((s:= discont(f, op(x,1), F)))
      of piecewise do
        userinfo(10, "Discontinuities depend on parameters: ".
                 expr2text(s));
        return(piecewise::extmap(s,_intersect,
                                 Dom::Interval([op(r,1), op(r,2)]) ))
      of "solve" do
        return(procname(args()))
      otherwise
        userinfo(10, "The set of discontinuities is ".expr2text(s));
        return(solvelib::solve_intersect(s, Dom::Interval([op(r,1), op(r,2)])))
    end_case
  end_if;


  
  // constant functions may only be constantly undefined or continous

  if not has(f, x) then
    F:= hold(Undefined)
  end_if;
  
 // overloading for function environments 
  if type((r:=eval(op(f,0))))=DOM_FUNC_ENV then
    case F
      of Dom::Real do
        s:= r::realDiscont; break
      of Dom::Complex do
        s:= r::complexDiscont; break
      of hold(Undefined) do
        s:= r::undefined; break
      otherwise
        // NOT REACHED
        assert(FALSE);
    end_case;

    if s<>FAIL then
      // f(g(x)) is continous unless f is not continous
      // at g(x) or g is not continous at x; let s be the set
      // of exceptional points
      MAXEFFORT:= MAXEFFORT/2;
      s:= solvelib::preImage(op(f), x, s)
      union discont(op(f),x, F);
      if F = Dom::Real then
        return(R_ intersect s)
      else
        return(s)
      end_if;
    else
      // s = FAIL
      if (s:= r::discont(f, x, F) ) <> FAIL then
        return(s)
      end_if
    end_if;
  end_if;


  // do not handle RootOf's
  // (would cause problems in property mechanism)
  
  if hastype(f, RootOf) then
    return(procname(args()))
  end_if;
  
  
  case type(f)
    of DOM_INT do
    of DOM_RAT do
    of DOM_IDENT do
    of "_index" do  
    of DOM_COMPLEX do
    of DOM_FLOAT do 
    of stdlib::Infinity do
    of stdlib::CInfinity do  
      return({})
    of "_plus" do
//  of "igamma" do   // igamma has singular points and branch cuts
    of "_mult" do
      MAXEFFORT:= MAXEFFORT/nops(f);
      return(_union(discont(op(f,i),x, F)$i=1..nops(f)))
    of "_power" do

       // special case F=Undefined
       // f(x)^g(x) is undefined iff f(x) or g(x) is undefined
       // or f(x) is zero and g(x) is negative
       // for efficiency reasons, we handle the case g(x)=const separately
      if F=hold(Undefined) then
        if not has(op(f,2), x) then
          return(piecewise([Re(op(f,2))>=0, discont(op(f,1), x, F)],
                           [Re(op(f,2))<0, discont(op(f,1), x, F) union
                            solve(op(f,1), x, options)]))
        else
          // x occurs in the exponent
          // we have to call solve in oirder to decide
          // exponent >=0 / exponent <0
          MAXEFFORT:= MAXEFFORT/4;
          return(
                 solve(op(f, 2)<0, x, options) intersect
                            solve(op(f,1), x, options)
                 union discont(op(f,2), x, F)
                 union discont(op(f,1), x, F)
                 )
        end_if
      end_if;

      assert(F <> hold(Undefined));
      
       // f=a^b
       // special cases for b integer and independent of x
      if not has(op(f,2), x) and is(op(f,2), Type::Integer)=TRUE
        then
         // x -> x^b is everywhere continous for b>0, and has
         // its only discontinuity at zero for b<=0
        return(piecewise([op(f,2)>0, discont(op(f,1), x, F, options)],
                         [op(f,2)<=0, discont(op(f,1), x, F, options) union
                          solve(op(f,1), x, options)]))
      end_if;
      
      // special case: real base, b independent of x
      // then, as a function of the reals, x -> x^b
      // is everywhere continous for b>0, and discontinous only
      // at zero otherwise
      if F=Dom::Real and not has(op(f,2), x) then
        // test whether base is real
        i:= genident();
        eval(hold(assume)(i, Type::Real));
        if is(subs(op(f, 1), x=i), Type::Real)=TRUE then
          return(piecewise([op(f,2)>0, discont(op(f,1), x, F, options)],
                         [not op(f,2)>0, discont(op(f,1), x, F, options) union
                          solve(op(f,1), x, options)]))
        end_if;
      end_if;
        
       // = exp(b*ln(a)) if a is not zero
       // discontinuities are those of b and those of ln(a)
      MAXEFFORT:= MAXEFFORT/3;
      if F = Dom::Real then
        i := ln::realDiscont;
      else
        i := ln::complexDiscont;
      end_if;
      return(discont(op(f,2), x, F) union discont(op(f,1), x, F)
             union solvelib::preImage(op(f,1), x, i))
       // functions without singularities 
     of "besselJ" do
       f:=[op(f,2)];
     of "sin" do
     of "cos" do
     of "abs" do
     of "exp" do
     of "sinh" do
     of "cosh" do
     of "erf" do
    of "erfc" do
    of "Re" do
    of "Im" do  
       return(discont(op(f), x, F))
   // functions with a discontinuity in 0 
     of "besselY" do
       f:=[op(f,2)];
       // fall through
     of "dirac" do
     of "heaviside" do
    of "sign" do
      if F=hold(Undefined) then
        return(discont(op(f), x, F))
      else
        MAXEFFORT:= MAXEFFORT/2;
        return(discont(op(f),x, F) union solve(op(f),x, options))
      end_if;
   // functions with a discontinuity in 1 
    of "zeta" do
       MAXEFFORT:= MAXEFFORT/2;
       return(discont(op(f),x, F) union solve(op(f)=1,x, options))
       // functions with discontinuities in all integers
       // to be corrected for F=Dom::Complex !!!
     of "floor" do
     of "frac" do
     of "ceil" do
    of "trunc" do
      if F=hold(Undefined) then
        return(discont(op(f), x, F))
      else
        MAXEFFORT:= MAXEFFORT/2;
        return(discont(op(f), x, F) union
               solvelib::preImage(op(f), x, Z_))
      end_if
    of "round" do
      if F=hold(Undefined) then
        return(discont(op(f), x, F))
      else         
        i:=genident();
        MAXEFFORT:= MAXEFFORT/2;
        return(discont(op(f), x, F) union
              solvelib::preImage(op(f), x, Dom::ImageSet(i+1/2, i, Z_)))
      end_if
   // functions with a discontinuity in -n 
    of "psi" do
      MAXEFFORT:= MAXEFFORT/2;
      return(discont(op(f, 1), x, F) union
             solvelib::preImage(op(f, 1), x,
                                Z_ intersect Dom::Interval(-infinity..[0])))
    of "fact" do
    of "binomial" do  
       return(discont(rewrite(f, gamma), x, F))
   // logarithm: rewrite by ln
   // assume the base to be positive and not equal 1
   // either the base is constant and positive anyway, or it is an identifier
   // in the latter case, replace with a positive identifier   
    of "log" do
      if type(op(f,1))=DOM_IDENT then
        i:=genident("b");
        eval(hold(assume)(i>0));
      // einkommentieren, wenn property-Problem sich erledigt hat:  
      //  eval(hold(assume)(i<>1, hold(_and)));
        return(subs
               (
                discont(rewrite(subs(f, op(f,1)=i),ln), subs(x, op(f,1)=i),F),
                i=op(f,1)))
      else  
        return(discont(rewrite(f, ln), x, F))
      end_if;
   // integrals    
    of "int" do
      if type(op(f,2))="_equal" then
        MAXEFFORT:= MAXEFFORT/3;
        return(discont(op(f,1),x, F) union
               discont(op(f,[2,2,1]),x, F)
               union discont(op(f,[2,2,2]),x, F))
      else
        return(discont(op(f,1),x, F))
      end_if
   end_case;

  procname(args())
end_proc:


discont := funcenv(discont):

discont::type := "discont":
discont::print:= "discont":
discont::info := "discont -- discontinuities of a function":


// end of file 
