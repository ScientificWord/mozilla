/*++

Relation -- expression to test for a relation
  
Relation

++*/

Type::Relation:=
      new(Type,
	  "Relation",
	  proc(t,x)
	    name Type::Relation;
	    option noDebug;
	  begin
	      if args(0) <> 2 then return(FALSE) end_if;
	      if testtype(x, "_equal") or testtype(x, "_unequal") or
                 testtype(x, "_leequal") or testtype(x, "_less") then
		  TRUE
	      else
		  FAIL
	      end_if
	  end_proc,
	  FALSE, FALSE
	  ):

// end of file 
