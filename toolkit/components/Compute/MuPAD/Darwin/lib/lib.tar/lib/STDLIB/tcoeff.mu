// $Date: 2002-03-25 13:40:18 +0100 (Mon, 25 Mar 2002) $  $Author: stefanw $ $Revision: 17846 $ 

/* General convention: a monomial ordering is a function
  ord: N^k x N^k -> {-1, 0, 1}

  for elements of Dom::MonomOrdering, this is satisfied
  (by definition of Dom::MonomOrdering::func_call)

  Here ord([m_1,..,m_k],[n_1,..,n_k])=-1 iff [m_1,..,m_k] < [n_1,..,n_k]
                                     = 1 iff              >
                                     = 0 iff              =
*/


/* tcoeff(f,ord)
  
  f   - polynomial
  ord - monomial ordering 

  computes the trailing coefficient with respect to ord
*/

tcoeff:=
proc(ff, o)
local f, dv, nt, dvec, i, result,ord, nvars;
begin
  if args(0)=0 then
    error("tcoeff called without arguments")
  end_if;
  if ff::dom::tcoeff <> FAIL then
    return(ff::dom::tcoeff(args()))
  end_if;
  
  if args(0)=1 then
    return(polylib::tcoeff(args()))
  end_if;

  if type(o)=DOM_LIST then
    tcoeff(poly(ff,o), args(3..args(0)));
    if testtype(ff, Type::Arithmetical) then
      return(expr(%))
    else
      return(%)
    end_if
  end_if;

  if iszero(degree(ff)) then
    return(polylib::tcoeff(ff))
  end_if;

  f:=poly(ff);
  if f=FAIL then
     error("Cannot convert to polynomial")
  end_if;
  nvars:=nops(op(f,2));
  
  if type(o)=DOM_IDENT then
    if o=hold(LexOrder) then
      return(polylib::tcoeff(ff))
    elif o=hold(DegreeOrder) then
      ord:=Dom::MonomOrdering(DegLex(nvars))
    elif o=hold(DegInvLexOrder) then
      ord:=Dom::MonomOrdering(DegInvLex(nvars))
    else
      error("Unknown monomial ordering ".expr2text(o))
    end_if
  else
    ord:=o
  end_if;
 
  result:=nthcoeff(f,1);
  dv:=degreevec(nthterm(f,1));
  for i from 2 to nterms(f) do
    nt:=nthterm(f,i);
    dvec:=degreevec(nt);
    if ord(dv,dvec)=1 then
      dv:=dvec;
      result:=nthcoeff(f,i)
    end_if
  end_for;
  result
end_proc:

// end of file 












