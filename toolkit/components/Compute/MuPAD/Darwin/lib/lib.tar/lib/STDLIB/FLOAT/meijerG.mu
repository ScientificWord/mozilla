//
//
//      meijerg -- Numerical Meijer G Function
//
//

alias(hypergeom=hypergeom::float):
alias(meijerG=meijerG::float):

alias(Hypergeom=specfunc::Hypergeom):
alias(MeijerG=specfunc::MeijerG):

alias(typenumcomplex=Hypergeom::typenumcomplex):
alias(CondC=Hypergeom::CondC):
alias(CondA=Hypergeom::CondA):

alias(evalfp=MeijerG::evalp):
alias(forall=MeijerG::forall):
alias(epsilon=MeijerG::epsilon):
alias(flip=MeijerG::flip):
alias(slater=MeijerG::slater):
alias(Inf=MeijerG::Inf):

evalfp:=proc(z)
begin
  bool(z=0 or typenumcomplex(z)):
end_proc:

  // Test if all zs are zero or type complex(float)
forall:=proc(zs)
  local z,answer;
begin
  answer:=TRUE:
for z in zs do
    if not(evalfp(z)) then
      answer:=FALSE:
      break:
    end_if:
  end_for:
return(answer):
end_proc:

meijerG:=proc(as,bs,cs,ds,z)
  local as1,bs1,cs1,ds1,z1,m,n,p,q,delta,t,sigma,i,answer;
  begin
  as1:=float(as):
  bs1:=float(bs):
  cs1:=float(cs):
  ds1:=float(ds):
  z1:=float(z):
  if type(as1)=DOM_LIST and type(bs1)=DOM_LIST and type(cs1)=DOM_LIST and
      type(ds1)=DOM_LIST and forall([op(as1),op(bs1),op(cs1),op(ds1),z1]) then
    m:=nops(as1):
    n:=nops(bs1):
    p:=nops(cs1):
    q:=nops(ds1):
    delta:=m+n-p-q:
    if delta < 0 then
      answer:=Inf(as1,bs1,cs1,ds1,z1):
    elif delta > 0 then
      answer:=flip(as1,bs1,cs1,ds1,z1):
    else
      t:=abs(Re(z1)):
      if t<1 then
	answer:=Inf(as1,bs1,cs1,ds1,z1):
      elif t>1 then
	answer:=flip(as1,bs1,cs1,ds1,z1):
      else
	sigma:=_plus(Re(as1[i])$i=1..m)+_plus(Re(bs1[i])$i=1..n)
          -_plus(Re(cs1[i])$i=1..p)-_plus(Re(ds1[i])$i=1..q):
	if sigma>1 then
	  answer:=Inf(as1,bs1,cs1,ds1,z1):
	else
          // print("Unable to compute meijerG"):
	  return(procname(args()));
	end_if:
      end_if:
    end_if:
  else
    answer:=procname(as1,bs1,cs1,ds1,z1):
  end_if:
  return(answer):
end_proc:

// Evaluate MeijerG using L=L_infinity contour.
Inf:=proc(as,bs,cs,ds,z)
  local oldDIGITS,m,n,p,q,as1,bs1,cs1,ds1,e,a,i,j,answer,tol;
  save DIGITS;
  begin
  tol:=float(10^(-DIGITS)):
  oldDIGITS:=DIGITS:
  DIGITS:=DIGITS+3:
  m:=nops(as):
  n:=nops(bs):
  p:=nops(cs):
  q:=nops(ds):
  as1:=float(as):
  bs1:=float(bs):
  cs1:=float(cs):
  ds1:=float(ds):
  if CondC([op(cs1)],p) and CondA([op(as1)],[op(ds1)],m,q) and CondA([op(ds1)],[op(cs1)],q,p) and CondA([op(cs1)],[op(bs1)],p,n) then
  	answer:=slater(as1,bs1,cs1,ds1,z):
  else
    // Although I hate traperrors (tcs), in case the previous conditions
    // happened to miss: just in case it might work, try it:
    answer:=traperror(slater(as1,bs1,cs1,ds1,z)): 
    if iszero(answer) then
	return(slater(as1,bs1,cs1,ds1,z)):
    end_if:
    e:=epsilon(as1,bs1,cs1,ds1):
    answer:=0:
    DIGITS:=(p+1)*oldDIGITS:
    for j from 0 to 5 do
      DIGITS:=DIGITS+10:
      e:=e/100:
      as1:=[(as[i]+(i-1)*e)$i=1..m]:
      bs1:=[(bs[i]+(m+i-1)*e)$i=1..n]:
      cs1:=[(cs[i]+(m+n+i-1)*e)$i=1..p]:
      ds1:=[(ds[i]+(m+n+p+i-1)*e)$i=1..q]:
      a:=slater(as1,bs1,cs1,ds1,z):
      a:=float(a):
      if abs(a-answer) < 10*tol then
	break:
      end_if:
      answer:=a:
    end_for:
  end_if:
  return(answer):
end_proc:

// Starting epsilon.
epsilon:=proc(as,bs,cs,ds)
  local xs;
  begin
  //xs:=subs([op(as),op(bs),op(cs),op(ds)],0=null()):
  xs:=[op(as),op(bs),op(cs),op(ds)]:
  xs:=min(op(map(xs,abs))):
  if not(iszero(xs)) then
	xs*float(10^(-DIGITS)):
  else
	float(10^(-DIGITS)):
  end_if:
end_proc:

slater:=proc(as,bs,cs,ds,z)
  local m,n,p,q,ci,cstar,prod1,prod2,prod3,prod4,prod,lt1,lt2,f,i,j,answer;
  begin
  m:=nops(as):
  n:=nops(bs):
  p:=nops(cs):
  q:=nops(ds):
  answer:=0:
  for i from 1 to p do
    ci:=cs[i]:
    cstar:=subsop(cs,i=null()):
    prod1:=_mult((gamma(1-as[j]+ci))$j=1..m):
    prod2:=_mult((gamma(bs[j]-ci))$j=1..n):
    prod3:=_mult((gamma(cstar[j]-ci))$j=1..p-1):
    prod4:=_mult((gamma(1-ds[j]+ci))$j=1..q):
    prod:=(prod1*prod3)/(prod2*prod4):
    lt1:=[(1-as[j]+ci)$j=1..m,(1-bs[j]+ci)$j=1..n]:
    lt2:=[(1-cstar[j]+ci)$j=1..p-1,(1-ds[j]+ci)$j=1..q]:
    f:=float(hypergeom(lt1,lt2,(-1)^(n-p)*z)):
    answer:=answer+float(prod*(z^ci)*f):
  end_for:
  return(answer):
end_proc:

// Change contour from L[infinity] to L[-infinity].
flip:=proc(as,bs,cs,ds,z)
  local m,n,p,q,as1,bs1,cs1,ds1,z1,i,answer;
begin
  m:=nops(as):
  n:=nops(bs):
  p:=nops(cs):
  q:=nops(ds):
  as1:=[(1-cs[i])$i=1..p]:
  bs1:=[(1-ds[i])$i=1..q]:
  cs1:=[(1-as[i])$i=1..m]:
  ds1:=[(1-bs[i])$i=1..n]:
  z1:=1/z:
  answer:=Inf(as1,bs1,cs1,ds1,z1):
  return(answer):
end_proc:

unalias(hypergeom):
unalias(Hypergeom):
unalias(MeijerG):
unalias(meijerG):
unalias(typenumcomplex):
unalias(CondC):
unalias(CondA):

unalias(evalfp):
unalias(forall):
unalias(epsilon):
unalias(flip):
unalias(slate):
unalias(Inf):

