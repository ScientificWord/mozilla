// $Id: subset.mu 37636 2006-03-13 12:21:51Z rensmann $

// The operator subset and its negation

_subset := funcenv
(proc(A, B)
   name _subset;
   local newA, a;
 begin
   if A = B then
     return(TRUE)
   end_if;

  if A::dom = DOM_SET then
     if B::dom = DOM_SET then
       // because subset is used also in a ,,technical'' sense,
       // we have to create a special case that is mathematically wrong
       // e.g. {a} may be a subset of {b}
       return(bool(A minus B = {}))
     end_if;
     newA:= [];
     for a in A do
       case is(a in B)
         of FALSE do
           return(FALSE)
         of UNKNOWN do
           newA:= newA.[a]
       end_case
     end_for;
     case nops(newA)
       of 0 do
         return(TRUE)
       of 1 do
         return(op(newA, 1) in B)
       otherwise
         return(procname({op(newA)}, B))
     end_case;
   end_if;

   if A::dom::_subset <> FAIL then
     a := A::dom::_subset(A, B);
     if type(a)<>"_subset" then return(a); end_if;
   end_if;
   if B::dom::_subset <> FAIL then
     a := B::dom::_subset(A, B);
     if type(a)<>"_subset" then return(a); end_if;
   end_if;
 
   procname(args())

 end_proc,
 builtin(1100, output::Priority::Relation, " subset ", "_subset")):

_subset::TeX :=
(arg1, arg2, arg3) -> (generate::TeXoperator(" \\subset ", arg3,
                                             output::Priority::Relation, op(arg2))):

_subset::Content := (Out, data) ->
                     Out::Capply(Out::Csubset, map(op(data), Out)):
_subset::_not := () -> _notsubset(args()):
_subset::type := "_subset":
_subset::print := "_subset":

// _prsubset := funcenv
// (proc(A, B)
//    name _prsubset;
//    local sub;
//  begin
//    if A::dom::_prsubset <> FAIL then
//      return(A::dom::_prsubset(A, B));
//    elif B::dom::_prsubset <> FAIL then
//      return(B::dom::_prsubset(A, B));
//    elif A = B then
//      return(FALSE);
//    else
//      sub := _subset(A, B);
//      if sub::dom = DOM_BOOL then
//        return(sub);
//      else
//        procname(args());
//      end_if
//    end_if
//  end_proc,
//  builtin(1100, output::Priority::Relation, " prsubset ", "_prsubset")):
//
// _prsubset::TeX :=
// (arg1, arg2, arg3) -> (generate::TeXoperator(" \\subsetneq ", arg3,
//                                              output::Priority::Relation, op(arg2))):
//
// _prsubset::Content := (Out, data) ->
//                      Out::Capply(Out::Cprsubset, map(op(data), Out)):
// _prsubset::_not := () -> _notprsubset(args()):
// _prsubset::type := "_prsubset":
// _prsubset::print := "_prsubset":

_notsubset := funcenv
(proc(A, B)
   name _notsubset;
   local sub;
 begin
   sub := _subset(A, B);
   if type(sub) <> "_subset" then
     return(not sub)
   else
     procname(op(sub))
   end_if
 end_proc,
 ex -> hold(_not)(hold(_subset)(op(ex)))):

_notsubset::TeX :=
(arg1, arg2, arg3) -> (generate::TeXoperator(" \\not\\subset ", arg3,
                                             output::Priority::Relation, op(arg2))):

_notsubset::Content := (Out, data) ->
                       Out::Capply(Out::Cnotsubset, map(op(data), Out)):
_notsubset::_not := () -> _subset(args()):
_notsubset::type := "_notsubset":
_notsubset::print := "_notsubset":

// _notprsubset := funcenv
// (proc(A, B)
//    name _notprsubset;
//    local sub;
//  begin
//    sub := _prsubset(A, B);
//    if sub::dom = DOM_BOOL then
//      return(not sub);
//    else
//      procname(args());
//    end_if
//  end_proc,
//  ex -> hold(_not)(hold(_prsubset)(op(ex)))):
//
// _notprsubset::TeX :=
// (arg1, arg2, arg3) -> (generate::TeXoperator(" \\not\\subsetneq ", arg3,
//                                              output::Priority::Relation, op(arg2))):
//
// _notprsubset::Content := (Out, data) ->
//                          Out::Capply(Out::Cnotprsubset, map(op(data), Out)):
// _notprsubset::_not := () -> _prsubset(args()):
// _notprsubset::type := "_notprsubset":
// _notprsubset::print := "_notprsubset":

null():
