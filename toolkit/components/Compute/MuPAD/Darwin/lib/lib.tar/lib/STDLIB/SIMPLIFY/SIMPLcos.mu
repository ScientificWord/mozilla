// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	simplify/cos -- the function attribut "cos" for simplify

 	tries combine( normal(%),sincos ).
--*/

simplify:=slot(simplify,"cos",proc(a)
				    name simplify::cos;
begin
   if type(a) = "_plus" then
      // first try to express all in terms of sin(..) or cos(..) 
      if has(a,hold(sin)) and has(a,hold(cos)) then
	 a:=misc::maprec(a,{"_power"}=proc() begin if testtype(op(args(1),2)/2,Type::PosInt)
	   and type(op(args(1),1))="cos" then (1-sin(op(args(1),[1,1]))^2)^
		(op(args(1),2)/2)
	   else args(1) end_if end_proc );
	 if has(a,hold(cos)) then 
	    a:=misc::maprec(args(1),{"_power"}=proc() begin if testtype(op(args(1),2)/2,
		Type::PosInt) and type(op(args(1),1))="sin" then
			(1-cos(op(args(1),[1,1]))^2)^(op(args(1),2)/2)
	   	else args(1) end_if end_proc );
	    if has(a,hold(sin)) then a:=args(1) end_if;
         end_if;
      end_if;
      a:=normal(a);
      combine(a,hold(sincos));
      if nops(indets(%,RatExpr))<=nops(indets(a,RatExpr)) then a:=% end_if;
   end_if;
   a
end_proc):

// end of file 
