// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	igamma/conjugate -- the function attribut "conjugate" for igamma
--*/

igamma:= slot(igamma, "conjugate",
             proc(a, x) begin 
              if is(x > 0) = TRUE
                 then return(igamma(conjugate(a), x))
                 else return(hold(conjugate)(hold(igamma)(a,x)));
              end_if;
             end_proc  ):

// end of file 
