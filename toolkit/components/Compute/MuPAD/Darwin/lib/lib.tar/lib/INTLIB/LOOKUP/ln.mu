// $Date: 2002-02-01 14:17:30 +0100 (Fri, 01 Feb 2002) $ $Author: ccr $ $Revision: 17070 $ 

intlib::lookupln:=proc(f)
save _m_,a,b,g,r,i;
begin
  delete _m_,a,b,g,r,i;
  case type(f) of "_mult" do
      // case x^a*ln(g)^_m_ 
      if intlib::matchassign(f,_X^_pattern(a,not has,_X)
	*ln(_pattern(g))^_pattern(_m_,not has,_X)) then return((
         if _m_=1 then
	    // case x^a*ln(b+_m_*x) 
	    if intlib::matchassign(g,_pattern(b,
	      proc() begin not (has(args(1),_X) or iszero(args(1))) end_proc )
	      +_pattern(hold(_m_),not has,_X)*_X) then return((
	      if is(a,Type::NonNegInt)=TRUE then
		      ((_X^(a+1)-(-b/_m_)^(a+1))*ln(b+_m_*_X)
		      -(-b/_m_)^(a+1)*sum((-_m_*_X/b)^r/r,r=1..a+1))/(a+1)
	      elif is((a:=-a-1),Type::PosInt)=TRUE then
		 ((-_X^(-a)*ln(b+_m_*_X)+
	          (-_m_/b)^a*(ln(b/_X+_m_)+sum((-b/_m_/_X)^r/r,r=1..a-1)))/a)
	      else FAIL end_if))
            // case x^_m_*ln((x+b)/(x-b)) 
	    elif is(a,Type::NonNegInt)=TRUE and intlib::matchassign(
	       g,(_X+_pattern(b,not has,_X))/(_X-_pattern(b,not has,_X))) then
	         _m_:=a+1; a:=b; (a^_m_-_X^_m_)*ln(_X-a)/_m_+
		      (_X^_m_-(-a)^_m_)*ln(_X+a)/_m_+2*a^_m_/_m_*
		      sum((_X/a)^(_m_+1-2*r)/(_m_+1-2*r),r=1.._m_ div 2)
	    // case x^_m_*ln(x+sqrt(x^2+b)) 
	    elif intlib::matchassign(g,_X+(_X^2+_pattern(b,not has,
		   _X))^(1/2)) then
	       if a=1 then -_X/4*(g-_X)+(b/4/_X+_X/2)*f
	       elif a=-2 then -ln((g-_X+b^(1/2))/_X)/b^(1/2)-_X*f
	       else FAIL end_if
	    // x^a*ln(x^2-b) 
	    elif not has((b:=_X^2-g),_X) and is(a,Type::NonNegInt)=TRUE then
	       a:=a+1; b^(1/2);
	       1/a*(-ln(_X-%)*%^a-(-%)^a*ln(_X+%)+_X^a*ln(g)-
		   2*sum(b^i*_X^(a-2*i)/(a-2*i),i=0..floor((a-1)/2)))
            else FAIL end_if
	 elif g=_X and _m_=-1 then    // int(x^a/ln(x),x)=-Ei((-a-1)*ln(x)) 
            if a=-1 then ln(ln(_X)) else -Ei((-a-1)*ln(_X)) end_if
         elif (g=_X and is(_m_,Type::NonNegInt))=TRUE 
	 then if a=-1 then ln(_X)^(_m_+1)/(_m_+1)
              else (-1)^_m_*fact(_m_)*_X^(a+1)/(a+1)^(_m_+1)
		*sum((-(a+1)*ln(_X))^i/fact(i),i=0.._m_) end_if
         else FAIL end_if))
      end_if;
      break;
   of "_power" do
      if op(f,1)=ln(_X) and is((_m_:=op(f,2)),Type::NonNegInt)=TRUE then
         return((-1)^_m_*fact(_m_)*_X*sum((-ln(_X))^i/fact(i),i=0.._m_))
      end_if;
      break;
   of "ln" do
      if intlib::matchassign(op(f),_X+(_X^2+_pattern(a,not has,_X))^(1/2))
      then return(_X-op(f)+_X*f)
      end_if
   end_case;
   FAIL
end_proc:
intlib::lookupln(1/ln(_X)):=-Ei(-ln(_X)):
intlib::lookupln(ln(_X)/(1-_X)):=dilog(_X):
intlib::lookupln(ln(1-_X)/_X):=-dilog(1-_X):
