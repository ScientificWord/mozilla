// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ #

// Fraction -- expression to test for fraction integers

Type::Fraction:=
    new(property::NRange,
	"Fraction",
	proc(t,x) 
	  option noDebug;
	  name Type::Fraction;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if domtype(x) = DOM_RAT then
		TRUE
	    else
		FAIL
	    end_if;
	end_proc,
	FALSE, FALSE,
	["Fraction", property::Null]):
