// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	igamma/rectform -- the function attribut "rectform" for igamma
--*/

igamma:= slot( igamma, "rectform", proc(a,xx)
        local t, x;
    begin
        x:= rectform::new(xx);

        if extop(x,3) <> 0 or not iszero(extop(x,2)) then
            new(rectform,0,0,hold(igamma)(a,args(2)))
        else
            t:= extop(x,1);
            if domtype(t) = DOM_FLOAT then
                rectform::new(igamma(a,t))
            else
                new(rectform,igamma(a,t),0,0)
            end_if
        end_if
    end_proc
):

// end of file 
