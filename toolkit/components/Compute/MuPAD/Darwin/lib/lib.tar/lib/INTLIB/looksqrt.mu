// $Date: 2003-04-09 15:24:38 +0200 (Wed, 09 Apr 2003) $ $Author: ccr $ $Revision: 22555 $ 

/* intlib::looksqrt(p,f,x) computes int(p*sqrt(f),x) where p and f are
  polynomials in x:

>> intlib::looksqrt(1,a+b*x,x);

                                         3/2
                              2 (a + b x)
                              --------------
                                   3 b

>> intlib::looksqrt(x^3,a+b*x^2,x);

                                2 3/2    2         2 3/2
                    2 a (a + b x )      x  (a + b x )
                  - ----------------- + ----------------
                              2               5 b
                          15 b
*/

intlib::looksqrt :=  //necessary, since e.g. 1-x, 1-x^2, x are otherwise
  proc(p,f,x)        // not correctly treated.
    local i,n;
  begin 
    if iszero(p) then return(0) end_if;
    if (n:=nterms(p,[x]))>1 then
      // ccr 19.2.02: reactived the following line, discarding
      // Winfrieds lookup1. This seems to fix various problems.
      _plus(intlib::looksqrt1(nthmonomial(p,[x],i),f,x) $ i=1..n)

      // Winfried: I use the following line instead of the previous
      // one to avoid complex expressions with ln.
      // _plus(intlib::lookup1(nthmonomial(p,[x],i),f,x) $ i=1..n)
    else
      intlib::looksqrt1(p,f,x)
    end_if
  end_proc:

//-----------------------------------------------------
// int(p*sqrt(f),x) 
intlib::looksqrt1 := proc(p,f,x) local n,k,a,q,c,df,b;
begin 
   if iszero(p) then return(0) end_if;
   n:=degree(p,[x]); k:=degree(f,[x]);
   if n<k-1 then
      // impossible if k=1 
      if k=2 then // necessary n=0 
         c:=polylib::lcoeff(f,[x]); df:=diff(f,x); a:=coeff(f,[x],0);
         b:=coeff(f,[x],1);
         p*(1/4*df*f^(1/2)/c+ln(df/2/c^(1/2)+f^(1/2))
	*(a/c^(1/2)/2-b^2/c^(3/2)/8))
      else FAIL // hold(int)(p*sqrt(f),x)
      end_if
   elif n=k-1 then
      q:=expand(3/2*diff(f,x)); // diff(f^(3/2),x)=f^(1/2)*q 
      a:=polylib::lcoeff(q,[x]);		
      q:=q-polylib::lmonomial(q,[x]); // diff(f^(3/2),x)=f^(1/2)*(a*x^(k-1)+q) 
      a:=polylib::lcoeff(p,[x])/a;
      a*f^(3/2)-a*intlib::looksqrt(q,f,x)
   else
      q:=expand((n-k+1)*f+3/2*x*diff(f,x)); // deg(q)=k 
      // diff(x^(n-k+1)*f^(3/2),x) = x^(n-k)*f^(1/2)*q 
      a:=polylib::lcoeff(q,[x]);
      q:=q-polylib::lmonomial(q,[x]);
      /* diff(x^(n-k+1)*f^(3/2),x) = x^(n-k)*f^(1/2)*(a*x^k+q)
                                  = a*x^n*f^(1/2)+q*x^(n-k)*f^(1/2) */
      a:=polylib::lcoeff(p,[x])/a;
      p:=expand(p-polylib::lmonomial(p,[x])-a*q*x^(n-k));
      a*x^(n-k+1)*f^(3/2)+intlib::looksqrt(p,f,x)
   end_if
end_proc:

//-----------------------------------------------------
// int(p/sqrt(f),x) 
intlib::looksqrt2:=proc(p,f,x) local n,k,a,b,c,q,discr;
begin
   if iszero(p) then return(0) end_if;
   n:=degree(p,[x]); k:=degree(f,[x]);
   if n=FAIL or k=FAIL then // p or f is not a polynomial in x
     return(FAIL)
   end_if;
   if n<k-1 then // impossible if k=1 
      if k=2 then // necessary n=0 
         //c:=polylib::lcoeff(f,[x]); b:=coeff(f,[x],1)/c; a:=coeff(f,[x],0)/c;
         //a:=b^2-4*a;
         //if is(a>=0)<>TRUE then
         //  a:=2/sqrt(a); p/c^(1/2)*arccosh(a*x+a*b/2)
         //else
         //  p*ln(c^(1/2)*(x+b/2)+f^(1/2))/c^(1/2)
         //end_if
        c:=polylib::lcoeff(f,[x]); b:=coeff(f,[x],1); a:=coeff(f,[x],0);
        discr:=4*a*c-b^2;
        // see Gradshteyn,Ryzhik 2.261
        if is(c>0)=TRUE then 
          if is(discr>0)=TRUE then
            //p*1/sqrt(c)*arcsin(I*(2*c*x+b)/sqrt(discr))/I
            // or equivalent:
            p*1/sqrt(c)*ln((2*c*x+b)/sqrt(discr)+sqrt((2*c*x+b)^2/discr+1))
          elif is(discr=0)=TRUE then
            p*1/sqrt(c)*ln(2*c*x+b)*sign(x)
	  else // not elif is(discr<0)=TRUE!
	    p*1/sqrt(c)*ln(2*sqrt(c*f)+2*c*x+b)
          end_if
	elif is(c<0)=TRUE then
	  if is(discr=0)=TRUE then FAIL
	  else
	    p*(-1)/sqrt(-c)*arcsin((2*c*x+b)/sqrt(-discr))
	  end_if;
        else //hold(int)(p/sqrt(f),x)
          //alternative if previous is conditions returns UNKNOWN
          b:=b/c; a:=a/c;
          a:=b^2-4*a;
          if is(a>=0)<>TRUE then
            a:=2/sqrt(a); p/c^(1/2)*arccosh(a*x+a*b/2)
          else p*ln(c^(1/2)*(x+b/2)+f^(1/2))/c^(1/2) end_if  
        end_if
      else FAIL // hold(int)(p/sqrt(f),x)
      end_if
   else // (x^j*f^(1/2))' = x^(j-1)/sqrt(f)*(j*f+1/2*x*f') 
      q:=expand((n-k+1)*f+1/2*x*diff(f,x)); // deg(q)=k 
      a:=polylib::lcoeff(q,[x]);
      q:=q-polylib::lmonomial(q,[x]);
      a:=polylib::lcoeff(p,[x])/a;
      p:=expand(p-polylib::lmonomial(p,[x])-a*q*x^(n-k));
      a*x^(n-k+1)*f^(1/2)+intlib::looksqrt2(p,f,x)
   end_if
end_proc:
