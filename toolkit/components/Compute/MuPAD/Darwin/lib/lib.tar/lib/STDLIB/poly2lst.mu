// kg, 26/06/96 

/*++
poly2list -- convert polynomial into term list

poly2list(p)
poly2list(e [,v] [,r])

p - polynomial (DOM_POLY)
e - polynomial expression
v - variable list
t - coefficient ring

poly2list returns the term list of the given polynomial or FAIL
if an expression can not be converted into a polynomial.
++*/

poly2list:= proc(p) local i; begin 
    if testargs() then
        if args(0) = 0 then error("wrong no of args") end_if;
        if domtype(p) = DOM_POLY then
            if args(0) <> 1 then error("wrong no of args") end_if
        else
            if args(0) > 3 then error("wrong no of args") end_if
        end_if
    end_if;
    
    case domtype(p)
    of DOM_POLY do
        if nops(op(p,2)) = 1 then
            [ [ nthcoeff(p,i), degree(nthterm(p,i)) ]
              $ i=1..nterms(p) ]
        else
            [ [ nthcoeff(p,i), degreevec(nthterm(p,i)) ]
              $ i=1..nterms(p) ]
        end_if;
        break;
    of DOM_FAIL do
        FAIL;
        break;
    otherwise
        poly2list(poly(args()))
    end_case
 end_proc :

// end of file 
