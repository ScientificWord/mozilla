// $Date: 2001-11-07 17:10:10 +0100 (Wed, 07 Nov 2001) $ $Author: stefanw $ $Revision: 15413 $ 

// kg, 19/01/94 

/*++
denom -- the denominator of a rational expression

denom(x)

x - expression
++*/

denom:=
proc(x)
begin
  if args(0) <> 1 then
    error("wrong no of args")
  end_if;
  if x::dom::denom <> FAIL then
    return(x::dom::denom(x))
  end_if;
    if testargs() then 
      if not testtype(x, Type::Arithmetical) then
        error("no arithmetical expression")
      end_if;
    end_if;


// main part (old stdlib::denom)
  
  case type(x)
    of DOM_INT do
      1;
      break;
    of DOM_RAT do
      op(x,2);
      break;
    of DOM_COMPLEX do
      case domtype(op(x,1))
        of DOM_INT do
          case domtype(op(x,2))
            of DOM_INT do
              1;
              break;
            of DOM_RAT do
              op(x,[2,2]);
              break;
            otherwise
              1.0;
          end_case;
          break;
        of DOM_RAT do
          case domtype(op(x,2))
            of DOM_INT do
              op(x,[1,2]);
              break;
            of DOM_RAT do
              op(x,[1,2])*op(x,[2,2]) /
              igcd(op(x,[1,2]), op(x,[2,2]));
              break;
            otherwise
              1.0;
          end_case;
          break;
        otherwise
          1.0;
      end_case;
      break;
    of "_mult" do
      map(x, denom);
      break;
    of "_power" do
        if domtype(op(x,2)) = DOM_INT then
            if op(x,2) > 0 then
                denom(op(x,1)) ^ op(x,2)
            else
                numer(op(x,1)) ^ (-op(x,2))
            end_if
        else
            normal(x, List)[2]
        end_if;
        break;
    otherwise
        normal(x, List)[2];
    end_case
 end_proc :

// end of file 
