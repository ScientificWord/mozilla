/*****************************************************************************
  $Id: TableOf.mu,v 1.2 2003/05/03 22:22:08 nthiery Exp $
  File:		lib/TYPE/TableOf.mu
  Authors:	Nicolas M. Thi�ry <nthiery@users.sourceforge.net>
  Created:	26/09/2002
*****************************************************************************/

Type::TableOf :=
proc(Tindex=Type::AnyType, Tentries=Type::AnyType)
    option noDebug;
begin
    new(Type, "TableOf",
	proc(T,t)
	  name Type::TableOf;
	  option noDebug;
	  local res, eq;
	begin
	    if _lazy_or(args(0)<>2, domtype(t)<>DOM_TABLE) then
		return(FALSE);
	    end_if;
	    for eq in t do
		if (res:=testtype(lhs(eq), op(T,1))) <> TRUE then
		    return(res);
		end_if;
		if (res:=testtype(rhs(eq), op(T,2))) <> TRUE then
		    return(res);
		end_if;
	    end_for;
	    return(TRUE);
	end_proc,
	[Tindex, Tentries], FALSE);
end_proc:
