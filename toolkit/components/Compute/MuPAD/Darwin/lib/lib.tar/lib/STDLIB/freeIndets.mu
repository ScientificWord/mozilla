// $Date: 2006-01-05 14:41:32 +0100 (Thu, 05 Jan 2006) $ $Author: rensmann $  $Revision: 36092 $
/*
    freeIndets(a)

    a - any object

    determines the free identifiers contained in a
    by default, every identifier in a is free, but domains and function
    environments may overload this


*/

freeIndets:=
proc(a)
  local f;
begin
  if args(0) <> 1 then
    error("Wrong number of arguments")
  end_if;

  // overloading for domains
  if a::dom::freeIndets <> FAIL then
    return(a::dom::freeIndets(a))
  end_if;

  // overloading for function environments
  if type((f:=eval(op(a, 0)))) = DOM_FUNC_ENV and f::freeIndets <> FAIL then
    return(f::freeIndets(a))
  end_if;

  if contains({DOM_LIST, DOM_SET, DOM_EXPR}, domtype(a)) then
    _union(op(map({op(a)}, freeIndets))) minus Type::ConstantIdents;
  else
    // default:
    indets(a) minus Type::ConstantIdents;
  end_if
end_proc: