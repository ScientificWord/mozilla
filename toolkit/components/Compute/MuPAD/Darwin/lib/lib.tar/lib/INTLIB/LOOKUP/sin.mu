// $Date: 2002-10-21 09:06:45 +0200 (Mon, 21 Oct 2002) $ $Author: tonner $ $Revision: 20531 $ 

intlib::lookupsin :=
proc(f)
  save a,b,c,xx,g,m,r;
  local F, res;
begin
   delete a,b,c,xx,g,m,r;
   if hastype(f,"cos") then
     F:=intlib::lookupsincos(f);
     if F<>FAIL then return(F) end_if;
   end_if;
   if type(f)="_power" then
      // case 1/(a+b*sin(c*x)+g*cos(x)) 
      if op(f,2)=-1 and intlib::matchassign(op(f,1),_pattern(a,not has,_X)+
	_pattern(b,not has,_X)*sin(_pattern(c,not has,_X)*_X)+
	_pattern(g,not has,_X)*cos(_X)) then return((
         if g=0 then
	    F:=sqrt(a^2-b^2); 
	    if a=0 then ln((1-cos(c*_X))/(1+cos(c*_X)))/2/c
            elif F<>0 then
              if is(a,Type::Real)=TRUE and is(b,Type::Real)=TRUE then 
                 if is(a^2>b^2) then
                    2/c/F*arctan((a*tan(c*_X/2)+b)/F)
                 else // a^2<>b^2
                    1/c/sqrt(b^2-a^2)*ln((a*tan(c*_X/2)+b-sqrt(b^2-a^2))/
                                         (a*tan(c*_X/2)+b+sqrt(b^2-a^2)))
                 end_if;
              else // This seems to be wrong! return FAIL would be better
                //2*arctan(a*tan(c*_X/2)+b/%)/%/c
                2*arctan((a*tan(c*_X/2)+b)/%)/%/c
              end_if
            else  
              -2/a/(b/a+tan(c*_X/2))/c 
              //eval(subs(intlib::lookupsin(1/(1+b/a*sin(_X))),_X=c*_X)/c/a);
            end_if
         elif c=1 then
            c:=g;
            (a^2-b^2-c^2)^(1/2);
            if %<>0 then 2*arctan((b+(a-c)*tan(_X/2))/%)/% else FAIL end_if
         else FAIL end_if))
      // case 1/(1+b*sin(a*x))^2 
      elif op(f,2)=-2 and intlib::matchassign(op(f,1),1+_pattern(b,not has,_X)*
	sin(_pattern(a,not has,_X)*_X)) then
	b*tan(PI/4-a*_X/2)^b;
	return((if b=1 or b=-1 then -%/2/a-%^3/6/a else FAIL end_if))
      // case sin(x)^n: int(sin(x)^n,x)=-int(cos(u)^n,u) with x=PI/2-u 
      elif op(f,1)=sin(_X) and not has(op(f,2),_X) then
         intlib::lookupcos(cos(_X)^op(f,2));
         if %<>FAIL then return(-subs(%,_X=PI/2-_X)) end_if
      end_if
   elif type(f)="_mult" then
      // case g*sin(a*x) 
      if intlib::matchassign(f,sin(_pattern(a,not has,_X)*_X)*_pattern(g))
      then
         // case sin(a*x)/(b+c*sin(a*x)) = 1/c - 1/(1+c/b*sin(a*x)) 
	 if intlib::matchassign(g,1/(_pattern(b,not has,_X)
		+_pattern(c,not has,_X)*sin(a*_X))) then 
	    1/(c+c^2/b*sin(a*_X));
	    if type(%)="_power" then return(1/c*_X-intlib::lookupsin(%)) end_if
	 /* case sin(a*x)/(1+b*sin(a*x))^c = 1/(1+b*sin(a*x))^(c-1)
	   -1/(1+b*sin(a*x))^c */
	 elif intlib::matchassign(g,1/(1+_pattern(b,not has,_X)*sin(a*_X))^
	   _pattern(c,testtype,Type::PosInt)) then
	    return(intlib::lookupsin(1/(1+b*sin(a*_X))^(c-1))
	    -intlib::lookupsin(1/(1+b*sin(a*_X))^c))
         // case x^m*sin(a*x) 
         //elif intlib::matchassign(g,_X^_pattern(m,is,Type::PosInt)) then
         elif intlib::matchassign(g,_X^_pattern(m,not has,_X)) then
           if m=-1 then return(Si(a*_X))
           elif is(m,Type::PosInt)=TRUE then
             return(sin(a*_X)*(_plus((-1)^r*a^(-2-2*r)*_X^(m-1-2*r)*fact(m)
                                     /fact(m-1-2*r) $ r=0..(m-1) div 2))
                    -cos(a*_X)*(_plus((-1)^r*a^(-1-2*r)*_X^(m-2*r)*fact(m)
                                      /fact(m-2*r) $ r=0..m div 2)))
           end_if;
         elif not has((b:=subs(g,sin(a*_X)^2=1-xx^2,cos(a*_X)=xx)/a),_X) then
           res := intlib::int(b,xx);
           if type(res) <> "int" then
             return(-subs(res,xx=cos(a*_X)))
           else
             return(FAIL)
           end_if
         end_if
      // case g/(1+b*sin(a*x)) 
      elif intlib::matchassign(f,_pattern(g)/(1+_pattern(b,not has,_X)
	*sin(_pattern(a,not has,_X)*_X))) then
	 // case 1/cos(a*x)/(1+b*sin(a*x)) 
	 if g=1/cos(a*_X) then
	    return((if b=1 or b=-1 then
	      (ln(tan(PI/4+a*_X/2))-b/(1+b*sin(a*_X)))/2/a else FAIL end_if))
	 // case tan(a*x)/(1+b*sin(a*x)) 
	 elif g=tan(a*_X) then
	    return((if b=1 or b=-1 then
	      (b*ln(tan(PI/4+a*_X/2))+1/(1+b*sin(a*_X)))/2/a else FAIL end_if))
         // case x/(1+b*sin(a*x)) 
         elif g=_X then
            return((if b=1 or b=-1 then -b*f*cos(a*_X)/a+ln(1+b*sin(a*_X))/a^2
            else FAIL end_if))
         end_if
      end_if
   end_if;
   //intlib::lookupsincos(f)
   FAIL  
end_proc:
intlib::lookupsin((1+sin(_X))^(1/2)):=2*(sin(_X)-1)*(1+sin(_X))^(1/2)/cos(_X):
intlib::lookupsin((1-sin(_X))^(1/2)):=2*(sin(_X)+1)*(1-sin(_X))^(1/2)/cos(_X):
intlib::lookupsin((1-sin(_X))^(-1/2)):=arctanh((1+sin(_X)+cos(_X))/2/
	(1+cos(_X))^(1/2))*(sin(_X)+cos(_X)-1)/sin(_X)
	*((1+cos(_X))/(1-sin(_X)))^(1/2):
intlib::lookupsin((1+sin(_X))^(-1/2)):=arctanh((1-sin(_X)+cos(_X))/2/
        (1+cos(_X))^(1/2))*(-sin(_X)+cos(_X)-1)/sin(_X)
        *((1+cos(_X))/(1+sin(_X)))^(1/2):
intlib::lookupsin((1-sin(_X)^2)^(1/2)):=sin(_X)/cos(_X)*(cos(_X)^2)^(1/2):
//intlib::lookupsin(1/(1+sin(_X))):=(tan(_X/2)+1)^(-1)*(-2)://-tan(PI/4-_X/2):
//intlib::lookupsin(1/(1-sin(_X))):=(tan(_X/2)-1)^(-1)*(-2)://tan(PI/4+_X/2):

intlib::lookupsincos:=proc(_f_) local g,intg;
save a,b,c,d,f,p;			
begin
   delete a,b,c,d,f,p;			
   g:=combine(_f_,sincos);
   if intlib::matchassign(g,_pattern(p,not has,_X)*
      sin(_pattern(a,not has,_X)*_X)/_X) then return(p*Si(a*_X))
   end_if;
   intg:=intlib::sincos(g,_X);
   if not has(intg,FAIL) then return(intg)
   elif length(g)<length(_f_) then // avoids loops between int and lookup 
      if type((intg:=intlib::int(g,_X)))<>"int" then
         return(intlib::to_sincos(intg,_X))
      end_if
   end_if;
   // case 1/(b+c*cos(a*x)+d*sin(a*x)), p constant 
   if intlib::matchassign(g,_pattern(p,not has,_X)/
          (_pattern(b,not has,_X)+
           _pattern(c,not has,_X)*cos(_pattern(a,not has,_X)*_X)+
           _pattern(d,not has,_X)*sin(_pattern(f,not has,_X)*_X)))
      then
        if a=f and a<>0 and b<>0 and c<>0 and d<>0 and p<>0 then
          if is(d<0)=TRUE then p:=-p; b:=-b; c:=-c; d:=-d; end_if;
          intg:=intlib::lookupsin(1/(b+sqrt(c^2+d^2)*sin(a*_X)));
          if intg<>FAIL then
            intg:=eval(subs(p*intg,_X=_X+arctan(c/d)/a));
            return(intg)
          end_if;
        end_if;
     end_if;                     
   FAIL
end_proc:

intlib::sincos := proc(f,x) // integrates a*sin(b*x) 
local b;
begin
   if not has(f,x) then return(f*x) end_if;
   case type(f)
   of "_plus" do return(map(f,intlib::sincos,x))
   of "sin" do b:=op(f)/x; if not has(b,x) then return(-cos(b*x)/b) else return(FAIL) end_if; break;
   of "cos" do b:=op(f)/x; if not has(b,x) then return(sin(b*x)/b) else return(FAIL) end_if; break;
   of "_mult" do
      b:=select(f,has,x);
      if type(b)<>"_mult" then // only one factor contains x 
         return(f/b*intlib::sincos(b,x))
      end_if
   end_case;
   FAIL
end_proc:

// converts exp(n*I*x) to cos(n*x)+I*sin(n*x) 
intlib::to_sincos := proc(f,x) local n;
begin
   case type(f)
   of DOM_LIST do
   of "_equal" do
   of "ln" do
   of "_mult" do
   of "_plus" do return(map(f,intlib::to_sincos,x))
   of "exp" do
      n:=op(f)/I/x;
      if not has(n,x) and type(n)<>DOM_COMPLEX then return(cos(n*x)+I*sin(n*x))
      else return(f)
      end_if;
      break;
   of "_power" do
      if type(op(f,1))="exp" and type(op(f,2))=DOM_INT then
         return(intlib::to_sincos(exp(op(f,[1,1])*op(f,2)),x))
      else return(intlib::to_sincos(op(f,1),x)^op(f,2))
      end_if;
      break;
   otherwise f
   end_case
end_proc:

