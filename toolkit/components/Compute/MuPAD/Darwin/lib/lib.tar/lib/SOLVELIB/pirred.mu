/* */
/* $Date: 2005-08-12 18:22:53 +0200 (Fri, 12 Aug 2005) $ $Author: stefanw $ $Revision: 32628 $ */
/* */
/* zimmerma, 14/12/95 */

/*--
	solvelib::solve_poly_irred

   solve irreducible polynomials and polynomials we did not want to factor

--*/

solvelib::solve_poly_irred :=
proc(p,x) /* p is irreducible */
  local a,b,c,d,f,l,l2, s, k, dummy,
  lev:DOM_INT,
  multi: DOM_BOOL,
  options: DOM_TABLE,
  // flattenSets: DOM_PROC,
  solve_inner: DOM_PROC,
  halveExponent: DOM_PROC,
  baseSet: solvelib::BasicSet,
  pw;

  save MAXEFFORT;
  
begin
  options:=solvelib::getOptions(args(3..args(0)));
  lev:=options["MaxDegree"];
  multi:=options["Multiple"];
  pw:= if options["IgnoreSpecialCases"] then
         solvelib::ignoreSpecialCases
       else
         piecewise::new
       end_if;

  if options["Real"] then
    baseSet:= R_
  else
    baseSet:= C_
  end_if;
  
  d:=degree(p,x);
  userinfo(2,"solving irreducible polynomial of degree ".expr2text(d));
  userinfo(10, "Polynomial is ".expr2text(p));
  userinfo(10, "Variable to solve for: ".expr2text(x));
  userinfo(10, "Options are ".expr2text(op(options)));
  if multi then
    s:=Dom::Multiset
  else
    s:=DOM_SET
  end_if;
  if d=0 then
    expr(coeff(p,x,0));
    // multi: deliver an error instead of C_ (or R_) ?
    pw([%=0, baseSet],[%<>0, {}])
  elif d = 1 then
    if op(p,2) = [x] then
      l:= -coeff(p, x, 0);
      d:= coeff(p, x, 1)
    else
      l:= -expr(coeff(p, x, 0));
      d:= expr(coeff(p, x, 1))
    end_if;
    // we are solving d*x - l = 0, so
    // x = l/d is the solution
    // we might try to simplify l/d ?!
    case traperror((f:= normal(l/d)))
      of 0 do
        break;
      of 260 do
        // Division by zero -> d was zero
        return(pw([l=0, baseSet],[l<>0, {}]))
      otherwise
        // do not catch other errors
        lasterror()
    end_case;
    if length(f) >= length(l/d) then
      f:= l/d
    end_if;
    pw([d<>0, s(f)],
       [d=0 and l=0, baseSet],
       [d=0 and l<>0, {}])
  elif d = 2 and lev >= 2 then
    a:=coeff(p,x,2);
    b:=coeff(p,x,1);
    c:=coeff(p,x,0);
    if op(p,2)<>[x] then
      a:=expr(a); b:=expr(b); c:=expr(c)
    end_if;

    d:= b^2 - 4*a*c;
    l:= length(d);
    if MAXEFFORT > 20*l then
      d:=expr(factor(expand(d), MaxDegree = 1));
      MAXEFFORT:= MAXEFFORT - 10*l
    end_if;

    if options["Real"] then
      MAXEFFORT:= MAXEFFORT/4;
      return(
      pw([a=0 and b=0 and c=0, baseSet],
         [a=0 and b=0 and c<>0 or a<>0 and d<0, {}],
         [a=0 and b<>0, s(-c/b)],
         [a<>0 and d>=0, s((-b+sqrt(d))/2/a,(-b-sqrt(d))/2/a)])
             )
    end_if;
    
    /* if d=X*Y^2 we can choose d=X^(1/2)*Y which is prettier
       in most cases  */

    halveExponent:=
    proc(pow: "_power")
    begin
      op(pow, 1)^(op(pow,2)/2)
    end_proc;
    

    if type(d) = "_power" and type((l:=op(d, 2)/ 2)) = DOM_INT then
      d:= op(d, 1)^l
    elif type(d) = "_mult" then
      [l, l2, dummy] := split([op(d)],
                             proc(fctor)
                               begin
                                 type(fctor) = "_power" and
                                 type(op(fctor, 2)/2) = DOM_INT
                             end_proc
                             );
      if nops(l) > 0 then
        d:= _mult(op(map(l, halveExponent))) * sqrt(_mult(op(l2)))
      else
        d:= sqrt(d)
      end_if
    else
      d:= sqrt(d)
    end_if;


    if is(b=0)<>TRUE then
      // to avoid division by zero 
      pw([a=0 and b=0 and c=0, baseSet],
                 [a=0 and b=0 and c<>0, {}],
                 [a=0 and b<>0, s(-c/b)],
                 [a<>0, simplify(s((-b+d)/2/a,(-b-d)/2/a))])
    else
      pw([a=0 and c=0, baseSet],
                 [a=0 and c<>0, {}],
                 [a<>0, simplify(s((-b+d)/2/a,(-b-d)/2/a))])
    end_if
  elif d=3 and lev>=3 then
    pw([coeff(p,x,3)=0, solvelib::solve_poly(divide(p, poly(x^3),
                                                    hold(Rem)), x, options) ],
       [coeff(p,x,3)<>0, solvelib::solve_poly3(p,x,options)  ])
  else /* d>=4 */
    // before calling polylib::decompose, find out the gcd of exponents:
    // if it is greater than 1, we get an obvious decomposition
    l:= poly2list(p);
    a:= igcd(op(map(l, op, 2)));
    if a > 1 then
      // p is a polynomial in x^l, p = f(x^l) for some f
      // thus, p(x) = 0 iff f(x^l) = 0 iff x^l = y for some solution y
      // of f(y) = 0
      f:= map(l, term -> [op(term, 1), op(term,2) div a]);
      f:= poly(f, [x]);
      b:= solvelib::solve_poly_irred(f, x, options);
      c:= solve(`#y`^a - x, `#y`, options);
      assert(domtype(c) = DOM_SET or domtype(c) = Dom::Multiset
             or domtype(c) = piecewise);
      d:= genident("z");
      return(solvelib::Union(subs(c, x=d), d, b))
    end_if;
    userinfo(1,"trying polynomial decomposition");
    /* do not try decomposition if lev=1 */
    if lev<2 or nops((a:=[polylib::decompose(p,x)]))=1 then
/* no decomposition */
      userinfo(1,"decomposition failed");
      if d=4 and lev>=4 then
         pw([coeff(p,x,4)=0, solvelib::solve_poly(divide(p, poly(x^4),
                                                    hold(Rem)), x, options)],
            [coeff(p,x,4)<>0, solvelib::solve_poly4(p,x,options)  ])
      elif hastype((a:=expr(p)),DOM_FLOAT) and
        indets(a)={x} then
        if options["Real"] then
          s(op(select(numeric::polyroots(p), numeric::isreal)))
        else
          s(op(numeric::polyroots(p)))
        end_if
      elif nterms(p)=2 then
           // polynom is of the form a*x^d + b
           // of course this can be solved by radicals also for high d
        if options["Real"] then
          a:= coeff(p, d);
          b:= coeff(p, 0);
          if d mod 2=0 then
            return(
                   pw([a=0 and b=0, baseSet],
                      [a=0 and b<>0 or a*b > 0, {}],
                      [a<>0 and a*b<=0, s((-b/a)^(1/d), -(-b/a)^(1/d)) ]
                    )
                 )
          else
            // odd degree
              return(
                   pw([a=0 and b=0, baseSet],
                      [a=0 and b<>0, {}],
                      [a<>0, s(surd(-b/a, d)) ]
                    )
                     )
          end_if
        end_if;
        if testtype(coeff(p,0)/coeff(p,d), Type::Real) then
          // use arg to get a simpler result, e.g., when solving x^5=-1
          l:= -coeff(p,0)/coeff(p,d);
          l:= abs(l)^(1/d) * exp(I*arg(l, 0)/d);
          s(l * exp(2*k*PI*I/d) $k=0..d-1)
        else
          // note that the coefficients may contain identifiers
          l:= [coeff(p,d)=0, solvelib::solve_poly(poly(coeff(p,0), [x]),
                                                 x, options)],
             [coeff(p,d)<>0,
              s((-coeff(p,0)/coeff(p,d))^(1/d)* exp(2*k*PI*I/d) $k=0..d-1)];
          pw(l)
        end_if
      else
        userinfo(5, "Cannot solve by radicals");
        genident();
        RootOf(subs(a, x=%),%)
      end_if
    else
      userinfo(1,"decomposition succeeded");
      userinfo(5,"decomposed input into ".expr2text(nops(a)).
               " polynomials");

      // now a=[f1,..,fk]
      // This means we have to solve f1(f2(...(x)..))=0 for x
      // start by solving f1(y)=0 for y; for each solution y,
      // solve f2(z)=y for z, and so on
      
      b:=solvelib::solve_poly(a[1],x,options);
      delete a[1];
      for f in a do
        // we have solved f1(f2(..f_{i-1}(y)..))=0; the solutions
        // are stored in b . For each such solution y, we now have to solve
        // f(x) = y and store all of these x in b.
        

        // piecewise - case: uncommented because of efficiency problems
        
        if type(b)<>s /* and type(b)<>piecewise */ then
          /* cannot solve innermost -> return a RootOf */
          if d = 4 then
            return(pw([coeff(p,x,4)=0,
                       solvelib::solve_poly(divide(p, poly(x^4),
                                                   hold(Rem)), x, options)],
                      [coeff(p,x,4)<>0,
                       solvelib::solve_poly4(p,x,options)  ]))
          else
            
            genident();
            return(RootOf(subs(expr(p),x=%), %))
          end_if;
        end_if;

        // b may be a set or a piecewise of sets of y's
        // we map a function that returns, for each y,
        // the set of solutions of f(x)=y
        
     
                             
        solve_inner:=
        proc(S)
          local solve_el;

        begin
          
          solve_el:=
          proc(y)
            local g;
          begin
            g:=f-poly(y, [x]);
            userinfo(10, "Polynomial to solve:".
                     expr2text(g));
            g:=solvelib::solve_poly(g, x, options);
            userinfo(10,"Set of solutions is ".
                     expr2text(g));
            g
          end_proc;

          case type(S)
            of piecewise do
              map(S, solve_inner); break
            of DOM_SET do
            of Dom::Multiset do  
              Dom::Multiset::nestedUnion(map(S, solve_el)); break
            of solvelib::BasicSet do
              // S=C_
              // but g(x) in C_ is true for every x anyway
              S; break
            otherwise
              error("Unknown type of solution ".expr2text(S))
          end_case;

        end_proc;
              

        b:= solve_inner(b);

        if type(b)=piecewise then b:=simplify(b) end_if;          
         
        // b might be set of piecewise objects, or a piecewise of such sets

        /*
        flattenSets:=
        proc(S)
          local uncond, cond, dummy;               
        begin
          if type(S)=piecewise then
            return(map(S, flattenSets))
          end_if;
          if type(S)<>DOM_SET then
            return(S)
          end_if;
          
          [cond, uncond, dummy]:=
          split(S, a-> type(a)=piecewise);
          // assertion: dummy={} must hold
          // now cond are piecewise objects,
          // and uncond are others

          // make every piecewise object
          // obj= a1 if c1,..., ak if ck
          // to a piecewise obj
          // {a1} if c1, ..., {ak} if ck
          // and compute their union
          cond:=map(cond, piecewise::map, el->{el});
          _union(op(cond)) union uncond
        end_proc;
        
        b:= flattenSets(b);

        */
        
        // now be is a set of sets: each of its elements contains the
        // solutions for one particular y
        // we have to compute the union of all these sets
        
        // Dom::Multiset can also handle sets
        // only one call necessary
        /* b:= Dom::Multiset::nestedUnion(b) */
      end_for;
      userinfo(5, "Return value is ".expr2text(b));
      b
    end_if
  end_if
end_proc:

/* end of file */



