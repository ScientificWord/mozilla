
/*
_mult::combine(a1, ..., an)

combines a1*...*an
using the rule
x^a * x^b = x^(a+b)

*/


_mult::combine:=
proc()
  local e, i, l, f, gcdfunc;
begin
  e:= _mult(args());
  e:= map(e, combine);
  if type(e) <> "_mult" then
    return(e)
  end_if;


  // rewrite x^a*x^b --> x^(a+b)

  f:= map([op(e)],
          proc(x)
          begin
            if type(x) = "_power" then
              op(x)
            else
              x, 1
            end_if
          end_proc
          );
  // now f is a list suitable for polylib::refineFactorization
  gcdfunc:=
  proc(x,y)
  begin
    if x=y then
      x
    elif type(x) = DOM_INT and type(y) = DOM_INT then
      igcd(x, y)
    else
      1
    end_if
  end_proc;
  
  l:= polylib::refineFactorization(f, gcdfunc);
  if l <> f then // simplification succeeded
    e:= _mult(l[2*i-1]^l[2*i] $i=1..nops(l) div 2)
  end_if;
  if type(e) <> "_mult" then
    return(e)
  end_if;
  

  if hastype( e,"_power" ) then
    return( slot(combine,"_power")(e) )
              
  else
    return( e )
  end_if;

  
end_proc: