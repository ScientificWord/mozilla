
/*
solvelib::preImageInterval(a, x, iv, options)
-  a: arithmetical expression
-  x: identifier
-  iv: interval
- options: table of options as returned by solvelib::getOptions

returns the set { x in C_; a(x) in iv }
*/


solvelib::preImageInterval:=
proc(a, x, iv: Dom::Interval, options: DOM_TABLE)
  local mapB: DOM_PROC, default: DOM_PROC,
  polyInIv: DOM_PROC,
  CxInIv: DOM_PROC,
  preImageIVP: DOM_PROC,
  preImageIVN: DOM_PROC,
  handleIV: DOM_PROC,
  handlePreImageR: DOM_PROC,
  handleZeroes: DOM_PROC,
  preImageR: TypeSet,
  k,
  l, r, lb, rb, // left and right border
  ivp: Type::Set,
  ivn: Type::Set,
  IV, reals, others, dummy,
  sol, sls, base, expo,
  inds: DOM_SET,
  X: DOM_IDENT;

begin

  // mapB - a useful utility function
  mapB:= proc(b, f)
         begin
           if type(b) = DOM_LIST then
             [f(op(b, 1), args(3..args(0)))]
           else
             f(b, args(3..args(0)))
           end_if
         end_proc;

  default:= () ->
            if {IV::left(iv), IV::right(iv)} intersect
              {-infinity, infinity} <> {} then
              hold(solve)(_in::expand(a, iv), x,
                          solvelib::nonDefaultOptions(options)
                          )
            else
              hold(solve)(a in iv, x,
                          solvelib::nonDefaultOptions(options)
                          )
            end_if;


  // given a constant C, returns the set of all x with C*x in iv
  CxInIv:=
  proc(C, x, iv, options)
    local divC;
  begin
    if is(x in R_) = TRUE then
      // C*x in iv iff C=0 and 0 in iv or x=0 and 0 in iv or
      // C real and x in iv/C
      divC:= (x, C) -> if x=-infinity or x=infinity then x else x/C end;
      piecewise([C = 0 and 0 in iv, R_],
                [not C in R_ and 0 in iv, {0}],
                [(C= 0 or not C in R_) and not 0 in iv, {}],
                [C > 0, IV::mapBorders(iv, divC, C)],
                [C < 0, IV::mapBorders(-iv, divC, -C)]
                )
    else  
      piecewise([C = 0 and 0 in iv, C_],
                       [C = 0 and not 0 in iv, {}],
                       [C <> 0, IV::mapmultparam(iv, 1/C)]
                )
      
    end_if
  end_proc;

  polyInIv:=
  proc(f, x, iv, options)
    local a, b, c, i;
  begin
    case degree(f, x)
      of 1 do
        // can have been caused by an implicit collect;
        // normally, this should be handled below
        return(solvelib::preImage(coeff(f, x, 1)*x, x, iv - coeff(f, x, 0),
                                  options)
               )
      of 2 do
        // a*x^2 + b*x + c in iv can be reduced to a=0 or
        // x^2 + B*X + C in iv/a with B=b/a, C=C/a
        // which is equivalent to (x+B/2)^2 in iv/a + (B^2/4 - C)
        [c, b, a]:= [coeff(f, x, i) $i=0..2];
        return(piecewise
               ([a = 0, CxInIv(b, x, iv-c, options)],
                [a <> 0, 
                 solvelib::preImage
                 ((x+b/a/2)^2, x,
                  IV::mapmultparam(iv, 1/a) + ((b/2/a)^2 - c/a)
                  )
                 ]
                )
               )
     
    end_case;
    hold(solve)(f in iv, x, options)
  end_proc;


  handlePreImageR:=
  proc(preImageR: Type::Set)
    local sol, res, i: DOM_INT,
    zeroes, // solutions of the corresponding equation(s)
    critPts,  // solutions + interval borders
    J, 
    pt, cond, condleft, condright, newiv, newa, branches;
  begin
    case type(preImageR)  
      of Dom::Interval do
        break;
      of DOM_SET do
        if preImageR = {} then
          return({})
        else
          return(default())
        end_if
      of piecewise do
        branches:= [];
        for i from 1 to nops(preImageR) do
          cond:= piecewise::condition(preImageR, i);
          newa:= piecewise::subsEqualities(a, cond);
          newiv:= piecewise::subsEqualities(iv, cond);
          if newa <> a or newiv <> iv then
            res:= solvelib::preImage(newa, x, newiv, options)
          else
            res:= handlePreImageR(piecewise::expression(preImageR, i))
          end_if;
          if type(res) = "solve" then
            return(default())
          end_if;
          branches:= branches.[[cond, res]];
        end_for;
        return(piecewise(op(branches)))
      of solvelib::BasicSet do
        if preImageR = R_ then
          preImageR:= Dom::Interval(-infinity, infinity)
        else
          return(default())
        end_if;
        break
      of "_union" do
        sol:= {};
        for i from 1 to nops(preImageR) do
          if type((res:= handlePreImageR(op(preImageR, i)))) = "solve" then
            return(default())
          else  
            sol:= sol union res
          end_if
        end_for;
        return(sol)
      of "_minus" do
        if op(preImageR, 1) = R_ and type(op(preImageR, 2)) = DOM_SET and
          nops(op(preImageR, 2)) = 1 then
          return(handlePreImageR
                 (Dom::Interval(-infinity, op(preImageR, [2, 1])))
                 union
                 handlePreImageR
                 (Dom::Interval(op(preImageR, [2, 1]), infinity))
                 )
        else
          return(default())
        end_if
      otherwise
        return(default())
    end_case;
  
    assert(type(preImageR) = Dom::Interval);

    // use the intermediate value theorem
    // we want to find those x in preImageR that satisfy
    // a(x) in iv
    // hence we have to solve a = IV::left(iv) and a = IV::right(iv)
    // between two adjacent solutions of this, either all or no x 
    // satisfies a(x) in iv

    zeroes:= sls intersect preImageR;

    handleZeroes:=
    proc(zeroes)
      local J, critPts, i: DOM_INT;
    begin
      case type(zeroes)
        of piecewise do
          J:= piecewise::extmap(zeroes, handleZeroes);
          if type(J) <> "solve" then
            return(J)
          else
            return(default())
          end_if
        of Dom::Interval do
          zeroes:= {IV::left(zeroes), IV::right(zeroes)} minus
               {-infinity, infinity};
          break;
        of DOM_SET do
          break
        otherwise
          return(default())
      end_case;
    
      critPts:= solvelib::conditionalSort
      ([op(zeroes union
           {IV::left(preImageR), IV::right(preImageR)})]);
      
      if type(critPts) <> DOM_LIST then
        return(default())
      end_if;
      // drop those critical points that have turned out to lie outside the
      // interval
      critPts:= [op(critPts, contains(critPts, IV::left(preImageR))..
                    contains(critPts, IV::right(preImageR)))];

      sol:= {};
      for i from 1 to nops(critPts) - 1 do
        // decide whether the interval (critPts[i], critPts[i+1])
        // consists of solutions and whether the borders have to be
        // included, too

        J:= Dom::Interval([critPts[i], critPts[i+1]]);
        
        pt:= solvelib::getElement(J);
        cond:= evalAt(a, x = pt) in iv;
        
    
        if i=1 then
          if critPts[i] = -infinity or
            IV::isleftopen(preImageR) 
            or traperror((condleft:= evalAt(a, x = critPts[1]) in iv)) <> 0
            then
            condleft := FALSE
          end_if
        else
          // right border of previous iteration becomes left border
          // of this iteration
          condleft:= condright
        end_if;
        if critPts[i+1] = infinity or
          (i + 1 = nops(critPts) and IV::isrightopen(preImageR))
          or traperror((  condright:= evalAt(a, x = critPts[i+1]) in iv)) <> 0
          then
          condright:= FALSE
        end_if;
        J:= piecewise(
                  [not cond and not condleft and not condright, {}],
                  [not cond and condleft and not condright, {critPts[i]}],
                  [not cond and not condleft and condright, {critPts[i+1]}],
                  [not cond and condleft and condright,
                   {critPts[i], critPts[i+1]}],    
                  [cond and not condleft and not condright,
                   IV(critPts[i], critPts[i+1])
                   ],
                  [cond and not condleft and condright,
                   IV(critPts[i], [critPts[i+1]])
                   ],
                  [cond and condleft and not condright,
                   IV([critPts[i]], critPts[i+1])
                   ],
                  [cond and condleft and condright,
                   IV([critPts[i], critPts[i+1]])
                   ]
                  );

        sol:= sol union J
      end_for;
    
      sol
    end_proc;

    handleZeroes(zeroes)
    
  end_proc;
  
  
  IV:= Dom::Interval;
  [l, r]:= IV::borders(iv);
  lb:= IV::leftB(iv);
  rb:= IV::rightB(iv);
  
  
  if not has(a, x) then
    return(piecewise([a in iv, C_], [not a in iv, {}]))
  end_if;
  
  case type(a)
    of DOM_IDENT do
      assert(a = x);
      return(iv)
    of "_plus" do
      reals:= select(a, s -> not has(s, x));
      if not iszero(reals) then
        return(solvelib::preImage(a - reals, x, iv - reals))
      else
        break
      end_if;
    of "_mult" do
      [reals, others, dummy]:= split(a, s -> not has(s, x));
      if reals <> 1 then
        return(solvelib::preImage(others, x, CxInIv(reals, x, iv, options)))
      end_if;
      break
    of "_power" do
      [base, expo]:= [op(a)];
      // inequalities with constant exponent, f(x)^C in iv
      if not has(expo, x) then
        if stdlib::hasmsign(expo) then
          return(solvelib::preImage(base^(-expo), x, 1/iv, options))
        end_if;
        case type(expo)
          of DOM_INT do
            assert(expo > 0);
            // split iv into a positive and a negative part ivp and ivn
            ivp:= iv intersect Dom::Interval([0], infinity);
            ivn:= iv intersect Dom::Interval(-infinity, [0]);
            // x^n in ivp iff abs(x)^n in ivp and n*arg(x)/PI is even
            // x^n in ivn iff abs(x)^n in -ivn and n*arg(x)/PI is odd
            
            // local methods preImageIVP, preImageIVN
            // given n, x, iv, these functions return the set of all
            // x with x^n in iv
            preImageIVP:=
            proc(n, x, iv, options)
              local ivroot, k;
            begin
              case domtype(iv)
                of piecewise do
                  return(piecewise::extmap
                         (iv, u -> preImageIVP(n, x, u, options))
                         )
                of DOM_SET do
                  return(solvelib::preImage(x^n, x, iv, options))
                of Dom::Interval do
                  ivroot:= Dom::Interval::mapBorders(iv, _power, 1/n);
                  return(_union(ivroot*exp(2*PI*I*k/n) $k=0..n-1))
              end_case;
              error("Unknown type of interval")
            end_proc;

            preImageIVN:=
            proc(n, x, iv, options)
              local ivroot, k;
            begin
              case domtype(iv)
                of piecewise do
                  return(piecewise::extmap
                         (iv, u -> preImageIVN(n, x, u, options))
                         )
                of DOM_SET do
                  return(solvelib::preImage(x^n, x, iv, options))
                of Dom::Interval do
                  ivroot:= Dom::Interval::mapBorders(-iv, _power, 1/n);
                  return(_union(ivroot*exp((2*k+1)*PI*I/n) $k=0..n-1))
              end_case;
              error("Unknown type of interval")
            end_proc;

          
          
            sol:= preImageIVP(expo, x, ivp, options) union
                  preImageIVN(expo, x, ivn, options);
            return(solvelib::preImage(base, x, sol, options))
            // type(expo) = DOM_INT
          of DOM_RAT do
            assert(expo > 0);
             //Let c>0. Then  x^b = c iff x= c^(1/b)*exp(2*PI*I*k/b)
            // with k integer, -b/2 < k <= b/2

            handleIV:=
            proc(iv)   // the left border of iv must be >=0
              local ivr;
            begin
              // with iv = (l, r), let ivr = (l^(1/b), r^(1/b))
              ivr:= iv^(1/expo);
              _union(ivr*exp(2*PI*I*k/expo)
                     $k=floor(-expo/2)+1 .. floor(expo/2))
            end_proc;
            
            // a fractional power can never be negative
            // thus we have to replace the left border of iv by
            // max(l, 0)
           return(solvelib::preImage(op(a, 1), x,
                  piecewise([l<0, handleIV(IV([0], IV::rightB(iv) ))],
                            [l>=0, handleIV(iv)]
                            ),
                                     options
                  ))
        end_case
      end_if;
      // inequalities with constant base, C^(f(x)) in iv
      //if not has(base, x) then

      //end_if;

      if is(op(a, 1) <>0 ) = TRUE then
        // rewrite by exp and fall through
        a:= hold(exp)(op(a, 2) * ln(op(a, 1)))
      else
        break
      end_if;
    of "exp" do
      if is(op(a, 1) in R_) = TRUE then
        sol:= piecewise([r<=0, {}],
                       [l<=0 and r>0, 
                        Dom::Interval(-infinity, mapB(rb, simplify@ln))
                         ],
                       [l>0, Dom::Interval(mapB(lb, simplify@ln),
                                                    mapB(rb, simplify@ln))
                        ]
                       )
      else
        // exp(z) = C -> z = ln(C) + 2*k*PI*I for C<>0
        k:= genident();
        sol:= piecewise([l>0, IV::mapBorders(iv, ln) + 2*PI*I*Z_],
                        [l=0, IV(-infinity, mapB(IV::rightB(iv), ln))
                         + 2*PI*I*Z_],                                 
                        [r<0, IV::mapBorders(-iv, ln) +
                         Dom::ImageSet((2*k+1)*PI*I, k, Z_) ],
                        [r=0,  (IV(-infinity, mapB(IV::leftB(iv), ln@_negate))+
                          Dom::ImageSet((2*k+1)*PI*I, k, Z_))],
                        [l<0 and r>0,
                         (IV(-infinity, mapB(IV::leftB(iv), ln@_negate))+
                          Dom::ImageSet((2*k+1)*PI*I, k, Z_)) union
                         (IV(-infinity, mapB(IV::rightB(iv), ln)) + 2*PI*I*Z_)
                         ]
                        );
      end_if;
      return(solvelib::preImage(op(a, 1), x, sol, options))
    of "sin" do
      if not is(op(a, 1), Type::Real) = TRUE then
        break
      end_if;
      k:= solvelib::getIdent(Z_);
      case [IV::isleftopen(iv), IV::isrightopen(iv)]
        of [TRUE, TRUE] do
          sol:=piecewise
                ([l < -1 and r > 1, R_],
                 [l >= -1 and r > 1,
                  solvelib::Union(IV(arcsin(l) + 2*k*PI,
                                     PI-arcsin(l) + 2*k*PI),
                                  k, Z_)],
                 [l < -1 and r <= 1,
                  solvelib::Union(IV(-arcsin(r)-PI + 2*k*PI,
                                     arcsin(r) + 2*k*PI),
                                  k, Z_)],
                 [l >= -1 and r <= 1,
                  solvelib::Union(IV(arcsin(l) + 2*k*PI,
                                     arcsin(r) + 2*k*PI),
                                  k, Z_) ],
                 [not l < r, {}]
                 );
          break
        of [TRUE, FALSE] do
          sol:=piecewise
                ([l < -1 and r >= 1, R_],
                 [l >= -1 and r >= 1,
                  solvelib::Union(IV(arcsin(l) + 2*k*PI,
                                     PI-arcsin(l) + 2*k*PI),
                                  k, Z_)],
                 [l < -1 and r < 1,
                  solvelib::Union(IV([-arcsin(r)-PI + 2*k*PI,
                                      arcsin(r) + 2*k*PI]),
                                  k, Z_)],
                 [l >= -1 and r < 1,
                  solvelib::Union(IV(arcsin(l) + 2*k*PI,
                                     [arcsin(r) + 2*k*PI]),
                                  k, Z_) ],
                 [not l < r, {}]
                 );
          break
        of [FALSE, TRUE] do
          sol:=piecewise
                ([l <= -1 and r > 1, R_],
                 [l > -1 and r > 1,
                  solvelib::Union(IV([arcsin(l) + 2*k*PI,
                                      PI-arcsin(l) + 2*k*PI]),
                                  k, Z_)],
                 [l <= -1 and r <= 1,
                  solvelib::Union(IV(-arcsin(r)-PI + 2*k*PI,
                                     arcsin(r) + 2*k*PI),
                                  k, Z_)],
                 [l > -1 and r <= 1,
                  solvelib::Union(IV([arcsin(l) + 2*k*PI],
                                     arcsin(r) + 2*k*PI),
                                  k, Z_) ],
                 [not l < r, {}]
                 );
          break
        of [FALSE, FALSE] do
          sol:=piecewise
                ([l <= -1 and r >= 1, R_],
                 [l > -1 and r >= 1,
                  solvelib::Union(IV([arcsin(l) + 2*k*PI,
                                      PI-arcsin(l) + 2*k*PI]),
                                  k, Z_)],
                 [l <= -1 and r < 1,
                  solvelib::Union(IV([-arcsin(r)-PI + 2*k*PI,
                                      arcsin(r) + 2*k*PI]),
                                  k, Z_)],
                 [l > -1 and r < 1,
                  solvelib::Union(IV([arcsin(l) + 2*k*PI,
                                      arcsin(r) + 2*k*PI]),
                                  k, Z_) ],
                 [not l <= r, {}]
                 );
          break
      end_case;
      return(solvelib::preImage(op(a, 1), x, sol))
      // end of type(a) = "sin"
    of "cos" do
      // handle via "sin"
      return(solvelib::preImage(sin(op(a, 1) + PI/2), x, iv, options))
    of "abs" do
      iv:= iv intersect Dom::Interval([0], infinity);
      X:= solvelib::getIdent(R_, indets(a));
      return(solvelib::preImage
             (op(a, 1), x, solvelib::Union
              (exp(X*I) * iv, X, Dom::Interval([0], 2*PI)))
             )
    // of "arg" do
      // ???
  end_case;

  // heuristics for "_plus", "_mult", "_power"
  if contains({"_plus", "_mult", "_power"}, type(a)) then
    inds:= select(indets(a, PolyExpr), has, x);
    if nops(inds) = 1 then
      // input is a polynomial in f(x) for some f
      // replace by new identifier if necessary
      if op(inds, 1) <> a then
        // op(inds, 1) = a would cause infinite recursion
        if op(inds, 1) <> x then
          X:= genident();
          sol:= polyInIv(subs(a, op(inds, 1) = X), X, iv, options);
          if type(sol) <> "solve" then
            return
            (
             solvelib::preImage(op(inds, 1), x, sol, options)
             )
          end_if
        else
          sol:= polyInIv(a, x, iv, options);
          if type(sol) <> "solve" then
            return(sol)
            // else: try intermediate-value theorem heuristic below
          end_if
        end_if;
      end_if
    end_if;
  end_if;

  // rewrite heaviside 
  if hastype(a, "heaviside") then
    a:= rewrite(a, piecewise);
    return(solvelib::preImage(a, x, iv, options))
  end_if;

  // try to find the preImage of R_ first; 
  preImageR:= solvelib::preImage(a, x, R_, options);

  save x;
  if traperror((
  assume(x in preImageR, _and)
                )) <> 0 then
    // impossible assumption -> a cannot be real, hence the inequality
    // is not solvable
    return({})
  end_if;
  if IV::left(iv) = -infinity then
    sls:= solve(a = IV::right(iv), x)
  elif IV::right(iv) = infinity then
    sls:= solve(a = IV::left(iv), x)
  else        
    sls:= solve(a = IV::right(iv), x) union solve(a = IV::left(iv), x)
  end_if;

  sls:= sls union discont(a, x, Undefined);
  
  sol:= handlePreImageR(preImageR);
  if not hastype(sol, "solve") then
    return(sol)
  end_if;
 

  // default
 default()
end_proc: