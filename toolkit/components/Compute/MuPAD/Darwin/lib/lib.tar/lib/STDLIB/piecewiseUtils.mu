piecewise::inhomog_union:=
table(
      Dom::ImageSet = piecewise::_union,
      Dom::Interval = piecewise::_union
      ):

piecewise::inhomog_intersect:=
table(
      Dom::ImageSet = piecewise::_intersect,
      Dom::Interval = piecewise::_intersect
      ):
