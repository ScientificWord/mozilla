//alias(_pattern = intlib::_pattern): geht nicht!

intlib::lookuparctan:=
  proc(f)
    save a,b;
    local ah;
  begin
    delete a,b;
    case type(f)
      of "arctan" do
        return((
                // arctan(a*x) 
                if not has((ah:=op(f)/_X),_X) then -ln(ah^2*_X^2+1)/2/ah+_X*f
                  // arctan(sqrt(a*x+b)) 
                elif intlib::matchassign(f,
                              arctan(sqrt(_pattern(a,not has,_X)*_X+
                                          _pattern(b,not has,_X)))) then
                  arctan((a*_X+b)^(1/2))*_X+
                  1/a*arctan((a*_X+b)^(1/2))*b-1/a*(a*_X+b)^(1/2)+
                  1/a*arctan((a*_X+b)^(1/2))
                else
                  FAIL
                end_if))
      of "_mult" do
        return((
                // arctan(a*x)/x 
                if intlib::matchassign(f,arctan(_pattern(a,not has,_X)*
                                                _X)/_X) then
                  I/2*(dilog(1+I*a*_X)-dilog(1-I*a*_X))
                else FAIL end_if))
    end_case;
    FAIL
end_proc:
