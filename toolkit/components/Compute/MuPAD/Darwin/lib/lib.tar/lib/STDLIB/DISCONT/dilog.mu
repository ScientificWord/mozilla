dilog::complexDiscont := Dom::Interval(-infinity, 0):
