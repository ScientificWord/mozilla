
// realDiscont - attribute for function floor

floor::realDiscont:= Z_:
