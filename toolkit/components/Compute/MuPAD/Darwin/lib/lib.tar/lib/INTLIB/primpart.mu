// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 
/*--
intlib::primpart(a) -- returns the primitive part and the content of a.
--*/
intlib::primpart:= proc(a)
  local c,i,den;
begin
  if iszero(a) then return(a,1) end_if;
  den:=1;
  for i in coeff(a) do
    den:=den*denom(i);
  end_for;
  a:=intlib::sim(multcoeffs(a,den));
  c:=content(a);
  a:=intlib::sim(multcoeffs(a,1/c));
  if indets(polylib::lcoeff(a))={} then a:=multcoeffs(a,sign(polylib::lcoeff(a))); end_if;
  c:=normal(c/den);
  return(a,c);
end_proc:
