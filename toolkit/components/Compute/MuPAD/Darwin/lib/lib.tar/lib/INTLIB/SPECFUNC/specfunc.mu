// $Date: 2004-07-05 09:54:56 +0200 (Mon, 05 Jul 2004) $ $Author: ccr $ $Revision: 27942 $ 

/*++ ---------------- specfunc.mu ---------------------

Author: Winfried Fakler,  University of Paderborn
Date Created:  29 July  1999
Last Update :  27 March 2000


Description:
This file contains functions for integrating generalized functions as well as
special functions and "functions" like "big Oh".
							  
Functions: 

 - used Parameter:
    ++ f,a,b :DOM_EXPR
    ++ x     :DOM_IDENT				  
    ++ f     = (complex) generalized function 
    ++ x     = indeterminate of f					  
    ++ a,b   = constant expression w.r.t. x, representing lower and upper limit

 - intlib::specialFunctionInt(f,x)
    ++ returns FAIL or an (formal) antiderivative of the generalized function
    ++ f w.r.t. x.                               
 - intlib::specialFunctionDef(f,x,a,b, options) 
    ++ returns FAIL or the definite integral of the generalized function f 
    ++ w.r.t. x in the range of a to b.
 - intlib::absInt(f,x)
    ++ rewrites occuring absolute values with the rule |u|=u/sign(u) and
    ++ tries to integrate the resulting expression. If f does not contain an
    ++ absolute value or a sign-function FAIL is returned.
 - intlib::bigOhInt(f,x)
    ++ returns the integral unevaluated or an formal antiderivative of f
    ++ w.r.t. x, if it contains an order term.

Examples:
++*/

intlib::specialFunctionDef:=
  proc(f,x,a,b) // options
    local options;
  begin
    options:=intlib::getOptions(args(5..args(0)));
    
    userinfo(4,"looking for special functions");
    // integrand contains absolute value
    if has(f,{abs,sign}) then
      return(intlib::antiderivative(f,x=a..b,options))
    end_if;
     // big Oh
    if hastype(f,O) then
      return(hold(int)(f,x=a..b,intlib::printOptions(options)))
    end_if;
    // generalized functions
    if has(f,dirac) then return(intlib::diracDef(f,x,a,b,options));
      // heaviside case is treated by indefinite integration 
    end_if;

    // otherwise
    FAIL;
  end_proc:

intlib::specialFunctionInt:=
  proc(f,x)
    local T: DOM_TABLE,
    substitute: DOM_PROC,
    g, i, oldg;
  begin

    // local method substitute
    // replaces one call ceil(..), floor(..), trunc(..) by an identifier X
    // and adds an entry the argument = X to table T
    substitute:=
    proc(subExpression): DOM_IDENT
      local id: DOM_IDENT;
    begin
      if contains(T, subExpression) then
        T[subExpression]
      else  
        id:= genident("CeilTruncFloor");
        T[subExpression]:= id;
        id
      end_if
    end_proc;
    
    userinfo(4,"looking for special functions");
    // integrand contains absolute value or a sign function
    if has(f,{abs,sign}) then
      return(intlib::absInt(f,x))
    end_if;
    // big Oh
    if hastype(f,O) then
      return(intlib::bigOhInt(f,x))
    end_if;
    // generalized functions
    if has(f, dirac) then
      return(intlib::diracInt(f,x));
    elif has(f, heaviside) then
      return(intlib::heavisideInt(f,x));
    end_if;
    // piecewise constant functions
    if has(f, {ceil, floor, trunc}) then
      // replace each call to a constant function by
      // an identifier, integrate, then substitute back
      T:= table();
      g:= misc::maprec(f, {"floor", "ceil", "trunc"} = substitute);
      g:= int(g, x);
      if type(g)="int" then
        return(hold(int)(f, x))
      else
	oldg := FAIL;
	while g <> oldg do
	  oldg := g;
	  g := subs(g, op(i, 2)=op(i, 1) $i in T);
	end_while;
	return(g);
      end_if;  
    end_if;
    // functions that are integrals, such as Si, Ci,
    // and products involving them
    if contains({"Ci", "Si"}, type(f)) then
      return(eval(intlib::byparts(hold(int)(f,x), 1)))
    end_if;
    if type(f) = "_mult" then
      for i from 1 to nops(f) do
        if contains({"Ci", "Si"}, type(op(f, i))) then
          g:= eval(intlib::byparts(hold(int)(f,x), f / op(f, i)));
          if not hastype(g, "int") then
            return(g)
          end_if
        end_if
      end_for
    end_if;
    
    // otherwise
    FAIL;
  end_proc:

intlib::absInt:=
  proc(f,x)
    local fs,fr,F;
  begin
    fs:=eval(subs(f,hold(abs)=(u -> u/sign(u))));
    fr:=rationalize(fs,proc(x) begin
                                 domtype(x)=DOM_EXPR and type(x)<>"sign"
                       end_proc);
    if fr[2]<>{} then 
      F:=intlib::int(fr[1],x);
      if type(F)<>"int" then
        eval(subs(F,fr[2]));
      else
        hold(int)(f,x)
      end_if;
    else
      FAIL
    end_if;
  end_proc:

intlib::bigOhInt:=
  proc(f,x) 
    local g;
  begin
    //print("entering bigOhInt with ",f,x);
    case type(f)
      of "_plus" do //print("case _plus");
        return( map(f, e->if hastype(e,O) then
                            intlib::bigOhInt(e,x) 
                          else intlib::int(e,x) 
                          end_if)); break;
      of O do break; //print("case O");
      otherwise //print("case otherwise");
        return(hold(int)(f,x)); 
    end_case;

    // now f(x)=O(g(x))
    g:=op(f,1);
    O::create(int(g,x),f::dom::points(f));
  end_proc:

