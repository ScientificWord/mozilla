// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ #

// Prime -- expression to test for prime numbers

Type::Prime:=
    new(property::NRange,
	"Prime",
	proc(t,x)
	  name Type::Prime;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if domtype(x) = DOM_INT then
		isprime(x)
	    else
		FAIL
	    end_if;
	end_proc,
	FALSE, FALSE,
	["Prime", property::Null]):
