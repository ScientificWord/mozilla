// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	sec/conjugate -- the function attribut "conjugate" for sec
--*/

sec:= slot(sec, "conjugate", proc() begin 
    conjugate(args(1));
    if type(%) = "conjugate" then hold(sec)(%)
    else sec(%)
    end_if
 end_proc  ):

// end of file 
