// $Date: 2001-07-30 14:30:58 +0200 (Mon, 30 Jul 2001) $  $Author: kg $ $Revision: 13260 $ 

/* General convention: a monomial ordering is a function
  ord: N^k x N^k -> {-1, 0, 1}

  for elements of Dom::MonomOrdering, this is satisfied
  (by definition of Dom::MonomOrdering::func_call)

  Here ord([m_1,..,m_k],[n_1,..,n_k])=-1 iff [m_1,..,m_k] < [n_1,..,n_k]
                                     = 1 iff              >
                                     = 0 iff              =
*/


/* lterm(f,ord)
  
  f   - polynomial
  ord - monomial ordering

  computes the leading term with respect to ord
*/ 

lterm:=
proc(ff,ord)
  local f, result,dv,nt,dvec,i;
  
begin
  if args(0)=0 then 
	error("lterm called without arguments")
  end_if;
  if ff::dom::lterm <> FAIL then
	return(ff::dom::lterm(args()))
  end_if;
  if args(0)=1 or type(ord)=DOM_IDENT then
    return(polylib::lterm(args()))
  end_if;
  if type(ord)=DOM_LIST then
    lterm(poly(ff, ord), args(3..args(0)));
    if testtype(ff, Type::Arithmetical) then
      return(expr(%))
    else
      return(%)
    end_if;
  end_if;
  if iszero(ff) then
    return(ff)
  end_if;
  if degree(ff)=0 then
    return(ff/ff)
  end_if;
  f:=poly(ff);
  if f=FAIL then
	error("Cannot convert to polynomial")
  end_if;
  if ff=expr(ff) then
    return(expr(lterm(f, args(2..args(0)))))
  end_if;
  
  result:=nthterm(f,1);
  dv:=degreevec(result);
  for i from 2 to nterms(f) do
    nt:=nthterm(f,i);
    dvec:=degreevec(nt);
    if ord(dv,dvec)=-1 then
      dv:=dvec;
      result:=nt
    end_if
  end_for;
  result
end_proc:

// end of file 











