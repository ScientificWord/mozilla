// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ #

// Imaginary -- expression to test for imaginary numbers

Type::Imaginary:=
    new(property::NRange,
	"Imaginary",
	proc(t,x)
	  name Type::Imaginary;
          option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if domtype(x) = DOM_COMPLEX then
		iszero(Re(x))
            elif iszero(x) then
                TRUE
	    else
		FAIL
	    end_if;
	end_proc,
	FALSE, FALSE,
	["Imaginary", property::Null]):
