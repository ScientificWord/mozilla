ceil::realDiscont:= Z_:
