// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	fact/expand -- the function attribut "expand" for fact
--*/

fact := slot(fact,"expand",
proc(e) local i,j;
begin
   if type(e)="_plus" then
      i:=op(e,nops(e)); // integers are always in the last operand ??? 
      if testtype(i,Type::PosInt) then
         return(_mult(fact(e-i),e-j$j=0..i-1))
      elif testtype(i,Type::NegInt) then
         _mult(e+j$j=1..-i);
         return(fact(e-i)/%)
      end_if
   end_if;
   fact(e)
end_proc):

// end of file 
