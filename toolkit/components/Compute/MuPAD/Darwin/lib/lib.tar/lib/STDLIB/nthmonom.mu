// $Date: 2001-07-30 14:30:58 +0200 (Mon, 30 Jul 2001) $ $Author: kg $ $Revision: 13260 $ 


/*
   nthmonomial(f, n, <order>)

   return the n-th monomial of f w.r.t. to order (default is LexOrder)

*/


nthmonomial:=
proc(f, n, ord)
  local M;
begin
  if args(0)=0 then
    error("nthmonomial called without arguments")
  end_if;
  if f::dom::nthmonomial <> FAIL then
    return(f::dom::nthmonomial(args()))
  end_if;
  if args(0)<2 or args(0)>4 then
    error("Wrong number of arguments")
  end_if;
  if type(n)=DOM_LIST then
    M:= nthmonomial(poly(f, n), args(3..args(0)));
    if testtype(f, Type::Arithmetical) then
      return(expr(M))
    else
      return(M)
    end_if
  end_if;
  if args(0)=2 or ord=hold(LexOrder) then
    polylib::nthmonomial(f, n)
  else
    op(polylib::sortMonomials(f, ord), n)
  end_if
end_proc:


