// $Date: 2006-05-12 15:24:04 +0200 (Fri, 12 May 2006) $ $Author: stefanw $ $Revision: 38991 $ 

/*--
intlib::diffs(f,n) - computes the derivative of the expression f.
(not the partial derivative with respect to the integration variable)
--*/

intlib::diffs:=proc(f,n)
  local i, ff;
// global _global_k,_global_k_sub;
begin
//  print("---------------------------------------");
  ff := f;
  if f::dom = DOM_POLY then ff := expr(f); end_if;
  ff:=subs(ff,(_global_k_sub[n-i]=_global_k[n-i] $i=0..n-2));
  ff:=diff(ff,_global_k[1]);
  ff:=/*intlib::*/subsex(ff,(_global_k[i]=_global_k_sub[i]) $ i = 2 .. n);
  if f::dom = DOM_POLY then ff := poly(ff, op(f, 2..3)); end_if;
  ff;
end_proc:


// intlib::subsex -- an extended subsex which can do
//   intlib::subsex(exp(-2*X1*X), exp(-X1*X)=a) = a^2e
intlib::subsex :=
proc(ex)
  local substs, i, ex2;
begin
  ex := eval(ex);
  substs := [args(2..args(0))];
  // dependencies, as in intlib::subsex(sqrt(x), ln(x)=X1, exp(X1/2)=X2):
  for i from nops(substs)-1 downto 1 do
    substs := substs.map(substs[i+1..-1], subs, rhs(substs[i])=lhs(substs[i]));
  end;
  // simplify exp(ln(...)); inside Risch, we don't care for branch cuts
  substs := map(substs,
		proc(eq)
		  local l;
		begin
		  l := lhs(eq);
		  if type(l) = "exp" then
		    l := op(l);
		    if type(l) = "ln" then
		      return(op(l)=rhs(eq));
		    end;
		    if type(l) = "_mult" and
		       nops(l) = 2 and
		       type(op(l, 1)) = "ln" and
		       testtype(op(l, 2), Type::Constant) then
		      return(op(op(l, 1))^op(l,2)=rhs(eq));
		    end;
		  end;
		  eq;
		end);
  // expand exp(-X) to also match exp(-2*X) and
  // X^(1/2) to also match X, as in (X*Y)^(1/2)
  substs := op(map(substs,
		   proc(eq)
		     local n;
		   begin
		     if type(lhs(eq)) = "exp" and
			type(op(eq, [1,1])) = "_mult" then
		       n := select(op(eq, [1, 1]), testtype, Type::Constant);
		       eq, exp(op(lhs(eq), 1)/n) = rhs(eq)^(1/n)
		     elif type(lhs(eq)) = "_power" and
			  testtype(op(eq, [1,2]), Type::Constant) then
		       eq, eval(op(eq, [1,1])) = op(eq, [2])^(1/op(eq, [1,2]))
		     else
		       eq
		     end
		   end));
  // substitute completely until no more work is to be done
  ex2 := FAIL;
  repeat
    [ex, ex2] := [normal(subsex(ex, substs)), ex];
  until ex=ex2 end_repeat;
  ex;
end:
