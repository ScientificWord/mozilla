// $Date: 2002-02-06 16:14:50 +0100 (Wed, 06 Feb 2002) $ $Author: tonner $ $Revision: 17136 $ 


/*
   nthcoeff(f, n, <order>)

   return the n-th coefficient of f w.r.t. to order (default is LexOrder)

*/


nthcoeff:=
proc(f, n, ord)

begin
  if args(0)=0 then
    error("nthcoeff called without arguments")
  end_if;
  if f::dom::nthcoeff <> FAIL then
    return(f::dom::nthcoeff(args()))
  end_if;
  if args(0)<2 or args(0)>4 then
    error("Wrong number of arguments")
  end_if;
  if type(n)=DOM_LIST then
    nthcoeff(poly(f,n), args(3..args(0)));
    if testtype(f, Type::Arithmetical) then
      return(expr(%))
    else
      return(%)
    end_if
  end_if;
  if args(0)=2 or ord=hold(LexOrder) then
    polylib::nthcoeff(f, n)
  else
    coeff(op(polylib::sortMonomials(f, ord),n))
  end_if
end_proc:


