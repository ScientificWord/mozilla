int:=slot(int,"simplify",proc(e)
   name int::simplify;
   local c,v,f,x;
begin
   f:= simplify( op(e,1) ); x:= op(e,2);
   if type(f)="_mult" then
      if type(x)="_equal" then v:=op(x,1) else v:=x end_if;
      c:=select(f,not has,v); f:=f/c;
   else c:=1
   end_if;

   // I do not like this simplification since it causes e.g.
   //  simplify(int(f(x),x=0..a)) = -int(f(x), x = a..0)

   //if type(x)="_equal" then
   //   if sysorder(op(op(x,2)))=FALSE then
   //      return(-c*hold(int)(f,op(x,1)=op(x,[2,2])..op(x,[2,1])))
   //   elif type(f)="int" then # double integrals #
   //      if type(op(f,2))="_equal" and not has(op(f,2),op(x,1)) then
   //         if sysorder(op(f,2),x)=FALSE then
   //            return(c*int(int(op(f,1),x),op(f,2)))
   //         end_if
   //      end_if
   //   end_if
   //end_if;
   c*hold(int)(f,x)
end_proc):
