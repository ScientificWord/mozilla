// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ 

/*++
Divs -- property::Divs as Type::Divs

Divs
++*/

Type::Divs:=
    proc()
      option noDebug;
      local _Args;
    begin
      if domtype(args()) = DOM_LIST then
        _Args:= args()
      else
	_Args:= extop(property::Divs(args()), 5)
      end_if;
      new(property::Divs,
	  "Divs",
	  proc(t,x)
	    name Type::Divs;
	  begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    bool(domtype(x) = property::Divs)
	  end_proc,
	  FALSE, FALSE,
	  _Args):
    end_proc:

// end of file 
