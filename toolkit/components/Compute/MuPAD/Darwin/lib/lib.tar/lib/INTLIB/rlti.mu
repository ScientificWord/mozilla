// $Date: 2002-10-15 18:51:42 +0200 (Tue, 15 Oct 2002) $ $Author: stefanw $ $Revision: 20466 $ 
/*--
The input for the procedure intlib::rlti (Rioboo-Lazard-Trager Improvement) is 
the simple function f in the fieldextension _global_k[n] splitted into numerator and 
denominator of the special part and the normal part of f respectively.
rlti(f_sNum,f_sDen,f_nNum,f_nNum,n) - computes g and h, which is n-reduced, so
that g'+h=f.
M. Bronstein, A Unification of Liouvillian Extension, AAECC 1990, 1
--*/
intlib::rlti:=
proc(f_sNum,f_sDen,A,B,n)
  local x,z,S,R,i,j,s,c,integral,zz,mp,sols,t,deg, f;
// global _global_k,_global_k_deg,Q_sub; 
begin
  if iszero(A) then return(f_sNum,f_sDen,0) end_if;
  x:=op(A,2);
  integral:=0;
  z:=genident();
  A:=A-poly(z,x)*intlib::diffs(B,n);
  S:=intlib::subres(A,B);
  userinfo(3,"subres prs:",S);
  S[0]:=intlib::primpart(poly(S[0],[z]))[1];
/*tt
  if test then print("Resultante:",S[0]); end_if;
  if indets(expr(S[0])) intersect {op(_global_k_sub)} <> {}
    then _proof(expr(A)/expr(B),
                "is not elementary integrable because",
                "the resultant contains non constant coefficients");
  end_if;
tt*/
  if indets(expr(S[0])) intersect {op(_global_k_sub)} <> {} then return(FAIL); end_if;
//  R:=intlib::sqffTab(multcoeffs(S[0],1/lcoeff(S[0])));
  R:=intlib::sqffTab(S[0]);
  userinfo(3,"R=",R);
  for i from 1 to nops(R) do
    if R[i]=poly(1,[z]) then next; end_if;
    s:=gcdex(poly(polylib::lcoeff(S[i]),[z]),R[i])[2]; // instead of intlib::gcdex 
    s:=intlib::sim(poly(divide(s*poly(S[i],[z]),R[i],Rem),x));
    userinfo(3,"s=",s);
    if traperror((j:=factor(R[i])))=0
      then R[i]:=[];
           j:= Factored::convert_to(j,DOM_LIST);
           for c from 2 to nops(j) step 2 do
             j[c]:=poly(j[c],[z]);
             R[i]:=append(R[i],multcoeffs(j[c],1/polylib::lcoeff(j[c])));
           end_for;
      else R[i]:=[R[i]];
    end_if;
    userinfo(3,"factors of resultant: ",R[i]);
    for j from 1 to nops(R[i]) do
      case degree(R[i][j])
        of 1 do
          c:=-coeff(R[i][j],0);
          integral:=integral-c*degree(s)*op(_global_k[n])*_global_k_deg[n]
                     +c*ln(normal(eval(expr(subs(s,z=c)))));
          break;
        of 2 do
          -coeff(R[i][j],1)/2;
          sqrt(%^2-coeff(R[i][j],0));
          %2+%1,%2-%1;
          integral:=integral+op(%1,1)*
                     ln(normal(eval(expr(subs(s,z=op(%1,1))))))
                     +op(%1,2)*ln(normal(eval(expr(subs(s,z=op(%1,2))))))
                     -(op(%1,1)+op(%1,2))*degree(s)*op(_global_k[n])*
                     _global_k_deg[n];
          break;
        otherwise
          zz:=genident(); // for RootOf 
          mp:=expr(R[i][j]);
          deg:=degree(mp,[z],z);
          if deg<=4 then
            sols:=solve(mp,z,MaxDegree=4,IgnoreProperties);
            
            f:=
            proc(sols)
            begin
              sols:= [op(sols)];
              if length(sols)< deg*100 then //heuristic assumption
                _plus(eval(subs(z*(ln(normal(expr(s)))-_global_k_deg[n]
                                   *degree(s)
                                   *op(_global_k[n])), z=sols[t]))
                      $ t=1..nops(sols))
              else
                _plus(
                      sum(z*(ln(normal(expr(s)))-
                             _global_k_deg[n]*degree(s)
                             *op(_global_k[n])),
                          z in RootOf(subs(expr(R[i][j]),z=zz),zz)))
              end_if;
            end_proc;

            if type(sols) = piecewise then
              integral:= integral + piecewise::extmap(sols, f)
            else
              integral:= integral + f(sols)
            end_if;
            
          else
            integral:=_plus(integral,
                            sum(z*(ln(normal(expr(s)))-_global_k_deg[n]*
                                   degree(s)
                                   *op(_global_k[n])),
                                z in RootOf(subs(expr(R[i][j]),z=zz),zz)))
          end_if
      end_case;
    end_for;
  end_for;
  return(f_sNum,f_sDen,integral);
end_proc:
