// $Date: 2007-02-01 10:43:33 +0100 (Thu, 01 Feb 2007) $ $Author: Christopher Creutzig $ $Revision: 42810 $

/*--
intlib::defInt( f,x=a..b, options )

--*/

// tests xrng used to be x=a..b
intlib::xrngTest:=
  proc(xrng)
    name intlib;
  begin
    if type(xrng) <> "_equal" then
       error("Second argument must be of form x=a..b")
    elif domtype(op(xrng,1)) <> DOM_IDENT then
       error("Integration variable is not an identifier")
    elif type(op(xrng,2)) <> "_range" then
       error("Second argument must be of form x=a..b")
//    elif has(op(xrng,2), op(xrng,1)) then
//       error("Range depends upon integration variable")
    end_if;
    null()
  end_proc:

// main procedure for definite integration
intlib::defInt:=
  proc(f :Type::Arithmetical, xrng) // options
    local prop,C,F,Ft,options,x,a,b,f0,x0,vorz, /*c, fc,*/ tmp, Float;
    save _X_; // necessary to make assumption on integration variable
              // I choose _X_ instead of _X as in intlib::int, since this is
              // more efficient if intlib::int is called
  begin
    f0:=f;
//    if testargs() then f:=eval(f); intlib::xrngTest(xrng) end_if;

    x:=op(xrng,1); a:=op(op(xrng,2),1); b:=op(op(xrng,2),2);
    vorz := 1;
    // empty range
    if iszero(b - a) then
      userinfo(1, "definite lookup: found empty range, result is 0");
      return(0)
    elif is(a > b) = TRUE then
      vorz := -1;
      C := a; a := b; b := C;
    end;
    options:=intlib::getOptions(args(3..args(0)));

    //----------------------------------------------
    // Changed by Walter, 13.12.05:
    // Move the call of diracInt to this place.
    // Later, x will be substituted by _X_ which
    // is assumed to lie in the open interval (a, b),
    // so that int(dirac(_X_), _X_ = a..b) does not
    // see the boundaries and returns 0.
    //----------------------------------------------
    if has(f, dirac) then
       tmp:= intlib::diracDef(f, x, a, b, options);
       if tmp <> FAIL then
          return(tmp);
       else
          return(hold(int)(args()));
       end_if;
    end_if;
    //----------------------------------------------
    // end of change by Walter
    //----------------------------------------------

    C:=genident("__X");
    if property::hasprop(_X_) then
      // (prop1:=getprop(_X_))<>hold(_X_) then //assume(C,prop1) end_if;
      //assume(C,prop1)  // does'nt work due to an error in assume
      zip([C],[getprop(_X_)],assume);
    end_if;
    delete _X_;
    if property::hasprop(x) then // x has property
      prop:= getprop(x);
      if property::IV::_and(prop,Type::Interval([a,b]))=Type::Interval([a,b])
        then
        //assume(_X_,prop); // properties are consistent
        zip([_X_],[prop],assume);
      else // properties may be inconsistent
        prop:=Type::Interval([a,b]);
        if intlib::printWarningsFlag then
          warning("While integrating, we will assume ".strprint(NoNL, x).
                  " has property ".strprint(NoNL, prop).
                  " instead of given property ".strprint(NoNL, getprop(x)).".");
        end_if;
        //assume(_X_,prop); // does'nt work due to an error in assume
        zip([_X_],[prop],assume);
      end_if;
    else
      //assume(_X_,Type::Interval(a,b));
      //zip([_X_],[Type::Interval([a,b])],assume);
      prop := Type::Interval(a,b);
      if prop::dom = property::IV then
        assume(_X_, prop);
      end_if;
    end_if;

    if has(f,int) then
      // in that case the following subs of this procedure may lead to
      // a wrong result, since different integration variables may become
      // the same
      if getprop(_X_)=Type::Interval(a,b) then
        // perhaps it is now possible to solve the nested integrals
        x0:=genident("_X_");
        zip([x0],[Type::Interval(a,b)],assume);
        f:=eval(subs(f,x=x0));
        if has(f,int) then
          return(hold(int)(f0,x=a..b,intlib::printOptions(options)))
        end_if;
        f:=eval(subs(f,x0=x));
        delete x0;
      else
        return(hold(int)(f0,x=a..b,intlib::printOptions(options)))
      end_if;
    end_if;

    if x<>_X_ then
      f:=eval(subs(f,[_X_=C,x=_X_]));
//      f:=Simplify(f, Steps=10);
      a:=subs(a,[_X_=C/* ,x=_X_ */]);
      b:=subs(b,[_X_=C/* ,x=_X_ */]);
    end_if;
    
    // look for floats
    tmp := f;
    f := misc::maprec(f,
                      {DOM_FLOAT, DOM_COMPLEX}=
                      (x -> numeric::rationalize(x, Minimize)));
    Float := if tmp=f then id else float end_if;
    
    // trying to integrate a sum term by term first
    // is in general a *good* idea.
    // Beware: int( (heaviside(x - x0) - heaviside(x - x1))*f(t), x = -infinity..infinity)
    //         = int(f(t), x = x0 .. x1).
    // Here, int(heaviside(x - x0)*f(t), -infinity .. infinity) may be undefined!
    // We need to do some work here!
    Ft := intlib::defInt_termByTerm(f, _X_, a, b, options);
    if Ft = FAIL or has(Ft, int) or has(Ft, undefined) then
      F:=intlib::defInt_intern(f,_X_=a..b,options);
      if Ft = FAIL or has(Ft, undefined) or 
        not has(F, int) or
        Simplify::defaultValuation(F) < Simplify::defaultValuation(Ft) then
        Ft := F;
      end;
    else
      F := Ft;
    end_if;
//    if type(F)<>"int" then
    F:=subs(F,[_X_=x,C=_X_]);
    Ft:=subs(Ft,[_X_=x,C=_X_]);
%if FALSE then // testeq uses expand, which can be very expensive
    if F = FAIL or has(F,int) then
    // use symmetries unless integrand contains symbolic int
      if not has(f0, hold(int)) and
         {a,b} intersect {infinity, -infinity, RD_INF, RD_NINF} = {} then
        c := (a+b)/2;
        if traperror((fc := eval(subs(f0, x=c)))) = 0 then
          if intlib::isodd(f0, x, c, fc) then
            userinfo(2, "integrand is odd around ".expr2text(c));
            return(Float(vorz * fc * (b-a)));
          end_if;
          if intlib::iseven(f0, x, (a+b)/2) then
            userinfo(2, "integrand is even around ".expr2text(c));
            return(Float(vorz * 2 * intlib::defInt(f0, x=c..b, args(3..args(0)))));
          end_if;
        elif options["PrincipalValue"] then
          if intlib::iseven(f0, x, (a+b)/2) then
            userinfo(2, "integrand is even around ".expr2text(c));
            return(Float(vorz * 2 * intlib::defInt(f0, x=c..b, args(3..args(0)))));
          end_if;
        end_if;
      end_if;
end_if;

      if not hastype(F, piecewise) then
        F:=hold(int)(Float(f0),x=subs(a, C=_X_)..subs(b, C=_X_),
                     intlib::printOptions(options));
      end_if;
    end_if;
    unassume(C);
    if Ft=FAIL then
      return(hold(int)(Float(f0),x=subs(a, C=_X_)..subs(b, C=_X_),
                       intlib::printOptions(options)));
    end_if;
    if vorz = -1 then Float(-Ft) else Float(Ft) end;
  end_proc:

intlib::defInt_termByTerm :=
proc(f, x, a, b, options)
  local f0, e, i, r, r2;
begin
  f0:=f;
  if type(f)="_mult" and contains(map({op(f)},type),"_plus") then
//      f:=expand(f)
    f := [op(f)];
     // find the first sum in the operands, expand
    for i from 1 to nops(f) do
      if type(f[i]) = "_plus" then
        e := f[i];
        delete f[i];
        f := `*`(op(f));
        f := map(e, `*`, f);
        break;
      end_if;
    end_for;
  end_if;
  if type(f)="_plus" then
    r:=0;
    r2 := 0;
    for e in [op(f)] do
      i:=intlib::defInt(e, x=a..b, options);
      if hastype(i,"int") or hastype(i, "limit") then
        r2 := r2+e;
      else
        r:=r+i
      end_if;
      if has(i, infinity) then // probably a bad idea to split the integral
        return(FAIL);
      end_if;
    end_for;
    if iszero(r2) then
      return(r);
    else
      if iszero(r) then
        return(FAIL);
      end_if;
      return(r+hold(int)(r2, x=a..b, intlib::printOptions(options)));
    end_if;
  end_if;
  FAIL
end_proc:


intlib::defInt_intern :=
  proc(f,xrng)  // options
    local i,res,tmp,g,fac,options,x,b,a,hf, ret, evalhull;
    save _X_; // to make prog::check happy.  already saved by our caller.
  begin
//    if testargs() then f:=eval(f); intlib::xrngTest(xrng) end_if;

    if f = undefined then
      return(undefined)
    end_if;
    x:=op(xrng,1); a:=op(op(xrng,2),1); b:=op(op(xrng,2),2);
    options:=intlib::getOptions(args(3..args(0)));
    if testtype(f,Type::PolyExpr(x)) and not options["PrincipalValue"] then
       // no singularity possible
       f:=poly(f,[x]);
       f:=_plus(coeff(f,i)*x^(i+1)/(i+1) $ i=0..degree(f));
       return(intlib::int_eval(f,x=b)-intlib::int_eval(f,x=a))
    elif is(b<a)=TRUE then
       return(-intlib::defInt_intern(f,x=a..b,options))
    end_if;

    // dirac must not reach some of the functions below
    if has(f, hold(dirac)) then return(intlib::diracDef(f, x, a, b, options)); end_if;

    // utility function: hull(f | _X_=u...v)
    evalhull := proc(f, u, v)
                  local iv;
                begin
                  iv := u...v;
                  hull(interval::evalSimple(f, _X_=iv));
                end_proc;
    
    // integrand bounded away from zero over infinite interval?
    if a = -infinity and is(b > -infinity)=TRUE then
      ret := FAIL;
      if traperror((hf := evalhull(f, RD_NINF, -1e100);
                    if min(hf,10^(2-DIGITS)) = 10^(2-DIGITS) then
                      ret := infinity;
                    elif max(hf,-10^(2-DIGITS)) = -10^(2-DIGITS) then
                      ret := -infinity;
                    end_if)) = 0 and ret <> FAIL then
        return(ret);
      end_if;
    end_if;
    if b = infinity and is(a < infinity)=TRUE then
      ret := FAIL;
      if traperror((hf := evalhull(f, 1e100, RD_INF);
                    if min(hf, 10^(2-DIGITS)) = 10^(2-DIGITS) then
                      ret := infinity;
                    elif max(hf, -10^(2-DIGITS)) = -10^(2-DIGITS) then
                      ret := -infinity;
                    end_if)) = 0 and ret <> FAIL then
        return(ret);
      end_if;
    end_if;

    // handle int(positive(x)/x, x=0..t) and similar
    if is(b>a) = TRUE and traperror((hf := evalhull(f, a, b))) = 0 and
       (op(hf, 1) = RD_NINF or op(hf, 2) = RD_INF) then
      ret := FAIL;
      // avoid missing other poles
      if traperror((hf := evalhull(eval(f*(_X_-a)), a, b)))
         = 0 and op(hf, 0) = hold(hull) and 
         op(hf, 1) > RD_NINF and op(hf, 2) < RD_INF then
        ret := FAIL;
        if traperror((hf := evalhull(eval(f*(_X_-a)),
                               a, (a+(b-a)*10^(3-DIGITS)));
                      if min(hf,10^(2-DIGITS)) = 10^(2-DIGITS) then
                        ret := infinity;
                      elif max(hf,-10^(2-DIGITS)) = -10^(2-DIGITS) then
                        ret := -infinity;
                      end_if)) = 0 and ret <> FAIL then
          return(ret);
        end_if;
      end_if;
      if traperror((hf := evalhull(eval(f*(b-_X_)), a, b)))
         = 0 and op(hf, 0) = hold(hull) and 
         op(hf, 1) > RD_NINF and op(hf, 2) < RD_INF then
        ret := FAIL;
        if traperror((hf := evalhull(eval(f*(b-_X_)), 
                                 (b-(b-a)*10^(3-DIGITS)), b);
                      if min(hf,10^(2-DIGITS)) = 10^(2-DIGITS) then
                        ret := infinity;
                      elif max(hf,-10^(2-DIGITS)) = -10^(2-DIGITS) then
                        ret := -infinity;
                      end_if)) = 0 and ret <> FAIL then
          return(ret);
        end_if;
      end_if;
    end_if;

    // frac(x) = x-floor(x)
    f := eval(subs(f, hold(frac)=(x->x-floor(x))));

    // functions containing ceil/floor are handled by this function:
    if has(f, {hold(ceil), hold(floor), hold(round),
               hold(heaviside)}) then
      i := intlib::defInt_ceil_floor(f, x, a, b, options);
      if i <> FAIL then return(i); end_if;
    end_if;
    // abs(real stuff) is also handled by partitioning the interval
    if has(f, {hold(abs)}) then
      i := intlib::defInt_abs(f, x, a, b, options);
      if i <> FAIL then return(i); end_if;
    end_if;

    // first try the lookup method
    // remove constant factors before lookup method
    if type(f)="_mult" then
      g:=select(f,has,x); fac:=select(f,not has,x)
    else g:=f; fac:=1
    end_if;

    res:=intlib::definite(g,a,b,options);
    if res=FAIL then
      res:=intlib::defLookup(g,x=a..b,options);
    end_if;
    if res<>FAIL then
      res:=fac*res;
      if type(res)<>piecewise or
        piecewise::isDefined(res) = TRUE then
        return(res)
      end_if;
    end_if;
    
    // special case due to changed normal form
    if fac = -1 then
      tmp:=intlib::definite(f,a,b,options);
      if tmp=FAIL then
        tmp:=intlib::defLookup(f,x=a..b,options);
      end_if;
      if tmp<>FAIL then
        if type(res)=piecewise and type(tmp)=piecewise then
          res:=piecewise::_concat(res,tmp);
        else
          res:=tmp;
        end_if;
        if type(res)<>piecewise or
          piecewise::isDefined(res)=TRUE then
          return(res)
        end_if;
      end_if;
    end_if;

    // test if integrand contains special functions that can be treated
    tmp:=intlib::specialFunctionDef(f,x,a,b,options);
    if tmp<>FAIL then
      if type(res)=piecewise and type(tmp)=piecewise then
        res:=piecewise::_concat(res,tmp);
      else
        res:=tmp;
      end_if;
      if type(res)<>piecewise or
        piecewise::isDefined(res)=TRUE then
        return(res)
      end_if;
    end_if;

    userinfo(1,"definite lookup method failed,try to use an antiderivative");
    // then try using an antiderivative
    tmp:=intlib::antiderivative(f,x=a..b,options);
    if type(tmp)<>"int" then
      if type(res)=piecewise and type(tmp)=piecewise then
        res:=piecewise::_concat(res,tmp);
      else
        res:=tmp;
      end_if;
    end_if;

    if type(res)=piecewise then
      res:=piecewise::fillCases(res, freeze(int)(f,x=a..b,intlib::printOptions(options)));
    end_if;

    return(res);
  end_proc:

intlib::antiderivative:=
  proc(f :Type::Arithmetical,xrng) // options
    save calledFromWithinDefInt;
    local g,g0,s,y,eps,lr,ia,ib,x,a,b,options,treat_disconts;
  begin

    // first do some tests and extract from arguments
    if testargs() then f:=eval(f); intlib::xrngTest(xrng) end_if;

    x:=op(xrng,1); a:=op(op(xrng,2),1); b:=op(op(xrng,2),2);
    options:=intlib::getOptions(args(3..args(0)));

    // set flag to prevent some simplifications done in indefinite integration
    sysassign(calledFromWithinDefInt,TRUE);

    // compute the antiderivative
    g:=int(f,x);

    // try to evaluate a sum(....z=RootOf(..))
    g0:=g;
    if type(g)="sum" then
      g0:=intlib::expandSum(g,x);
    elif has(g,sum) then
      g0:=map(g,intlib::expandSum,x);
    end_if;
    // test heuristically, if complexity of g0 is not too big,
    // otherwise exponential growth in memory usage may occur
    if length(g)*intlib::memGrowthFactor > length(g0) then g:=g0 end_if;
//    if has(g,I) then
//      g:=intlib::simplifyComplexIntegral(g,x,hold(Unique));
//    end_if;

    // substitute remaining two-argument arcus tangents
    // otherwise we could run into a bad branch and getting a wrong answer
    if has(g,arctan) then
      g:=eval(subs(g,hold(arctan)=proc(x,y)
                                  begin
                                    if args(0)=1 then
                                      arctan(x)
                                    else
                                      -I * ln((x+I*y)/(abs(x+I*y)))
                                    end_if
                                  end_proc));
    end_if;
    if has(g,arg) then
      g:=eval(subs(g,hold(arg)=((x,y)->-I*ln((x+I*y)/(abs(x+I*y))))));
    end_if;

    userinfo(2,"antiderivative is",g);
    if not hastype(g, "int") and g<>NIL then
      if options["Continuous"] then // g is assumed to be continuous
        if not has({a, b}, {infinity, -infinity}) then
          if traperror((g0 := (intlib::int_eval(g,x=b)
                               -intlib::int_eval(g,x=a))),
                        MaxSteps=intlib::discontMaxSteps(g, x, a, b)) = 0 then
            return(g0);
          end_if;
          if traperror(((g0 := intlib::limit(g, x=b, Right)
                             - intlib::limit(g, x=a, Left))))=0 then
            return(g0);
          end_if;
          return(hold(int)(f,x=a..b,intlib::printOptions(options)));
        end_if;
        s:={};
        userinfo(2,"antiderivative is assumed to be continuous");
      else
        // discontinuities in a..b
        // for finding discontinuities, we expand RootOf:
        g0 := misc::maprec(g,
                           {RootOf} =
                           (rof -> solve(op(rof, 1), op(rof, 2),
                                         MaxDegree=4, IgnoreSpecialCases)));

        if hastype(g0,RootOf) or has(f, dirac) then // this would yield an error within discont
          s:=Type::Interval(a,b);
        else
          traperror((g0:=Simplify(g0, Steps=50)),
                    MaxSteps=intlib::simplifyMaxSteps(f, g, discont));
          userinfo(2,"searching for discontinuities of ",g0,"in ",a..b);
          if traperror((s:=intlib::discont(g0,x=a..b, (if has({a,b},I) then Dom::Complex
                                           else Dom::Real end_if));),
                       MaxSteps=intlib::discontMaxSteps(g0, x, a, b)) <> 0 then
            if intlib::printWarningsFlag then
              warning("Could not determine discontinuities within reasonable time")
            end_if;
            s:= Type::Interval(a, b)
          end_if;
        end_if;
      end_if;
      userinfo(2,"potential discontinuities of the antiderivative are",s);
      if type(s) <> DOM_SET and
         type(s) <> piecewise then
        if intlib::printWarningsFlag then
          if length(expr2text(s)) < 50 then
            warning("potential discontinuities of the antiderivative are:\n ".
                    expr2text(s));
          end_if;
          warning("Found potential discontinuities of the antiderivative.".
                  "\nTry to use properties (?assume).");
        end_if;
      end_if;
      treat_disconts :=
      proc(s)
        name intlib::antiderivative::treat_disconts;
        local integral;
      begin
        if type(s) = DOM_SET then
          lr:=intlib::boundaryTest(g,x=a,Right);
          if not lr[1] and intlib::printWarningsFlag then
            warning("Antiderivative is unbounded at lower limit");
          end_if;
          ia:=lr[2];

          lr:=intlib::boundaryTest(g,x=b,Left);
          if not lr[1] and intlib::printWarningsFlag then
            warning("Antiderivative is unbounded at upper limit");
          end_if;
          ib:=lr[2];

          integral:=ib-ia;
          s:=s minus {a,b};
          for y in s do
            if options["PrincipalValue"] then // compute principal value
              eps:= genident("eps");
              integral:=integral
                       +intlib::limit(subs(g,x=y-eps)-subs(g,x=y+eps),
                                      eps=0,Right);
            else
              lr:=intlib::poleLRTest(g,x=y);
              if lr[1] then integral:=integral+lr[2]-lr[3];
              //else return(hold(int)(f,x=a..b))
              // otherwise there should not be a discontinuity
              end_if;
            end_if
          end_for;
          if not hastype(integral, {"int", "limit"}) then
            traperror((integral := Simplify(integral, Steps=30)),
                      MaxSteps=intlib::simplifyMaxSteps(f, integral, return));
          end_if;
          return(integral);
        else
          integral := freeze(int)(f, xrng, intlib::printOptions(options));
        end_if;
      end_proc;
      if type(s) <> piecewise then return(treat_disconts(s)); end_if;
      s := piecewise::extmap(s, treat_disconts);
      if type(s) <> piecewise then return(treat_disconts(s)); end_if;
      s := piecewise::selectExpressions(s, _not@hastype, "int");
      if type(s) <> piecewise then return(treat_disconts(s)); end_if;
      return(piecewise::fillCases(s, freeze(int)(f,x=a..b,intlib::printOptions(options))));
    end_if;
    if a=b then 0 else hold(int)(f,x=a..b,intlib::printOptions(options)) end_if
  end_proc:

intlib::boundaryTest:= // test, if lower or upper bound of given range is
  proc(f,x,dir)        // bounded
    local t,r;
  begin
    userinfo(6,"test, if antiderivative is bounded at ".expr2text(x));
    r:=intlib::limit(f,x,dir);
  //t:=(if has(r,{infinity,-infinity,undefined}) then FALSE else TRUE end_if);
    t:=not(bool(has(r,{infinity,-infinity,undefined})));
    [t,r]
  end_proc:

intlib::poleLRTest:=  // test, if limit's result is correct most probably
  proc(f,x)           // for inner discontinuous points
    local r,t,s;
  begin
    userinfo(6,"test, if antiderivative is indeed discontinuous at ".
               (s:=expr2text(x);));
    //if type(op(x,2))=stdlib::Infinity then
    if has(op(x,2),{infinity,-infinity}) then
      r:=intlib::limit(f,x);
      r:=[r,r];
    else
      r:=[intlib::limit(f,x,Left),intlib::limit(f,x,Right)]
    end_if;
    //t:=(if has(r,{infinity,-infinity,undefined}) or r[1]<>r[2] then TRUE
    //  else FALSE
    //    end_if);
    t:=bool(has(r,{infinity,-infinity,undefined}) or r[1]<>r[2]);
    userinfo(10, (if t then "is discontinuous at ".s
                 else "not discontinuous at ".s
                 end_if;));
    [t, op(r)]
  end_proc:

// wrapper function for limit which secures that only a valid value
// like an arithmetical expression or a symbolic limit-call is returned
// and performs a timeout wrapper.
intlib::limit:=
  proc(f)
    local lim;
    save _X_;
  begin
    delete _X_;
    lim := FAIL;
    f := eval(subs(f, hold(arctan) = (x -> (ln(1-x*I)-ln(1+x*I))*I/2)));
    traperror((lim := eval(hold(limit)(args()))),
               MaxSteps=intlib::limitMaxSteps(args()));
    case type(lim)
      of Dom::Interval do
      of DOM_FAIL do
        hold(limit)(args());
        break
      otherwise
        lim
    end_case
  end_proc:


/*--
        intlib::int_eval(f,x=a,dir,typ)

        evaluates f in x=a with direction dir (Left or Right) and typ=TRUE
        iff a is a singular point
--*/
intlib::int_eval := proc(f,x)
begin
   //if type(op(x,2))=stdlib::Infinity then
   if has(op(x,2),{infinity,-infinity}) then
       intlib::limit(f,x)
   elif args(0)>=4 and args(4) then
       intlib::limit(f,x,args(3))
   else
       eval(subs(f,x))
   end_if
end_proc:

