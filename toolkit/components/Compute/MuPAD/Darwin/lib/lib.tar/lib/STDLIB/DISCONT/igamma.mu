
/*
igamma::discont - the discont method for the incomplete gamma function

*/

igamma::discont:=
proc(f:"igamma", x: DOM_IDENT, F)
  local t;
begin
  t:= op(f, 1);
  if is(Re(t) > 0) = TRUE then
    // igamma(t, x) is everywhere continous if Re(t) > 0:
    return(discont(t, x, F))
  end_if;

  // otherwise we don�t know:
  FAIL
end_proc: