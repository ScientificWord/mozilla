
genident("k"):
coth::complexDiscont :=
     Dom::ImageSet(PI*I*%, %,
                   solvelib::BasicSet(Dom::Integer)):

coth::undefined := coth::complexDiscont:
