// $Date: 2004-04-01 14:01:37 +0200 (Thu, 01 Apr 2004) $ $Author: stefanw $ $Revision: 27091 $ 
/*--
intlib::solveRde(f,g,n) -solves the 
Risch differential equation y'+fy=g for f,g in _global_k[n]
M. Bronstein, The Transcendental Risch Differential Equation, Journal of
Symbolic Computation, 1990, 9
--*/
intlib::solveRde:=
proc(f,g,n)
  local P,G,T,A,B,C,x,b,c,r,t,Y;
// global _global_k_sub,_global_k_diff; 
begin
  f:= normal(f);
  userinfo(2,"n=",n,"solving Risch de Y'+(",f,")*Y=",g);
  x:=_global_k_sub[n];
  P:=intlib::weaknorm(f,n);
  if P=FAIL then return(FAIL); end_if;
  f:=intlib::split2(f-intlib::diffs(P,n, _global_k,_global_k_sub)/P,n);
  g:=intlib::split2(P*g,n);
  G:=intlib::gcdk_n(f[4],g[4]);
  T:=intlib::sim(divide(intlib::gcdk_n(g[4],diff(g[4],x)),
                        intlib::gcdk_n(G,diff(G,x)))[1]);
  G:=intlib::sim(divide(f[4]*T^2,g[4]));
  if not(iszero(G[2])) then return(FAIL); end_if;  
  A:=intlib::sim(f[4]*T);
  B:=intlib::sim(f[1]*f[4]*T+(f[3]*T-f[4]*intlib::diffs(T,n, _global_k,_global_k_sub))*f[2]);
  C:=intlib::sim(g[1]*f[4]*T^2+g[3]*G[1]*g[2]);
  if op(_global_k[n],0)=hold(exp) then 
     if iszero(B) then
       b:=degree(f[2]);
     else
       b:=degree(f[2])- degree(nthmonomial(B,nterms(B)));
     end_if;
     if iszero(C) then
       c:=0;
     else
       c:=degree(g[2])-degree(nthmonomial(C,nterms(C)));
     end_if;
     if b<>0 then 
          r:=min(0,max(0,b)-c);
     else //--------------------------------------------------------------
          // Winfrieds original code:
          // r:=intlib::inttest(nthcoeff(B,nterms(B))/nthcoeff(A,nterms(A)),n);
          // Walter 6.2.02: replaced by the following if statement (note that
          // nthcoeff(0-poly, 0) produces an error)
          if nterms(B) <> 0 and nterms(A) <> 0 then
               r:=intlib::inttest(nthcoeff(B,nterms(B))/nthcoeff(A,nterms(A)),n);
          else // Walter 6.2.02: I am not sure what to do
               // in this case. I hope, r := FAIL is OK.
               r:= FAIL
          end_if;
          //--------------------------------------------------------------
          if r=FAIL then 
               r:=min(0,-c); 
          else r:=min(-r[1],-c); 
          end_if;
     end_if;
     t:=max(0,b,r+c);
     A:=A*poly(x^t,[x]);
     B:=intlib::sim(multcoeffs(A,r*_global_k_diff[n])+
                    B*poly(x^(t-degree(f[2])),[x]));
     C:=C*poly(x^(t-r-degree(g[2])),[x]);
  else
     r:=0;
  end_if;
  Y:=intlib::bound(A,B,C,n);
  if Y=FAIL then
    userinfo(10,"can't solve polynomial de:(",A,")*Y'+(",B,")*Y=",C,"n=",n);
    return(FAIL); end_if;
  return(Y/(expr(T)*P)*x^r);
end_proc:
