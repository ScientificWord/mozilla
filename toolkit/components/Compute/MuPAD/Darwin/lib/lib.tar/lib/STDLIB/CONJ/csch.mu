// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	csch/conjugate -- the function attribut "conjugate" for csch
--*/

csch:= slot( csch, "conjugate", proc() begin 
    conjugate(args(1));
    if type(%) = "conjugate" then hold(csch)(%)
    else csch(%)
    end_if
 end_proc  ):

// end of file 
