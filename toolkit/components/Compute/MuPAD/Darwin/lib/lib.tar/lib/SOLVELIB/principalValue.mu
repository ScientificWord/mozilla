
alias(CONSTANTS = [0, 1, PI, exp(1)]):

solvelib::principalValue:=
proc(eqs, vars, options: DOM_TABLE)
  local result, c, sol;
begin

  if not contains({DOM_LIST, DOM_SET}, type(eqs)) and
    type(vars) = DOM_IDENT then
    for c in CONSTANTS do
      if testeq((eqs | vars=c), 0) then
        return({c})
      end_if
    end_for
  end_if;

  options["PrincipalValue"]:=FALSE;
  sol:= solve(eqs, vars, options);
  if sol = {} then
    return({})
  else
    result:= solvelib::getElement(sol)
  end_if;
  if result = FAIL then
    options["PrincipalValue"]:= TRUE;
    if type(sol) <> "solve" then
      warning("Equation has been solved, but no element could be extracted")
    end_if;
    return(hold(solve)(eqs, vars, solvelib::nonDefaultOptions(options)))
  else
    return({result})
  end_if

end_proc: