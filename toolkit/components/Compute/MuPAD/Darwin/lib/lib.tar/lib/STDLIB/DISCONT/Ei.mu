Ei::complexDiscont:= Dom::Interval(-infinity, [0]):
