// $Date: 2006-01-24 16:44:45 +0100 (Tue, 24 Jan 2006) $ $Author: rensmann $ $Revision: 36483 $

/*++
infinity -- representing the real positive infinity

An infinite number is represented as an element of the domain
stdlib::Infinity. An element of this domain has one operand:

- The sign, which is either -1 or 1.

- Given the sign s the elements represent limes(s*a, a = infinity).

The domain element 'infinity' (which represents the positive real
infinity) is defined here. Other domain elements are only created
via the operations of this domain and NOT via 'new'.
++*/

stdlib::Infinity:= newDomain("stdlib::Infinity"):
stdlib::Infinity::create_dom:=hold(stdlib::Infinity):

infinity:= new(stdlib::Infinity, 1):

stdlib::Infinity::info:= "Domain 'stdlib::Infinity': representing infinity":
stdlib::Infinity::interface:= {}:

stdlib::Infinity::expr:=
proc()
begin
    extop(args(1),1) * hold(infinity)
end_proc:

stdlib::Infinity::print:= stdlib::Infinity::expr:
stdlib::Infinity::isNeg:= x->bool(op(extop(x,1))<0):

stdlib::Infinity::subs:=
proc(inf, subst)
  local unsimp: DOM_BOOL;
begin
  if args(0) = 1 then
    return(inf)
  end_if;
  unsimp:= contains({args()}, Unsimplified);
  assert(args(0) = 2 or unsimp);
  // other cases should be caught by the kernel
  if type(subst) = DOM_LIST  then
    return(subs(inf, op(subst)))
  end_if;
  assert(type(subst) = "_equal");
  if op(subst, 1) = inf then
    return(op(subst, 2))
  end_if;
  if sign(inf) = -1 then
    if op(subst, 1) = -1 then
      if unsimp then
        hold(_mult)(op(subst, 2), infinity)
      else
        op(subst, 2)*infinity
      end_if
    elif op(subst, 1) = infinity then
      if unsimp then
        hold(_mult)(op(subst, 2), -1)
      else
        -op(subst, 2)
      end_if
    else
      inf
    end_if
  else
    inf
  end_if;
end_proc:

stdlib::Infinity::TeX:=
proc()
begin
  case extop(args(1),1)
    of 1 do
      "\\infty";
      break;
    of -1 do
      "- \\infty";
      break;
    end_case
end_proc:

stdlib::Infinity::_negate:=
proc()
  option noDebug;
begin
  extsubsop(args(1), 1 = -extop(args(1),1))
end_proc:

stdlib::Infinity::_invert:=
proc()
  option noDebug;
begin
  0
end_proc:

stdlib::Infinity::_subtract:=
proc()
  option noDebug;
begin
  args(1)+(-args(2))
end_proc:

stdlib::Infinity::_divide:=
proc(x, y)
  option noDebug;
begin
  x*(1/y)
end_proc:

stdlib::Infinity::_not:=
proc()
begin
  error("invalid operand")
end_proc:

stdlib::Infinity::_power:=
proc(x, pow)
begin
  if type(pow) = piecewise then
    return(piecewise::extmap(pow, y -> x^y))
  end_if;
  if domtype(x) = DOM_SET then
    return(map(x, _power, pow))
  end_if;
  case domtype(pow)
    of stdlib::Infinity do
      if // no! x = infinity or // not 'undefined' for infinity^infinity!
         x = -infinity or // could also be 'complexInfinity'
         x = complexInfinity or
         x = undefined
        or (x= infinity and pow = -infinity)
        then
        return(undefined)
      end_if;

      if not testtype(x, Type::Arithmetical) then
        error("Illegal argument")
      end_if;
      if pow = infinity then
        return(piecewise([x=1, 1],
                         [x>1, infinity],
                         [abs(x) < 1, 0]
                      //   abs(x) >= 1 and not x>0 -> undefined
                         )
               )
      else
        return((x^extop(pow,1))^infinity)
      end_if;
      // NOT REACHED
      assert(FALSE);
      break
    of stdlib::CInfinity do
      // infinity^complexInfinity .-> undefined
      return(undefined)
    of DOM_FLOAT do
      if iszero(pow) then return(1.0) end_if;
    of DOM_INT do
      if pow = 0 then return(1) end_if;
    of DOM_RAT do
      if pow < 0 then return(0) end_if;
      (extop(x,1)^pow) * infinity;
      break
    of DOM_SET do
      return(map(pow, t -> x^t ))
    otherwise
      if not testtype(pow, Type::Arithmetical) then
        error("Illegal argument")
      end_if;
      if x = infinity then
        piecewise([pow > 0, infinity],
                  [Re(pow) < 0, 0])
      else
        assert(x = -infinity);
        piecewise([Re(pow) < 0, 0])
      end_if
  end_case
end_proc:

stdlib::Infinity::_plus:=
proc()
  local a, b, dummy;
begin
  // handle sets separately
  [b, a, dummy]:= split([args()], x-> domtype(x) = DOM_SET);
  assert(nops(dummy) = 0);
  if nops(b) > 0 then
    b:= _plus(op(b));
    a:= _plus(op(a));
    return(map(b, _plus, a))
  end_if;
  // handle other Cat::Set separately
  [a, b, dummy]:= split([args()], x-> x::dom::hasProp(Cat::Set) = TRUE);
  assert(nops(dummy) = 0);
  if nops(a) > 0 then
    b:= _plus(op(b));
    a:= _plus(op(a));
    // in this order! uses a::dom::_plus
    return(a+b)
  end_if;
  // handle piecewises separately
  [b, a, dummy]:= split([args()], x-> domtype(x) = piecewise);
  assert(nops(dummy) = 0);
  if nops(b) > 0 then
    b:= _plus(op(b));
    a:= _plus(op(a));
    return(b+a)
  end_if;
  // select infinities and others
  [a, b, dummy]:= split(a, not (stdlib::Infinity)::thisDomain);
  assert(nops(dummy) = 0);
  // skip real part of constants
  if contains(a, complexInfinity) > 0 or
    contains(a, undefined) > 0 then
    return(undefined)
  end_if;

  // skip reals
  a:= select(a, z -> is(z, Type::Real) <> TRUE);

  a:= map(a, u-> if testtype(u, Type::Constant) then
                   I*Im(u)
                 else
                   u
                 end_if
                   );
  a:= _plus(op(a));
  if a = undefined or a = complexInfinity then
    return(undefined)
  end_if;

  b:= {op(b)};
  if nops(b) > 1 then
    return(undefined)
  elif nops(b)=0 then
    // should not happen!
    return(a)
  end_if;

  // now nops(b)=1

  if iszero(a) then
      op(b)
  elif type(a) = "_plus" then  // flat operands of a
    hold(_plus)(op(a), op(b))
  else
    hold(_plus)(a, op(b))
  end_if
end_proc:

stdlib::Infinity::_mult:=
proc()
  local a, b, c, f, dummy, sgn:DOM_INT;
begin
  // handle sets separately
  [a, b, dummy]:= split([args()], x-> domtype(x) = DOM_SET);
  assert(nops(dummy) = 0);
  if nops(a) > 0 then
    b:= _mult(op(b));
    a:= _mult(op(a));
    return(map(a, _mult, b))
  end_if;
  // handle other Cat::Set separately
  [a, b, dummy]:= split([args()], x-> x::dom::hasProp(Cat::Set) = TRUE);
  assert(nops(dummy) = 0);
  if nops(a) > 0 then
    b:= _mult(op(b));
    a:= _mult(op(a));
    // in this order! uses a::dom::_mult
    return(a*b)
  end_if;
  // handle piecewises separately
  [b, a, dummy]:= split([args()], x-> domtype(x) = piecewise);
  assert(nops(dummy) = 0);
  if nops(b) > 0 then
    b:= _mult(op(b));
    a:= _mult(op(a));
    return(b*a)
  end_if;

  b:= [args()];

  if contains(b, undefined) <> 0 then return(undefined) end_if;
  if contains(b, complexInfinity) <> 0 then return(complexInfinity) end_if;

  // f is only a dummy arg:

  [a,c,f]:=split(b, (stdlib::Infinity)::thisDomain);

  // multiply the signs of all infinities
  sgn:=_mult(op(map(a, extop, 1)));

  // multiply by all arguments one after the other
  // if the multiplication cannot be done, coellect the factors in a

  a:=[];

  for b in c do
    case sign(b)
      of 0 do
        // 0*infinity is undefined
        return(undefined)
      of 1 do
        break; // nothing to be done
      of -1 do
        sgn:= -sgn;
        break;
      otherwise
        if type(b) = "_mult" then  // flat operands of a
          a:=a.[op(b)]
        else
          a:=a.[b]
        end_if
    end_case;

  end_for;

  b:=new(stdlib::Infinity, sgn);

  if a = [] then
    b
  else
    a:= _mult(op(a));
    if type(a) = DOM_COMPLEX then
      if iszero(op(a, 1)) then
        hold(_mult)(sign(op(a, 2))*sgn*I, infinity)
      else
        new(stdlib::Infinity, sign(op(a ,1))*sgn) +
        hold(_mult)(sign(op(a, 2))*sgn*I, infinity)
      end_if
    elif is(a, Type::Real) = TRUE then
      piecewise([a > 0, b], [a < 0, _negate(b)])
    else
      hold(_mult)(a, b)
      // does not work well together with limit:
      //genident();
      //hold(limit)(a*%, %, b)
      // too complicated:
      /*
      piecewise([Re(a) > 0 and Im(a) > 0, infinity + I*infinity],
                [Re(a) > 0 and Im(a) = 0, infinity],
                [Re(a) > 0 and Im(a) < 0, infinity - I*infinity],
                [Re(a) = 0 and Im(a) > 0, I*infinity],
                [Re(a) = 0 and Im(a) < 0, -I*infinity],
                 [Re(a) < 0 and Im(a) > 0, -infinity + I*infinity],
                [Re(a) < 0 and Im(a) = 0, -infinity],
                [Re(a) < 0 and Im(a) < 0, -infinity - I*infinity]
                )
      */
    end_if
  end_if
end_proc:

stdlib::Infinity::_less:=
proc(x,y)
begin
  if x = infinity or y = -infinity then
    FALSE
  elif x = -infinity then
    bool(y=infinity) or numeric::isreal(y)
  else
    assert(y = infinity);
    numeric::isreal(x)
  end_if
end_proc:


stdlib::Infinity::_leequal:= (x, y) ->bool(x=y or x<y):

stdlib::Infinity::min:=
proc()
  local b;
begin
  b:= { args() };
  if contains(map(b, domtype), DOM_COMPLEX) then
    error("complex numbers are not allowed as arguments")
  elif contains(b, -infinity) then
    -infinity
  else
    // remove all +infinity
    b:=select(b, _unequal, infinity);
    if b={} then
      infinity
    else
      min(op(b))
    end_if
  end_if
end_proc:


stdlib::Infinity::max:=
proc()
  local b;
begin
 b:= { args() };
  if contains(map(b, domtype), DOM_COMPLEX) then
    error("complex numbers are not allowed as arguments")
  elif contains(b, infinity) then
    infinity
  else
    // remove all +infinity
    b:=select(b, _unequal, -infinity);
    if b={} then
      -infinity
    else
      max(op(b))
    end_if
  end_if
end_proc:


stdlib::Infinity::intmult:=
proc()
begin
  if iszero(args(2)) then
    undefined
  elif
    args(2) > 0 then
    args(1)
  else
    extsubsop(args(1), 1 = -extop(args(1),1))
  end_if
end_proc:

stdlib::Infinity::thisDomain:=
proc()
begin
  bool(domtype(args(1)) = stdlib::Infinity)
end_proc:


stdlib::Infinity::simplify:= id:

// the only thing that an infinity "has" is the object infinity

stdlib::Infinity::has:=(x,y) -> bool(y=infinity):

stdlib::Infinity::sign:=
proc()
begin
  extop(args(1),1)
end_proc:

stdlib::Infinity::O:= proc() begin undefined end_proc:

stdlib::Infinity::Re := id:

stdlib::Infinity::Im := 0:

stdlib::Infinity::ceil:= id:
stdlib::Infinity::floor:= id:
stdlib::Infinity::trunc:= id:
stdlib::Infinity::frac:= () -> undefined:

stdlib::Infinity::float:=
proc(inf)
begin
  if extop(inf, 1)=1 then RD_INF else RD_NINF end_if
end_proc:

stdlib::Infinity::hull :=
proc(self)
begin
  case extop(self, 1)
  of 1 do
    hull(RD_INF);
    break;
  of -1 do
    hull(RD_NINF);
    break;
  end_case;
end_proc:


stdlib::Infinity::hasmsign:= x -> stdlib::hasmsign(extop(x, 1)):


stdlib::Infinity::Content :=
proc(Out, data)
  local res;
begin
  res := Out::Ccn(["type"="constant"], Out::Cinfinity()):
  if data > 0 then
    res
  else
    Out::Capply(Out::Cminus, res)
  end_if
end_proc:

// end of file
