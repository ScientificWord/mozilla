// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ 

/*++
Complex -- expression to test for complex numbers

Complex
++*/

//  
// erweitert fur `property' 

Type::Complex:=
  new(property::NRange,
      "Complex",
      proc(t,x)
	name Type::Complex;
	option noDebug;
      begin
        if args(0) <> 2 then return(FALSE) end_if;
        if contains({DOM_INT, DOM_RAT, DOM_FLOAT, DOM_COMPLEX}, domtype(x)) then
          TRUE
        else
          FAIL
        end_if;
      end_proc,
      FALSE, FALSE,
      ["Complex", property::Null]
      ):

// real complex
// Type::Complex:=
//   new(property::Complex,
//       "Complex",
//       proc(t,x)
//       option noDebug;
//       begin
//         if args(0) <> 2 then return(FALSE) end_if;
//         if contains({DOM_INT, DOM_RAT, DOM_FLOAT, DOM_COMPLEX}, domtype(x)) then
//           TRUE
//         else
//           FAIL
//         end_if;
//       end_proc,
//       FALSE, FALSE,
//       [Type::Real, Type::Real]
//       ):
