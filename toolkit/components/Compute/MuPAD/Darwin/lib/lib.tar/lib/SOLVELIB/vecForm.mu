// $Date: 2004-11-09 18:10:15 +0100 (Tue, 09 Nov 2004) $ $Author: stefanw $ $Revision: 29206 $

// solvelib::vectorForm - writes the output of the system solver
// as a set of vectors
// a solution var1=value1,..., varn=valuen
// corresponds to the vector [value1, ...,valuen]
// if varlist was [var1,...,varn]


solvelib::vectorForm:=
proc(solution, varlist)
  local x, Rhs, i;
begin

case type(solution)
  of piecewise do
    return(piecewise::extmap(solution, solvelib::vectorForm, varlist))
  of "_in" do
    x:=op(solution,1);
    Rhs:=op(solution,2);
    case type(Rhs)
      of DOM_SET do
      // expand
        return({matrix(subs(varlist, x=op(Rhs, i)) $i=1..nops(Rhs))})
      of piecewise do
        return(map(Rhs, S-> solvelib::vectorForm(hold(_in)(x,S), varlist)))
      otherwise
        return(Dom::ImageSet(varlist, x, Rhs))
    end_case
  of DOM_SET do
    // solution consists of lists of equations or
    // inequalities or in-expressions
    
    return(_union
           (op
            (map
             (solution,
              proc(eqlist)
                local equ, result, cond, var;
              begin
                cond:= table();
                result:= varlist;
                for equ in eqlist do
                  if type(equ) = "_equal" then
                    // substitute
                    result:= subs(result, equ)
                  else
                    error("Solution does not consist of equations")
                   end_if;
                 end_for;
              // handle unsubstituted vars
              // implicit image set
              for var in indets(result) intersect {op(varlist)} do
                cond[var]:= C_
              end_for;
              
              if nops(cond) = 0 then
                {matrix(result)}
              else
                [op(cond)];
                Dom::ImageSet(result, map(%, op, 1), map(%, op, 2))
              end_if
              end_proc
              ))))
end_case;

// NOT REACHED

  error("Unknown type of solution")

end_proc:
  