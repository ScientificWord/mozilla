// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $  $Author: bij $  $Revision: 8304 $ 
// kg, 08/07/93 

/************* Now obselete and no longer allowed ****************/

/*++
func -- create a function from an expression


func(e, [x1,...,xn])

e         - expression, a function of x1,...,xn
x1,...,xn - (optional) indeterminates

func views the expression e as a function of the indeterminates x1,...,xn
and returns a 'pure function' computing that function. If no
indeterminates are given, any indeterminates of e found by indets are
used.

(A pure function is a special form of procedure which evaluates in the
context of the caller and is faster than procedures.)

The arguments are not evaluated!


++*/

func:= proc() option hold; begin
    error("func(...) no longer available")
end_proc:

// end of file 
