// $Id: discont.mu 35402 2005-12-05 08:28:58Z ccr $

// intlib::discont: Call discont, tracing all is-calls to the identifiers
// found.  If no set or piecewise of sets is returned, try assumptions.
// This may be an expensive operation.

intlib::discont_intern :=
proc(f, xr, over, notTheseIdents={}, cond)
local s, ids, conds, i, a, l, res, OtherTRUE;
save is, property; // for tracing of conditions
begin
	// for simpler Otherwise-treatment
	OtherTRUE := x -> x;
	OtherTRUE(Otherwise) := TRUE;
	ids := [op(indets(f) minus notTheseIdents)];
	map(ids, property::trace);
	s := piecewise::disregardPoints(discont(f, xr, over));
	conds := map(ids, property::untrace);
	if s::dom = DOM_SET then
		return([cond, s]);
	elif s::dom = piecewise and {domtype(piecewise::expression(s,i))$i=1..nops(s)}={DOM_SET} then
		return([cond and OtherTRUE(piecewise::condition(s, i)),
		        piecewise::expression(s, i)] $ i = 1..nops(s))
	else
		// choose the ide\mntifier with the simplest conditions
		l := prog::sort(select([$1..nops(ids)], i -> conds[i]<>[]),  i -> Simplify::defaultValuation(conds[i]));
		if l=[] then 
			if s::dom = piecewise then
				return([cond and OtherTRUE(piecewise::condition(s, i)),
				        piecewise::expression(s, i)] $ i = 1..nops(s))
			else
				return([cond, s]);
			end_if;
		end_if;
		a := ids[l[1]];
		conds := conds[l[1]];
		// we can't use assume here, since the conditions may be way too complex for that.
		// but we know what the code will be asking for... :-)
		res := [proc()
		    	save is;
		    	begin
		    		if nops(conds[i]) = 1 then
		    			sysassign(is(op(conds[i])), TRUE);
		    			sysassign(is(op(conds[i]), property::Null), TRUE);
		    		else
		    			sysassign(is(op(conds[i])), TRUE);
		    		end_if;
		    		intlib::discont_intern(f, xr, over, notTheseIdents union {a},
						cond and if nops(conds[i])=1 then op(conds[i]) else _in(op(conds[i])) end_if);
		    	end_proc() $ i = 1..nops(conds)];
		res := prog::sort(select(res, _not@has, hold(discont)), Simplify::defaultValuation);
		op(res);
	end_if;
end_proc:

intlib::discont := (f, xr, over) -> eval(hold(piecewise)(intlib::discont_intern(f, xr, over, {}, TRUE), [Otherwise, C_])):


null():

