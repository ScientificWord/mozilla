/* $Date: 2007-01-17 13:51:05 +0100 (Wed, 17 Jan 2007) $ $Author: Stefan Wehmeier $ $Revision: 42431 $ */

// solvelib::BasicSet - the domain of basic sets



alias(Z = new(solvelib::BasicSet, Dom::Integer)):
alias(Q = new(solvelib::BasicSet, Dom::Rational)):
alias(R = new(solvelib::BasicSet, Dom::Real)):
alias(C = new(solvelib::BasicSet, Dom::Complex)):


alias(path = pathname("SOLVELIB", "BASICSET")):


domain solvelib::BasicSet

  local plusexpr, multexpr, simpexInReal, simpexInRational, simpexInInteger;

  inherits Dom::BaseDomain;

  category Cat::Set;

  axiom Ax::canonicalRep;
      /* no two basic sets represent the same mathematical object !? */


      /* entries */

    convert:=
    proc(x)

    begin
      if contains({Dom::Integer, Dom::Real, Dom::Rational, Dom::Complex}, x)
        then
        new(dom, x)
      else
        FAIL
      end_if
    end_proc;

    _subset :=
    proc( A, B )
      local r;
    begin
      case type(A)
        of dom do
          case type(B)
            of dom do
              // should have been handled by assignment
              assert(FALSE);
              return(bool(A minus B = {}))
            of Dom::Interval do
              if B = Dom::Interval(-infinity, infinity) then
                return(A subset R_)
              else
                return(FALSE)
              end_if
            of DOM_SET do
              return(FALSE)
          end_case
        of Dom::Interval do
          if B=R_ or B=C_ then
            return(TRUE)
          end_if;
          break
        of DOM_SET do
          // should have been handled in _subset
          assert(FALSE);
          return(hold(_subset)(A, B))
        of "_intersect" do
          r := map( {op(A)}, _subset, B );
          if contains( r, TRUE ) then return( TRUE ); end_if;
          break;
        of "_union" do
          r := map( {op(A)}, _subset, B );
          if contains( r, FALSE ) then return( FALSE ); end_if;
          break;
        of "_minus" do
          r := op(A,1) subset B;
          if ( r=TRUE) then return( TRUE ) end_if;
          break;

      end_case;

      hold(_subset)(A,B)
  end_proc;


    /* equality */


  bin_equal:= bool@_equal;


  inhomog_equal:=
  table(
        DOM_SET = FALSE
        );


/* union, intersection, minus */

  homog_intersect:=
  proc()
    local arglist;

  begin
    arglist:=[args()];
    if testargs() then
      if {op(arglist)} minus {Z, Q, R, C} <> {} then
        error("Illegal argument")
      end_if
    end_if;
    if contains(arglist, Z)>0 then
      Z
    elif contains(arglist, Q)>0 then
      Q
    elif contains(arglist, R)>0 then
      R
    else
      C
    end_if
  end_proc;


  homog_union:=
  proc()
    local arglist;

  begin
    arglist:=[args()];
    if testargs() then
      if {op(arglist)} minus {Z, Q, R, C} <> {} then
        error("Illegal argument")
      end_if
    end_if;
    if contains(arglist, C)>0 then
      C
    elif contains(arglist, R)>0 then
      R
    elif contains(arglist, Q)>0 then
      Q
    else
      Z
    end_if
  end_proc;


  bin_minus:=
  proc(A: dom, B: dom)
  begin
    // should be controlled by the category
    assert(args(0) = 2);
    if A=B or B = C then
      {}
    else
      // some cases are also handled by assignment below !
      hold(_minus)(A, B)
    end_if
  end_proc;



  inhomog_intersect:=
  table(

        DOM_EXPR=
        proc(bset, e:DOM_EXPR)
          local A, B;
        begin
          if bset=C then
            e
          else
            case type(e)
              of "_minus" do
                A:=bset intersect op(e,1);
                B:=bset intersect op(e,2);
                if type(A)<>"_intersect" and type(B)<>"_intersect" then
                  return(A minus B)
                end_if;
                if B=bset then return( {} ); end_if;
                break
              of "_union" do
                A:=map([op(e)], _intersect, bset);
                if contains(map(A, type), "_intersect")=0 then
                  return(_union(op(A)))
                end_if;
                break
              of "Union" do
                A:= op(e, 1) intersect bset;
                if type(A) <> "_intersect" then
                  return(solvelib::Union(A, op(e, 2..nops(e))))
                end_if;
                break
            end_case;
            FAIL
          end_if
        end_proc,

        DOM_SET=
        proc(bset, S:DOM_SET)
          local splitset;
        begin
          if bset=C then
            return(S)
          end_if;
          splitset:=split(S, is,(case bset
                                   of Z_ do
                                     Type::Integer;
                                     break;
                                   of Q_ do
                                     Type::Rational;
                                     break
                                   of R_ do
                                     Type::Real;
                                     break
                                 end_case));
          if op(splitset,3)={} then
            splitset[1]
          else
            // expand each element of splitset[3] to a piecewise
            map(splitset[3], el-> piecewise([el in bset, {el}],
                                            [not el in bset, {}]));
            splitset[1] union _union(op(%))
          end_if
        end_proc,

        Dom::Multiset =
        proc(bset, S:Dom::Multiset)
          local splitset;
        begin
         if bset=C then
            return(S)
          end_if;
          splitset:=split(S, is,(case bset
                                   of Z_ do
                                     Type::Integer;
                                     break;
                                   of Q_ do
                                     Type::Rational;
                                     break
                                   of R_ do
                                     Type::Real;
                                     break
                                 end_case));
          if nops(splitset[3])=0 then
            splitset[1]
          else
            splitset[1] union hold(_intersect)(splitset[3], bset)
          end_if
        end_proc,


        Dom::Interval =
        proc(bset,iv)
          local lb, rb;
        begin
          if bset=R or bset=C then
            iv
          elif iv=Dom::Interval(-infinity, infinity) then
            bset
          elif bset=Q then
            FAIL
          else /* bset = Z */
            if testtype((lb:=iv::dom::left(iv)), Type::Constant)=TRUE and lb<>RD_NINF and
              testtype((rb:=iv::dom::right(iv)), Type::Constant)=TRUE and rb<>RD_INF then
              if not iv::dom::isleftopen(iv) then
                lb:=ceil(lb)
              else
                lb:=floor(lb+1)
              end_if;
              if not iv::dom::isrightopen(iv) then
                rb:=floor(rb)
              else
                rb:=ceil(rb-1)
              end_if;
              if rb - lb < 1000 then
                {$lb..rb}
              else
                hold(_intersect)(args())
              end_if
            else
              hold(_intersect)(args())
            end_if
          end_if
        end_proc,

        Dom::ImageSet=
        proc(bset, iset)
          local x, S, rform, setlist, varlist, i, proplist;
        begin
          if bset=C then
            return(iset)
          end_if;

          // test for special case: Z_ intersect a + b*Z_
          if bset=Z and iset::dom::isisetLinear(iset)<>FALSE and iset::dom::sets(iset)=[Z_] then
            S := ( iset::dom::linZ_intersect( Z_, iset ) );
            if not testtype( S, "_intersect" ) then return( S ); end_if;
          end_if;

          if bset<>R then
            // we proceed in two steps:
            // intersect with R_, then find out rationals/integers
            // if possible
            S:= R intersect iset;
            if type(S) = DOM_SET then
              return(bset intersect S)
            else
              return(FAIL)
            end_if;
           end_if;

        assert(bset = R);

        /* call ImageSets own function to reduce iset to a simpler form */
        iset := iset::dom::intersectR_( iset );
        if not testtype( iset, Dom::ImageSet ) then return( iset intersect bset ); end_if;

        varlist:= iset::dom::variables(iset);
          if nops(varlist) <> 1 then
            // handle only one simple case
            setlist:= iset::dom::sets(iset);
            // should not happen, but we test it anyway
            if contains(setlist, {}) > 0 then
              return({})
            end_if;
            proplist:= map(setlist, solvelib::set2prop);
            for i from 1 to nops(varlist) do
              if proplist[i] <> FAIL then
                save varlist[i];
                assume(varlist[i], proplist[i])
              end_if
            end_for;
            rform:= rectform(expr(iset));
            if op(rform, 3) = 0 then
              if nops((S:= indets(op(rform, 2)) intersect
                       {op(varlist)})) = 1 then
                x:= op(S);
                i:= contains(varlist, x);
                setlist[i]:= solve(op(rform, 2), x) intersect setlist[i];
                return(Dom::ImageSet(op(rform, 1), varlist, setlist))
              end_if;
            end_if;
            // cannot solve for more than one var
            return( hold(_intersect)( iset, R_ ) );
          end_if;
          x := iset::dom::variables(iset)[1];
          S:= iset::dom::sets(iset)[1];
        // should not happen:
        if S = {} then
          return({})
        end_if;
          // re - attach the properties to x
        save x;
        eval(hold(assume)(x, solvelib::set2prop(S, Superset)));
        solvelib::preImage(expr(iset) , x, R_);
        if hastype(%, "solve") or type(%)=Dom::ImageSet then
          // avoid infinite recursion
          return(FAIL)
        else
          % intersect S
        end_if;
        solvelib::substituteBySet(expr(iset), x, %)
        end_proc,

        piecewise= piecewise::_intersect

          );

  inhomog_union:=
  table(

        DOM_EXPR=
        proc(bset, e)
        begin
          if bset=C then
            return(bset)
          end_if;
          FAIL
        end_proc,

        DOM_SET=
        proc(bset, S)
          local splitset;
        begin
          if bset=C then
            return(bset)
          end_if;
          splitset:=split(S, is,(case bset
                                   of Z do
                                     Type::Integer;
                                     break;
                                   of Q do
                                     Type::Rational;
                                     break
                                   of R do
                                     Type::Real;
                                     break
                                 end_case));
        if op(splitset,2)={} and op(splitset,3)={} then
          bset
        else
          hold(_union)(splitset[2] union splitset[3], bset)
        end_if
        end_proc,


        Dom::ImageSet =
        proc(bset, iset)
        begin
          if bset = C then
            return(bset)
          end_if;
          FAIL
        end_proc,

        Dom::Interval =
        proc(bset, iv)
        begin
          if bset=R or bset=C then
            bset
          elif iv=Dom::Interval(-infinity, infinity) then
            R
          else
            FAIL
          end_if
        end_proc,

        Dom::Multiset=
        proc()
	name BasicSet_union;
	begin
	  error("This would be an infinite multiset")
        end_proc,

        piecewise=piecewise::_union
            );



  // inhomogleft_minus: methods that handle basic set minus other set

  inhomogleft_minus:=
  table(
        DOM_SET=
        proc(bset, S: DOM_SET)
          local newS: DOM_SET;
        begin
          newS:=select(S, x-> is(x in bset)<>FALSE );
          if newS={} then
            bset
          else
            hold(_minus)(bset, newS)
          end_if
        end_proc,

        Dom::Interval=
        proc(bset, iv:Dom::Interval)
        begin
          if bset=R then
            Dom::Interval(-infinity, infinity) minus iv
          elif bset<>C then
            if Dom::Interval::left(iv)=-infinity or Dom::Interval::right(iv)=infinity then
              return( _intersect( bset, Dom::Interval::bin_minus( Dom::Interval(-infinity,infinity), iv) ) );
            end_if;
            FAIL
          else
            FAIL
          end_if
        end_proc,

        DOM_EXPR=proc( bset : solvelib::BasicSet, xpr : DOM_EXPR )
          local a;
        begin
          if not testtype( xpr, "_intersect" ) then return( hold(_minus)(bset, xpr ) ); end_if;
          xpr := select( xpr, X->X<>bset );
          if not testtype(xpr, "_intersect")  then return( _minus( bset, xpr ) ); end_if;
          return( hold( _minus)( bset, xpr ) );
        end_proc,

        piecewise=piecewise::_minus
          );

  // inhomogright_minus: table of methods for handling
  // "other set minus BasicSet""

  inhomogright_minus:=
  table(
        DOM_EXPR=
        proc(xpr, bset)

        begin
          if bset=C then
            return({})
          end_if;
          case type(xpr)
            of "_union" do
            of "_intersect" do
              return(map(xpr, _minus, bset))
            of "_minus" do
              return(op(xpr,1) minus (op(xpr,2) union bset))
            otherwise
              FAIL
          end_case;
        end_proc,

        DOM_SET=
        proc(S: DOM_SET, bset: solvelib::BasicSet)
          local splitset;
        begin
          if bset=C then
            return({})
          end_if;
          splitset:= split(S, u-> is(u in bset));
          if op(splitset,3)={} then
            op(splitset,2)
          else
            op(splitset,2) union hold(_minus)(op(splitset,3), bset)
          end_if
        end_proc,

        Dom::Interval=
        proc(J: Dom::Interval, bset: solvelib::BasicSet)
        begin
          if bset=C or bset=R then
            {}
          else
            FAIL
          end_if
        end_proc
        );


// _plus, _mult, _minus, special functions

homog_plus:= () -> dom::homog_union(args());

homog_mult:= () -> dom::homog_union(args());

inhomog_plus:=
table(
      DOM_INT= ((bset,n) -> bset),

      DOM_RAT=
      proc(bset, r)
        local i;
      begin
        if bset=Z then
          i:=genident();
          Dom::ImageSet(i+(op(r,1) mod op(r,2)) / op(r,2), i, Z)
        else
          bset
        end_if
      end_proc,


      DOM_IDENT= plusexpr,

      DOM_EXPR= plusexpr,

      DOM_FLOAT = plusexpr,

      DOM_COMPLEX= plusexpr,

      DOM_SET=
      proc(bset, S)
      begin
        _union(bset + op(S,i) $i=1..nops(S))
      end_proc,

      Dom::Interval=
      proc(bset, iv)
      begin
        if bset=R or bset=Q then
          R
        elif bset=C then
          C
        else
          FAIL
        end_if
      end_proc,

      Dom::ImageSet=
      proc(bset, iset)
      begin
        if bset=C then
          C
        else
          genident();
          Dom::ImageSet(expr(iset)+%, append(iset::dom::variables(iset), %),
                        append(iset::dom::sets(iset), bset))
        end_if
      end_proc,

      piecewise=
      proc(bset, pw)
      begin
        piecewise::map(pw, _plus, bset)
      end_proc
        );


inhomog_mult:=
table(
      DOM_INT=
      proc(bset, n)
        local u;
      begin
        if n=0 then
          return({0})
        end_if;
        if bset<>Z then
          return(bset)
        end_if;
        if n=1 or n=-1 then
          Z
        else
          u:=genident();
          Dom::ImageSet(n*u, u, Z)
        end_if
      end_proc,

      DOM_RAT = multexpr,

      DOM_EXPR=multexpr,

      DOM_IDENT=multexpr,

      DOM_COMPLEX=multexpr,

      DOM_FLOAT=multexpr,

      DOM_SET=
      proc(bset, S)
      begin
        _union(bset * op(S,i) $i=1..nops(S))
      end_proc,

      Dom::ImageSet=
      proc(bset, iset)
      begin
        if bset=C then
          C
        else
          genident();
          Dom::ImageSet(expr(iset)*%, append(iset::dom::variables(iset), %),
                        append(iset::dom::sets(iset), bset))
        end_if
      end_proc,

      piecewise=
      proc(bset, pw)
      begin
        piecewise::map(pw, _mult, bset)
      end_proc
        );

_negate:=id;


bin_power:=
proc(bset1, bset2)
  local u;
begin
  if bset2 <> Z then
    return(C)
  end_if;
  if bset1 <> Z then
    return(bset1)
  end_if;
  u:=genident();
  Dom::ImageSet(1/u, u, Z)
end_proc;

inhomogleft_power:=
table(
      DOM_INT=
      proc(bset, n)
        local u;
      begin
        if n=0 then
          return({1})
        end_if;
      if n=1 then
        return(bset)
      end_if;
      if bset=C then
        if n>0 then
          return(bset)
        else
          return(bset minus {0})
        end_if
      end_if;
      if bset=Z or bset=Q then
        u:=genident();
        return(Dom::ImageSet(u^n, u, bset))
      end_if;
      /* bset = R */
      if n mod 2= 1 then
        bset
      else
        Dom::Interval([0], infinity)
      end_if
      end_proc,

      DOM_RAT=
      proc(bset, q)
        local u;
      begin
        if bset=C then
          return(bset)
        end_if;
      if bset=Z or bset=Q then
        u:=genident();
        return(Dom::ImageSet(u^q, u, bset))
      end_if;
      /* bset = R */
        u:=genident();
      return(hold(_union)(Dom::Interval([0], infinity),
                          Dom::ImageSet((-1)^q * u, u,
                                        Dom::Interval([0], infinity)) ))
      end_proc


        );


inhomogright_power:=
table(
      DOM_INT=
      proc(n, bset)
        local u;
      begin
        if n=0 then
          return({0,1})
        end_if;
      if n=1 then
        return({1})
      end_if;
      case bset
        of C do
          return(C minus {0})
        of R do
          if n>0 then
            return(R)
          elif n=-1 then
            return(exp(I*R))
          else
            return(C minus {0})
          end_if
        of Q do
          u:=genident();
          return(Dom::ImageSet(n^u, u, Q))
        of Z do
          u:=genident();
          return(Dom::ImageSet(n^u, u, Z))
      end_case
      end_proc



      );

spfun:=
proc(u)
  option escape;
begin
  /* return value : */
  proc(S)
    local newvar:DOM_IDENT;
  begin
    newvar:=genident();
    Dom::ImageSet(u(newvar), newvar, S)
  end_proc;

end_proc;

  exp := proc(bs)
  begin
    case bs
      of R_ do return( Dom::Interval( 0, infinity ) );
      of C_ do return( C_ minus 0 );
    end_case;
    bs::dom::map( bs, exp );
  end_proc;

_invert:= loadproc(solvelib::BasicSet::_invert, path, "_invert");

sin:=loadproc(solvelib::BasicSet::sin, path,
                                         "sin");
cos:= loadproc(solvelib::BasicSet::cos, path,
                                         "cos");

tan := loadproc(solvelib::BasicSet::tan, path, "tan");

arcsin:= loadproc(solvelib::BasicSet::arcsin, path,
                                         "arcsin");

arccos:=dom::spfun(arccos);
arctan:=dom::spfun(arctan);
sign:=dom::spfun(sign);
dirac:=dom::spfun(dirac);
heaviside:=dom::spfun(heaviside);

expr:= x -> extop(x,1);

normal:= id;

print:= x -> error("body should never be reached");

TeX:= x -> "\\mathbb ".((expr2text(dom::print(x)))[1]);


indets:= {};


contains:=
proc(X: dom, x)
begin
  case X
    of Z_ do
      return(is(x, Type::Integer))
    of Q_ do
      return(is(x, Type::Rational))
    of R_ do
      return(is(x, Type::Real))
    of C_ do
      return(testtype(x, Type::Arithmetical))
  end_case
end_proc;

// simpexIn(expression, S)
// returns a "simple" statement equivalent to expression \in S
simpexIn:=
proc(expression, S: dom)
begin
  if hastype(expression, stdlib::Infinity) then
    return(FALSE)
  end_if;
  if stdlib::hasmsign( expression ) then
    expression := -expression;
  end_if;
  case S
    of C do
      return(TRUE)
    of R do
      return(simpexInReal(expression))
    of Q do
      return(simpexInRational(expression))
    of Z do
      return(simpexInInteger(expression))
  end_case;
  // NOT REACHED
  assert(FALSE)
end_proc;


isEmpty:=FALSE;

isFinite:=FALSE;

card:= infinity;

set2prop:=
proc(S:dom)
begin
  case S
    of C do return(Type::Complex)
    of R do return(Type::Real)
    of Q do return(Type::Rational)
    of Z do return(Type::Integer)
  end_case;
  // NOT REACHED
  assert(FALSE);
end_proc;

preferredPrefix:=
table(
      Z = "k",
      R = "lambda",
      Q = "r",
      C = "z"
      );

// overload solvelib::substituteBySet
// substituteBySet(a, x, S) - returns { a(y): y \in S } for given a(x)
substituteBySet:=
proc(a, x, S: solvelib::BasicSet)
begin
  // simple implementation
  genident(dom::preferredPrefix[S]);
  Dom::ImageSet(subs(a, x=%), %, S)
end_proc;

// overload solvelib::getElement : zero is in every basic set

getElement:= 0;

// overload solvelib::Union: no basic set depends on any parameter, but
// we have to take care that xset might be empty
Union:=
proc(bset, x, xset)
  local empty;
begin
  empty:= solvelib::isEmpty(xset);
  piecewise([empty, {}],
            [not empty, bset])
end_proc;

  /*  e n d    o f     m e t h o d s  */


begin

  /* l o c a l  f u n c t i o n s  */


  // plusexpr: add basic set and DOM_IDENT/DOM_EXPR/..

  plusexpr:=
  proc(bset, xpr)
    local u,v;
  begin
    case bset
      of C do
        return(C)
      of R do
        if is(xpr, Type::Real)=TRUE then
          return(R)
        else
          u:=genident();
          if length((v:=Im(xpr)))>length(xpr) then
            v:=xpr
          else
            v:=I*v
          end_if;
          return(Dom::ImageSet(v+u, u, R))
        end_if
      of Q do
        if is(xpr, Type::Rational)=TRUE then
          return(Q)
        else
          u:=genident();
          /* simplify xpr by removing some subexpressions ? */
          return(Dom::ImageSet(xpr+u, u, Q))
        end_if
      of Z do
        if is(xpr,Type::Integer)=TRUE then
          return(Z)
        else
          u:=genident();
          return(Dom::ImageSet(xpr+u,u, Z) )
        end_if
    end_case;
  end_proc;


  // multexpr - mult basic set and DOM_IDENT/DOM_EXPR

multexpr:=
proc(bset, xpr)
  local u,v;
begin
  case bset
    of C do
      return(piecewise([xpr<>0, C], [xpr=0, {0}]))
    of R do
      if is(xpr, Type::Real)=TRUE then
        return(piecewise([xpr<>0, R], [xpr=0, {0}]))
      else
        u:=genident();
        // try to get vector of norm 1 (hopefully simpler ..)
        if length((v:=sign(xpr)))>length(xpr) then
          v:=xpr
        end_if;
        return(Dom::ImageSet(v*u, u, R))
      end_if
    of Q do
      if is(xpr, Type::Rational)=TRUE then
        return(piecewise([xpr<>0, Q], [xpr=0, {0}]))
      else
        u:=genident();
        return(Dom::ImageSet(xpr*u, u, Q))
      end_if;
    of Z do
      u:=genident();
      return(Dom::ImageSet(u*xpr, u, Z))
  end_case;
end_proc;


// simpexIn ....
// functions that return a logical expression that is true
// iff the input is real[rational, integer]


simpexInReal:=
proc(e)
  local exponent;
begin
  case type(e)
    of DOM_INT do
    of DOM_RAT do
    of DOM_FLOAT do
      return(TRUE)
    of DOM_COMPLEX do
      return(FALSE)
    of DOM_IDENT do
      if property::sysis(e, Type::Real) or contains({PI, CATALAN, EULER}, e)
        then
        return(TRUE)
      else
        break
      end_if;
    of "_plus" do
      e:= select(e, x -> is(x, Type::Real) <> TRUE);
      if type(e) = "_plus" then
        break
      else
        return(simpexInReal(e))
      end_if
    of "_mult" do
      e:= select(e, x -> (is(x, Type::Real) and is(x<>0)) <> TRUE);
      if type(e) = "_mult" then
        break
      else
        return(simpexInReal(e))
      end_if
    of "_power" do
      exponent:= op(e, 2);
      case is(exponent, Type::Integer)
        of TRUE do
          if is(op(e, 1), Type::Real)=TRUE then
            return(TRUE)
          else
            break
          end_if
        of UNKNOWN do
          // what to do here ??
          break
        of FALSE do
          if (is(exponent, Type::Rational) and is(exponent <> 0)) = TRUE then
            return(simplify::simplifyCondition(op(e, 1) >= 0))
          end_if;
      end_case;
      break
  end_case;
  // default:
  e in R
end_proc;

simpexInRational:=
proc(e)
  local exponent, ispow;
begin
   case type(e)
     of DOM_IDENT do
       if is(e, Type::Rational) = TRUE then
         return(TRUE)
       else
         break
       end_if;
     of "_plus" do
        e:= select(e, x -> is(x, Type::Rational) <> TRUE);
      if type(e) = "_plus" then
        break
      else
        return(simpexInRational(e))
      end_if
     of "_mult" do
       e:= select(e, x -> is(x, Type::Rational) and is(x<>0) <> TRUE);
       if type(e) = "_mult" then
         break
       else
         return(simpexInRational(e))
       end_if
     of "_power" do
       exponent:= op(e, 2);
       if type(op(e, 1)) = DOM_INT and type(exponent) = DOM_RAT then
         ispow:= numlib::ispower(op(e, 1));
         if ispow <> FALSE and op(ispow, 2) mod op(exponent, 2) = 0 then
           return(TRUE)
         else
           return(FALSE)
         end_if
       end_if;
     of DOM_INT do
     of DOM_RAT do
      return(TRUE);
     of DOM_COMPLEX do
      return(FALSE);
   end_case;
  // default:
  e in Q
end_proc;


simpexInInteger:=
proc(e)
  local res;
begin
  case type(e)
    of DOM_IDENT do
       if property::sysis(e, Type::Integer) then
        return(TRUE)
      else
        break
      end_if;
    of DOM_INT do
      return(TRUE)
    of DOM_RAT do
    of DOM_COMPLEX do
      return(FALSE)
    of "_plus" do
      e:= select(e, x -> is(x, Type::Integer) <> TRUE);
      if type(e) = "_plus" then
        break
      else
        return(simpexInInteger(e))
      end_if
    of "_mult" do
      res := map( {op(e)}, simpexInInteger );
      if res={ TRUE } then return( TRUE ); end_if;
      break;
  end_case;
  // default:
  if testtype(e, Type::Constant) and
    ((res:= is(e, Type::Integer))) <> UNKNOWN then
    return(res)
  end_if;
  e in Z
end_proc;

end_domain:


// values for special functions


solvelib::BasicSet::bin_minus(Z, R) := {}:
solvelib::BasicSet::bin_minus(Q, R) := {}:
solvelib::BasicSet::bin_minus(Z, Q) := {}:

solvelib::BasicSet::_subset(C, R) := FALSE:
solvelib::BasicSet::_subset(C, Q) := FALSE:
solvelib::BasicSet::_subset(C, Z) := FALSE:
solvelib::BasicSet::_subset(R, Q) := FALSE:
solvelib::BasicSet::_subset(R, Z) := FALSE:
solvelib::BasicSet::_subset(Q, Z) := FALSE:
solvelib::BasicSet::_subset(R, C) := TRUE:
solvelib::BasicSet::_subset(Q, C) := TRUE:
solvelib::BasicSet::_subset(Z, C) := TRUE:
solvelib::BasicSet::_subset(Z, R) := TRUE:
solvelib::BasicSet::_subset(Q, R) := TRUE:
solvelib::BasicSet::_subset(Z, Q) := TRUE:


solvelib::BasicSet::sign(Z):={-1,0,1}:
solvelib::BasicSet::sign(Q):={-1,0,1}:
solvelib::BasicSet::sign(R):={-1,0,1}:
solvelib::BasicSet::dirac(Z):= {0, dirac(0)}:
solvelib::BasicSet::dirac(Q):= {0, dirac(0)}:
solvelib::BasicSet::dirac(R):= {0, dirac(0)}:
solvelib::BasicSet::heaviside(Z):= {0, 1, heaviside(0)}:
solvelib::BasicSet::heaviside(Q):= {0, 1, heaviside(0)}:
solvelib::BasicSet::heaviside(R):= {0, 1, heaviside(0)}:

solvelib::BasicSet::print(R):=hold(R_):
solvelib::BasicSet::print(Z):=hold(Z_):
solvelib::BasicSet::print(Q):=hold(Q_):
solvelib::BasicSet::print(C):=hold(C_):



//////////////////////////////////////////////////////////////////////
//       define basic sets
//////////////////////////////////////////////////////////////////////

Z_ := solvelib::BasicSet(Dom::Integer):
Q_ := solvelib::BasicSet(Dom::Rational):
R_ := solvelib::BasicSet(Dom::Real):
C_ := solvelib::BasicSet(Dom::Complex):

