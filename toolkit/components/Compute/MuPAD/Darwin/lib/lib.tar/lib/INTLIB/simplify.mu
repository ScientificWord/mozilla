// $Date: 2007-01-11 10:42:30 +0100 (Thu, 11 Jan 2007) $ $Author: Christopher Creutzig $ $Revision: 42313 $ 
/*++
intlib::simplify(f,x) - simplifies the expression f over the variable x and 
returns the simplified expression if possible or f otherwise.
++*/
intlib::simplify:=
proc(f,x)
  local opt,i; 
  save _global_n,_global_k,_global_k_sub,_global_k_ident,_global_k_diff,
  _global_k_deg,_global_k_alg,_global_Q,_global_Q_sub;
  begin
    delete _global_n,_global_k,_global_k_sub,_global_k_ident,_global_k_diff,
    _global_k_deg,_global_k_alg,_global_Q,_global_Q_sub;
// test of input and options
    if testargs() then
      if args(0)<>2 then
        error("wrong no of arguments");
      end_if;
      if (domtype(f)<>DOM_LIST or nops(f)<1 or
          (map({op(f)},domtype) minus
           {DOM_EXPR,DOM_IDENT,DOM_INT,DOM_RAT,DOM_COMPLEX}) <> {}) and
        not(contains({DOM_EXPR,DOM_IDENT,DOM_INT,DOM_RAT,DOM_COMPLEX},
                     domtype(f)))
        or not(testtype(x,DOM_IDENT)) then
        error("Illegal argument");
      end_if;
    end_if;
  opt:=hold(Exp);
  _global_n:=1; _global_k:=[x];
  _global_k_sub:=[x];
  _global_k_ident:=[genident()];
  _global_k_diff:=[1];
  _global_k_deg:=[0];
  _global_k_alg:=[0];
  _global_Q:=[];
  _global_Q_sub:=[];
  f:=intlib::subst(f,opt);
  repeat
    i:= intlib::tower(f)
  until i<>FALSE end_repeat;
  f:=i;
  if f=FAIL then return(procname(args())); end_if;
  f:= subs(f,_global_k_sub[_global_n-i]=_global_k[_global_n-i]
           $ i=0.._global_n-2,
           _global_Q_sub[nops(_global_Q)-i]=_global_Q[nops(_global_Q)-i]
           $ i=0..nops(_global_Q)-1);
  normal(f);
end_proc:


// intlib::Simplify - specific rules and valuation for integration
intlib::Simplify :=
funcenv(() -> intlib::Simplify::Simplify(args())):

intlib::Simplify::operatorTable := subs(Simplify::defaultOperatorTable,
  hold(Simplify::complexity) = hold(intlib::Simplify::complexity)):
  
intlib::Simplify::operatorTable["sin"] := [26, 1.5]:
intlib::Simplify::operatorTable["cos"] := [26.01, 1.5]:
intlib::Simplify::operatorTable["tan"] := [70, 3]:
intlib::Simplify::operatorTable["cot"] := [75, 3]:
intlib::Simplify::operatorTable["I"] := 8:

intlib::Simplify::complexity :=
  Simplify::createValuation(intlib::Simplify::operatorTable):

intlib::Simplify::defaultValuation:=
proc(EXPR)
begin
  float(Simplify::indetComplexity(EXPR) + intlib::Simplify::complexity(EXPR)/2
        + Simplify::pairPenalty(EXPR))
end_proc:

// "inherit" match rules from Simplify, with local modifications
intlib::Simplify::Rules := newDomain("intlib::Simplify::Rules"):

/*intlib::Simplify::Rules::tan :=
proc(ex: "tan")
begin
  Simplify::Rules::tan(ex) .
  [
    Rule(tan(`#x`), sin(`#x`)/cos(`#x`)),
    Rule(tan(`#x`), 2*tan(`#x`/2)/(1-tan(`#x`/2)^2)),
    Rule(tan(`#x`), -tan(2*`#x`)*(tan(`#x`)^2-1)/2)
  ]
end_proc:
*/

intlib::Simplify::Rules::All :=
proc(ex) : DOM_LIST
//  local ;
begin
  Simplify::All(ex) . [
    if domtype(ex) = DOM_EXPR then
      if has(ex, {hold(tan)}) then
        Rule(x -> rewrite(x, cos), {}, table("Default" = 0.8)),
        Rule(x -> expand(rewrite(x, cos)), {}, table("Default" = 1.3))
      else null() end_if,
      if has(ex, {hold(tan)}) then
        Rule(x -> rewrite(x, sin), {}, table("Default" = 0.8)),
        Rule(x -> expand(rewrite(x, sin)), {}, table("Default" = 1.3))
      else null() end_if
    else null() end_if
  ]
end_proc:

// "Global" rules apply at top level only
// for antiderivatives, at this place, we want
// to allow simplifications that ignore
// piecewise constants. NOTE: These rules work
// if and only if the variable of integration is _X!
intlib::Simplify::RulesAntiderivative := 
newDomain("RulesAntiderivative", intlib::Simplify::Rules):

intlib::Simplify::RulesAntiderivative::Global :=
proc(ex) : DOM_LIST
begin
  intlib::Simplify::Rules::Global(ex) . [
    if type(ex) = "_plus" then
      Rule(x -> select(x, has, _X), {}, table("Default" = 0.9)),
      // This rule doesn't really work yet
//      Rule(`#a`+`#b`*ln(`#A`+I*`#B`)-`#b`*ln(`#A`-I*`#B`),
//           hold(`#a`-I*`#b`*intlib::Simplify::RulesAntiderivative::LogToAtan(`#A`, `#B`))),
      Rule(`#a`+arctan(tan(`#b`)), `#a`+`#b`, {}, table("Default" = 0.8)),
      Rule(`#a`+arcsin(sin(`#b`)), `#a`+`#b`, {}, table("Default" = 0.8)),
      Rule(`#a`+ln(exp(`#b`)), `#a`+`#b`, {}, table("Default" = 0.8))
    else null() end_if
  ]
end_proc:

intlib::Simplify::RulesAntiderivative::LogToAtan :=
proc(A, B)
  local G, C, D;
begin
  if iszero(B) then return(FAIL); end_if;
  if not testtype(A, Type::PolyExpr(_X)) or
     not testtype(B, Type::PolyExpr(_X)) then
    return(FAIL);
  end_if;
  if iszero(divide(poly(A, [_X]), poly(B, [_X]), Rem)) then
    return(2*arctan(A/B));
  end_if;
  if degree(A, _X) < degree(B, _X) then
    return(intlib::Simplify::RulesAntiderivative::LogToAtan(-B, A));
  end_if;
  [g, c, d] := [gcdex(B, -A, _X)];
  return(2*arctan((A*d+B*c)/g)+intlib::Simplify::RulesAntiderivative::LogToAtan(d,c));
end_proc:


intlib::Simplify::RulesAntiderivative::make_slot := 
proc(DOM, e)
//  local t;
begin
  slot(intlib::Simplify::Rules, e);
end_proc:

intlib::Simplify::Rules::make_slot := 
proc(DOM, e)
//  local t;
begin
  slot(Simplify, e);
end_proc:




intlib::Simplify::Simplify := subsop(Simplify::Simplifier(
  RuleBase  = intlib::Simplify::Rules,
  Valuation = intlib::Simplify::defaultValuation,
//  Discard   = FALSE,
  Remember  = FALSE // we must change the name first ...
), 6=NIL):

intlib::Simplify::Simplify := prog::remember(
  intlib::Simplify::Simplify,
  property::Depends,
  PreventRecursion,
  x -> x // first arg only
):

null():
