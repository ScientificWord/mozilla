// $Id: load_patterns.mu 34809 2005-11-11 13:45:17Z ccr $

proc()
  save patternFSA;
begin
  read("INTLIB".stdlib::PathSep."patternFSA.mb", Plain);
  intlib::patternFSA := patternFSA;
end():
