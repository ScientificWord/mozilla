// simplify::sinh - just in analogy to simplify::sin

simplify::sinh:=
proc(a)
begin
  if type(a) = "_plus" then
    a := normal(a)
  end_if;
  combine(a, hold(sinhcosh))
end_proc