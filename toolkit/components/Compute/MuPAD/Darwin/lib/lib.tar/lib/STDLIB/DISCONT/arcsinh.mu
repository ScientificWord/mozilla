genident("z"):
arcsinh::complexDiscont:=
  Dom::ImageSet(%*I, %, Dom::Interval(-infinity, -1) union
                Dom::Interval(1, infinity)):
