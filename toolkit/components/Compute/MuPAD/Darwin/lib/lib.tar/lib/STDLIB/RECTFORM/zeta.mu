
zeta::rectform:=
proc(xx)
  local x;
begin
  x:= rectform(xx);
  if extop(x, 2) <> 0 or extop(x, 3) <> 0 then
    new(rectform, 0, 0, hold(zeta)(rectform::expr(x)))
  else
    new(rectform, zeta(xx), 0, 0)
  end_if
end_proc: