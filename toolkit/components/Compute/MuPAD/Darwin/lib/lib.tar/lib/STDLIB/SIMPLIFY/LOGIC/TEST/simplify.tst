prog::testinit("simplify::logic"):
prog::testfunc(simplify):

prog::test(simplify(a or a and b,logic), a, "Test 1"):
prog::test(simplify(b and c or not c,logic), (b or not c), "Test 2"):
prog::test(simplify(not a and c or b and not c or not b and not c,logic),
           (not a or not c), "Test 3"):
prog::test(simplify((a and b) or (a and (not b)),logic), a, "Test 4"):
prog::test(simplify((a and b) or (not a and c) or (b and c),logic),
           (a and b or not a and c), "Test 5"):
prog::test(simplify(x and y and (x or y) and 2 < 3,logic),
           (x and y), "Test 6"):

prog::testexit():
