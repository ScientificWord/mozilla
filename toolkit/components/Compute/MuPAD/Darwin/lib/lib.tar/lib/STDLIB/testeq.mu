// $Id: testeq.mu 38699 2006-04-27 15:46:22Z stefanw $

// testeq - check for equality of given equations

alias(NumberOfRandomtests = 5):

// bij, 04/2003

testeq :=
proc(ex1, ex2 = 0)
  local OPT, ex, newex1, newex2, n,
  numericalTest: DOM_PROC;
begin
  
  numericalTest:=
  proc(ex1, ex2)
    local i:DOM_INT,
    j: DOM_INT,
    res, 
    inds: DOM_LIST,
    proplist: DOM_LIST,
    randomValueGenerator:DOM_PROC;

  begin

    // local method randomValueGenerator(S, i, j)
    // returns a "random" element from S, with "seed" i and j
    // may also return FAIL
    randomValueGenerator:=
    proc(S, i, j)
    begin
      case type(S)
        of solvelib::BasicSet do
          case S
            of R_ do
              return(
              j/2*sin(j^2+i+12345/10000)
                     )
            of C_ do
              // perform real tests in one third of all cases
              if j mod 3 = 0 then
                 return(
              j/2*sin(j^2+i+12345/10000)
                     )
              else
                return(
                       (j*cos(12/7-i+j^3) + I*j/2*sin(i+j^2+12345/10000))
                       )
              end_if
          end_case
        of Dom::Interval do
          if S::dom::left(S) = -infinity then
            if S::dom::right(S) = infinity then
              return(
              j/2*sin(j^2+i+12345/10000)
                     )
            else
              return(
              S::dom::right(S) - j/2*abs(sin(j^2+i+12345/10000))
                     )
            end_if;
          else
            if S::dom::right(S) = infinity then
              return(
              S::dom::left(S) + j/2*abs(sin(j^2+i+12345/10000))
                     )
            else
              return(
                  S::dom::left(S) +
                  (S::dom::right(S) - S::dom::left(S))*791/792*abs(sin(i+j^2))
                 )
            end_if;
          end_if;
      end_case;
      FAIL
    end_proc;

    // numerical test for non-constant expressions
    // if replacing the variables in ex by values leads to
    // a nonzero result, the expression cannot be zero-equivalent
    // we may only do this if the substitutions are consistent with the
    // properties of our identifiers; currently, we require that none of
    // the identifiers has a property
    inds:= [op(indets([ex1, ex2]) minus Type::ConstantIdents)];
    proplist:=  map(inds, x -> if not property::hasprop(x) then
                                 C_
                               else
                                 property::prop2set(getprop(x))
                               end_if
                    );
    for j from 1 to NumberOfRandomtests do
        if traperror((
                      res:=eval(subs(ex1-ex2,
                                     (op(inds, i) = randomValueGenerator
                                      (proplist[i], i, j)
                                      $i=1..nops(inds) )))
                      )) = 0 and
          numeric::isnonzero(res) = TRUE then
          return(FALSE)
        end_if;

    end_for;
    UNKNOWN
  end_proc:


  /**********************************************/
  // m a i n   p r o g r a m   o f    t e s t e q
  /**********************************************/

  if type(ex1) = "_approx" and (ex:= bool(ex1)) <> UNKNOWN then
    return(ex)
  end_if;
 
  // accept one equation as input
  if type(ex1) = "_equal" or type(ex1) = "_approx" then
    [ex1, ex2] := [op(ex1)];
    n:= 1 // start of options - section
  else
    n:= 2
  end_if;

  if ex1::dom::testeq <> FAIL then
    return(ex1::dom::testeq(ex1, ex2, args(n..args(0))))
  elif ex2::dom::testeq <> FAIL then
    return(ex2::dom::testeq(ex2, ex1, args(n..args(0))))
  end_if;


  if {domtype(ex1), domtype(ex2)} minus
    {DOM_INT, DOM_RAT, DOM_COMPLEX, DOM_FLOAT, DOM_EXPR, DOM_IDENT} <> {}
    then
    if ex1 = ex2 then
      return(TRUE)
    end_if;
    if domtype(ex1) <> domtype(ex2) then
      return(FALSE)
    end_if;

    // handling of particular datatypes
    case domtype(ex1)
      of DOM_LIST do
        // two lists [a1, a2, ...] and [b1, b2, ..] are equal iff
        // a_i = b_i for all i
        return(_lazy_and(op(zip(ex1, ex2, testeq, args(n..args(0))))))
      of DOM_POLY do
      of DOM_RPOLY do
        return(_lazy_and(op(ex1, 2) = op(ex2, 2),
                         op(ex1, 3) = op(ex2, 3),
                         testeq(op(ex1, 1), op(ex2, 1), args(n..args(0)))))
    end_case;
    // default
    return(UNKNOWN)
  end_if;

  
   // options for Simplify, skip one or two arguments
  OPT := prog::getOptions(table(hold(Steps) = 100,
                                hold(Seconds) = infinity,
                                // ??should use special rule base??
                                //hold(RuleBase) = Simplify::MatchRules,
                                hold(RuleBase) = Simplify,
                                hold(Goal) = 0), n);
  
  
  ex := expand(ex1 - ex2);

 
  // numerical test
  // works only for constant expressions
  if (n := numeric::isnonzero(ex)) <> UNKNOWN then
    userinfo(1, "isnonzero returns ".expr2text(n)." [testeq]");
    return(not n)
  end_if;

  // general numerical test
  if (n:= numericalTest(ex1, ex2)) <> UNKNOWN then
    userinfo(1, "random substitution succeeds");
    return(n)
  end_if;
  
  
  // simplification of the expanded diffenence
  ex := Simplify::defaultSimplifier(ex, op(OPT));
  userinfo(1, "Simplification of expanded difference results ".
           expr2text(ex)." [testeq]");
  if (n := is(ex = 0)) <> UNKNOWN then
    userinfo(1, "'is = 0' returns ".expr2text(n)." [testeq]");
    return(n)
  end_if;


  
  // simplification
  newex1 := Simplify::defaultSimplifier(ex1, op(OPT));
  newex2 := Simplify::defaultSimplifier(ex2, op(OPT));
  userinfo(1, "Simplification results ".expr2text(newex1, newex2)." [testeq]");
    
  if (n := is(newex1 = newex2)) <> UNKNOWN then
    userinfo(1, "'is =' returns ".expr2text(n)." [testeq]");
    return(n)
  elif (n := is(newex1 <> newex2)) <> UNKNOWN then
    userinfo(1, "'is <>' returns ".expr2text(n)." [testeq]");
    return(not n)
  end_if;
    
  if newex1 <> ex1 or newex2 <> ex2 then
    // second numerical test after simplification
    numericalTest(newex1, newex2)
  else
    UNKNOWN
  end_if

  
end_proc:
