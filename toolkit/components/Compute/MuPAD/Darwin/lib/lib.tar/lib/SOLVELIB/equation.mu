/* */
/* $Date: 2007-01-17 13:51:05 +0100 (Wed, 17 Jan 2007) $ $Author: Stefan Wehmeier $ $Revision: 42431 $ */
/* */
/* zimmerma, 14/12/95 */

/*--
	solvelib::solve_eq
--*/

solvelib::solve_eq:=
proc(eq, x)
  local options, l, r, dummy, mapfloat: DOM_PROC,
  maxeffort;
  save MAXEFFORT;
begin

  // local method mapfloat(S) -> converts arithmetical expressions in S to floats
  mapfloat:=
  proc(S)
  begin
    case type(S)
      of "solve" do
        subsop(S, 1 = float(op(S, 1)));
        break
      of "_union" do
      of "_intersect" do
      of "_minus" do
        map(S, mapfloat);
        break
      of piecewise do
        piecewise::extmap(S, mapfloat);
        break
      otherwise
        float(S)
    end_case
  end_proc;
  
  userinfo(3, "solve_eq called with equation ".expr2text(eq));

  if eq::dom::solve <> FAIL then
    return(eq::dom::solve(args()))
  end_if;
  
  options:=solvelib::getOptions(args(3..args(0)));

  // check for  easy cases first
  case domtype(eq)
    of DOM_INT do
    of DOM_FLOAT do
    of DOM_COMPLEX do  
      return((if iszero(eq) then
                if options["Multiple"]=TRUE then
                  error("Infinitely many solutions, cannot create multiset")
                else
                  if options["Real"] then
                    R_
                  else
                    C_
                  end_if
                end_if
              else
                {}
              end_if))
    of DOM_RAT do
      // there is no DOM_RAT representing zero
      return({})
           // some strange cases

    of stdlib::Infinity do
    of stdlib::CInfinity do
      return({})
  end_case;
  
  // expressions containing infinity are considered nonzero
  if has(eq, infinity) then
    return({})
  end_if;

  if not has(eq, x) then
    if options["IgnoreSpecialCases"] then
      return({})
    elif options["Multiple"] then
      return(piecewise([eq<>0, {}]))
    else
      if options["Real"] then
        return(piecewise([eq=0, R_], [eq<>0, {}]))
      else
        return(piecewise([eq=0, C_], [eq<>0, {}]))
      end_if
    end_if
  end_if;
  
  // special cases
  // expressions containing RootOf's cannot be handled

  if hastype(eq, RootOf) then
    userinfo(2, "Cannot solve equations containing RootOf's");
    return(hold(solve)(eq, x))
  end_if;
  
  case domtype(eq)
    of DOM_IDENT do /* solve(x,x) or maybe solve(y,x) */
      return(solvelib::solve_poly_irred(poly(eq,[x]), x, options))
    of DOM_EXPR do
      if contains( Type::ConstantIdents,x ) then
        error("Invalid variable (mathematical constant was given)")
      elif type(x)=DOM_FUNC_ENV then
        error("cannot solve for ".expr2text(x))
      end_if;

      case type(eq)
        of "_mult" do
        // do *not* immediately call the polynomial solver
        // because expanding a product would be the worst thing
        // one could do
          userinfo(5, "Solving factors ".expr2text(op(eq))." separately");
          maxeffort:= MAXEFFORT/3;
          MAXEFFORT:= maxeffort/nops(eq);
          l:= map([op(eq)], solvelib::solve_eq, x, options);
          MAXEFFORT:= maxeffort;
          r:= discont(eq, x, undefined);
          return(solvelib::solve_minus(_union(op(l)), r, options))
        of "_power" do
          if is(op(eq,2) > 0)= FALSE then
            return({})
          end_if;
          if not has(op(eq,2), x) then
            userinfo(5, "Equation ".expr2text(eq)." reduces to ".
                     expr2text(op(eq,1)));
            l:= solvelib::solve_eq(op(eq,1), x, options);
            if options["Multiple"]=TRUE then
              if type(op(eq, 2)) = DOM_INT then 
                return(_union(l $op(eq,2)))
              else
                error("Option multiple is only allowed for polynomial equations")
              end_if
            else
              return(piecewise([op(eq, 2) > 0, l],
                               [not op(eq, 2) > 0, {}]))
            end_if
          end_if
        of "_plus" do
          if testtype(eq,Type::PolyExpr(x)) then
            // test for special case f(x)^n = C
            // in this case, return the union of the sets
            // of solutions for f(x)=C^(1/n) + exp(2*PI*I*j/n)
            // for 0 <= j <= n-1


              [l, r, dummy]:= split(eq, has, x);
              if type(l)= "_power" then
                // polynomial of special form x^n + r for some integer n
                return(solvelib::purePolynomial(l, r, x, options))
              end_if;
           
            // polynomial has not special form
            return(solvelib::solve_poly(poly(eq,[x]),x,options))
          end_if;
          break
        of "function" do
          return(hold(solve)(eq, x))
      end_case;
        
     
      // type(eq) is none of _mult, _plus, or _power, or eq is a sum
      // but not polynomial in x
      
      if options["Multiple"]=TRUE then
        error("Option multiple is only allowed for polynomial equations")
      end_if;


      // handle floating-point input
  
      if stdlib::hasfloat(eq) then
        eq:= numeric::rationalize(eq);
        solvelib::solve_eq(eq, x, options);
        return(mapfloat(%))
      end_if;


      
      // do *not* normalize here, because this would destroy
      // sums where some summands do not contain x

      l := solvelib::avoidAliasProblem(solvelib::isolate(eq, 0, x, options),
                                       {x});
      if options["Real"] and type(l) = "solve" and has(l, hold(log)) then
        return(rewrite(l, ln));
      else
        return(l);
      end_if;

    of DOM_POLY do
      return(solvelib::solve_poly(eq, x, options))

 
  end_case;
  // NOT REACHED

  assert(FALSE);
  return(hold(solve)(eq, x))

end_proc:



/* end of file */

