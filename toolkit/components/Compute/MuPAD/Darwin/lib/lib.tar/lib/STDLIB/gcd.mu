// $Date: 2005-11-25 16:47:26 +0100 (Fri, 25 Nov 2005) $ $Author: acrowley $ $Revision: 35141 $ 

// kg, 09/12/93 

/*++
gcd -- compute the gcd of polynomials or expressions

gcd(poly,...)
gcd(expr,...)

poly - polynomials
expr - polynomial expressions

gcd computes the gcd of polynomials or expressions.
++*/

gcd:=
proc()
  local a, p, q, n, c, T, i, g, f, conv, normp, gcdp,
  floatFlag: DOM_BOOL;
  
begin
  if args(0) = 0 then
    return(0)
  end_if;
  a:= { args() };
    
  // only integer or rational args? 
  T:= map(a, domtype);
  if (T minus {DOM_INT,DOM_RAT,DOM_FLOAT,DOM_COMPLEX}) = {} then
    if T = {DOM_INT} then
      return(igcd(op(a)))
    end_if;
    if T minus {DOM_RAT, DOM_INT} = {} then
      return(igcd(op(map(a, numer))) / ilcm(op(map(a, denom))))
    end_if;
    if stdlib::hasfloat(a) then
      return(1.0)
    else  
      return(1)
    end_if
  end_if;
    
  p:= op(a,1);
  n:= nops(a);
  // handle cases n=1 and n>2 
  case n
    of 2 do break;
    of 1 do
      T:= op(T,1);
      if T::zero <> FAIL then
        return(gcd(p, T::zero))
      end_if;
      if T = DOM_POLY then
        if iszero(p) then
          return(p) // avoid infinite recursion 
        else
          return(gcd(p, poly(0,op(p,2..3))))
        end_if
      end_if;

      return(gcd(p, 0));

    otherwise
      if T minus {DOM_EXPR, DOM_POLY} <> {} and
        map(T minus {DOM_EXPR, DOM_POLY},
            proc(g)
            begin
              g::hasProp(Cat::Polynomial)
            end_proc)
        <> {TRUE} then
        
        g:= op(a,1);
        for i from 2 to n do
          g:= gcd(g, op(a,i))
        end_for;
        return(g)
      else
        // arguments are polynomials or expressions 
        // remove contents 
        a:= [op(a)];
        c:=select(a,not iszero);
        if nops(%)=0 then
          return(gcd(a[1],a[2]))
        elif
          nops(c)<=2 then
          return(gcd(op(c)))
        else
          n:=nops(c);
          a:=c
        end_if;
        
        c:= map(a, content);
        if contains(c, FAIL) = 0 then  
          a:= zip(a, c, proc()
                        begin
                          mapcoeffs(args(1), _divide, args(2))
                        end_proc );
          c:= gcd(op(c));
          /* quick exit if there is a constant polynomial among
             the arguments */
          if contains(map(a,degree),0)>0 then
            return(poly(c,op(p,2..3)))
          end_if
        else
          c:= FAIL
        end_if;
          
        T:= op(p, 3);
        // sort according to ascending degrees, then iterate gcd 
        a:= sort(a, proc()
                    begin
                      if degree(args(1)) = FAIL or
                         degree(args(2)) = FAIL then
                        return(FALSE);
                      end_if;
                      bool(degree(args(1)) < degree(args(2)))
                    end_proc );
        g:= a[1];
        for i from 2 to n do
          g:= gcd(g, a[i])
        end_for;
        if c <> FAIL then
          return(multcoeffs(g, c))
        else
          return(g)
        end_if
      end_if;
  end_case;

  // now n=2
  assert(n = 2);
  q:= op(a,2);
    // try to overload 
  if p::dom::gcd <> FAIL then return(p::dom::gcd(p,q)) end_if;
  if q::dom::gcd <> FAIL then return(q::dom::gcd(p,q)) end_if;

  // convert args to polys 

  if T<>{DOM_POLY} then // at least one arg. is an expression
    if testargs() then
      T:=split(a, x -> domtype(x) = DOM_POLY);
      if map(op(T,1), op, 3) minus
        {hold(Expr)} <> {} then
        error("Gcd of polynomials and expressions is not possible ".
              "unless coefficient ring of all polynomials is Expr")
      end_if;
      if contains(map(op(T,2), testtype, Type::Arithmetical), FALSE) then
        error("Argument must be a polynomial or an arithmetical expression")
      end_if
    end_if;
	// convert expr to polys  
    a:= map(a, expr);

    // special case: if the arguments contain DOM_FLOAT's,
    // rationalize and apply float to the result
    if hastype(a, DOM_FLOAT, {DOM_COMPLEX}) then
      a:= numeric::rationalize(a);
      floatFlag:= TRUE
    else
      floatFlag:= FALSE
    end_if;
    
    // convert all polynomials to expressions
    a:= polylib::makerat(a);
    // Bug-Fix: 25.11.05 jetzt: ...op(op(a,3))) statt ...op(a,3));
    f:= subs(expr(gcd(op(op(a,1)))) / expr(lcm(op(op(a,2)))) , op(op(a,3)));
    if floatFlag then
      return(float(f))
    else
      return(f)
    end_if;
  end_if;

  // now T={DOM_POLY} : both args are polynomials
  assert( T = {DOM_POLY});
  conv:=id;
  T:= op(p, 3);
  // test args 
  if testargs() then
    if op(p, 2..3) <> op(q, 2..3) then
      error("polynomial types differ")
    end_if;
    if domtype(T) = DOM_DOMAIN then
      // need gcd method for coeffs 
      if T::gcd = FAIL then error("method 'gcd' missing") end_if;
      if T::_divide = FAIL then error("method '_divide' missing") end_if
    elif T<>hold(Expr)  // T = IntMod(p) 
      // polynomial with coeffs from Zp must have prime modulus 
      and not isprime(op(T,1)) then
      error("modulus must be prime")
    end_if
  end_if;

    

  f:= [];
  if T = hold(Expr) then
	// polynomial with expressions as coeffs 
	/* change varibles which are expressions into indets,
	  otherwise scaling may cause problems later on */
    if select(map(op(p,2), domtype), _unequal, DOM_IDENT) <> [] then
      f:= op(p,2);
      g:= [ (if domtype(f[i]) = DOM_IDENT then f[i]
             else genident() end_if) $ i=1..nops(f) ];
      p:= poly(poly2list(p), g, T);
      q:= poly(poly2list(q), g, T);
    end_if;
    T:= map({coeff(p), coeff(q)}, domtype);
    if T = {DOM_INT} then
      gcdp:= gcdlib::int_gcd;
      normp:= gcdlib::norm_intp;
    elif T minus {DOM_INT,DOM_RAT} = {} then
      gcdp:= gcdlib::int_gcd;
      normp:= proc() begin args(1) end_proc ;
      conv:= proc()
             begin
               multcoeffs(args(1), 1/lcoeff(args(1)))
             end_proc;
      // p:= multcoeffs(p, 1/icontent(p));
      // q:= multcoeffs(q, 1/icontent(q));
      p:= polylib::primpart(p);
      q:= polylib::primpart(q)
    else
    // we try our best... 
      g:= gcd(expr(p), expr(q));
      if g = FAIL then
        error("illegal coefficients")
      end_if;
      g:= poly(g, op(p, 2..3));
      if f <> [] then
        g:= poly(poly2list(g), f, op(p,3))
      end_if;
      return(g);
    end_if
  elif domtype(T) = DOM_DOMAIN then
    gcdp:= gcdlib::dom_gcd;
    normp:= gcdlib::norm_domp;
  else // T = IntMod(p) 
    gcdp:= gcdlib::mod_gcd;
    normp:= gcdlib::norm_modp;
    conv:= proc()
           begin
             multcoeffs(args(1), 1/lcoeff(args(1)))
           end_proc ;
  end_if;

  if iszero(p) then
    g:= normp(q) 
  elif iszero(q) then
    g:= normp(p)
  else
    g:= gcdlib::special_cases(p, q, gcdp, normp)
  end_if;
  
  if f <> [] then
    g:= poly(poly2list(g), f, op(p,3))
  end_if;
  conv(g);
end_proc:

// end of file 
