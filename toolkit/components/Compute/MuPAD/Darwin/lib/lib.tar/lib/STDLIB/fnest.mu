/*-

@@ - the repeated composition operator



f @@ n : f - any function, n - an integer



sin @@ 3      -> sin@sin@sin

(sin @@ 2)(x) -> sin(sin(x))

sin @@ (-1)   -> arcsin

(f @@ g)(x)   -> (f @@ g)(x)

(f @@ n) @@ m -> f @@ (n*m)
-*/

_fnest := proc(x, i) 
local y;

begin
   if type(x) = "_fnest" then
      return(_fnest(op(x,1), op(x,2)*i))
   end_if;	
   if type(i) = DOM_INT then
      if i = 0 then
         return(id)
      elif x=id then
	 return(id)
      elif i=1 then
	 return(x)
      elif i > 1 then
         return( _fconcat(x $ i ) )
      elif i <= -1 then
	 if domtype(x)= DOM_FUNC_ENV then
        	y := slot(x, "inverse"); 
         	if y=FAIL then
            		return( procname( args() ) )
		end_if
	 else
		return(procname(args()))
         end_if;
	 if i=-1 then
	    return(eval(text2expr(y)))
	 else
            return(_fconcat(eval(text2expr(y)) $-i))
 	 end_if
      end_if
 
   end_if;
 
   procname( args() )
 
end_proc:

/*-- Not used anymore:

sysassign((stdlib::inv_func1), 

   table(

      sin  = arcsin,
      cos  = arccos,
      tan  = arctan,
      cot  = arccot,
      sec  = arcsec,
      csc  = arccsc,

      sinh = arcsinh,
      cosh = arccosh,
      tanh = arctanh,
      coth = arccoth, 
      sech = arcsech,
      csch = arccsch,

      ln   = exp
   )
):

sysassign(stdlib::inv_func2, proc() local i; begin
      table( (op(stdlib::inv_func1,[i,2]) = op(stdlib::inv_func1,[i,1]))
             $ i = 1..nops(stdlib::inv_func1)
      )
      end_proc()
):

--*/

_fnest := funcenv(_fnest):
_fnest := slot(_fnest, "type", "_fnest"):
_fnest := slot(_fnest, "print", "@@"):
_fnest::Content := (Out, data) -> Out::Capply(Out::Cfnest, 
                                              map(op(data), Out)): 

/*--
  Redefine output, such that _fnest(f,g) gives f @@ g
--*/

// do not touch the priority; has to be consistent with the
// MuPAD parser and output::Priority (Typesetting)
_fnest := subsop(_fnest, 2=builtin(1100, 1600, "@@", "_fnest")):

