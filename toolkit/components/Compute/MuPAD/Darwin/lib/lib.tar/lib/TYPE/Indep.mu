/*++
Independent -- returns type expression to test for dependency

Independent(x)

x - unknown or set of unknowns

The type expression created returns TRUE if an expression is independent of x.
++*/

Type::Independent:= proc(x)
          option noDebug;
       begin
    if testargs() then
	case args(0)
	of 1 do break;
	otherwise error("wrong no of args");
	end_case;
    end_if;

    new(Type,
	"Independent",
	proc(t,x)
	  name Type::Independent;
	begin
           not has(x,t)
	end_proc,
	x, FALSE)
end_proc:

