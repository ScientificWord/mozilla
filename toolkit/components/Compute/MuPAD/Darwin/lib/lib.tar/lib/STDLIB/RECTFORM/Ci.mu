

Ci::rectform:=
proc(x)
begin
  if is(x, Type::Real) = TRUE then
    return(new(rectform, Ci(abs(x)), (1-sign(x))/2 *PI , 0))
  end_if;
  new(rectform, 0, 0, hold(Ci)(x))
end_proc: