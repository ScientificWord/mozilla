// $Date: 2006-04-27 13:47:21 +0200 (Thu, 27 Apr 2006) $ $Author: walter $ $Revision: 38684 $ #
/*
  frankp, 15.09.1999

        lhs  -- left side of an equation or a range
	rhs  -- right side of an equation or a range
*/
lhs:= proc(e) begin
    if args(0) = 0 then error("no arguments given") end_if;
    if e::dom::lhs <> FAIL then return( e::dom::lhs(args()) )
    elif args(0) <> 1 or 
         not contains( {"_equal","_unequal", "_approx", "_less",
                "_leequal","_range", "_in"},
                type(e) ) 
    then
        error("expecting an equation")
    else
        return( op(e,1) )
    end_if
end_proc:

rhs:= proc(e) begin
    if args(0) = 0 then error("no arguments given") end_if;
    if e::dom::rhs <> FAIL then return( e::dom::rhs(args()) )
    elif args(0) <> 1 or 
         not contains( {"_equal","_unequal", "_approx", "_less",
                "_leequal","_range", "_in"},
                type(e) ) 
    then
        error("expecting an equation")
    else
        return( op(e,2) )
    end_if
end_proc:
