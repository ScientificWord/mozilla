
round::rectform:=
proc(x)
begin
  new(rectform, op(map([extop(rectform(x))], round)))
end_proc:
  