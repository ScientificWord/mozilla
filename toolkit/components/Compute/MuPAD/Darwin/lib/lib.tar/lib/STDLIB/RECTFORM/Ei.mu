Ei::rectform:=
proc(xx)
  local x, a;
begin
  x:= rectform(xx);
  if extop(x, 3) <> 0 or not iszero(extop(x, 2)) then
    new(rectform, 0, 0, hold(Ei)(rectform::expr(x)))
  else
    a := extop(x, 1);
    if domtype(a) = DOM_FLOAT then
      rectform::new(Ei(a))
    elif is(a, Type::Real) = TRUE then
      new(rectform, Ei(a) + I*PI*heaviside(-a), -I*PI*heaviside(-a), 0)
    else
      new(rectform, 0, 0, hold(Ei)(a))
    end_if
  end_if;
end_proc: