// $Date: 2006-12-11 14:30:19 +0100 (Mon, 11 Dec 2006) $ $Author: Stefan Wehmeier $ $Revision: 41991 $

/* solvelib::getElement(S)

   returns *one* element of S

   returns FAIL if no element could be found


*/


solvelib::getElement:=
proc(S)
  local i:DOM_INT, result;

begin
  if S::dom::getElement <> FAIL then
    return(S::dom::getElement(S))
  end_if;

  case type(S)
    of DOM_SET do
      if nops(S)=0 then
        FAIL
      else
        op(S,1)
      end_if;
      break
    of "_union" do
      i:=1;
      repeat
        result:=solvelib::getElement(op(S,i));
        i:=i+1
      until i>nops(S) or result<>FAIL end_repeat;
      return(result)
    // of "_intersect" do: don't know ...
    of "Union" do
      // there can be no general heuristic
      result:= solvelib::getElement(op(S, 3));
      if result = FAIL then
        FAIL
      elif type(op(S, 2)) = DOM_LIST then
        assert(nops(op(S, 2)) = nops(result));
        solvelib::getElement(op(S, 1) | zip(op(S, 2), [op(result)], _equal))
      else
        solvelib::getElement(op(S, 1) | op(S, 2) =  result)
      end_if;
      break
    otherwise
      FAIL
  end_case
end_proc:



