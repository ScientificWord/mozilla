domain solvelib::cartesianPower
  inherits Dom::BaseDomain;
  category Cat::Set;


    new:=
    proc(S: Type::Set, n: Type::PosInt)
    begin
      if domtype(S) = DOM_SET then
        {op(map(combinat::cartesianProduct(S $ n), matrix))}
      elif domtype(S) = piecewise then
        piecewise::extmap(S, solvelib::cartesianPower, n)
      else
        new(dom, S, n)
      end_if
    end_proc;


    convert:=
    proc(a)
    begin
      if domtype(a) = dom then
        a
      else
        FAIL
      end_if
    end_proc;
    
    evaluate := S -> dom::new(eval(extop(S, 1)), extop(S, 2));

    base:= S -> extop(S, 1);

    dimension:= S -> extop(S, 2);

    /* union, intersect, minus */


    homog_union:=
    proc()
      local d;
    begin  
      d:= map({args()}, dom::dimension);
      if d <> {1} then
        FAIL
      else
        dom::new(_union(map(args(), dom::base)), 1)
      end_if
    end_proc;
    
    homog_intersect:=
    proc()
      local d;
    begin
      d:= map({args()}, dom::dimension);
      if nops(d) <> 1 then
        return({})
      else
        d:= op(d)
      end_if;
      dom::new(_intersect(map(args(), dom::base)), d)
    end_proc;

    // homog. unions and differences cannot be simplified

    inhomog_intersect:=
    table(
          DOM_SET =
          proc(CP: solvelib::cartesianPower, S: DOM_SET )
            local B;
          begin
            if CP::dom::dimension(CP) <> solvelib::dimension(S) then
              return({})
            end_if;
            B:= CP::dom::base(CP);
            _union(op(map(S,
                          proc(s)
                            local i, cond;
                          begin
                            cond:= _and(s[i] in B $i=1..nops(s));
                            piecewise([cond, {s}],
                                      [not cond, {}])
                          end_proc
                     )))
          end_proc,
          
          piecewise =
          proc(CP: solvelib::cartesianPower, pw: piecewise)
          begin
            piecewise::extmap(pw, solvelib::solve_intersect, CP)
          end_proc,
          
          solvelib::VectorImageSet =
          proc(CP: solvelib::cartesianPower, VS: solvelib::VectorImageSet)
          begin
            if op(CP, 1) = C_ then
              return(VS)
            end_if;
            FAIL
          end_proc,

          DOM_EXPR =
          proc(CP: solvelib::cartesianPower, a: DOM_EXPR )
          begin
            if CP::dom::base(CP) = C_ then
              a
            else
              FAIL
            end_if
          end_proc
          );
    


    float:= CP -> dom::new(float(extop(CP, 1)), extop(CP, 2));

    expr:= CP -> hold(_power)(extop(CP, 1), extop(CP, 2));

    print:=
    proc(CP)
    begin
      hold(_power)(extop(CP, 1), extop(CP, 2))
    end_proc;

    
end_domain:




