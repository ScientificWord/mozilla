//alias(_pattern = intlib::_pattern): geht nicht

intlib::lookuparcsin:=proc(f)
local n;
save a,b,g,r;
begin
  delete a,b,g,r;
  case type(f) of "_mult" do
      if intlib::matchassign(f,_pattern(g)*arcsin(_pattern(a,not has,_X)*
	_X^_pattern(b,not has,_X))) then return((
         if g=_X and b=1 then
	    (a*_X*(1-a^2*_X^2)^(1/2)+(2*a^2*_X^2-1)*arcsin(a*_X))/4/a^2
         elif g=_X and b=-1 then _X/2*(f+(1-a^2/_X^2)^(1/2)*a)
         elif g=1/_X^2 and b=1 then -f*_X-a*arctanh((1-a^2*_X^2)^(-1/2))
         elif g=1/_X^2 and b=-1 then -f*_X-(1-a^2/_X^2)^(1/2)/a
         else FAIL end_if))
      end_if;
      break;
   of "arcsin" do
      return((if not has((a:=op(f,1)/_X),_X) then _X*f+(1-a^2*_X^2)^(1/2)/a
      elif not has((a:=op(f,1)*_X),_X) then _X*f+a*arctanh((1-a^2/_X^2)^(-1/2))
      else FAIL end_if))
   of "_power" do
      // case arcsin(a*x)^n 
      if is((n:=op(f,2)),Type::PosInt)=TRUE and type(op(f,1))="arcsin" 
	and not has((a:=op(f,[1,1])/_X),_X) then return(fact(n)*
	(sum(arcsin(a*_X)^(n-1-2*r)*(-1)^r*(1-a^2*_X^2)^(1/2)/a/fact(n-1-2*r),
	r=0..(n-1)div 2)+sum(_X*(-1)^r*arcsin(a*_X)^(n-2*r)/fact(n-2*r),r=0..
	n div 2)))
      end_if
   end_case;
   FAIL
end_proc:
