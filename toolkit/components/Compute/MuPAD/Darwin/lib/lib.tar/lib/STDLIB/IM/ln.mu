// $Date: 2001-08-15 17:57:58 +0200 (Wed, 15 Aug 2001) $ $Author: jngerhar $ $Revision: 13473 $ 

/*--
	ln/Im -- the function attribut "Im" for ln
--*/

ln := slot( ln, "Im", proc(x)
    local s;
begin 
    s:= sign(x);
    if s = 1 then 
        return( 0 )
    elif s = -1 then 
        return( PI )
    elif iszero(s) then 
        error("singularity")
    elif domtype(x) = DOM_COMPLEX then
        if op(x,1) = 0 then
            return( 1/2*PI*sign(op(x,2)) )
        else
            return( arg(op(x,1),op(x,2)) )
        end_if
    elif not has(s,hold(sign)) then
        return( arg(Re(s),Im(s)) )
    else
        return( FAIL )
    end_if
 end_proc  ):

// end of file 
