// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $  $Author: bij $  $Revision: 8304 $ 
// kg, 15/07/94 

/************* Now obselete and no longer allowed ****************/

/*++
fun -- create a pure function

fun(e [,Named][,Name=String][,hold])

e      - expression, a function of args(1),...args(n)
Named  - option
Name   - option
String - a character string, the name of the fun
hold   - option

fun views the expression e as a function of the indeterminates args(i)
and returns either a 'pure function' computing that function.

A pure function is a special form of procedure which evaluates in the
context of the caller and is faster than procedures.

If the option 'Named' is used the function name is set to a default
value. With 'Name=String' this name can be given explicitly. Other-
wise it is anonymous, printed as 'fun(...)'.

If the option 'hold' is used the function created does not evaluates
its arguments.

The first argument 'e' of fun are not evaluated!

Examples:

f:= fun(sin(args(1)^2+args(2)^2));		-> fun(...)
f(x,1);						-> sin(x^2+1)

f:= fun(sin(args(1)^2+args(2)^2), Named);	-> fun(sin(args(1)^2+args(2)^2)
f(x,1);						-> sin(x^2+1)

f:= fun(args(1)+1, Name="Inc");                 -> Inc->fun(...)
f(42);                                          -> 43

f:= fun(args(1), hold);                         -> fun(...,hold)
f:= fun(args(1), hold, Named);                  -> fun(args(1),hold)
f:= fun(args(1), hold, Name="f");               -> f->fun(...,hold)
f(42+13);                                       -> 42 + 13
++*/

fun:= proc() option hold; begin
    error("fun(...) no longer available")
end_proc:

// end of file 
