// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	coth/rectform -- the function attribut "rectform" for coth
--*/

coth := slot( coth, "rectform", proc(xx)
        local a, b, t, x;
    begin
        x:= rectform::new(xx);

        if extop(x,3) <> 0 then
            new(rectform,0,0,hold(coth)(rectform::expr(x)))
        else
            a:= extop(x,1);
            b:= extop(x,2);
            if domtype(a+I*b) = DOM_COMPLEX
               and (domtype(a) = DOM_FLOAT or domtype(b) = DOM_FLOAT)
            then
                rectform::new(coth(a+I*b))
            elif iszero(b) then
                new(rectform,coth(a),0,0)
            else
                t:= sinh(a)^2+sin(b)^2;
                new(rectform,sinh(a)*cosh(a)/t,-sin(b)*cos(b)/t,0)
            end_if
        end_if
    end_proc
):

// end of file 
