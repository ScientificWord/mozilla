intlib::makeproc := proc(f, x, __a, __b, eps)
  option escape;
  local _f_, _x_, newf, ta, tb;
begin

  if type(f) = "int" then

     // proc(x) begin float(hold(int)(....)) end_proc 
     // Use hold to avoid symbolic integration.       

     newf := subsop(f, 0=hold(hold(int)));
  /* for release <=1.4 :  
     return(subs(proc(_x_) begin float(_f_) end_proc, _x_ = x, _f_ = newf))
  */
  // for release >1.4 : 
     return( proc() begin subs(newf, x=args(1));float(eval(%)); end_proc);
  end_if;

  // Convert expression f to a function.        
  // The routines ccquad and ncquad needs the   
  // integrand as a function or as a procedure. 
  // Use float(f) to force floating point eval- 
  // uation. For example f:=func(x*PI), f(1.0)  
  // returns 1.0*PI, so use func(float(x*PI)).  

  /*for release <=1.4 :
  newf := subsop((() -> float(f)), [4,1]=f); newf := level(newf,2);
  */
  //for release >1.4: 

  newf:= proc() begin subs(f, x=args(1)); float(eval(%)); end_proc;

  // If a or/and b are singularities of f, then compute the limit   
  // f(x), x->a+ or/and x->+b                                       
  // We assume, that this limit exists and therefore isn't infinity 
  // This check is done in intlib::control. Note that a is the left 
  // and b the right end-point of the interval.                     
  // Generate a procedure and store the limit as the value of f(a)  
  // or/and f(b) in the remember table of the new procedure.        

  ta := traperror(newf(__a)) <> 0; tb := traperror(newf(__b)) <> 0;
  if ta or tb then
    /* for release <= 1.4
     newf := subs(proc(_x_) begin float(_f_) end_proc, _x_ = x, _f_ = f);
    */
    // for release >1.4 
     newf:= proc() begin subs(f, x=args(1)); float(eval(%)); end_proc;
     if ta then
        newf(float(__a)):=float(limit(f,x=__a, Right));
     end_if;
     if tb then
        newf(float(__b)):=float(limit(f,x=__b, Left));
     end_if
  end_if;

  newf

end_proc:

// end of file 
