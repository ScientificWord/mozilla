
// intlib::intOverset(f, x, S)
//

// return int_{-\infty}^{\infty} f(x) chi_S(x) dx
// where chi_S is the charcateristic function of S



intlib::intOverSet:=
proc(integrand, variable: DOM_IDENT, set)
  local a, b, el, iel, s1, s2;
begin

  if set::dom::intOverSet <> FAIL then
    return(set::dom::intOverSet(args()))
  end_if;
  
  integrand := eval(integrand);
  
  case type(set)
    of Dom::Interval do
      a:= set::dom::left(set);
      b:= set::dom::right(set);
      return(piecewise
             ([a < b, int(integrand, variable=a..b)],
              [a >= b, 0]))
    of DOM_SET do
      // integral over a finite set is zero
      // (ignoring the case dirac(..) at the moment)
      return(0)
    of "_union" do
      s1 := {};
      s2 := 0;
      for el in set do
	iel := intlib::intOverSet(integrand, variable, el);
	if op(iel, 0) = procname then
	  s1 := s1 union el;
	else
	  s2 := s2 + iel;
	end;
      end;
      if s1 <> {} then
	return(s2 + procname(integrand, variable, s1));
      else
	return(s2);
      end;
  end_case;

  procname(args())
end_proc:


intlib::intOverSet:=funcenv(intlib::intOverSet):

intlib::intOverSet::type:="intOverSet":