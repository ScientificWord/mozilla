// _plus::simplify - simplification rules for sums

_plus::simplify:=
proc(e)
  local t, l, equ, p, q, base, variable, expo;

begin
  if MAXEFFORT < 500 or MAXEFFORT < property::complexity(e) then
    return(e)
  end_if;

  if not testtype(e, Type::Arithmetical) then
    return(e)
  end_if;
 
  t:= normal(e);
  if length(t) < length(e) then
    e:= t;
  end_if;

    
  // take care of expansions to f(I) such as exp(I*x)+I!
  t:=maprat( e, expand, {DOM_COMPLEX} );
  if length(t) < length(e) then
    e:= t
  end_if;

 

  t:= rationalize(e, NIL, NIL, {"_power"}, ShowDependencies);
  e:= op(t, 1);
  // we only carry out a squarefree factorization
  // (no full factorization) for performance reasons
  e:= expr(polylib::sqrfree(e));
  // for each equation in op(t, 2)  of the form variable = expression^(p/q)
  // replace variable^q by expression^p
  
  for equ in op(t, 2) do
    if type(op(equ, 2)) = "_power" and type((expo:= op(equ, [2, 2]))) = DOM_RAT
      then
      base:= op(equ, [2, 1]);
      variable:= op(equ, 1);
      p:= op(expo, 1);
      q:= op(expo, 2);
      e:= misc::maprec(e,
                       {"_power"} =
                       proc(pow)
                       begin
                         // if pow = base^n where n = aq + b,
                         // we write base^n = (base^q)^a * base^b
                         // = (variable^p)^a * base^b
                         if op(pow, 1) = variable and
                           type(op(pow, 2)) = DOM_INT then
                           
                           variable^(op(pow, 2) mod q) *
                           base^((op(pow,2) div q)*p) 
                         
                         else
                           pow
                         end_if
                       end_proc
                         )
    end_if
  end_for;

  // we have to substitute repeatedly, until no left hand side
  // appears in the expression any more
  repeat
    l:= e;
    e:= subs(e, op(t, 2))
  until l=e end_repeat;      
 
  e
 
 
end_proc:
