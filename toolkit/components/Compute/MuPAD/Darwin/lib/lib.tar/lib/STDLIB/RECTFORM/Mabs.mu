// 
// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 
// 
// frankp, 25.11.1994 

/*--
	rectform::abs  --  the function abs for rectform
--*/

slot(rectform,"abs") := proc(xx)
    name rectform::abs;
    local a, b, x;
begin
    x := rectform::new(xx);

    if extop(x,3) = 0 then
        a := extop(x,1);
        b := extop(x,2);
        if domtype(a+I*b) = DOM_COMPLEX
           and (domtype(a) = DOM_FLOAT or domtype(b) = DOM_FLOAT)
        then
            rectform::new(abs(a+I*b))
        elif sign(a+I*b) = 0 or sign(a+I*b) = 1 then
            new(rectform,a+I*b,0,0)
        elif iszero(a) or iszero(b) then
            new(rectform,abs(a+I*b),0,0)
        else
            new(rectform,sqrt(normal(a^2+b^2)),0,0)
        end_if
    else
        rectform::new(0,0,abs(rectform::expr(x)))
    end_if
end_proc:

// end of file 
