//alias(_pattern = intlib::_pattern): geht nicht

intlib::lookuparccosh:=proc(f) save a,g,b;
begin
  delete a,g,b;
  case type(f) of "_mult" do
      if intlib::matchassign(f,_pattern(g)*arccosh(_pattern(a,not has,_X)*
	_X^_pattern(b,not has,_X))) then return((
         if g=_X and b=1 then (_X/2-1/4/a^2/_X)*f-_X/4/a*(a^2*_X^2-1)^(1/2)
         elif g=_X and b=-1 then _X/2*(f-a*(a^2/_X^2-1)^(1/2))
         else FAIL end_if))
      end_if;
      break;
   of "arccosh" do
      return((if not has((a:=op(f,1)/_X),_X) then _X*f-(a^2*_X^2-1)^(1/2)/a
      elif not has((a:=op(f)*_X),_X) then _X*f+a*arctan((a^2/_X^2-1)^(-1/2))
      else FAIL end_if))
   end_case;
   FAIL
end_proc:
