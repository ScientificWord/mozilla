// $Date: 2003-04-24 14:17:55 +0200 (Thu, 24 Apr 2003) $ $Author: ccr $ $Revision: 22683 $

// card(S)
//
//  returns the cardinality of the set S
//


card:= funcenv
(proc(x)
   name card;
 begin
   if args(0)=0 then
     error("card called without arguments")
   end_if;
   
   // overloading 
   if x::dom::card <> FAIL then
     return(x::dom::card(x))
   end_if;

   // use size-entry of domains if present

   if type(x)=DOM_DOMAIN and x::size <> FAIL then
     return(x::size)
   end_if;
 
   // arg. check

   if testargs() then
     if args(0) > 1 then
       error("Too many arguments")
     end_if;
     if not testtype(x, Type::Set) then
       error("Argument must be a set-theoretic expression")
     end_if
   end_if;

   case type(x)
     of DOM_SET do
       return(nops(x))
     of "_union" do
       if contains(map([op(x)], card), infinity) > 0 then
         return(infinity)
       end_if;
       // otherwise fall through and return unevaluated
       break
   end_case;
   procname(args())
 end_proc):

card::type  := "card":
card::print := "card":

card::Content := (Out, data) ->
                     Out::Capply(Out::Ccard, op(map([op(data)], Out))):

card::TeX := (arg1, arg2, arg3) -> "\\#(".generate::tex(op(arg2), output::Priority::Noop).")":