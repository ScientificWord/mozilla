// $Date: 2002-12-10 11:29:04 +0100 (Tue, 10 Dec 2002) $ $Author: stefanw $ $Revision: 21261 $ 
/*--
intlib::tower(f) - constructs the tower of field extensions in which f is an 
element.

f - expression

--*/
intlib::tower:=
proc(f)
  local i,j,L,x;
// global _global_n,_global_k,_global_k_sub,_global_k_ident,_global_k_diff,_global_k_deg,_global_k_alg,_global_Q,_global_Q_sub; 
begin

  // if f is an indexed expression, it is regarded as independent of the
  // integration variable in any event (e.g. int(x[3], x) = x x[3]
  // otherwise, we replace constant subexpressions by identifiers if they are
  // neither sums, products, or powers
  if type(f)="_index" or not contains({"_power", "_mult", "_plus"}, type(f))
    and indets(_global_k_sub) intersect indets(f) = {} then
    if (j:=contains(_global_Q,f))>0 then
      return(_global_Q_sub[j]);
	 else
      _global_Q:=append(_global_Q,f);
      x:=genident("C");
      _global_Q_sub:=append(_global_Q_sub,x);
      return(x);
    end_if;
  end_if;
  L:=null();
  for i in f do
    case domtype(i)
      of DOM_EXPR    do
        case (j:=intlib::tower(i))
          of FAIL  do
            return(FAIL);
          of FALSE do
            return(FALSE);
          otherwise
            L:=L,j;
        end_case;
        break;
      of DOM_INT     do ;
      of DOM_RAT     do
        L:=L,i;
        break;
      of DOM_COMPLEX do
        if (j:=contains(_global_Q,I))>0 then
          L:=L,op(i,1)+op(i,2)*_global_Q_sub[j];
        else
          x:=genident();
          L:=L,op(i,1)+op(i,2)*x;
          _global_Q:=append(_global_Q,I);
          _global_Q_sub:=append(_global_Q_sub,x);
        end_if;
        break;
      of DOM_IDENT   do
        if (j:=contains(_global_Q,i))>0 then
          L:=L,_global_Q_sub[j];
          break;
        end_if;
        if contains(_global_Q_sub,i)>0 then
          L:=L,i;
          break;
        end_if;
        if contains(_global_k,i)>0 then
          L:=L,i;
          break;
        end_if;
        if contains(_global_k_sub,i)>0 then
          L:=L,i;
          break;
        end_if;
        x:=genident();
        L:=L,x;
        _global_Q:=append(_global_Q,i);
        _global_Q_sub:=append(_global_Q_sub,x);
        break;
      of DOM_FLOAT   do
        return(FAIL);
      otherwise
        return(FAIL);
    end_case;
  end_for;
  case op(f,0)
    of hold(ln)       do /* -----------------------------------------------
                         // This is Winfried's original code:
                         i:=numer(L); j:=denom(L);
                         if domtype(i)<>DOM_EXPR and domtype(i)<>DOM_IDENT or
                            domtype(j)<>DOM_EXPR and domtype(j)<>DOM_IDENT
                           then return(intlib::insert(0,hold(ln),i/j));
                           else return(intlib::insert(0,hold(ln),i)
                                      -intlib::insert(0,hold(ln),j));
                         end_if;
                         ------------------------------------------------*/
                         /* ----------------------------------------------
                         //  Walter 3.2.2: ln(i/j) <> ln(i) - ln(j) !!
                         //  Changed the previous code to the following:
                         ------------------------------------------------*/
                         return(intlib::insert(0,hold(ln),L));
    of hold(exp)      do return(intlib::insert(1,hold(exp),normal(L)));
    of hold(tan)      do return(intlib::insert(2,hold(tan),normal(L)));
    of hold(arctan)   do return(intlib::insert(0,hold(arctan),normal(L)));

    of hold(_plus)    do return(intlib::algred(_plus(L),_global_n));
    of hold(_mult)    do return(intlib::algred(_mult(L),_global_n));
    of hold(_power)   do
      if domtype(L[2])=DOM_INT then
        return(L[1]^L[2])
      else
        return(intlib::tower(hold(exp)(L[2]*ln(L[1]))));
      end_if;
    of FAIL           do
      if domtype(f)=DOM_LIST then
        return([L]);
      else
        return(f);
      end_if;
    otherwise
      return(FAIL);
  end_case;
end_proc:
