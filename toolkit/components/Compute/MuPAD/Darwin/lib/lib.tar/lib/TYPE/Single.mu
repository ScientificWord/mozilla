// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ 

/*++
Singleton - returns type expression to test singleton types

Singleton(e)

e - expression defining the singleton type, may NOT be an
    expression sequence

A singleton type is a type consisting of only one element - the
expression given by e.
++*/

Type::Singleton:=
    proc()
      option noDebug;
    begin
      if args(0) <> 1 then error("wrong no of args") end_if;
      new(Type,
	  "Singleton",
	  proc()
	    name Type::Singleton;
	    option noDebug;
	  begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    bool(args(2) = args(1)[1])
	  end_proc,
	  [ args(1) ], FALSE)
    end_proc:

// end of file 
