/*++ ---------------- getOptions.mu ---------------------

Author: Winfried Fakler,  University of Paderborn
Date Created: 17 March  2000
 $Id: getOptions.mu 36781 2006-02-07 12:44:48Z tonner $


Description:
This file contains functions for handling the user given options.
                                                          
Functions: 


++*/

intlib::defaultOptions:=
table(
      "PrincipalValue"=FALSE,
      "Continuous"=FALSE,
      "UseNewLookup"=TRUE
      ):

intlib::getOptions:=
  proc()
    local options,o;  
  begin
    if args(0)>=1 and type(args(1))=DOM_TABLE then
      return(args(1))
    end_if;
    
    options:=intlib::defaultOptions;
    /* get options */
    if args(0)>=1 then
      for o in [args()] do
        case o
          of hold(PrincipalValue) do
            options["PrincipalValue"]:=TRUE;
            break
          of hold(Continuous) do
            options["Continuous"]:=TRUE;
            break
          of hold(UseNewLookup) do
            options["UseNewLookup"]:=TRUE;
            break
          otherwise
            if type(o) = "_equal" then
              case op(o, 1)
                of hold(PrincipalValue) do
                  if op(o, 2) in {TRUE, FALSE} then
                    options["PrincipalValue"] := op(o, 2);
                  else
                    error("Illegal value: ".expr2text(o));
                  end_if;
                  break;
                of hold(Continuous) do
                  if op(o, 2) in {TRUE, FALSE} then
                    options["Continuous"] := op(o, 2);
                  else
                    error("Illegal value: ".expr2text(o));
                  end_if;
                  break;
                of hold(UseNewLookup) do
                  if op(o, 2) in {TRUE, FALSE} then
                    options["UseNewLookup"] := op(o, 2);
                  else
                    error("Illegal value: ".expr2text(o));
                  end_if;
                  break;
                otherwise
                  error("Unknown option ".expr2text(o));
              end_case;
            else
              error("Unknown option ".expr2text(o));
            end_if;
        end_case;
      end_for;
    end_if;
    if options["PrincipalValue"] and options["Continuous"] then
      error("Illegal combination of options")
    end_if;
    userinfo(10, "Options used: ".expr2text(options));    
    options    
  end_proc:

intlib::printOptions:=
  proc(optionTable=intlib::defaultOptions)
    local o;
  begin
    op([(if op(o,2)<>intlib::defaultOptions[op(o,1)] and
            op(o, 1) <> "UseNewLookup"
         then
           if op(o,2) = TRUE then
             text2expr(op(o,1))
           else
             text2expr(op(o, 1)) = op(o, 2)
           end_if
         else null()
         end_if) $ o in optionTable])
  end_proc:
