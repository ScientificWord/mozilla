_plus::combine:=
proc()
  local s,sint,sint2,u,v,changed;
begin
  s:=_plus(map(args(),combine));
  if type(s) <> "_plus" then
    return(s)
  end_if;
  sint:=select(s,testtype,"int");
  if nops(sint) > 0 then s:=s-sint; end_if:
  if type(sint)="_plus" then
    sint2:=select(sint,
                  proc()
                  begin
                    type(op(args(1),2))="_equal"
                  end_proc );
    sint:=sint-sint2;
    while type(sint2)="_plus" do
         changed:=FALSE;
      for u in sint2 do
        for v in sint2 do
          if op(u,1)=op(v,1) and op(u,[2,1])=op(v,[2,1]) and
            op(u,[2,2,2])=op(v,[2,2,1]) then
            sint2:=sint2-u-v+eval(subsop(u,[2,2,2]=op(v,[2,2,2])));
            changed:=TRUE; break
          end_if
        end_for;
        if changed then break end_if
      end_for;
      if not changed then break end_if
    end_while;
    sint:=sint+sint2
  end_if;
  s:=s+sint;
  if type(s) <> "_plus" then return(s); end_if;
  sint:=select(s,testtype,"sum");
  if nops(sint) > 0 then s:=s-sint; end_if:
  if type(sint)="_plus" then
    sint2:=sint; sint:=0;
    while type(sint2)="_plus" do
      changed:=FALSE;
      for u in sint2 do
        for v in sint2 do
          if op(u,2)=op(v,2) and u<>v then
            sint2:=sint2-u-v+eval(subsop(u,1=op(u,1)+op(v,1)));
            changed:=TRUE; break
          end_if
        end_for;
        if changed then break end_if
      end_for;
      if not changed then break end_if
    end_while;
    sint:=sint+sint2
  end_if;
  s+sint
end_proc:
