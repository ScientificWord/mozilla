
/*--
	log/Re -- the function attribut "Re" for log
--*/

log := slot( log, "Re", proc(b, x) 
    local s;
begin 
    s:= sign(x);
    if s = 1 then 
        return( log(b, x) )
    elif s = -1 then 
        return( log(b, -x) )
    elif iszero(s) then 
        error("singularity")
    elif domtype(x) = DOM_COMPLEX then
        s:= abs(x);
        if domtype(s) = DOM_EXPR then 1/2*log(b, s^2) else log(b, s) end_if
    else
        return( log(b, abs(x)) )
    end_if
 end_proc  ):

// end of file 
