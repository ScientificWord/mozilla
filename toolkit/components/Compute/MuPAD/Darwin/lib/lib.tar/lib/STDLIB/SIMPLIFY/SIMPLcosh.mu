// very simple form, just uses combine

simplify::cosh:=
proc(a)
begin
  if type(a) = "_plus" then
    a := normal(a)
  end_if;
  combine(a, hold(sinhcosh))
end_proc