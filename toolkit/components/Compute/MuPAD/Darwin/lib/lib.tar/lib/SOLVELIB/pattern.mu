/* $Id: pattern.mu 38826 2006-05-05 14:12:31Z meista $
 *
 * solvelib::pattern(eq, x, options)
 *
 * Tries to solve an (in-)equation eq(x) by using the pattern matcher, or
 * returns FAIL if no pattern in solvelib::patternFSA matches.
 */



solvelib::pattern :=
proc(eq, x, options: DOM_TABLE)
  local l, s;
begin
  if solvelib::patternFSA <> FAIL then
    l := matchlib::evalFSA(`#solve`(eq, x, options), solvelib::patternFSA);
    if nops(l) > 0 then
      s := fp::nest(unfreeze, 2)(l[1]);
      case type(l[1])
        of "_intersect" do
          return(unfreeze(_intersect(s)));
        of "_union" do
          return(unfreeze(_union(s)));
        otherwise
          if type(s) = piecewise then
            /* unfreeze piecewise expressions */
            return(piecewise(map(op(s), t->[t[1], unfreeze(t[2])])));
          else
            return(s);
          end_if;
      end_case;
    end_if;
  end_if;
  return(FAIL);
end_proc:
