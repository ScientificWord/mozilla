// $Date: 2007-01-30 13:31:54 +0100 (Tue, 30 Jan 2007) $ $Author: Stefan Wehmeier $ $Revision: 42761 $

/*
  computes the gcd of A and B with respect to x,
  using the extended Euclidean algorithm 
  PZ, 14/10/1994

  arg. testing rewritten S.W., 19/10/1999

*/

gcdex :=
proc(A,B)
  local x,s,t,u,v,q,a,b,tmp;
begin
  if args(0)<2 or args(0)>4 then
    error("Wrong number of arguments")
  end_if;

  if A::dom::gcdex <> FAIL then return(A::dom::gcdex(args())) end_if;
  if B::dom::gcdex <> FAIL then return(B::dom::gcdex(args())) end_if;

  if iszero(A) then
    if iszero(B) then
      return(A, A, A^0)
    else
      gcdex(B,A, args(3..args(0)));
      // it is sure we get a sequence with three args
      return(op(%,1), op(%,3), op(%,2))
    end_if
  end_if;
  
  if args(0)=3 then
    x:=[args(3)];
    a:=poly(A, x);
    b:=poly(B, x);
    if a=FAIL or b=FAIL then
      error("Could not convert input to polynomials in the given variable")
    end_if
  else
    if {domtype(A), domtype(B)}<>{DOM_POLY} then
      error("Either a variable must be given, ".
            "or input must consist of polynomials")
    end_if;
    // now A and B are polynomials
    if op(A,2..3)<>op(B,2..3) then
      error("Polynomial types differ")
    end_if;
    x:=op(A,2);
    if nops(x)<>1 then
      error("Polynomials must be univariate")
    end_if;
    a:=A;
    b:=B
  end_if;

  // handle special case of rational polynomials separately
  if op(a, 3) = Expr and
    map({coeff(a), coeff(b)}, domtype) minus {DOM_INT, DOM_RAT} = {} then
    a:= gcdlib::gcdexRational(a, b);
    if type(A) = DOM_POLY then
      return(a)
    else  
      return(op(map([a], expr)))
    end_if
  end_if;

  if op(a, 3) = Dom::Rational then
    return(op(map([gcdex(poly(a, Expr), poly(b, Expr))], poly, Dom::Rational)))
  end_if;

  if type(a) <> DOM_POLY or op(a, 3) = hold(Expr) then
    a:= normal(a);
    b:= normal(b)
  end_if;
  
  s:=a^0; t:=s-s; u:=t; v:=s;
   // loop invariant : a = s*A+t*B, b = u*A+v*B
  while not iszero(b) do
    userinfo(10, "Applying Euclidean step");
    q:=divide(a,b);
    if q = FAIL then
       error("Could not divide");
    end_if;
    userinfo(10, expr2text(a)." = ".expr2text(b)."*".expr2text(q[1]).
             " + ".expr2text(q[2]));
    a:=b;
    if type(a) <> DOM_POLY or op(a, 3) = hold(Expr) then
      b:=mapcoeffs(q[2], normal);
      q:=mapcoeffs(q[1], normal)
    else
      b:= q[2];
      q:= q[1]
    end_if;
    tmp:=s; s:=u; u:=tmp-q*u;
    tmp:=t; t:=v; v:=tmp-q*v;
    userinfo(10, expr2text(a)." = ".expr2text(s). "*". expr2text(A).
             " + ".expr2text(t)."*".expr2text(B))
  end_while;
  tmp:=1/lcoeff(a);
  userinfo(20, "Normalizing ");
  s:=multcoeffs(a,tmp),multcoeffs(s,tmp),multcoeffs(t,tmp);

  if type(A)=DOM_POLY then
    s
  else
    op( map([s],normal@expr) )
  end_if
end_proc:

