// $Date: 2002-02-04 09:50:26 +0100 (Mon, 04 Feb 2002) $ $Author: walter $ $Revision: 17095 $ 

/*--
intlib::pde_ln(A,B,C,n,m) - solves the
polynomial differential equation AY'+BY=C
when the degrees of A and B as polynomials in the last extension are zero and 
this extension is an logarithmic monomial.
It call's the procedure solve_Rde recursiv.
M. Bronstein, The Transcendental Risch Differential Equation, Journal of
Symbolic Computation, 1990, 9
--*/

intlib::pde_ln:=proc(A,B,C,n,m)
  local c,y,Y,i;
// global _global_k_sub,_global_k_diff; 
begin
  if (c:=degree(C))>m then
    userinfo(10,"can't solve the Rde:",
                         A,B,C,n,"because the bound is to low");
    return(FAIL); end_if;
  A:=expr(A); B:=expr(B);
  y:=intlib::solveRde(B/A,polylib::lcoeff(C)/A,n-1);
  if y=FAIL then
    userinfo(10,"can't solve the polynomial differential equation",
                         A,B,C,n);
    return(FAIL); end_if;
  Y:=y*_global_k_sub[n]^c;
  for i from c-1 downto 0 do
    y:=intlib::solveRde(B/A,coeff(C,i)/A-(i+1)*_global_k_diff[n]*y,n-1);
    if y=FAIL then
    userinfo(10,"can't solve the polynomial differential equation",
                         A,B,C,n);
      return(FAIL); end_if;
    Y:=Y+y*_global_k_sub[n]^i;
  end_for;
  return(Y);
end_proc:
