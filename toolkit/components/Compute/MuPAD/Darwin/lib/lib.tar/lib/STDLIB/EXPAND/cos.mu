// $Date: 2002-04-04 10:23:38 +0200 (Thu, 04 Apr 2002) $ $Author: stefanw $ $Revision: 17914 $ 

/*--
cos/expand -- the function attribut "expand" for cos

 cos(-x)     = cos(x)                                      
 cos(x +- y) = cos(x) * cos(y) -+ sin(x) * sin(y)           
              n/2                                           
              ---                                           
              \   (  n )                                    
 cos(n * x) = /   ( 2*i) cos(x)^(n-2*i)*sin(x)^(2*i)*(-1)^i 
              ---                                           
              i=0                                           
--*/

cos := slot
(cos, "expand",
 proc(x)
  local n, t, y, C, S;
 begin
  y := expand(x);

   case type(y)

     of "_plus" do

       n := op(y, 1); y := subsop(y, 1=null());
       return(expand(cos(n)*cos(y)-sin(n)*sin(y)));
       
     of "_mult" do
       n := op(y, nops(y));
       t := type(n);

       // apply the rule
       // cos(I*x) = cosh(x)
       if t = DOM_COMPLEX and iszero(op(n, 1)) then
         return(expand(cosh(y/I)))
       end_if;
       
       // cos(n*x) = sin(x)^(..)*cos(x)^(..) + ...
       // Do this, if n is integer and x contains at least on symbol,
       // because we do not want to expand cos(5*sqrt(2)) etc.
       if indets(y) minus Type::ConstantIdents = {} then
          break;
       end_if:
       n := op(y, nops(y));
       t := type(n);
       if t = DOM_INT or t = DOM_RAT then
          if n < 0 then
             return(expand(cos(-y)));
          else // n > 0
               // the following is due to Francois Maltey
             if n=1 then return(cos(y)) end_if; // avoids loop in expand(cos(1)) 
             if t = DOM_INT then
               y := y / n;
               S:= genident("S");
               C:= genident("C");
               return(
                  subs(expand(((C+I*S)^n+(C-I*S)^n)/2),[C=cos(y),S=sin(y)])
                     );
             end_if;
          end_if;
       end_if;

  end_case;

  cos(y)

end_proc):

// end of file
