// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $

//Residue Class -- expression to test for residue class

Type::Residue:=
  proc(RM = 0, CL = 0 : DOM_INT, ST = Type::Integer)
    local rs;
  begin
    case type(RM)
      of DOM_LIST do
        rs:= RM; break
      of "Residue" do
        return(rs)
      otherwise
        rs:= property::Residue(RM, CL, ST);
    end_case;
    if domtype(rs) = DOM_LIST then
      new(property::Residue,
          "Residue",
	  proc(t,x)
	    name Type::Residue;
            option noDebug;
          begin
            if args(0) <> 2 then return(FALSE) end_if;
            if domtype(x) = DOM_INT then
              bool((x mod op(t, 2)) = op(t, 1))
              and testtype(x, op(t, 3))
            else
              FALSE
            end_if
          end_proc,
          rs, FALSE,
          rs)
    else
      rs
    end_if
  end_proc:
