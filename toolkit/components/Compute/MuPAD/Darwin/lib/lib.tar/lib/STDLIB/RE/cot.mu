// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	cot/Re -- the function attribut "Re" for cot
--*/

cot := slot( cot, "Re", proc(x)
        local r, s;
    begin
        r := Re(x);
        if r = x then 
            return( cot(x) )
        elif not has(r,{hold(Re),hold(Im)}) then
            s := Im(x);
            if not has(s,{hold(Re),hold(Im)}) then
                return( sin(r)*cos(r) / (sin(r)^2+sinh(s)^2) )
            end_if
        end_if;
        return( FAIL )
    end_proc
):

// end of file 
