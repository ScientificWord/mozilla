
/***********************************************************
solvelib::completeLinearSolution

sol - a solution produced by linsolve(..., ShowAssumptions)
newsys - the system that has been solved
unk - the unknowns
options - table of options

***********************************************************/



solvelib::completeLinearSolution:=
proc(sol, newsys, unk, options = solvelib::getOptions())
  local lcoefflist, cond1, cond2, branches, lc, f, linear, pw, solutions,
  dummy, i, inds;

begin
  if options["IgnoreSpecialCases"] then
    pw:= solvelib::ignoreSpecialCases
  else
    pw:= piecewise
  end_if;

  if op(sol, 1) = FAIL then
    solutions:= {}
  else
    solutions:= solvelib::vectorForm({op(sol, 1)}, unk)
  end_if;

    
  lcoefflist:= op(sol, 3);
  cond1:=_and(op(op(sol,2)));
  cond2:=_and(op(op(sol, 3)));

  if nops(lcoefflist) = 0 or options["IgnoreSpecialCases"] then
    return(pw([cond1 and cond2,
               solutions],
              [not cond1, {}]))
  end_if;

  assert(map({op(lcoefflist)}, type) = {"_unequal"});

  // replace a <> b by a-b
  lcoefflist:= map(lcoefflist, ineq -> op(ineq, 1) - op(ineq, 2));

  // try to split conditions a*b <> 0 into a<>0 and b<>0

  lcoefflist:= map(lcoefflist,
                   proc(a)
                     local f;
                   begin
                     f:= factor(a);
                     op(f, 2*i) $i=1..nops(f) div 2
                   end_proc
                   );
  
  branches:=[[cond1 and cond2, solutions],
             [not cond1, {}]];
  // try to find out what happens if lc = 0 for as many elements
  // of lcoefflist as possible (currently, only linear polys are handled)
      
  for lc in lcoefflist do
    inds:= indets(lc);
    for i in inds do
      if testtype(lc, Type::PolyExpr([i])) and
        degree(lc, [i]) = 1 then
        linear:= [lc, i];
        f:= poly(linear[1], [linear[2]]);
        if traperror((dummy:= eval
                      (subs(newsys,
                            linear[2] = -coeff(f,0) / coeff(f, 1)))))
          = 0 then
          branches:= branches.[[linear[1] = 0, solve(dummy, unk, options)]]
        end_if
      end_if
    end_for;
  end_for;
    
          
  return(pw(op(branches)))
end_proc: