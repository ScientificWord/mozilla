gamma::complexDiscont:=
   solvelib::BasicSet(Dom::Integer) intersect Dom::Interval(-infinity..[0]):

gamma::realDiscont:= gamma::complexDiscont:
gamma::undefined:= gamma::complexDiscont: