// $Date: 2001-05-22 11:06:42 +0200 (Tue, 22 May 2001) $ $Author: bij $ $Revision: 11860 $ 

/* tries to compute the indefinite integral of an expression
  containing the Bessel J function.

  Reference: Integrals and Series vol. 2, 
             Prudnikov, Brychkov and Marichev, 1986, OPA (Amsterdam) */

//alias(_pattern = intlib::_pattern): geht nicht!

intlib::besselJ :=
  proc(f,x)
    local l, G;
  begin
    G:= genident("PATTERN");
    // formula 20 page 41
    if (l:=intlib::match1(f,1/x^2*besselJ(_pattern(G,not has,x),x)^2)) <> FAIL then
      return(
             expand(subs(2/(4*G^2-1)/x*((x*diff(besselJ(G,x),x)+besselJ(G,x)/2)^2
                                        +(x^2-G^2+1/4)*besselJ(G,x)^2),op(l))))
    end_if;
    FAIL
  end_proc:
