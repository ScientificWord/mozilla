// $Date: 2002-05-22 14:07:48 +0200 (Wed, 22 May 2002) $ $Author: stefanw $ $Revision: 18436 $ 

/*--
	exp/expand -- the function attribut "expand" for exp

	exp(-x)        = 1/exp(x)
	exp( x + y)    = exp(x) * exp(y)
	exp(n * x)     = exp(x) ^ n   if n*x is real
	exp(x * ln(y)) = x ^ y
--*/

exp:= slot
(exp, "expand",
 proc(x)
   local n, t, y, k;
 begin
   y := expand(x);

   case type(y)

     of "_plus" do
       
       return(expand(_mult(map(op(y), exp))));

     of "_mult" do

       n := op(y, nops(y));
       t := type(n);
       if t = DOM_INT then
         return(expand(exp(y/n))^n)
       elif t = DOM_RAT then
          // exp(x/2)=exp(x)^(1/2) is not true for x=2*I*PI for example 
         if is(y/n,Type::Real)=TRUE then
           return(slot(exp,"expand")(y/n)^n)
         elif n < 0 then
           return(1/expand(exp(-y)))
         end_if
       else
         for k from 1 to nops(y) do
           n := op(y, k);
           if testtype(n, "ln") then
             return(op(n, 1) ^ subsop(y, k=1))
           end_if
         end_for
       end_if;

       break

     of "LambertW" do
       // y= W(z); dividing the functional equation exp(W(z))*W(z) = z
       // by W(z) shows that exp(W(z)) = z / W(z) unless W(z) = 0
       return(piecewise([y = 0, 1], [y<>0, op(y, 2) / y]))
 
     of DOM_INT do
       return( exp(1)^y )

   end_case;

 exp(y)

end_proc):

// end of file 
