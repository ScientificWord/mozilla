genident("n"):
tan::undefined:= Dom::ImageSet((% + 1/2) * PI, %, Z_):

tan::realDiscont:= tan::undefined:
tan::complexDiscont:= tan::undefined:

