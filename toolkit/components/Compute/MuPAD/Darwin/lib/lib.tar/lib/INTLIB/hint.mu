/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Reduction of poles at infinity and computation of the
|                 logarithmic part using a combination of Trager algorithm and
|                 Cantor arithmetic in the Jacobian of hyperelliptic curves.
|                 The integral to compute must be in the form:
|                                          /
|                                          |p(x)/(q(x)y)dx
|                                          /
|                 where y^2=f(x) defines the hyperelliptic curve.
|                 f and q must be squarefree polynomials, we must have
|                 gcd(q,f)=gcd(p,q)=1 and degree(f)=2g+1 (odd). We suppose that
|                 the algebraic part corresponding to the multiple finite poles
|                 is already computed (nothing new here).
|
| Input :     h : The integrand. It must be as above.
|
|             x : The integration variable.
|
| Output:       : An antiderivative if there exists one. When there is no
|                 antiderivative, simplifications can be made in the returned
|                 integral (Computation of the algebraic part at infinity,
|                 simplification of poles when it is possible).
|
| Note:         : The case with parameters is not implemented (Problem with the
|                 computation of the basis of the residues).
|                 We don't verify the integrand is in the good form because
|                 such a function should be included in the more general
|                 integration algorithm.
|
|                                                              L.Bertrand 12/93
|                                                      e-mail: lbertran@cict.fr
|                         Translated from Maple to MuPAD by P. Zimmermann 12/95
|                                              e-mail: Paul.Zimmermann@loria.fr
Example:

>> f:=x^3+1: p:=2+21*x^5+12*x^2+5*x^4+2*x-3*x^3: q:=2*x:
>> intlib::hyperint(p,q,f,x);

                               /      3     1/2     3      3     1/2      \
                               | (- (x  + 1)    + 1)  (- (x  + 1)    - 1) |
                             ln| ---------------------------------------- |
                               |                     6                    |
  3     1/2         2          \                    x                     /
(x  + 1)    (x + 3 x  - 1) + ----------------------------------------------
                                                   3
*/

alias(SQRT(f)=sqrt(f)):

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Reduction of poles at infinity and computation of the
|                 logarithmic part using a combination of Trager algorithm and
|                 Cantor arithmetic in the Jacobian of hyperelliptic curves.
|                 The integral to compute must be in the form:
|                                          /
|                                          |(p(x)/q(x)y)dx
|                                          /
|                 where y^2=f(x) defines the hyperelliptic curve.
|                 f and q must be squarefree polynomials, we must have
|                 gcd(q,f)=gcd(p,q)=1 and degree(f)=2g+1 (odd). We suppose that
|                 the algebraic part corresponding to the multiple finite poles
|                 is already computed (nothing new here).
|
| Input :     p : The numerator of the differential: a univariate polynomial in
|                 x.
|
|             q : The denominator of the differential: a univariate squarefree
|                 polynomial in x.
|
|             f : The defining polynomial of the curve: a squarefree univariate
|                 polynomial in x of odd degree prime to q.
|
|             x : The integration variable.
|
| Output:       : An antiderivative if there exists one. When there is no
|                 antiderivative, simplifications can be made in the returned
|                 integral (Computation of the algebraic part at infinity,
|                 simplification of poles when it is possible).
|
| Note:         : The case with parameters is not implemented (Problem with the
|                 computation of the basis of the residues).
|                 We don't verify the integrand is in the good form because
|                 such a function should be included in the more general
|                 integration algorithm.
|
|                                                              L.Bertrand 12/93
*/

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Principality test for a reduced divisor.
|
| Input :     DD : The reduced divisor to test.
|
| Output:       : A boolean: if DD is principal then true else false.
|
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
|                 DD is reduced if deg(A)<=g.
*/
alias(isprincipal(x)=bool(degree(op(x,1))=0)):
alias(hyperint=intlib::hyperint):
alias(logparthyperel1=intlib::logparthyperel1):
alias(root2sqrt=intlib::root2sqrt):
alias(construcdivi=intlib::construcdivi):
alias(diviaddition2=intlib::diviaddition2):
alias(diviaddition2mod=intlib::diviaddition2mod):
alias(divireduction=intlib::divireduction):
alias(divireductionmod=intlib::divireductionmod):
alias(divtoresidue=intlib::divtoresidue):
alias(divtoresidues=intlib::divtoresidues):
alias(AlgExt=intlib::AlgExt):
alias(goodprime=intlib::goodprime):
alias(ntimesdivi=intlib::ntimesdivi):
alias(oppositedivi=intlib::oppositedivi):
alias(ordredivi=intlib::ordredivi):
alias(ordredivimod=intlib::ordredivimod):
alias(polyresidues1=intlib::polyresidues1):
alias(resbasis=intlib::resbasis):
alias(coeffs2=intlib::coeffs2):
alias(verif=intlib::verif):
alias(Afactor=intlib::Afactor):
alias(Afactor1=intlib::Afactor1):

hyperint:=proc(p,q,f,x) local g,T,S,algpart,B,y;
begin
          g:=(degree(f,x)-1)/2;
          userinfo(1,"Starting reduction at infinity at time",time());
/*
| Hermite reduction at infinity.
*/
          T:=divide(p,q,[x]); S:=T[2]; T:=T[1];
          algpart:=0;
          while degree(T,x)>=2*g do
             userinfo(3,"One step of Hermite reduction at infinity");
             B:=x^(degree(T,x)-2*g)*2*polylib::lcoeff(T,[x])
		 /polylib::lcoeff(f,[x])/(2*degree(T,x)-2*g+1);
             algpart:=algpart+B;
             T:=expand(T-diff(B,x)*f-diff(f,x)*B/2);
          end_while;
          userinfo(1,"End of reduction at infinity at time",time());
/*
| Test of non-elementarity and computation of the logarithmic part when it is
| required.
*/
          y:=SQRT(f);
          if degree(T,x)>=g then
           userinfo(1,"Not elementary because pole of order>=2");
           algpart*y+hold(int)(normal(T*q+S)/q/y,x);
           else algpart*y+logparthyperel1(T*q+S,q,f,x);
          end_if;
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the logarithmic part using a combination of
|                 Trager algorithm and Cantor arithmetic in the Jacobian of
|                 hyperelliptic curves.
|                 The integral to compute must be in the form:
|                                          /
|                                          |(p(x)/q(x)y)dx
|                                          /
|                 where y^2=p0(x) defines the hyperelliptic curve.
|                 p0 and q must be squarefree polynomials, we must have
|                 gcd(q,p0)=1, degree(p0)=2g+1 (odd) and degree(p)-degree(q)<g.
|
| Input :     p : The numerator of the differential: a univariate polynomial.
|
|             q : The denominator of the differential: a univariate squarefree
|                 polynomial.
|
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|
|             x : The integration variable.
|
| Output:       : An antiderivative if there exists one. When there is no
|                 antiderivative, simplifications can be made in the returned
|                 integral (simplification of poles when it is possible).
*/

logparthyperel1:=proc(p,q,p0,x)
local f,i,j,g,OO,R,base,M,H,V,residu,DD,nbres,d,F,mul,AE,
      Z,pp,qq,pp0,Zgen;
save _z,_y;
begin
  delete _z,_y;
/*
| Computation of the genus.
*/
  g:=(degree(p0,x)-1)/2;
  if iszero(p) then return(0) end_if;
  userinfo(2,"The genus is",g);
  userinfo(1,"Starting computation of logarithmic part at time",time());
/*
| Computation of the residues polynomial.
*/
  R:=polyresidues1(p,q,p0,x,_z);
  if degree(R)=0 then
    userinfo(1,"Not elementary, no poles");
    return(hold(int)(p/q/SQRT(p0),x));
  end_if;
  userinfo(1,"Starting computation of residues",time());
  userinfo(3,"Residues are roots of",R);
/*
| Computation of the basis of the residues.
*/
  M:=resbasis(R,_z);
  base:=M[2]; mul:=M[3]; M:=M[1];
// construction of the algebraic extension 
  if nops(base)=0 then AE:=Expr
  else
    AE:=Expr; Z:=table(); Zgen:=[0$linalg::nrows(M)]; f:=null();
    // Z is the alias name, Zgen its value Root(_Z^2-3) 
    for i from 1 to linalg::nrows(M) do
      if contains({DOM_INT,DOM_RAT},type(base[i])) then
	Z[i]:=base[i]; Zgen[i]:=base[i];
      else
	j:=op(indets(base[i],PolyExpr));
	if nops([j])=1 and op(j,0)=Root then
	  if (d:=contains(Zgen,j))<>0 then Z[i]:=Z[d]
	  else
	    Z[i]:=genident("Z"); // name of the RootOf 
	    if AE=Expr then AE:=Dom::Rational end_if;
	    AE:=Dom::AlgebraicExtension(AE,
		    poly(numer(eval(subs(op(j),f,_Z=Z[i]))),[Z[i]],AE));
	    f:=f,j=Z[i];
	  end_if;
	  Zgen[i]:=j;
	else error("unexpected base: ".expr2text(base[i]))
	end_if
      end_if
    end_for
  end_if;
  for j from 1 to linalg::ncols(M) do
    residu[j]:=0;
    for i from 1 to linalg::nrows(M) do
      residu[j]:=residu[j]+M[i,j]*subs(base[i],Zgen[i]=Z[i])
    end_for;
    if AE<>Expr then residu[j]:=AE(residu[j]) end_if
  end_for;
  nbres:=linalg::ncols(M);
  userinfo(3,"Nber of distinct residues is",nbres);
  userinfo(3,"Distinct residues are",residu);
  userinfo(3,"Residues basis is",base);
  userinfo(1,"End of computation of residues",time());
  userinfo(1,"Computing divisors corresponding to the",
             "basis of the residues",time());
  pp:=poly(p,[x],AE); qq:=poly(q,[x],AE); pp0:=poly(p0,[x],AE);
/*
| Computation of divisors corresponding to each residue
*/
  H:=divtoresidues(pp,qq,pp0,g,residu,nbres,_y);
/*
| Computation of divisors corresponding to the basis of the residues.
*/
                DD:=construcdivi(pp,qq,pp0,g,H,M,nbres,x,_y);
                userinfo(1,"Divisors computed at time",time());
                userinfo(1,"Computing the order of divisors",time());
/*
| Computation of the orders of the divisors.
*/
                OO:=ordredivi(DD,pp0,g,M,x);
                userinfo(1,"Order of divisors computed",time());
/*
| Tests of principality and computation of the candidate for an antiderivative
| if all the divisors are of finite order.
*/
  if OO=hold(infini) then
    userinfo(1,"Not elementary, divisor of infinite order");
    return(hold(int)(p/q/SQRT(p0),x));
  end_if;
  for i from 1 to linalg::nrows(M) do
    d:=ntimesdivi(DD[i],OO[i],pp0,g,_y);
    if isprincipal(d) then f[i]:=op(d,3);
    else userinfo(1,"Divisor not principal");
      return(hold(int)(p/q/SQRT(p0),x));
    end_if
  end_for;
  F:=0;
  for i from 1 to linalg::nrows(M) do
    F:=F+subs(base[i]/OO[i]*ln(f[i]),
	      Z[i]=Zgen[i],Zgen[i]=root2sqrt(Zgen[i]))
  end_for;
  userinfo(3,"The computed function is",F);
/*
| Verification of the candidate.
*/
  V:=verif(p,q,p0,F,x,_y);
  if V=0 then
    userinfo(1,"Logarithmic part computed at",time());
    subs(F,_y=SQRT(p0));
  else
    userinfo(1,"Not elementary, the computed function is not".
	       "an\nantiderivative. There is a differential of the first".
	       " kind.");
    userinfo(1,"Logarithmic part computed at",time());
    subs(F,_y=SQRT(p0))-hold(int)(V,x);
  end_if;
end_proc:

// converts Root(Z^2-a) to sqrt(a) 
root2sqrt := proc(b) local p;
begin
   if type(b)="function" and op(b,0)=Root then
      p:=poly(op(b));
      if degree(p)=2 and coeff(p,1)=0 then return(sqrt(-coeff(p,0)/coeff(p,2)))
      end_if
   end_if;
   b
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Construction of divisors corresponding to the basis of the
|                 residues.
|
| Input :     p : The numerator of the differential: a univariate polynomial.
|             q : The denominator of the differential: a univariate squarefree
|                 polynomial.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             g : The genus of the curve.
|             H : A table containing the divisors corresponding to each residue.
|             M : The matrix of decomposition of the residues in the basis.
|         nbres : The number of residues.
|             x : The integration variable.
|             y : The variable representing RootOf(_Z^2-p0(x)).
|
| Output:       : A table containing the divisors corresponding to the basis
|                 of the residues.
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
*/

construcdivi:=proc(p,q,p0,g,H,M,nbres,x,_y) local i,j,DD;
begin
      userinfo(2,"Computation of divisors corresponding to the basis");
      for i from 1 to linalg::nrows(M) do
          DD[i]:=[p^0,p-p,1];
          for j from 1 to nbres do
              if M[i,j]=0 then
              else if sign(M[i,j])=1 then
                   DD[i]:=diviaddition2(DD[i],
                                  ntimesdivi(H[j],M[i,j],p0,g,_y),p0,g,_y);
                   else DD[i]:=diviaddition2(DD[i],ntimesdivi(
                              oppositedivi(H[j]),-M[i,j],p0,g,_y),p0,g,_y);
                   end_if;
              end_if;
          end_for;
      end_for;
      DD
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the sum of two divisors D1+D2.
|
| Input : D1,D2 : The two divisors to sum.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             g : The genus of the curve.
|             y : The variable representing RootOf(_Z^2-p0(x)).
|
| Output:       : The sum of the two divisors D1+D2. (reduced)
|
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
*/

diviaddition2:=proc(D1,D2,p0,g,_y)
local A1,B1,A2,B2,d0,d,h1,h2,h3,alpha0,beta0,alpha1,beta1,A,B,g1,g2;
begin
              A1 := op(D1,1); B1 := op(D1,2); g1 := op(D1,3);
              A2 := op(D2,1); B2 := op(D2,2); g2 := op(D2,3);
              d0:=gcdex(A1,A2); alpha0:=d0[2]; beta0:=d0[3]; d0:=d0[1];
              d:=gcdex(d0,B1+B2); alpha1:=d[2]; beta1:=d[3]; d:=d[1];
              h1:=alpha0*alpha1; h2:=alpha1*beta0; h3:=beta1;
              A:=divide(A1*A2,d^2,Quo);
              B:=divide(divide(h1*A1*B2+h2*A2*B1+h3*(B1*B2+p0),d,Quo),A,Rem);
              divireduction(A,B,g1*g2*expr(d),p0,g,_y);
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the sum of two divisors D1+D2 in the finite
|                 field at p (prime) elements.
|
| Input : D1,D2 : The two divisors to sum.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             g : The genus of the curve.
|             p : The prime defining the reduction.
|             x : The integration variable.
|
| Output:       : The sum of the two divisors D1+D2 in the finite field.
|
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
*/

diviaddition2mod:=proc(D1,D2,p0,g)
local A1,B1,h1,A2,B2,h2,d0,d,h3,alpha0,beta0,alpha1,beta1,A,B;
begin
              A1 := op(D1,1); B1 := op(D1,2);
              A2 := op(D2,1); B2 := op(D2,2);
              d0:=gcdex(A1,A2); alpha0:=d0[2]; beta0:=d0[3]; d0:=d0[1];
              d:=gcdex(d0,B1+B2); alpha1:=d[2]; beta1:=d[3]; d:=d[1];
              h1:=alpha0*alpha1; h2:=alpha1*beta0; h3:=beta1;
              A:=divide(A1*A2,d^2,Quo);
              B:=divide(divide(h1*A1*B2+h2*A2*B1+h3*(B1*B2+p0),d,Quo),A,Rem);
              divireductionmod(A,B,p0,g)
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the reduced representative of a semi-reduced
|                 divisor.
|
| Input :     DD : The divisor to reduce.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             g : The genus of the curve.
|             y : The variable representing RootOf(_Z^2-p0(x)).
|
| Output:       : The reduced representative of DD.
|
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
|                 DD is reduced if deg(A)<=g.
*/

divireduction:=proc(A,B,h,p0,g,_y)
begin
               h:=expr(h);
               while degree(A)>g do
                     A:=divide(p0-B^2,A,Quo);
                     h:=h*(expr(B)-_y)/expr(A);
                     B:=divide(-B,A,Rem);
               end_while;
               [A,B,h]
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the reduced representative of a semi-reduced
|                 divisor in the finite field of p (prime) elements.
|
| Input :     DD : The divisor to reduce.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             g : The genus of the curve.
|             p : The prime defining the reduction.
|             x : The integration variable.
|
| Output:       : The reduced representative of DD in the finite field.
|
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
|                 DD is reduced if deg(A)<=g.
*/

divireductionmod:=proc(A,B,p0,g)
begin
   while degree(A)>g do
      A:=divide(p0-B^2,A,Quo);
      B:=divide(-B,A,Rem);
   end_while;
   [A,B]
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Construction of the divisor corresponding to a residue.
|
| Input :     p : The numerator of the differential: a univariate polynomial.
|             q : The denominator of the differential: a univariate squarefree
|                 polynomial.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             g : The genus of the curve.
|             r : A residue.
|             y : The variable representing RootOf(_Z^2-p0(x)).
|
| Output:       : The reduced divisor corresponding to the residue r.
|
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
*/

divtoresidue:=proc(p,q,p0,g,r,_y) local A,B,qprime;
begin
          userinfo(3,"Computation of the divisor corresponding to a residue");
          qprime:=polylib::Dpoly(q);
          A:=gcdex(q,p^2-multcoeffs(qprime,r)^2*p0)[1];
          gcdex(qprime,A);
          B:=divide(multcoeffs(p*%[2],1/r),A,Rem);
          divireduction(A,B,1,p0,g,_y)
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Construction of divisors corresponding to a table of
|                 residues.
|
| Input :     p : The numerator of the differential: a univariate polynomial.
|             q : The denominator of the differential: a univariate squarefree
|                 polynomial.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             g : The genus of the curve.
|       residus : A table of residues.
|          nbre : The number of residues.
|             y : The variable representing RootOf(_Z^2-p0(x)).
|
| Output:       : A table containing the divisors corresponding to the table of
|                 residues.
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
|
|Computes the divisors corresponding to a table of residues (residus).
*/

divtoresidues:=proc(p,q,p0,g,residus,nbre,_y) local i,H;
begin
  userinfo(3,"Computation of divisors corresponding to each residue.");
  for i from 1 to nbre do
      H[i]:=divtoresidue(p,q,p0,g,residus[i],_y);
  end_for;
  H;
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the first p with good reduction after prime1.
|
| Input :     d : A divisor.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|          pol : The defining polynomial of the RootOf defining the ground
|                 field.
|        prime1 : A prime.
|             x : The integration variable.
|
| Output:     i : The first p with good reduction after prime1.
|       newpoly : The defining polynomial of the new RootOf defining the ground
|                 field modulo i.
*/

/* AE=Expr ==> IntegerMod(i)
  AE=AlgebraicExtension(x,p) ==> AlgebraicExtension(AlgExt(x,i),p) */
AlgExt:=proc(AE,i) option remember; local r,p; begin
   if AE=Expr or AE=Dom::Rational then Dom::IntegerMod(i)
   else
      r:=AlgExt(AE::groundField,i);
      p:=AE::minpoly; // defining polynomial 
      Dom::AlgebraicExtension(r,poly(p,op(p,2),r))
   end_if
end_proc:

goodprime:=proc(d,p0,pol,prime1,x)
local i,a,q,b,boo,newpoly,factorlist,fac,p0i,ai,qi,AE;
begin
           userinfo(1,"Looking for a good prime.");
           i:=prime1;
           a:=op(d,1); b:=op(d,2);
           if degree(a)=0 then [i,pol]
           else
           q:=p0-b^2;
/*
| Tests for good reduction.
*/
           while iszero(divide(q,a,Rem)) do q:=divide(q,a,Quo) end_while;
           repeat
              userinfo(3,"trying prime number",i);
	      if traperror((AE:=AlgExt(op(p0,3),i);
			p0i:=poly(p0,[x],AE);
			ai:=poly(a,[x],AE);
			qi:=poly(q,[x],AE)))=0 then
                 if (polylib::lcoeff(p0i)<>AE::zero) and (polylib::lcoeff(ai)<>AE::zero) and
		    (degree(gcd(p0i,polylib::Dpoly(p0i)))=0) and (degree(gcd(ai,qi))=0)
                 then break end_if
              end_if;
              i:=nextprime(i+1);
              if i>1000 then error("prime limit exceeded") end_if;
           until FALSE end_repeat;
/*
| Computation of defining polynomial of the new RootOf, when the previous is
| not irreducible modulo i.
*/
           if iszero(pol) then [i,pol]
           else
           newpoly:=poly(pol,IntMod(i));
           // no irreducibility test other than factor in MuPAD 
           factorlist:=factor(newpoly);
           factorlist:= Factored::convert_to(factorlist,DOM_LIST);
           boo:=bool(nops(factorlist)<=3);
           if boo=FALSE then
              newpoly:=factorlist[2];
              factorlist:=[factorlist[2*a]$ a=2..nops(factorlist) div 2];
              for fac in factorlist do
                 if degree(fac)<degree(newpoly) then newpoly:=fac end_if;
              end_for;
           end_if; // irreducibility test. 
           [i,expr(newpoly)]
           end_if; // test on poly. 
           end_if; // test on degree(a). 
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the divisor equal to n-times a given divisor DD.
|
| Input :     DD : The given divisor.
|             n : A positive integer.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             g : The genus of the curve.
|             y : The variable representing RootOf(_Z^2-p0(x)).
|
| Output:       : The reduced representative of the divisor nD.
|
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
|                 DD is reduced if deg(A)<=g.
*/

ntimesdivi:=proc(DD,n,p0,g,_y) local i,D1;
begin
    D1:=[p0^0,p0-p0,1];
    for i from 1 to n do
        D1:=diviaddition2(DD,D1,p0,g,_y);
    end_for;
    D1;
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the negative of a divisor DD.
|
| Input :     DD : The given divisor.
|
| Output:       : The divisor -DD.
|
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
|                 DD is reduced if deg(A)<=g.
*/

oppositedivi:=proc(DD) local A,B,h;
begin
    A := op(DD,1);
    B := op(DD,2);
    h := op(DD,3);
    [A,-B,1/h/expr(A)];
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the orders of a table of divisors.
|
| Input :     DD : A table of divisors.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             g : The genus of the curve.
|             x : The integration variable.
|
| Output:       : The table of the orders of the divisors when they all are of
|                 finite order, hold(infini) if there exists a divisor of infinite
|                 order.
|
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
|                 DD is reduced if deg(A)<=g.
*/

ordredivi:=proc(DD,p0,g,M,x)
local i,d,j,k,p1,p2,o1,o2,OO,a,b,rof,pol,newpoly1,newpoly2,d1,d2,R1,R2;
begin
           userinfo(2,"Computation of the orders of the divisors");
           for i from 1 to linalg::nrows(M) do
                 a:=op(DD[i],1); b:=op(DD[i],2); d:=[a,b];
/*
| Searching for the RootOf defining the ground field and computation of a
| primitive element (No code available for imbricated RootOf modulo p).
*/
                 rof:=op(a,3);
                 if rof=Expr then pol:=0
                 else pol:=expr(rof::minpoly)
                 end_if;
/*
| Computation of a good prime.
*/
                 p1:=goodprime(d,p0,pol,3,x);
                 newpoly1:=op(p1,2); p1:=op(p1,1);
                 userinfo(3,"Good prime :",p1);
/*
| Computation of a second good prime.
*/
                 p2:=goodprime(d,p0,pol,nextprime(p1+1),x);
                 newpoly2:=op(p2,2); p2:=op(p2,1);
                 userinfo(3,"Good prime :",p2);
                 // d1:=d; d2:=d; 
		 R1:=AlgExt(rof,p1); R2:=AlgExt(rof,p2);
                 d1:=map(d,poly,[x],R1); d2:=map(d,poly,[x],R2);
/*
| Substitution of RootOfs when they are reducible modulo p1 or p2 and
| computation of the orders of the divisor in the finite fields defined by p1
| and p2.
*/
                 if degree(newpoly1)<degree(pol) then
                    d1:=subs(d1,RootOf(pol)=RootOf(newpoly1)); // evala 
                 end_if;
                 o1:=ordredivimod(d1,p0,g);
                 userinfo(2,"Order =",o1,"modulo",p1);
                 if degree(newpoly2)<degree(pol) then
                    d2:=subs(d2,RootOf(pol)=RootOf(newpoly2)); // evala 
                 end_if;
                 o2:=ordredivimod(d2,p0,g);
                 userinfo(2,"Order =",o2,"modulo",p2);
/*
| Verification of compatibility of the two orders modulo p1 and p2.
*/
                 k:=0;
                 while gcd(o1,p2)=p2 do
                                     o1:=o1/p2;
                                     k:=k+1
                 end_while;
                 j:=0;
                 while gcd(o2,p1)=p1 do
                                     o2:=o2/p1;
                                     j:=j+1
                 end_while;
                if o1<>o2 then return(hold(infini));
                          userinfo(2,"Infinite order.");
                else OO[i]:=o1*p1^j*p2^k
                end_if;
                userinfo(2,"The order must be ",OO[i]);
             end_for;
             OO
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the order of a divisor in a finite field.
|
| Input :     DD : A  divisor.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             g : The genus of the curve.
|
| Output:       : The order of the divisor in the finite field.
|
| Representation: A divisor DD=sum(n_iP_i) -sum(n_i)P_infinity + div(h)
|                 is represented by [A,B,h] where A(x)=sum(x-x_i),
|                 deg(B(x))<deg(A(x)) and valuation_P_i(y-B)>=n_i.
|                 DD is reduced if deg(A)<=g.
*/

ordredivimod:=proc(DD,p0,g) local i,D0;
begin
      userinfo(1,"Computation of the order of a divisor in",op(DD[1],3));
      i:=1;
      D0:=DD;
      p0:=poly(p0,op(DD[1],2..3));
      while not isprincipal(D0) do
            userinfo(3,"Power",i);
            D0:=diviaddition2mod(D0,DD,p0,g);
            i:=i+1;
            userinfo(3,"DD^",i,"=",D0);
      end_while;
      i;
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the polynomial whose roots are the residues.
|
| Input :     p : The numerator of the differential: a univariate polynomial.
|             q : The denominator of the differential: a univariate squarefree
|                 polynomial.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             x : The integration variable.
|             z : The indeterminate of the polynomial.
|
| Output:       : The polynomial whose roots are the residues.
*/

polyresidues1:=proc(p,q,p0,x,z) local _y;
begin
  _y:=genident("_y");	 
  userinfo(1,"Computation of the polynomial for the residues.");
  polylib::resultant(polylib::resultant(z*_y*diff(q,x)-p,_y^2-p0,_y),q,x);
end_proc:

/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Computation of the basis of the residues.
|
| Input :     R1: The polynomial for the residues.
|             z : The indeterminate of the polynomial.
|        ground : A set of RootOf defining the ground field.
|
| Output:       : a matrix S where S[i,j] is the i-th coefficients of
|                 the j-th residue in the basis Zbasis.
|        Zbasis : a basis of the Z-module generated by the roots of R
|          mult : a list containing the multiplicities of the residues.
|
| Note  : R1 must be a polynomial with rational coefficients.
*/

resbasis := proc(R1,z)
local R,M,N,T,Zbasis,c,c1,i,j,m,n,t,coord,den,fl,Zgenerators,newm,
      residue,rofs,num,mult;
begin
   if degree(R1,z) = 0 then
      error("degree should be positive");
   elif not testtype(R1,Type::PolyExpr(z,Type::Rational)) then
	// should be algnum instead of Type::Rational above 
      return([FAIL,Zbasis,mult]); // not implemented yet 
   end_if;
   R := normal(R1/z^ldegree(R1,z));
   userinfo(2,"computing a splitting field at time", time());
   userinfo(3,"polynomial has degree",degree(R,z));
   fl := Afactor(R);
   userinfo(3,"splitting field computed at time", time());
   n := nops(fl) div 2;
   mult := [fl[2*i+1] $ i=1..n];
   fl := [fl[2*i] $ i=1..n];
   fl := subs(fl,I=hold(_power)(-1,1/2));
   userinfo(3, "number of distinct residues",n);
   rofs := select([op(misc::subExpressions(fl,"function"))],()->op(args(1),0)=Root);
   T := table();
   for i from 1 to n do
      // fail if the factorization is not complete 
      if degree(fl[i],z)<>1 then error("absolute factorization failed") end_if;
      residue := -coeff(fl[i],z,0)/coeff(fl[i],z,1); 
     c := rationalize([residue,rofs],{"_plus","_mult","_power",DOM_LIST});
      c1 := subs(coeffs2(op(c[1])),c[2]);
      c := c1[1];
      t := c1[2];
      for j from 1 to nops(c) do
         if type(T[t[j]])="_index" then
            T[t[j]] := array(1..n,[0$n]);
         end_if;
         T[t[j]][i] := c[j];
      end_for;
   end_for;
/*
| Convert to matrices.
*/
   Zgenerators := Dom::/*Dense*/Matrix()(map([op(T)],()->[op(args(1),1)]));
   coord := map(map([op(T)],op,2),proc() begin [op(args(1))] end_proc );
   M := Dom::/*Dense*/Matrix()(coord);
   m := linalg::nrows(Zgenerators);
/*
| Remove the lcm of the denominators (integer) and the gcd
| of the numerators.
*/
   for i from 1 to m do
      den := ilcm(denom(M[i,j]) $ j=1..n);
      num := igcd(numer(M[i,j]) $ j=1..n);
      for j from 1 to n do M[i,j] := M[i,j] * den / num end_for;
      Zgenerators[i,1] := Zgenerators[i,1] * num / den;
   end_for;
   M := linalg::concatMatrix(M,M::dom::identity(m,m));
   M := linalg::hermiteForm(M); // ihermite(M); 
   N := 1/M[1..m,n+1..n+m];
   N := linalg::transpose(N);
   newm := linalg::rank(M[1..m,1..n]);
   M := M[1..newm,1..n];
   N := N[1..newm,1..m];
   Zbasis := N * Zgenerators;
/*
| Simplify
*/
   for i from 1 to newm do
      num := igcd(numer(M[i,j]) $ j=1..n);
      for j from 1 to n do M[i,j] := M[i,j] / num end_for;
      Zbasis[i] := Zbasis[i] * num;
   end_for;
   [M,Zbasis,mult]
end_proc:


coeffs2 := proc(residue, rofs) local i,n;
begin
   if rofs=[] then return([[residue],[1]]) end_if;
   residue:=poly(residue,rofs);
   n:=nterms(residue);
   [[nthcoeff(residue,i)$i=1..n],[expr(nthterm(residue,i))$i=1..n]]
end_proc:


/*------------------------------------------------------------------------------
| SYNOPSIS :    : Computation of indefinite hyperelliptic integrals.
|                 Verification for the computed function to be an
|  		  antiderivative
|
| Input :     p : The numerator of the differential: a univariate polynomial.
|             q : The denominator of the differential: a univariate squarefree
|                 polynomial.
|            p0 : The defining polynomial of the curve: a squarefree univariate
|                 polynomial of odd degree prime to q.
|             F : The computed function.
|             x : The integration variable.
|             y : The variable representing RootOf(_Z^2-p0(x)).
|
| Output:       : The difference between the derivative of the computed
|                 function and the initial function.
*/

verif:=proc(p,q,p0,F,x,_y) local F1,DF1;
begin
       userinfo(3,"Verification of the computed function");
       F1:=subs(F,_y=SQRT(p0));
       DF1:=diff(F1,x);
       normal(simplify(normal(DF1-p/q/SQRT(p0))))
end_proc:

// absolute factorization 
Afactor := proc(f) local l,i,r;
begin
   l := factor(f);
   l := Factored::convert_to(l,DOM_LIST);
   for i from nops(l) div 2 downto 1 do
      r:=Afactor1(l[2*i],l[2*i+1]);
      delete l[2*i+1];
      l[1]:=l[1]*r[1];
      l[2*i]:=op(r,2..nops(r));
   end_for;
   l
end_proc:

Afactor1 := proc(f,m) local x,a,b,c,r,d,i,s;
// Walter: 4.2.02
// Ouch: I am not at all sure that Winfried really wants
//       a _global_k here. This global dyn. scoping variable
//       competes with _global_k in other parts of intlib!!
save _global_k,_Z;
begin
   delete _global_k,_Z;
   x:=indets(f);
   if nops(x)=1 then
      x:=op(x,1);
      case degree(f,x)
      of 1 do a:=coeff(f,x,1); return([a^m,f/a,m]);
      of 2 do a:=coeff(f,x,2); b:=coeff(f,x,1)/a; c:=coeff(f,x,0)/a;
              if type(c)=DOM_RAT then
                 d:=stdlib::ifactor(op(c,2));
                 d:=_mult(d[2*i]^((d[2*i+1]+1) div 2)$i=1..nops(d) div 2);
              else d:=1 end_if;
              if contains({DOM_INT,DOM_RAT},type(c)) then
                 _global_k:=stdlib::ifactor(op(c,1));
                 _global_k:=_mult(_global_k[2*i]^(_global_k[2*i+1] div 2)$i=1..nops(_global_k) div 2);
                 d:=d/_global_k
              end_if;
              // if Z=Y/d then Z^2+b*Z+c=1/d^2*(Y^2+b*d*Y+d^2*c) 
       	      r:=Root(_Z^2+b*d*_Z+c*d^2)/d; return([a^m,x-r,m,x+b+r,m])
      of 4 do if coeff(f,x,3)=0 and coeff(f,x,1)=0 then
                 a:=coeff(f,x,4); b:=coeff(f,x,2)/a; c:=coeff(f,x,0)/a;
                 // try x1,-x1,x1+_global_k*x1^3,-x1-_global_k*x1^3 as roots 
                 d:=numer(4*c-8*b*c*_global_k-b^2+2*b^3*_global_k-b^4*_global_k^2+c^3*_global_k^4+5*b^2*c*_global_k^2
			-2*b*c^2*_global_k^3);
                 d:=select(solve(d,_global_k),testtype,Type::Union(DOM_INT,DOM_RAT));
                 r:=Root(numer(_Z^4+b*_Z^2+c));
                 if nops(d)<>0 then
                    _global_k:=op(d,1);
                    return([a^m,x-r,m,x+r,m,x-r-_global_k*r^3,m,x+r+_global_k*r^3,m])
                 else
                    s:=Root(_Z^2+r^2+b);
                    return([a^m,x-r,m,x+r,m,x-s,m,x+s,m])
                 end_if
              end_if;
      otherwise error("degree too large: ".expr2text(f))
      end_case
   else error("only for univariate polynomials")
   end_if
end_proc:


