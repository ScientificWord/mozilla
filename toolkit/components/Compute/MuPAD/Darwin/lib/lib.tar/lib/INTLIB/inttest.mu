// $Date: 2002-02-04 09:57:56 +0100 (Mon, 04 Feb 2002) $ $Author: walter $ $Revision: 17096 $ 
/*--
intlib::inttest(i,j) -- tests if it is possible to express i as l*h+r'/r where l is a positiv integer, r is in _global_k[j-1] and h=_global_k_diff[j]. It delivers l,r or FAIL.
--*/
intlib::inttest:=proc(i,j)
  local n;
// global   _global_k,_global_k_sub,_global_k_ident,_global_k_diff,_global_k_deg,_global_k_alg,_global_Q,_global_Q_sub; 
begin
  i:=intlib::intt(i,j-1);
  if i=FAIL then return(FAIL); end_if;
  n:=nops(_global_k);
  i:=intlib::tower(exp(i));
  if indets(i) minus {_global_k_sub[n]$ n=1..j} minus {op(_global_Q_sub)} <>{}
    then return(FAIL);
  end_if;
  i:=poly(i,[_global_k_sub[j]]);
  if i=FAIL then return(FAIL); end_if;
  if nterms(i)<>1 then return(FAIL); end_if;
  return(degree(i),nthcoeff(i,1));
end_proc:
