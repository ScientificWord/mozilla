// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ #

// NonNegRat -- expression to test for non-negative rationals

Type::NonNegRat:=
    new(property::NRange,
	"NonNegRat",
	proc(t,x) 
	  name Type::NonNegRat;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_INT, DOM_RAT}, domtype(x)) then
		return(bool(x >= 0))
	    end_if;
	    FAIL
	end_proc,
	FALSE, FALSE,
	["NonNegRat", property::Null]):
