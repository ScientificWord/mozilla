// $Id: bitmap.mu 22501 2003-04-04 13:25:02Z ccr $

// load the bitmap module and put it under stdlib::bitmap
  proc()
    save bitmap;
  begin
    sysdelete(bitmap);
    if traperror(module("bitmap")) <> 0 then
      sysassign(stdlib::bitmap, FAIL);
    else
      sysassign(stdlib::bitmap, bitmap);
    end_if;
  end_proc():
  
