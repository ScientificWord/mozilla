/*--
	log/simplify -- the function attribut "simplify" for log
        Analogous to ln::simplify.

	Rules (take properties into account):

	1) log(b, posint1/posint2 * r )  -->  log(b,posint1) - log(b,posint2) + log(b,r)
	2) log(b, exp(real) * r )        -->  real/ln(b) + log(b,r)
        3) log(b, positive^real * r )    -->  real*log(b,positive) + log(b,r)
           log(b, negative^even * r )    -->  even*log(b,-negative) + log(b,r)
           log(b, negative^odd  * r )    -->   odd*log(b,-negative) + log(b,-r)
        4) log(b, positive * r )         -->  log(b,positive) + log(b,r)
           log(b, negative * r )         -->  log(b,-negative) + log(b,-r)

        5) log(b, y^n )                  -->  n*log(b,y) if
                                              y = b and -PI < Im(n) <= PI or
                                              -1 < n <= 1 or
                                              n = -1 and is(y <= 0) = FALSE
                                              or -2 <= n <= 2 and Re(y) > 0
        6) log(b, exp(z) )               -->  z/ln(b) if -PI < Im(z) <= PI

        The ideology is to have only positive arguments in log's where
        possible.
--*/

log := slot(log, "simplify", proc(x: "log")
  name log::simplify;
  local l, t, r, k, y, n, z, b;
begin

  // recursively simplify the arguments of log
  b := simplify(op(x, 1));
  l := simplify(op(x, 2));
  
  // convert the result into a list of factors
  if type(l) = "_mult" then
    l := [op(l)];
  else
    l := [l];
  end_if;

  // determine all factors that are recognized as positive or negative by "is"
  l := split(l, proc(a) begin
      is(a > 0) or is(a < 0)
  end_proc);

  r := op(l[2])*op(l[3]);
  l := l[1];
  // now x = log(b,_mult(op(l)) * r), and every element of l "is" either >0 or <0

  // handle positive or negative factors
  k := 0;
  for t in l do
    case type(t)

    of DOM_RAT do // rule 1)
      // log(b,numer/denom) = log(b,numer) - log(b,denom)
      if t < 0 then
        t := -t;
        r := -r;
      end_if;
      k := k + log(b,op(t, 1)) - log(b,op(t, 2));
      break;

    of "exp" do // rule 2)
      if is(op(t), Type::Real) = TRUE then
	// t "is" positive and ln(t) = op(t)
        k := k + op(t)/ln(b);
      else
        r := r * t;
      end_if;
      break;

    of "_power" do // rule 3)
      [y, n] := [op(t)];
      if is(y > 0) = TRUE then
        // log(b,y^n * r) = n*log(b,y) + log(b,r) if y > 0 and n is real
        if is(n, Type::Real) = TRUE then
          k := k + n*log(b,y);
        else
          r := r * t;
        end_if;
      elif is(y < 0) = TRUE then
        // log(b,y^n * r) = n*log(b,-y) + log(b,r) if y < 0 and n is even
        // log(b,y^n * r) = n*log(b,-y) + log(b,-r) if y < 0 and n is odd
	if is(n, Type::Even) = TRUE then
	  k := k + n*log(b,-y);
        elif is(n, Type::Odd) = TRUE then
	  k := k + n*log(b,-y);
          r := -r;
        else
          r := r * t;
        end_if;
      else
        r := r * t;
      end_if;
      break;
      
    otherwise // rule 4)
      if is(t < 0) = TRUE then
        t := -t;
        r := -r;
      end_if;
      k := k + log(b,t);

    end_case;
  end_for;
  // now x = k + log(b,r)

  // handle the remainder log(b,r)
  case type(r)

  of "_power" do // rule 5
    [y, n] := [op(r)];
    /* log(b,y^n)=n*log(b,y) when -1< n <=1
       and for n = -1 if y is not real nonpositive
       and for -2 <= n <= 2 if Re(y) > 0
       and for -PI < Im(n) <= PI if y = b
    */
    if (is(-1 < n) = TRUE and is(n <= 1) = TRUE) or
       (is(n = -1) = TRUE and is(y <= 0) = FALSE) or
       (is(-2 <= n) = TRUE and is(n <= 2) = TRUE and is(Re(y) > 0) = TRUE) or
       (y = b and is(-PI < Im(n)) = TRUE and is(Im(n) <= PI) = TRUE) then
       return(k + n*log(b,y));
    end_if;
    break;

  of "exp" do // rule 6
    // log(b, exp(z)) = z/ln(b) if -PI < Im z <= PI
    z := op(r);
    if (is(Im(z) > -PI) = TRUE and is(Im(z) <= PI) = TRUE) or
       contains({-1, 0, 1}, sign(z)) then
      return(k + z/ln(b));
    end_if;

  end_case;

  return(k + log(b,r));

end_proc):

// old code, now obsolete, to be removed

// log := slot (log, "simplify",
( proc(x:"log")
//    name log::simplify;
    local b, i, t, k, _y, _x;
 begin
   b := op(x,1);
   _x:= op(x,2); 
   case type(_x)
     of DOM_RAT do
       return(log(b,op(_x,1))-log(b,op(_x,2)))
     of "_power" do
	/* log(b, x^n)=n*log(b, x) if
	   1) x is real nonnegative or
           2) -1<n<1 or 
	   3) n=-1 and x is not real nonnegative 
	*/
       if (is(op(_x,1)>=0)=TRUE and is(op(_x,2), Type::Real)=TRUE) or
          (is(-1<op(_x,2))=TRUE and is(op(_x,2)<1)=TRUE) or 
          (bool(op(_x,2)=-1) and is(op(_x,1)<0)=FALSE)
         then
         return(simplify(op(_x,2)) *
                simplify(log(b, simplify(op(_x,1)))));
       end_if;
      break
   of "_mult"  do
      t:=simplify(_x);
      if type(t)="_mult" then
	    // CAUTION: log(b, x*y) is not always log(b, x)+log(b, y),for example 
	    // if x=y=-1, log(b, x*y)=0 but log(b, x)+log(b, y)=2*I*PI/ln(b) 
            k:=1; for _y in t do
               if   is(_y>0)=TRUE then k:=k*_y; t:=t/_y
               elif is(_y<0)=TRUE then k:=k*(-_y); t:=t/(-_y)
               end_if
            end_for;
            if type(k)="_mult" then k:=op(k) end_if;
            return( _plus( log(b,t), simplify(log(b,i)) $ i in [k] ) )
       elif t <> _x then
            return( simplify(log(b,t)) )
       else return( x )
       end_if;
       break    
 end_case;

 t:= simplify(_x);
 if t <> _x
 then t:= log(b, t);
      if type(t) = "log"
      then return(slot(log,"simplify")(b,t))
      else return(t)
      end_if
 else return(x)
 end_if
end_proc):
