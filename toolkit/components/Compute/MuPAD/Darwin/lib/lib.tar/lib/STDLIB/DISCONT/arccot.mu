
genident("z"):
arccot::complexDiscont:=
              Dom::ImageSet(%*I, %, Dom::Interval([-1, 1])):


