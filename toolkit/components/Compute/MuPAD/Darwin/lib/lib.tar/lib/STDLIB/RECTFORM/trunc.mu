
trunc::rectform:=
proc(x)
begin
  new(rectform, op(map([extop(rectform(x))], trunc)))
end_proc:
  