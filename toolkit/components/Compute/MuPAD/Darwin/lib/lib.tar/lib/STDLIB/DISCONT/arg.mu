arg::complexDiscont := Dom::Interval(-infinity, [0]):
