// $Date: 2002-11-20 10:19:24 +0100 (Wed, 20 Nov 2002) $ $Author: tonner $ $Revision: 20965 $

// This has been placed into an extra file because loading Dom::Interval
// causes problems when testing the kernel (kg).

ln::complexDiscont:= Dom::Interval(-infinity, [0]):
