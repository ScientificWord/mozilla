//alias(_pattern = intlib::_pattern): geht nicht!

intlib::lookuparcsinh:=proc(f) save a,g,b;
begin
   delete a,g,b;
   case type(f) of "_mult" do
      if intlib::matchassign(f,_pattern(g)*arcsinh(_pattern(a,not has,_X)*
	_X^_pattern(b,not has,_X))) then return((
         if g=_X and b=1 then (1/4/a^2/_X+_X/2)*f-_X/4/a*(a^2*_X^2+1)^(1/2)
         elif g=_X and b=-1 then _X/2*(f+a*(1+a^2/_X^2)^(1/2))
         else FAIL end_if))
      end_if;
      break;
   of "arcsinh" do
      return((if not has((a:=op(f,1)/_X),_X) then _X*f-(a^2*_X^2+1)^(1/2)/a
      elif not has((a:=op(f)*_X),_X) then _X*f+a*arctanh((1+a^2/_X^2)^(-1/2))
      else FAIL end_if))
   end_case;
   FAIL
end_proc:
