// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	gamma/rectform -- the function attribut "rectform" for gamma
--*/

gamma:= slot( gamma, "rectform", proc(xx)
        local a, x;
    begin
        x:= rectform::new(xx);

        if extop(x,3) <> 0 or not iszero(extop(x,2)) then
            new(rectform,0,0,hold(gamma)(rectform::expr(x)))
        else
            a:= extop(x,1);
            if domtype(a) = DOM_FLOAT then
                rectform::new(gamma(a))
            else
                new(rectform,gamma(a),0,0)
            end_if
        end_if
    end_proc
):

// end of file 
