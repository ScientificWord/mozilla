// $Date: 2006-03-13 14:17:14 +0100 (Mon, 13 Mar 2006) $ $Author: stefanw $ $Revision: 37638 $ 

/*--
	simplify::log -- the function attribut "log" for simplify
--*/

simplify::log:=
proc(a)
  name simplify::log;
begin
  case type(a)
    of "log" do
      slot( log,"simplify" )(a);
      break
    of "_plus" do
      combine(a, log);
      break
    otherwise
      a
  end_case
end_proc:

// end of file 
