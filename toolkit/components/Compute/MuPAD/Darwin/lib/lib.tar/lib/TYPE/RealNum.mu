// $Date: 2004-02-10 14:51:40 +0100 (Tue, 10 Feb 2004) $  $Author: ccr $  $Revision: 26510 $ #

//Real -- expression to test for real numbers

Type::Real:=
    new(property::NRange,
	"Real",
	proc(t,x)
	  name Type::Real;
	  option noDebug;
	begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_INT, DOM_RAT, DOM_FLOAT}, domtype(x)) then
		TRUE
	    else
		FAIL
	    end_if;
	end_proc,
	FALSE, FALSE,
	["Real", property::Null]):
