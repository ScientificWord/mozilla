// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 
/*--
intlib::pdioe(A,B,C) - solves the polynomial diophantine equation S*A+T*B=C for 
gcd(A,B)=1 and delivers S,T as a sequence, so that deg(S)<deg(B).
K.O. Geddes, Algorithms for Computer Algebra, Theorem 2.6.
It is often used to construct a partial fraction decomposition of 
C/(A*B)=S/B+T/A.
--*/
intlib::pdioe:=proc(A,B,C)
  local S,T;
begin
  T:=gcdex(A,B); // instead of intlib::gcdex 
  S:=divide(T[2]*C,B);
  return(intlib::sim(S[2],T[3]*C+S[1]*A));
end_proc:
