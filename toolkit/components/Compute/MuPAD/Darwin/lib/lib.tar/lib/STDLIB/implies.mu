/// implies
_implies:= funcenv
(proc(x, y)
   name _implies;
 begin
   if args(0)<>2 then
     error("Wrong number of args")
   end_if;
   if {x, y} intersect {TRUE, FALSE} <> {} then
     (not x) or y
   else  
     procname(args())
   end_if
 end_proc,
 builtin(1100, 75, " ==> ", "_implies" )):
// do not touch the priority; has to be consistent with the
// MuPAD parser and output::Priority (Typesetting)

_implies::type  := "_implies":
_implies::print := "_implies":

_implies::bool :=
proc(x, y)
begin
  bool((not x) or y)
end_proc:

_implies::float:= (x, y) -> hold(_implies)(float(x), float(y)):

_implies::TeX := 
  (arg1, arg2, arg3) -> generate::TeXoperator(" \\Longrightarrow ",
                                              arg3, output::Priority::Implies,
                                              op(arg2)):

_implies::Content := (Out, data) ->
                     Out::Capply(Out::Cimplies, map(op(data), Out)):




