

/*
 solvelib::splitVectorSet(S)

 express S as S1 x ... x Sn, where the S_i are one-dimensional sets
 returns([S1, ..., Sn]) or FAIL

*/


solvelib::splitVectorSet:=
proc(S)
begin
  case type(S)
    of "cartesianProduct" do
      return([op(S)])
    of solvelib::VectorImageSet do
      if nops(expr(S)) = 1 then
        return([Dom::ImageSet(op(expr(S), 1), S::dom::variables(S),
                              S::dom::sets(S))])
      else
        return(FAIL)
      end_if  
  end_case;
  FAIL
end_proc: