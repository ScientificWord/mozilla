// $Id: approx.mu 38703 2006-04-28 07:13:08Z walter $

_approx := funcenv(() -> procname(args()),
		   builtin(1100, 400, " ~= ", "_approx")):

_approx::Content := (Out, data) -> Out::Capply(Out::Capprox, map(op(data), Out)):

_approx::type := "_approx":

_approx::bool :=
proc(a,b)
local fa, fb;
begin
  fa := float(a);
  fb := float(b);
  if {domtype(fa), domtype(fb)} minus {DOM_FLOAT, DOM_COMPLEX} <> {} then
    return(UNKNOWN);
  end;
  if iszero(fa) then
    return(bool(specfunc::abs(fb)<10^(-DIGITS)));
  elif iszero(fb) then
    return(bool(specfunc::abs(fa)<10^(-DIGITS)));
  else
    // use exact arithmetic for computing (b-a)/a, then float!
    return(bool(specfunc::abs(float((b-a)/a))<10^(-DIGITS)));
  end;
end:
