
// Platzhalter. Funktion wird noch implementiert zur
// Codierung von (lokal definierten) Umkehrfunktionen  
// in MuPAD. 

stdlib::inverseFcn:= () -> args():


