// $Date: 2006-05-22 18:37:32 +0200 (Mon, 22 May 2006) $ $Author: stefanw $ $Revision: 39192 $ 

// frankp, 15.02.1995 

/*++
   combine.mu

	combine  --  combine terms of the same algebraic structure

	combine(expr) combines terms of the same algebraic
	structure.

	For expressions of type DOM_FUNC_ENV the function attribute
	"combine" will be called with the operands of expr.
	If such a function attribute does not exist the expression will
	be returned without changes.
++*/

combine :=
proc(e, p)
  local _t;
begin
    // is overloaded ? 
  if e::dom::combine <> FAIL then
    return( e::dom::combine(e,args(2..args(0))) )
  end_if;

  case args(0)
    of 1 do
      break
    of 2 do
      if type(p)=DOM_LIST then
        for _t in p do
          e:= combine(e,_t)
        end_for;
        return(e)
      elif traperror((p:=slot(combine,expr2text(args(2)))))=0 then
        if p <> FAIL then
           return(p(e))
        end_if:
        error("invalid second argument")
      else
        error("invalid second argument")
      end_if
    otherwise
      error("wrong no of args")
  end_case;

  case domtype(e)
    // default is to return e, thus we do not need to consider these cases 
    of DOM_POLY  do
      return( mapcoeffs(e,combine) )
    of DOM_LIST  do
    of DOM_ARRAY do
    of DOM_SET   do
      return( map(e,combine) )
    of DOM_EXPR  do
      _t:= op(e,0);
      if domtype(eval(%)) = DOM_FUNC_ENV and
        (p:= slot(eval(%), "combine")) <> FAIL then
        return( p(op(e)) )
      end_if;      
      return( map(e,combine) )
  end_case;
  e
end_proc:

combine:= funcenv(combine):
combine::print:= "combine":

// sqrt(a)*sqrt(b) ==> sqrt(a*b) 
combine:=slot(combine,"sqrt",
proc(e) 
name combine::sqrt;
local t,a,f,g,matchsqrt,n;
begin
   matchsqrt := proc(e) // matches sqrt(f) and returns f, or FAIL 
   begin
      if type(e)="_power" then if op(e,2)=1/2 then return(op(e,1)) end_if
      elif type(e)="sqrt" then return(op(e))
      end_if;
      FAIL
   end_proc;

   case type(e)
   of "_mult" do
      f:=1; g:=1; n:= 0;
      for t in e do
         if (a:=matchsqrt(t))<>FAIL then 
	    if is(a>0) = TRUE then n:= n+1 end_if;
	    f:=f*a 
	 else 
	    g:=g*t 
   	 end_if
      end_for;
      if n+1 >= nops(e) then return(f^(1/2)*g)
      else return( e )
      end_if
   of "_plus" do return(map(e,slot(combine,"sqrt")))
   otherwise e
   end_case;
end_proc):

// cos(x)^2 -> cos(2*x)/2+1/2 
combine:=slot(combine,"sincos",proc(ee)
name combine::sincos;
local l,k,f, e;
begin
   e:=ee; // to avoid warnings 
   case domtype(e) // default is to return e 
   of DOM_POLY	  do return( mapcoeffs(e,slot(combine,"sincos")) )
   of DOM_LIST    do 
   of DOM_ARRAY   do
   of DOM_SET     do return( map(e,slot(combine,"sincos")) )
   of DOM_EXPR    do
      case type(e)
      of "_mult" do e:=[op(e)]; break
      of "_power" do e:=[e]; break
      otherwise return(map(e,slot(combine,"sincos")))
      end_case;
      // now deal with _mult and _power case 
      k:=1; l:=[];
      for f in e do
         case type(f)
         of "sin" do
         of "cos" do l:=append(l,f); break
         of "_power" do
            if contains({"sin","cos"},type(op(f,1))) and testtype(op(f,2),Type::PosInt) then
               l:=append(l,op(f,1)$op(f,2)); break
            end_if
         otherwise k:=k*map(f,slot(combine,"sincos"))
         end_case;
      end_for;
      return(stdlib::combine_sin_cos(l,k))
   end_case;
   e
end_proc):

// k is a scalar, l is a list of sin or cos expressions 
stdlib::combine_sin_cos := proc(ll,kk)
local l, k;
begin
   l:=ll; k:=kk; // to avoid warnings 
   if l=[] then return(k) end_if;
   while nops(l)>=2 do
      if type(l[1])="_plus" then
         l[1]:=map(l[1],stdlib::combine_sincos,l[2])
      else l[1]:=stdlib::combine_sincos(l[1],l[2])
      end_if;
      delete l[2];
   end_while;
   if type(l[1])="_plus" then map(l[1],_mult,k) else k*l[1] end_if
end_proc:

// for x*y where x and y can be cos(..) or a*cos(..) or a where a is a rational 
stdlib::combine_sincos := proc(xx,yy) 
local a,b,m, x, y;
begin
   x:=xx; y:=yy;
   if type(x)="_mult" then x:=split(x,testtype,Type::Union("cos","sin"));
	m:=x[2]; x:=x[1]; else m:=1 end_if;
   if type(y)="_mult" then y:=split(y,testtype,Type::Union("cos","sin"));
	m:=m*y[2]; y:=y[1] end_if;
   a:=op(x); b:=op(y);
   case type(x),type(y)
   of "sin","sin" do m/2*cos(a-b)-m/2*cos(a+b); break
   of "sin","cos" do
     if stdlib::hasmsign(a-b) then
       m/2*sin(a+b)-m/2*sin(b-a)
     else
       m/2*sin(a+b)+m/2*sin(a-b)
     end_if;
     break
   of "cos","sin" do
     if stdlib::hasmsign(a-b) then
       m/2*sin(a+b)+m/2*sin(b-a)
     else
       m/2*sin(a+b)-m/2*sin(a-b)
     end_if;
     break
   of "cos","cos" do m/2*cos(a-b)+m/2*cos(a+b); break
   otherwise m*x*y /* it can happen that x or y is a constant, 
			for example cos(0) -> 1 for cos(t)^3 */
   end_case
end_proc:

// arctan(x)+arctan(y) = arctan((x+y)/(1-x*y)) if abs(x*y) < 1
// thus, if abs(x*y)>1 
combine::arctan:=
proc(e)
  name combine::arctan;
  local s,f,x,y,n, A, v, M: DOM_DOMAIN;
begin
  case domtype(e) // default is to return e
    of DOM_POLY	  do
      return( mapcoeffs(e,slot(combine,"arctan")) )
    of DOM_LIST    do
    of DOM_ARRAY   do
    of DOM_SET     do
      return( map(e,slot(combine,"arctan")) )
    of DOM_EXPR    do
      case type(e)
        of "_plus" do
          s:=0; x:=0;
          e:= map(e, x -> if type(x) = "_mult" then
                            combine::arctan(x)
                          else
                            x
                          end_if
                            );
          for f in e do
            if type(f)="arctan" then
              y:=op(f);
              if is(abs(x*y) < 1) = TRUE then
                x:=(x+y)/(1-x*y)
              elif is(x = 1/y) = TRUE then
                s:= s+ signIm(I*x) * PI/2;
                x:= 0
              elif is(abs(x*y) > 1) = TRUE then
/*
arctan(x) + arctan(y) = (sgn1 + sgn2)*PI/2 - arctan(1/x) - arctan(1/y)
where sgn1 = signIm(I*x), sgn2 = signIm(I*y)
since abs(1/x * 1/y) < 1, we may apply the aforementioned rule:
arctan(1/x) + arctan(1/y) = arctan((1/x + 1/y)/(1 - 1/x * 1/y))
                          = arctan((x+y)/(x*y-1))
                          = -arctan((x+y)/(1-x*y))
*/
                s:= s+ PI/2*(signIm(I*x)+signIm(I*y));
                x:=(x+y)/(1-x*y)
              else
                s:= s+f;
              end_if
            else
              s:= s+f
            end_if
          end_for;
          return(s+arctan(x))
        of "_mult" do
          if nops(e)=2 and type(op(e,1))="arctan" and
            type((n:=op(e,2)))=DOM_INT then
            if testtype((x:= op(e, [1, 1])), Type::Constant) then
            // let arctan(F(n)) := n*arctan(x)
            // then F(n) is a rational function in x, F= p/q
            // modulo PI, it satisfies the recursion formula
            // F(n+1) = (x + F(n))/(1 - xF(n))
            //        = (x + p/q) / (1 - xp/q)
            //        = (p + xq) / (-xp + q)
            // F(0)   = 0/1
            // thus [p(n), q(n)] = A^n * [0, 1] where A is the matrix
            // A = [[1, x], [-x, 1]]
            //
            // we do this for numerical x only, as we cannot find out
            // which multiple of PI we have to add otherwise 
            
              M:= Dom::Matrix(Dom::ExpressionField(normal, iszero));
              A:= M(2, 2, [[1, `#x`], [-`#x`, 1]]);
              v:= M(2, 1, [0, 1]);
              v:= A^specfunc::abs(n) * v;
              s:= hold(arctan)(subs(expr(v[1]/v[2]),
                                    `#x` = x*specfunc::sign(n)));
              f:= round((e-s)/PI);
              return(s + f*PI)
            elif n<0 then
              return(-n*hold(arctan)(-x))
            else
              return(e)
            end_if
          end_if;
          return(e)
        otherwise
          return(map(e,slot(combine,"arctan")))
      end_case
  end_case;
  e
end_proc:

/* exp(a)*exp(b) ==> exp(a+b) (universally valid)
   exp(a)^b      ==> exp(a*b) (if b in Z or -PI < Im(a) <= PI)
     reason: exp(a)^b = exp(b*ln(exp(a)))
*/
combine:=slot(combine,"exp",proc(e) 
name combine::exp;
local x;
begin
   case type(e)
   of "_plus" do 
   of "_mult" do
   of "_power" do 
      e:= map(e, combine::exp);
   end_case;

   case type(e)
   of "_mult" do
         x:=split(e,testtype,"exp");
         if type(x[1]) = "_mult" then
            return(x[2]*exp(_plus(map(op(x[1]),op))))
         end_if;
         break;
   of "_power" do 
         if type((x:=op(e,1)))="exp" then
            if is(op(e, 2), Type::Integer) = TRUE or
               is(-PI < Im(op(x)) <= PI) = TRUE then
                 return(exp(op(x)*op(e,2)))
            end_if;
         end_if;
   end_case;
   e
end_proc):

//-----------------------------------------------------------------------
// combine::ln(ee): handles the call combine(ee, ln). Tries to rewrite
// k*ln(a)+l*ln(b) ==> ln(a^k*b^l) whenever possible.
//
// Descends recursively into expressions of type +, *, ^, but not
// into arguments of other function calls. In particular, arguments
// of exp are not combined.
// Properties are taken into account.
//
// Implemented rules:
//
// k*ln(a) --> ln(a^k) if
// - k in R and a > 0
// - -2 <= k <= 2 and Re(a) > 0
// - -1 < k <= 1 or (k = 1 and not a < 0)
// This is done first.
//
// k*ln(a) + k*ln(b) --> k*ln(a*b) if a > 0 or b > 0
// k*ln(a) - k*ln(b) --> k*ln(a/b) if a > 0 or b > 0
//
// Not implemented: the latter two rules if Re(a) > 0 and Re(b) > 0
//
// Note:
// - 2*ln(x) + ln(4) will NOT be combined, except if is(x < 0) = TRUE
// - products of logarithms, such as ln(2)*ln(3), are not combined
//
// CHANGED (jngerhar) 04.03.01
//
combine := slot
(combine, "ln",
 proc(ee)
   name combine::ln;
   local e, l, r, kn, ks, selectFirst, s,
         k, split_product, arguments1, arguments2, positiveArguments;
 begin

   // shortcut: do nothing if there are no logarithms
   if not has(ee, ln) then
     return(ee);
   end_if;

   // recursively combine all operands
   e := ee;
   if contains({DOM_EXPR, DOM_SET, DOM_LIST, DOM_ARRAY}, domtype(e)) then
     e := eval(map(e, slot(combine, "ln")));
   elif domtype(e) = DOM_POLY then
     e := mapcoeffs(e, eval@combine::ln)
   end_if;

   // shortcut: finished if there are no logarithms left
   if not has(e, ln) then
     return(e);
   end_if;

   // handle k*ln(x) --> ln(x^k)
   if type(e) = "_mult" then

      // extract ln factors
      l := split([op(e)], testtype, "ln");

      if nops(l[1]) = 0 then
        return(e);
      end_if;

      // split real factors in the coefficient
      kn := split(l[2], testtype, Type::Real);
      ks := split(kn[2], is, Type::Real);     
      r := _mult(op(ks[2].ks[3]));
      kn := _mult(op(kn[1]));
      ks := _mult(op(ks[1]));
      if kn*ks = 1 then
        // no real factors in the coefficient; we can do nothing
        return(e);
      end_if;

      l := map(l[1], op);
      // now e = r * kn * ks * _mult(ln(l[i]) $ i = 1..nops(l))
      // kn is real numeric, ks is real symbolic.

      // auxilliary procedure: return the index of the first
      // element in the list l for which f returns TRUE
      // if none exists, return FAIL
      selectFirst := proc(l, f)
        local i;
      begin
        for i from 1 to nops(l) do
          if f(l[i]) = TRUE then
            return(i)
          end_if
        end_for;
        FAIL
      end_proc;

      // is there a logarithm with positive argument?
      // prevent expansions n^k for integers n, k with k > 100
      if (domtype(kn) = DOM_INT or domtype(kn) = DOM_RAT) and
        specfunc::abs(kn) > 100 then
        s:= selectFirst(l, z -> bool(domtype(z) <> DOM_INT and
                        domtype(z) <> DOM_RAT) and is(z, Type::NonNegative))
      else
        s := selectFirst(l, z -> is(z, Type::NonNegative))
      end_if;
      if s <> FAIL then
        // pull the real factors as exponents into the first
        // logarithm with positive argument
        l := subsop(l, s = l[s]^(kn*ks));
        return(_mult(r, op(map(l, ln))))
      end_if;

      // try the rules for -1 <= k <= 1 and -2 <= k <= 2

      // first try k = kn*ks
      if ks <> 1 and is(kn*ks, Type::Interval([-1], [1])) = TRUE then
        if is(kn*ks > -1) = TRUE then
          s := 1
        else
          s := selectFirst(l, z -> not (is(z < 0)));
        end_if;
      elif ks <> 1 and is(kn*ks, Type::Interval([-2], [2])) = TRUE then
        s := selectFirst(l, z -> is(Re(z) > 0));
      end_if;
      if s <> FAIL then
        l := subsop(l, s = l[s]^(kn*ks));
        return(_mult(r, op(map(l, ln))))
      end_if;

      // try k = kn
      if kn <> 1 and -1 <= kn and kn <= 1 then
        if kn <> -1 then
          s := 1
        else
          s := selectFirst(l, z -> not (is(z < 0)));
        end_if;
      elif kn <> 1 and -2 <= kn and kn <= 2 then
        s := selectFirst(l, z -> is(Re(z) > 0));
      end_if;
      if s <> FAIL then
        l := subsop(l, s = l[s]^kn);
        kn := 1;
        s := FAIL;
      end_if;

      // finally, try k = ks
      if ks <> 1 and is(ks, Type::Interval([-1], [1])) = TRUE then
        if is(ks > -1) = TRUE then
          s := 1
        else
          s := selectFirst(l, z -> not (is(z < 0)));
        end_if;
      elif ks <> 1 and is(ks, Type::Interval([-2], [2])) = TRUE then
        s := selectFirst(l, z -> is(Re(z) > 0));
      end_if;
      if s <> FAIL then
        l := subsop(l, s = l[s]^ks);
        ks := 1;
      end_if;

      return(_mult(r, kn, ks, op(map(l, ln))));

   end_if; // type(e) = "_mult"

   // not a sum ==> finished
   if type(e) <> "_plus" then
     return(e);
   end_if;

   // auxilliary procedure: try to write y = k*ln(x) syntactically
   // return the list [k, x] if successful, and x otherwise
   split_product := proc(y)
     local l;
   begin
     if type(y) = "_mult" then
       l := select(y, testtype, "ln");
       if l = 1 then
         return(y)
       elif type(l) = "ln" then
         return([y/l, op(l)])
       else // l is a product of logs; take the last one
         l := op(l, nops(l));
         return([y/l, op(l)])
       end_if;
     elif type(y) = "ln" then
       return([1, op(y)])
     else
       return(y)
     end_if
   end_proc;
       
   l := map([op(e)], split_product);
   l := split(l, testtype, DOM_LIST);
   r := _plus(op(l[2]));
   l := l[1];
   // Now e = r + _plus(l[i][1] * ln(l[i][2]) $ i = 1..nops(l))

   // handle k*ln(x) +- k*ln(y)
   while nops(l) > 0 do
     k := l[1][1];
     l := split(l, z -> bool(z[1] = k));
     arguments1 := map(l[1], op, 2);
     l := l[2];
     l := split(l, z -> bool(z[1] = -k));
     arguments2 := map(l[1], op, 2);
     l := l[2];
     // all entries x of arguments1 occur in the form k*ln(x) in e,
     // all entries x of arguments2 occur in the form -k*ln(x) in e

     // do nothing if there is only one term
     if nops(arguments1) + nops(arguments2) > 1 then

       // Extract positive arguments
       arguments1 := split(arguments1, is, Type::NonNegative);
       positiveArguments := _mult(op(arguments1[1]));
       arguments1 := arguments1[2].arguments1[3];
       arguments2 := split(arguments2, is, Type::NonNegative);
       positiveArguments := positiveArguments/_mult(op(arguments2[1]));
       arguments2 := arguments2[2].arguments2[3];

       // multiply all positive arguments to the first of the other args
       if nops(arguments1) > 0 then
         arguments1 := subsop(arguments1, 1 = arguments1[1]*positiveArguments)
       elif nops(arguments2) > 0 then
         arguments2 := subsop(arguments2, 1 = arguments2[1]/positiveArguments)
       else
         arguments1 := [positiveArguments];
       end_if;

     end_if;

     // add linear combination of the logarithms of the combined arguments
     // to the final result r
     r := _plus(r, op(map(arguments1, z -> k*ln(z))),
                   op(map(arguments2, z -> -k*ln(z))))
   end_while;

   return(r)

end_proc):

//-----------------------------------------------------------------------
// (Walter) 24.03.02: combine::log implemented in analogy to
// Juergen's combine::ln above
//
// combine::log(ee): handles the call combine(ee, log). Tries to rewrite
// k*log(b, x)+l*log(b, y) ==> log(b, x^k*y^l) whenever possible.
//
// Descends recursively into expressions of type +, *, ^, but not
// into arguments of other function calls. In particular, arguments
// of exp are not combined.
// Properties are taken into account.
//
// Implemented rules:
//
// k*log(b, a) --> log(b, a^k) if
// *) k in R and a > 0
// *) -2 <= k <= 2 and Re(a) > 0
// *) -1 < k <= 1 or (k = 1 and not a < 0)
// This is done first.
//
// k*log(b, x) + k*log(b, y) --> k*log(b, x*y) if x > 0 or y > 0
// k*log(b, x) - k*log(b, y) --> k*log(b, x/y) if x > 0 or y > 0
//
// Not implemented: the latter two rules if Re(x) > 0 and Re(y) > 0
//
// Note:
// - 2*log(b, x) + log(b, 4) will NOT be combined, except if is(x < 0) = TRUE
// - products of logarithms, such as log(b, 2)*log(b, 3), are not combined
//
combine::log := proc(ee)
   name combine::log;
   local e, l, r, kn, ks, selectFirst, s, b,
         k, split_product, arguments1, arguments2, positiveArguments;
 begin

   // combine(.., log) implies combine(.., ln);
   if has(ee, ln) then
      ee:= combine(ee, ln);
   end_if;

   // shortcut: do nothing if there are no logarithms
   if not has(ee, log) then
     return(combine(ee, ln));
   end_if;

   // recursively combine all operands
   e := ee;
   if contains({DOM_EXPR, DOM_SET, DOM_LIST, DOM_ARRAY}, domtype(e)) then
     e := eval(map(e, slot(combine, "log")));
   elif domtype(e) = DOM_POLY then
     e := mapcoeffs(e, eval@combine::log)
   end_if;

   // shortcut: finished if there are no logarithms left
   if not has(e, log) then
     return(e);
   end_if;

   // handle k*log(b, x) --> log(b, x^k)
   if type(e) = "_mult" then

      // extract ln factors
      l := split([op(e)], testtype, "log");

      if nops(l[1]) = 0 then
        return(e);
      end_if;

      // split real factors in the coefficient
      kn := split(l[2], testtype, Type::Real);
      ks := split(kn[2], is, Type::Real);     
      r := _mult(op(ks[2].ks[3]));
      kn := _mult(op(kn[1]));
      ks := _mult(op(ks[1]));
      if kn*ks = 1 then
        // no real factors in the coefficient; we can do nothing
        return(e);
      end_if;

      l := map(l[1], [op]);
      // now e = r * kn * ks * _mult(log(b, l[i]) $ i = 1..nops(l))
      // kn is real numeric, ks is real symbolic.

      //----------------------------------------------------
      // auxilliary procedure: return the index of the first
      // element in the list l for which f returns TRUE
      // if none exists, return FAIL
      selectFirst := proc(l, f)
        local i;
      begin
        for i from 1 to nops(l) do
          if f(l[i]) = TRUE then
            return(i)
          end_if
        end_for;
        FAIL
      end_proc;
      //----------------------------------------------------

      // is there a logarithm with positive argument?
      // avoid expanding k*log(n) -> log(n^k)
     // for integers n and large k
     if (domtype(kn) = DOM_INT or domtype(kn) = DOM_RAT) and
       specfunc::abs(kn) > 100 then
       s:= selectFirst(l, z -> bool(domtype(z[2]) <> DOM_INT and
                        domtype(z[2]) <> DOM_RAT) and
                       is(z[2], Type::NonNegative))
     else
       s := selectFirst(l, z -> is(z[2], Type::NonNegative))
     end_if;
     
      if s <> FAIL then
        // pull the real factors as exponents into the first
        // logarithm with positive argument
        l := subsop(l, s = [l[s][1], (l[s][2])^(kn*ks)]);
        return(_mult(r, op(map(l, z -> log(z[1], z[2])))))
      end_if;

      // try the rules for -1 <= k <= 1 and -2 <= k <= 2

      // first try k = kn*ks
      if ks <> 1 and is(kn*ks, Type::Interval([-1], [1])) = TRUE then
        if is(kn*ks > -1) = TRUE then
          s := 1
        else
          s := selectFirst(l, z -> not (is(z[2] < 0)));
        end_if;
      elif ks <> 1 and is(kn*ks, Type::Interval([-2], [2])) = TRUE then
        s := selectFirst(l, z -> is(Re(z[2]) > 0));
      end_if;
      if s <> FAIL then
        l := subsop(l, s = [l[s][1], (l[s][2])^(kn*ks)]);
        return(_mult(r, op(map(l, z -> log(z[1], z[2])))))
      end_if;

      // try k = kn
      if kn <> 1 and -1 <= kn and kn <= 1 then
        if kn <> -1 then
          s := 1
        else
          s := selectFirst(l, z -> not (is(z[2] < 0)));
        end_if;
      elif kn <> 1 and -2 <= kn and kn <= 2 then
        s := selectFirst(l, z -> is(Re(z[2]) > 0));
      end_if;
      if s <> FAIL then
        l := subsop(l, s = [l[s][1], (l[s][2])^kn]);
        kn := 1;
        s := FAIL;
      end_if;

      // finally, try k = ks
      if ks <> 1 and is(ks, Type::Interval([-1], [1])) = TRUE then
        if is(ks > -1) = TRUE then
          s := 1
        else
          s := selectFirst(l, z -> not (is(z[2] < 0)));
        end_if;
      elif ks <> 1 and is(ks, Type::Interval([-2], [2])) = TRUE then
        s := selectFirst(l, z -> is(Re(z[2]) > 0));
      end_if;
      if s <> FAIL then
        l := subsop(l, s = [l[s][1], (l[s][2])^ks]);
        ks := 1;
      end_if;

      return(_mult(r, kn, ks, op(map(l, z -> log(z[1],z[2])))));

   end_if; // type(e) = "_mult"

   //-----------------------------------------------------------
   // not a sum ==> finished
   if type(e) <> "_plus" then
     return(e);
   end_if;
   //-----------------------------------------------------------

   //-----------------------------------------------------------
   // from here, e is of type "_plus":
   //-----------------------------------------------------------

   assert(type(e) = "_plus");

   //-----------------------------------------------------------
   // auxilliary procedure: try to write y = k*log(b, x) syntactically
   // return the list [k, [b, x]] if successful, and y otherwise
   split_product := proc(y)
     local l;
   begin
     if type(y) = "_mult" then
       l := select(y, testtype, "log");
       if l = 1 then
         return(y)
       elif type(l) = "log" then
         return([y/l, [op(l)]])
       else // l is a product of logs; take the last one
         l := op(l, nops(l));
         return([y/l, [op(l)]])
       end_if;
     elif type(y) = "log" then
       return([1, [op(y)]])
     else
       return(y)
     end_if
   end_proc;
   //-----------------------------------------------------------
       
   l := map([op(e)], split_product);
   l := split(l, testtype, DOM_LIST);
   r := _plus(op(l[2]));
   l := l[1];
   // Now e = r + _plus(l[i][1] * log(l[i][2][1], l[i][2][2]) $ i = 1..nops(l))

   // handle k*log(b, x) +- k*log(b, y)
   while nops(l) > 0 do
     k := l[1][1];
     b := l[1][2][1];
     l := split(l, z -> bool(z[1] = k and z[2][1] = b));
     arguments1 := map(l[1], op, [2, 2]);
     l := l[2];
     l := split(l, z -> bool(z[1] = -k and z[2][1] = b));
     arguments2 := map(l[1], op, [2, 2]);
     l := l[2];
     // all entries x of arguments1 occur in the form k*log(b,x) in e,
     // all entries x of arguments2 occur in the form -k*log(b,x) in e

     // do nothing if there is only one term
     if nops(arguments1) + nops(arguments2) > 1 then

       // Extract positive arguments
       arguments1 := split(arguments1, z -> is(z, Type::NonNegative));
       positiveArguments := _mult(op(arguments1[1]));
       arguments1 := arguments1[2].arguments1[3];
       arguments2 := split(arguments2, z -> is(z, Type::NonNegative));
       positiveArguments := positiveArguments/_mult(op(arguments2[1]));
       arguments2 := arguments2[2].arguments2[3];

       // multiply all positive arguments to the first of the other args
       if nops(arguments1) > 0 then
         arguments1 := subsop(arguments1, 1 = arguments1[1]*positiveArguments)
       elif nops(arguments2) > 0 then
         arguments2 := subsop(arguments2, 1 = arguments2[1]/positiveArguments)
       else
         arguments1 := [positiveArguments];
       end_if;

     end_if;

     // add linear combination of the logarithms of the combined arguments
     // to the final result r
     r := _plus(r, op(map(arguments1, z ->  k*log(b, z))),
                   op(map(arguments2, z -> -k*log(b, z))))
   end_while;

   return(r)

end_proc:


// 5^x*6^x/10^x/3^x ==> (5*6/10/3)^x ==> 1 // tonner 
combine::_power:=
proc(X)
  name combine::_power;
  local a,f,s,p,x,t, base;
 begin
   userinfo(5, "Attribute combine::_power called");
   if type(X)<>"_mult" then
     return(X)
   end_if;
 
  a:=1; // product of non-powers
  s:={}; // set of exponents
  p:=table(); // p[x] is the list of all factors being to power x
  for f in X do
    if type(f) = "_power" or type(f) = DOM_COMPLEX and op(f, 1) = 0 then
      if type(f) = DOM_COMPLEX then
        x:= 1/2;
        base:= -1;
        a:= a*f/I
      else         
        x:= op(f,2);
        base:= op(f,1)
      end_if;
      // extract integer factors from x where possible
      if type(x) = DOM_RAT and op(x, 1)<>1 and is(base>=0) = TRUE then
        base:= base^op(x,1);
        x:= 1/op(x,2)
      elif type(x) = "_mult" and type((t:= op(x, nops(x)))) = DOM_INT
        and is(base>=0) = TRUE then
        base:= base^t;
        x:= x/t
      end_if;
      if not contains(s,x) then
        if not contains(s,-x) or
          /* second case: a^(-x)=(1/a)^x does not hold e.g.
for a=I, x=1/2 */
          (is(x, Type::Integer) or is(base > 0))<>TRUE then
          p[x]:=[base]; s:=s union {x}
        else
          p[-x]:=p[-x] . [1/base]
        end_if
      else
        p[x]:=p[x] . [base]
      end_if
    else
      a:=a*f
    end_if
  end_for;
  userinfo(10, "Table of powers (by exponent): ",p);
  for f in s do
	 // x>0 or y>0  =>  x^b * y^b = (x*y)^b 
	 // Re(x)>0 or (Re(x)=0 and Im(y)>0)  =>  x^b * y^b = (x*y)^b 
    t:= map( p[f],
            proc(y)
            begin
              if testtype(y,Type::Numeric) then
                bool(sign(y)=1)
              else
                is(y>0)
              end_if
            end_proc);
	 // x>0 or y>0  =>  x^b * y^b = (x*y)^b 
    if nops(select(t,_equal,TRUE)) + 1 >= nops(t) then
      t:= _mult( op(p[f]) );
      if iszero(t) or length(t^f)<=length((1/t)^(-f)) or
        (is(f, Type::Integer) or is(t > 0)) <> TRUE then
        a:=a*t^f
      else
        a:=a*(1/t)^(-f)
      end_if
    else
            /* Re(x)>0 or (Re(x)=0 and Im(x)>0)  AND
	      Re(y)>0 or (Re(y)=0 and Im(y)>0)      =>  x^b * y^b = (x*y)^b 
	    */ 
      t:= select( p[f],
                 proc()
                 begin
                   (testtype(args(1),Type::Numeric) and
                    (sign(Re(args(1)))=1
                     or sign(Re(args(1)))=0 and sign(Im(args(1)))=1))
                   or (is(Re(args(1))>0)=TRUE or
                       (is(Re(args(1))=0) and is(Im(args(1))>0)) = TRUE)
                 end_proc  );
      if t = p[f] then
        t:= _mult( op(p[f]) );
        if length(t^f)<=length((1/t)^(-f)) or
          (is(f, Type::Integer) or is(t > 0)) <> TRUE then
          a:=a*t^f
        else
          a:=a*(1/t)^(-f)
        end_if
      else
        a:= _mult(a,op(map(p[f],_power,f)))
      end_if
    end_if
  end_for;
  a
end_proc:

/*
|    The following routines are used to combine expressions including
|    sinh and cosh. The algorithms are the same as in case of combining
|    expressions involving sin and cos. Therefore the above procedures
|    combine:=slot(combine,"sincos",...), sdtlib::combine_sin_cos()
|    and stdlib::combine_sincos() have been renamed to
|    combine:=slot(combine,"sincos",...), stdlib::combine_sinh_cosh
|    and stdlib::combine_sinhcosh. 
|    T.S. 03.05.1996
*/

combine:=slot(combine,"sinhcosh",proc(ee)
name combine::sinhcosh;
local l,k,f,e;
begin
   e:=ee;
   case domtype(e) // default is to return e 
   of DOM_POLY    do return( mapcoeffs(e,slot(combine,"sinhcosh")) )
   of DOM_LIST    do
   of DOM_ARRAY   do
   of DOM_SET     do return( map(e,slot(combine,"sinhcosh")) )
   of DOM_EXPR    do
      case type(e)
      of "_mult" do e:=[op(e)]; break
      of "_power" do e:=[e]; break
      otherwise return(map(e,slot(combine,"sinhcosh")))
      end_case;
      // now deal with _mult and _power case 
      k:=1; l:=[];
      for f in e do
         case type(f)
         of "sinh" do
         of "cosh" do l:=append(l,f); break
         of "_power" do
            if contains({"sinh","cosh"},type(op(f,1))) and 
               testtype(op(f,2),Type::PosInt) then
               l:=append(l,op(f,1)$op(f,2)); break
            end_if
         otherwise k:=k*map(f,slot(combine,"sinhcosh"))
         end_case;
      end_for;
      return(stdlib::combine_sinh_cosh(l,k))
   end_case;
   e
end_proc):

// k is a scalar, l is a list of sinh or cosh expressions 
stdlib::combine_sinh_cosh := proc(l,k)
begin
   if l=[] then return(k) end_if;
   while nops(l)>=2 do
      if type(l[1])="_plus" then
         l[1]:=map(l[1],stdlib::combine_sinhcosh,l[2])
      else l[1]:=stdlib::combine_sinhcosh(l[1],l[2])
      end_if;
      delete l[2];
   end_while;
   if type(l[1])="_plus" then map(l[1],_mult,k) else k*l[1] end_if
end_proc:

// for x*y where x and y can be cos(..) or a*cos(..) or a where a is a rational 
stdlib::combine_sinhcosh := proc(xx,yy)
local a,b,m, x, y;
begin
   x:=xx; y:=yy;
   if type(x)="_mult" then
        m:=op(x,2);
        x:=op(x,1):
   else
        m:=1
   end_if;
   if type(y)="_mult" then
       m:=m*op(y,2);
       y:=op(y,1):
   end_if;
   a:=op(x); b:=op(y);
   case type(x),type(y)
   of "sinh","sinh" do -m/2*cosh(a-b)+m/2*cosh(a+b); break
   of "sinh","cosh" do m/2*sinh(a+b)+m/2*sinh(a-b); break
   of "cosh","sinh" do
        if stdlib::hasmsign(a-b) then
            m/2*sinh(a+b)+m/2*sinh(b-a);
        else
            m/2*sinh(a+b)-m/2*sinh(a-b);
        end_if:
   break
   of "cosh","cosh" do m/2*cosh(a-b)+m/2*cosh(a+b); break
   otherwise m*x*y /* it can happen that x or y is a constant,
                        for example cos(0) -> 1 for cos(t)^3 */
   end_case:
end_proc:


/*
combine::gamma:
slot for combining expressions involving the gamma function

We use the rules gamma(-z) * gamma(z) = -PI / (z * sin(PI*z))
and
gamma(z) * gamma(1-z) = PI / sin(PI*z)
(see Abramowitz / Stegun 6.1.17)


On combining gamma(n-z) * gamma(z) for higher integer values, we
would have to exclude the possibility that z is an integer with 0 < z < n

*/

combine::gamma:=
proc(e)
  local gammas, i, j, n, z;
begin  
  if type(e) = "_mult" then
    // select gammas and integer powers of gammas
    gammas:= map([op(e)], x ->
                 if type(x) = "gamma" then
                   x
                 elif type(x) = "_power" and type(op(x, 1)) = "gamma"
                   and type(op(x, 2)) = DOM_INT then
                   op(x, 1)
                 else
                   null()
                 end_if
                   );
    i:= 1;
    while i < nops(gammas) do
      // try to combine with gammas[j] where j > i
      j:= i + 1;
      while j <= nops(gammas) do
        n:= (z:= op(gammas[i], 1)) + op(gammas[j], 1);
        if n = 0 then
          e:= e * (-PI) / (z * sin(PI*z)) / gammas[i] / gammas[j];
          delete gammas[j];
          break
          // we need not delete gammas[i] because i won�t be visited again
        elif n = 1 then
          e:= e * PI / sin(PI*z) / gammas[i] / gammas[j];
          delete gammas[j];
          break
        else
          j:= j + 1
        end_if
      end_while;
      i:= i + 1
    end_while;
  end_if;
  e
end_proc:
  




// end of file 

