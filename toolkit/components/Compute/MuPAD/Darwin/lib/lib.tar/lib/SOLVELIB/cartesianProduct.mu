

/*
   solvelib::cartesianProduct()

      returns the cartesian product of subsets of C^n
      (for possibly different n)

*/

solvelib::cartesianProduct:=
proc()
  local argv, flatten, genericElement, variables, sets, i, d, X;
begin
  
  flatten:=
  proc(S)
  begin
    map(S, map, l-> if domtype(l) = DOM_LIST or domtype(l) = matrix then
                      op(l)
                    else
                      l
                    end_if)
  end_proc;
  

  if contains({args()}, undefined) then
    return(undefined)
  end_if;

  // prefer to write a cartesian power
  if nops({args()}) = 1 then
    return(solvelib::cartesianPower(args(1), args(0)))
  end_if;
  
  argv:= [args()];
  

  // handle cartesianProducts in the arguments
  /*
  argv:= map(argv, S -> if type(S) = "solvelib::cartesianProduct" then
                          op(S)
                        else
                          S
                        end_if
             );
  */


  if contains(argv, {}) > 0 then
    return({})
  end_if;

  // apply the distributive law to _union and _intersect
  d:= map(argv, type);
  if (i:= contains(d, "_intersect")) > 0 then
    return(_intersect(solvelib::cartesianProduct(op(argv, 1..i-1), X,
                                                 op(argv, i+1..nops(argv)))
                      $X in argv[i]
                      ))
  end_if;
  if (i:= contains(d, "_union")) > 0 then
    return(_union(solvelib::cartesianProduct(op(argv, 1..i-1), X,
                                             op(argv, i+1..nops(argv)))
                  $X in argv[i]
                  ))
  end_if;

  
  variables:= sets:= [];
  genericElement:= [NIL $ nops(argv)];
  
  for i from 1 to nops(argv) do
    // obtain a formula for the set of "general elements"" of argv[i]
    case type(argv[i])
      of DOM_SET do
        genericElement[i] := argv[i];
        break
      of Dom::ImageSet do
      of solvelib::VectorImageSet do
        d:= (argv[i])::dom;
        for X in {op(d::variables(argv[i]))} intersect {op(variables)} do
          argv[i]:= d::changevar(argv[i], X, genident())
        end_for;
        genericElement[i] := {expr(argv[i])};
        variables:= variables.d::variables(argv[i]);
        sets:= sets.d::sets(argv[i]);
        break
      otherwise
        // assert(solvelib::dimension(argv[i])=1);
        X:= genident();
        genericElement[i] := {X};
        variables:= variables.[X];
        sets:= sets.[argv[i]]
    end_case
  end_for;


  map({op(flatten(combinat::cartesianProduct(op(genericElement))))}, matrix);

  if nops(sets) = 0 then
    %
  else
    _union(op(
              map(%,
                  el -> solvelib::VectorImageSet(el, variables, sets))
              ))
  end_if

end_proc:


// solvelib::cartesianProduct:= funcenv(solvelib::cartesianProduct):
// solvelib::cartesianProduct::type := "solvelib::cartesianProduct":