
// discont - attributes for trunc

trunc::realDiscont:= Z_ minus {0}:
