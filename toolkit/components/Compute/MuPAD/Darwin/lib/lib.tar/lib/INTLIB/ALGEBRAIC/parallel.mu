// 'parallel' integration, a heuristic integrator based on 
// an extended abstract and rudimentary maple code by Manuel Bronstein

intlib::algebraic::parallel :=
proc(f, x)
  local ts, vars, diffs, ff, q, d, dbar, darbouxPolys, substs, res;
begin
  // can't handle any of these
  if has(f, [hold(dirac), hold(heaviside),
             hold(Re), hold(Im),
             hold(abs), hold(sign),
             hold(ceil), hold(floor), hold(round)]) then
    return(FAIL);
  end_if;
  // find differential field in which the function is rational
  [ts, vars, diffs] := intlib::algebraic::transcendental(f, x);
  if ts=FAIL then // non-transcendental extension, sorry, folks
    return(FAIL);
  end_if;
  substs := revert(zip(vars, ts, _equal));
  ff := normal(subsex(f, substs));
  
  // the lcm of the denominator of the derivatives
  q := lcm(op(map(diffs, denom)));
  
  // our derivations
  d := ex -> intlib::algebraic::diff(ex, ts, diffs);
  dbar := ex -> intlib::algebraic::diff(ex, ts, map(diffs, _mult, q));

// this routine could be useful to find Darboux polynomials manually
//  return(ex -> Simplify(dbar(subsex(ex, revert(zip(vars, ts, _equal))))/
//                        subsex(ex, revert(zip(vars, ts, _equal)))));
  
  darbouxPolys := map(vars, 
                      intlib::algebraic::parallel::knownDarboux,
                      substs);
  darbouxPolys := darbouxPolys.intlib::algebraic::parallel::alsoDarboux(q, dbar, ts, substs);
                      
  // actual integration
  res := intlib::algebraic::parallel::pmIntegrate(ff, d, dbar, q, ts,
                                                  vars, diffs, darbouxPolys);
  
  res;
end_proc:


intlib::algebraic::parallel := funcenv(intlib::algebraic::parallel):

// known Darboux polynomials.
// The Boolean in the second entry determines if this
// polynomial is used in the heuristic guess for s
intlib::algebraic::parallel::knownDarboux :=
proc(f, substs)
begin
  case op(f, 0)
    of hold(tan) do return([subs(f, substs)^2+1, FALSE]);
    of hold(tanh) do return([1+subs(f, substs), FALSE],
                            [1-subs(f, substs), FALSE]);
    of hold(exp) do return([subsex(f, substs), FALSE]);
    of hold(lambertW) do return([subs(f, substs), TRUE]);
  end_case;
  null();
end_proc:

// the same, but not given some subexpression f but the lcm of denoms
intlib::algebraic::parallel::alsoDarboux :=
proc(q, dbar, ts, substs)
  local dq;
begin
  dq := poly(dbar(q), ts);
  if dq = FAIL then
    return([]);
  end_if;
  dq := gcd(dq, poly(q, ts));
  if degree(dq) > 0 then
    return([[expr(q), FALSE]]);
  end_if;
  [];
end:


// the core routine, which includes all the heuristics
intlib::algebraic::parallel::pmIntegrate :=
proc(f, d, dBar, q, ts, vars, diffs, knownDarboux)
  local i, qs, qn, s, ff, denF, denFs, denFn, candDen, deg, maxDeg,
        monomials, t, tmax, b, cand, Dcand, factors, adjoin,
        addTerm, guessMoreTerms, coeffs, sol;
begin
  [qs, qn] := intlib::algebraic::parallel::splitFactor(q, dBar, ts);
  s := _mult(qs, op(map(select(knownDarboux, op, 2), op, 1)));
  ff := normal(f);
  denF := denom(ff);
  [denFs, denFn] := intlib::algebraic::parallel::splitFactor(denF, dBar, ts);
  candDen := s * denFs * intlib::algebraic::parallel::deflation(denFn, ts);
  maxDeg := 1 + degree(candDen, ts) + max(degree(numer(ff), ts), degree(denF, ts));

  userinfo(5, "guess for degree bound: ".expr2text(maxDeg));

  deg := 1;
  while deg < maxDeg do
    deg := min(2*deg, maxDeg);
    userinfo(6, "now trying degree ".expr2text(deg));
  // given f, Dbar, q, the substituted expressions,
  // the monomials D(s[i])/s[i], D(p[i])/p[i], a candidate
  // denominator and a max degree for the candidate enumerator,
  // find a solution of eq. 1 in M. Bronstein: Parallel Integration,
  // Programming and Computer Software, Vol. 32, No. 1.

    monomials := map(combinat::compositions::list(deg, Length=nops(ts)+1, MinPart=0),
                     l -> expr(poly([[1, l[1..-2]]], ts)));

    for adjoin in [{}, {I}] do
      factors := coerce(factor(qn, Adjoin=adjoin), DOM_LIST)[2..-1] .
                 coerce(factor(denFs, Adjoin=adjoin), DOM_LIST)[2..-1] .
                 coerce(factor(denFn, Adjoin=adjoin), DOM_LIST)[2..-1];
      factors := [op({factors[2*i-1] $ i = 1..nops(factors)/2,
                      op(map(knownDarboux, op, 1))})];

      t := solvelib::getIdent(Any, indets([ts, ff, vars]));
      b := _plus(t[i]*monomials[i] $ i=1..nops(monomials));
      tmax := nops(monomials);
      cand := b/candDen;
      Dcand := d(cand);

      addTerm :=
      proc(ex, Dex)
        local i;
        name intlib::algebraic::parallel::pmIntegrate::addTerm;
      begin
        userinfo(10, "adding ".expr2text(ex));
        tmax := tmax+1;
        cand := cand + t[tmax]*ex;
        Dcand := Dcand + t[tmax]*Dex;
      end;
    
      // in addition to Bronstein's paper, we also try arctan terms,
      // Ei terms (including Li(x)=-Ei(-ln(x))) and erf terms:
      guessMoreTerms := 
      proc(ex)
        local t, pex, a, b, c, dis, i, e, te, cont, eIsSquare, sqrtE;
      begin
        addTerm(ln(ex), d(ex)/ex);
        i := contains(ts, ex);
        if i>0 then
          te := type(vars[i]);
          e := subs(op(vars[i]), revert(zip(vars, ts, _equal)));
        else
          te := type(ex);
          e := op(ex);
        end_if;
        // check if the argument is a square.
        eIsSquare := FALSE;
        t := [op(indets([e]) intersect {op(ts)})];
        if type(e) <> "_exprseq" and nops(t) = 1 then
          a := intlib::algebraic::normal(e, t);
          a := map(a, polylib::sqrfree);
          a := map(a, coerce, DOM_LIST);
          cont := TRUE;
          for i from 3 to nops(a[1]) step 2 do
            if not testtype(a[1][i]/2, DOM_INT) then
              cont := FALSE;
              break;
            end_if;
          end_for;
          if cont then
            for i from 3 to nops(a[1]) step 2 do
              if not testtype(a[1][i]/2, DOM_INT) then
                cont := FALSE;
                break;
              end_if;
            end_for;
            if cont then
              eIsSquare := TRUE;
              sqrtE := [sqrt(a[1][1]/a[2][1]),
                        _mult(expr(a[1][2*i])^(a[1][2*i+1]/2) 
                               $ i = 1..(nops(a[1])-1)/2) /
                        _mult(expr(a[2][2*i])^(a[2][2*i+1]) $ i = 1..(nops(a[2])-1)/2)];
            end_if;
          end_if;
        end_if;

        case te
        of "ln" do
          addTerm(Ei(-ex), -d(e)/ex);
          addTerm(dilog(e), -d(e)*ex/(e-1));
          break;
        of "exp" do
          addTerm(Ei(-e), -ex*d(e)/e);
          if eIsSquare then
            addTerm(sqrt(PI)/(2*sqrtE[1])*erf(sqrtE[1]*sqrtE[2]), d(sqrtE[2])/ex);
          end_if;
          break;
        of "cos" do
          addTerm(Ci(e), ex*d(e)/e);
          if eIsSquare then
            addTerm(sqrt(PI/2)*fresnelC(sqrt(2/PI)*sqrtE[1]*sqrtE[2]),
                    ex*d(sqrtE[1]*sqrtE[2]));
          end_if;
          break;
        of "sin" do
          addTerm(Si(e), ex*d(e)/e);
          if eIsSquare then
            addTerm(sqrt(PI/2)*fresnelS(sqrt(2/PI)*sqrtE[1]*sqrtE[2]),
                    ex*d(sqrtE[1]*sqrtE[2]));
          end_if;
          break;
        of "polylog" do
          if type(e) <> _exprseq or nops(e) <> 2 then break; end_if;
          [a, b] := [e];
          if iszero(d(a)) then
            addTerm(polylog(a+1, b), d(b)*ex/b);
          end_if;
          break;
        end_case;
      
        t := [op(indets([ex]) intersect {op(ts)})];
        if nops(t) = 1 then
          pex := poly(ex, t);
          if pex<>FAIL and degree(pex) = 2 then
            a := coeff(pex, 2);
            b := coeff(pex, 1);
            c := coeff(pex, 0);
            dis := 4*a*c-b^2;
            if not iszero(dis) and indets([dis]) intersect {op(ts)} = {} then
              addTerm(arctan((2*a*t[1]+b)/sqrt(dis)),
                      d(t[1])*sqrt(dis)/(2*ex))
            end_if;
          end_if;
        end_if;
      end:

      map({op(factors), op(ts)}, guessMoreTerms);
    
  //    print(cand, Dcand);
      userinfo(2, "set up candidate with ".tmax." free parameters");
    
      coeffs := [coeff(intlib::algebraic::normal(ff-Dcand, ts)[1])];
      if has(coeffs, ts) then
        error("internal logic error");
      end_if;
      sol := intlib::algebraic::linsolve(coeffs, [t[i]$i=1..tmax]);

//      sol := intlib::algebraic::parallel::linsolve([coeff(numer(ff-d(cand)), ts)], 
//                               [t[i]$i=1..tmax]);

      if sol <> FAIL then
        break;
      end_if;
    end_for;
  
    if sol <> FAIL then
      sol := subs(cand, sol);
      // new indets, indets not covered by the solution (e.g., not occuring in d(cand))
      sol := subs(sol, map(numeric::indets(sol) minus numeric::indets(f)
                           minus numeric::indets(vars) minus {op(ts)}, _equal, 0));
      // since we've introduced new indets, we must do the backsubstitution here
      // result treatment
      return(subs(sol, zip(ts, vars, _equal)));
    end_if;
    // try with a larger degree, until maxDeg
  end_while;
  FAIL;
end:

// splitting-factorization of a polynomial w.r.t. a derivation:
// return ps*pn, s.t. ps is a Darboux polynomial (i.e.,
// d(ps) divides ps) and no irreducible factor of pn is Darboux.
intlib::algebraic::parallel::splitFactor :=
proc(p, d, ts)
  local x, cont, ppart, splrek, s, splrek2;
begin
  if ts = [] then return([1, p]); end_if;
  x := ts[1];
  while not has(p, x) do
    delete ts[1];
    if ts = [] then return([1, p]); end_if;
    x := ts[1];
  end_while;
  cont := content(p, [x]);
//  ppart := multcoeffs(p, 1/cont);
//  ppart := normal(p/cont);
  ppart := expr(poly(p/cont, [x]));
  splrek := intlib::algebraic::parallel::splitFactor(cont, d, ts[2..-1]);
  s := normal(gcd(ppart, d(ppart))/gcd(ppart, diff(ppart, x)));
  if iszero(degree(s)) then
    return([splrek[1], ppart*splrek[2]]);
  end_if;
  splrek2 := intlib::algebraic::parallel::splitFactor(normal(ppart/s), d, ts[2..-1]);
  return([splrek[1]*splrek2[1]*s, splrek[2]*splrek2[2]]);
end:

// deflation: given p=product(pp[i]^i, i=1..n), return
// product(pp[i]^(i-1),i=2..n)
intlib::algebraic::parallel::deflation :=
proc(p, ts)
  local x, cont, ppart;
begin
  if ts = [] then return(p); end_if;
  x := ts[1];
  while not has(p, x) do
    delete ts[1];
    if ts = [] then return(p); end_if;
    x := ts[1];
  end_while;    
  cont := content(p, [x]);
  ppart := poly(p/cont, [x]);
  return(intlib::algebraic::parallel::deflation(cont, ts[2..-1]) *
         expr(gcd(ppart, diff(ppart, x))));
end:
