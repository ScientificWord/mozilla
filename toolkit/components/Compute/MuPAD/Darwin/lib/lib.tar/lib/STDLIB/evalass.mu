// $Date: 2003-07-04 15:41:28 +0200 (Fri, 04 Jul 2003) $  $Author: ccr $  $Revision: 23683 $ 

//*****************************************************
// 'evalassign'                                          
//                                                       
// Aufruf: evalassign(left, right, depth);               
//                                                       
// Prozedur realisiert eine Zuweisung, die vor der       
// Ausfuehrung der eigentlichen Zuweisung die linke      
// Seite 'depth' - Stufen evaluiert.                     
//                                                       
// Argumente : 'left'  --  linke Seite der Zuweisung     
//             'right' --  rechte Seite der Zuweisung    
//             'depth' --  Evaluierungsstufe             
//                                                       
//*****************************************************

evalassign:=
  proc(left, right, depth = 0)
    option hold;
  begin
    right:= context(right);
    depth:= context(depth);
    if testargs() then
      if args(0) < 2 or args(0) > 3 then
        error("Wrong number of arguments")
      end_if;
      if domtype(depth) <> DOM_INT or depth < 0 then
	error("Illegal third argument")
      end_if
    end_if;
    if depth = 0 then
      context(subsop(hold(_assign(NIL, NIL)), 1 = context(left), 2 = right))
    else
      context(subsop(hold(_assign(NIL, NIL)),
		     1 = context(hold(level)(left, depth)),
		     2 = right
		    )
	     )
    end_if
  end_proc:
