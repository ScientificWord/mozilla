// $Date: 2001-03-11 19:36:28 +0100 (Sun, 11 Mar 2001) $ $Author: walter $ $Revision: 11081 $ 

_fconcat:= slot(_fconcat, "simplify",

proc(x)
name fconcat::simplify;
local vv, nopsvv, i; 

begin
  vv:=[op(x)];
  repeat
    nopsvv:= nops(vv):
    for i from 2 to nops(vv) do
      if op(vv,i-1)=(op(vv,i))@@(-1) then
        case op(vv, i-1)    // do not simplify arcsin@sin = id !
          of ln do
          of arcsin do
          of arccos do
          of arctan do
          of arccot do
          of arcsinh do
          of arccosh do
          of arctanh do
          of arccoth do break;
          otherwise
            vv[i-1]:=(vv[i]:=id)
        end_case;
      end_if       
    end_for;
    vv:=select(vv, _unequal, id);
    // if there was some simplification (two operands were removed),
    // then we have to run the repeat loop again (consider exp@exp@ln@ln)
  until nops(vv) = nopsvv end_repeat;
  if nops(vv)=0 then
       id
  elif nops(vv)=1 then
       op(vv,1)
  else hold(_fconcat)(op(vv))
  end_if;
end_proc):

