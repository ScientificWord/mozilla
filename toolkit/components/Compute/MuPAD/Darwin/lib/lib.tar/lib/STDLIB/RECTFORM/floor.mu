
floor::rectform:=
proc(x)
begin
  new(rectform, op(map([extop(rectform(x))], floor)))
end_proc:
  