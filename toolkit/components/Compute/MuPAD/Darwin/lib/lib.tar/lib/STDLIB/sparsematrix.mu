
sparsematrix:= proc()
begin
  error("Use the function 'matrix' (it handles sparse matrices, too).")
end_proc:

// end of file 
