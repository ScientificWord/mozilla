// $Date: 2001-11-07 17:09:52 +0100 (Wed, 07 Nov 2001) $ $Author: stefanw $ $Revision: 15412 $ 

// kg, 19/01/94 

/*++
numer -- the numerator of a rational expression

numer(x)

x - expression
++*/

numer:=
proc(x)
begin
  if args(0) <> 1 then
    error("wrong no of args")
  end_if;
  if x::dom::numer <> FAIL then
    return(x::dom::numer(x))
  end_if;
  if testargs() then
    if not testtype(x, Type::Arithmetical) then
      error("no arithmetical expression")
    end_if;
  end_if;


  // main part (the former stdlib::numer of version 2.0)

  case type(x)
    of DOM_INT do
      x;
      break;
    of DOM_RAT do
      op(x,1);
      break;
    of DOM_COMPLEX do
      case domtype(op(x,1))
        of DOM_INT do
          case domtype(op(x,2))
            of DOM_INT do
              x;
              break;
            of DOM_RAT do
              op(x,1)*op(x,[2,2]) + I*op(x,[2,1]);
              break;
            otherwise
              x;
          end_case;
          break;
        of DOM_RAT do
          case domtype(op(x,2))
            of DOM_INT do
              op(x,[1,1]) + I*op(x,2)*op(x,[1,2]);
              break;
            of DOM_RAT do
              igcd(op(x,[1,2]), op(x,[2,2]));
              op(x,[1,1])*op(x,[2,2])/% +
              I*op(x,[2,1])*op(x,[1,2])/%;
              break;
            otherwise
              x;
          end_case;
          break;
        otherwise
          x;
      end_case;
      break;
    of "_mult" do
      map(x, numer);
      break;
    of "_power" do
      if domtype(op(x,2)) = DOM_INT then
        if op(x,2) > 0 then
          numer(op(x,1)) ^ op(x,2)
        else
          denom(op(x,1)) ^ (-op(x,2))
        end_if
      else
        normal(x, List)[1]
      end_if;
      break;
    otherwise
      normal(x, List)[1];
  end_case
end_proc :

// end of file 
