// $Date: 2002-02-06 00:07:24 +0100 (Wed, 06 Feb 2002) $ $Author: walter $ $Revision: 17126 $ 

/*--
intlib::sub() - is a remember table of the substitution equations
for sin,cos,..
--*/

intlib::sub:=proc()
  local i;
// global _global_notnagel_f; 
begin
  args(i) $ i=1..args(0)-1 end_proc:

// remember table for use with exp and ln 
intlib::sub(FAIL,Exp)        :=proc()
  local f;
begin
  f:=_global_notnagel_f;			 
  if domtype(f)=DOM_LIST then return([args()]) else return(f) end_if
end_proc:


//Walter 5.2.02: some entries were not consistent wird rewrite

intlib::sub(hold(sin),Exp)    :=proc(x) begin 1/(2*I)*(exp(x*I)-exp(-x*I))     end_proc:
intlib::sub(hold(cos),Exp)    :=proc(x) begin 1/2*(exp(x*I)+exp(-x*I))         end_proc:
intlib::sub(hold(tan),Exp)    :=proc(x) begin -I*(exp(x*I)^2-1)/(exp(x*I)^2+1) end_proc:
intlib::sub(hold(cot),Exp)    :=proc(x) begin  I*(exp(x*I)^2+1)/(exp(x*I)^2-1) end_proc:
intlib::sub(hold(arcsin),Exp) :=proc(x) begin -I*ln(I*x+sqrt(1-x^2))           end_proc:
intlib::sub(hold(arccos),Exp) :=proc(x) begin -I*ln(x+I*sqrt(1-x^2))           end_proc:
intlib::sub(hold(arctan),Exp) :=proc(x) begin I/2*(ln(1-I*x)-ln(1+I*x))        end_proc:
intlib::sub(hold(arccot),Exp) :=proc(x) begin I/2*(ln(1-I/x)-ln(1+I/x))        end_proc:
intlib::sub(hold(sinh),Exp)   :=proc(x) begin 1/2*(exp(x)-exp(-x))             end_proc:
intlib::sub(hold(cosh),Exp)   :=proc(x) begin 1/2*(exp(x)+exp(-x))             end_proc:
intlib::sub(hold(coth),Exp)   :=proc(x) begin (exp(x)^2+1)/(exp(x)^2-1)        end_proc:
intlib::sub(hold(tanh),Exp)   :=proc(x) begin (exp(x)^2-1)/(exp(x)^2+1)        end_proc:
intlib::sub(hold(arcsinh),Exp):=proc(x) begin ln(x+sqrt(x^2+1))                end_proc:
intlib::sub(hold(arccosh),Exp):=proc(x) begin ln(x+sqrt(x^2-1))                end_proc:
intlib::sub(hold(arctanh),Exp):=proc(x) begin 1/2*(ln(1+x)-ln(1-x))            end_proc:
intlib::sub(hold(arccoth),Exp):=proc(x) begin 1/2*(ln(1+1/x)-ln(1-1/x))        end_proc:

/* These were the original entries by Winfried:
intlib::sub(hold(arccos),Exp) :=proc(x) begin -I*ln(x+sqrt(x^2-1))       end_proc:
intlib::sub(hold(arctan),Exp) :=proc(x) begin -I*1/2*ln((1+I*x)/(1-I*x)) end_proc:
intlib::sub(hold(arctanh),Exp):=proc(x) begin 1/2*ln((1+x)/(1-x))        end_proc:
intlib::sub(hold(arccoth),Exp):=proc(x) begin 1/2*ln((x+1)/(x-1))        end_proc:
*/
