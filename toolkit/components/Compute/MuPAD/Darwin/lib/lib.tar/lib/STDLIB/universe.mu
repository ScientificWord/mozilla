// $Date: 2006-03-13 11:00:06 +0100 (Mon, 13 Mar 2006) $ $Author: ccr $ $Revision: 37632 $ 

/*

    universe - the set-theoretic universe of all objects

    universe is the only element of stdlib::Universe

*/


stdlib::Universe:= newDomain("stdlib::Universe"):
stdlib::Universe::create_dom:=hold(universe):

universe:= new(stdlib::Universe):

stdlib::Universe::info:= "Domain 'stdlib::Universe' representing the ".
"universe of all mathematical objects":

stdlib::Universe::interface:={}:

stdlib::Universe::expr:= ()-> hold(universe):

stdlib::Universe::print:= ()-> "universe":

stdlib::Universe::_intersect:=
proc()
begin
  _intersect(select(args(), _unequal, universe))
end_proc:

stdlib::Universe::_union:=()-> universe:

stdlib::Universe::_minus:=
proc(a,b)
begin
  if b=universe then
    {}
  elif a=universe then
      hold(_minus)(a,b)
  end_if
end_proc:
  
stdlib::Universe::_subset :=
proc(a,b)
begin
  if b=universe then TRUE
  else FALSE end_if;
end:

stdlib::Universe::TeX := () -> "\\mathrm{universe}":
