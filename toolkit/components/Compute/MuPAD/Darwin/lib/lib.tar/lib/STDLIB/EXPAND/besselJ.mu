// $Date: 2000-05-21 17:05:30 +0200 (Sun, 21 May 2000) $ $Author: bij $ $Revision: 8304 $ 

/*--
	besselJ/expand -- the function attribut "expand" for besselJ
--*/

besselJ := slot(besselJ,"expand",proc(v,z) // bessel(v,z) 
option remember;
begin
   if testtype(v-1,Type::PosInt) then expand(2*(v-1)/z*besselJ(v-1,z)-besselJ
(v-2,z))
   else hold(besselJ)(v,z)
   end_if
end_proc):

// end of file 
