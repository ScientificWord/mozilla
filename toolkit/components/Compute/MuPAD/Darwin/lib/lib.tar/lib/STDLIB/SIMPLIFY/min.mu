min := slot(min,"simplify", proc(e)
   name min::simplify;
   local s,olds,x,y;
begin
   s:= {op(e)};
   repeat
      olds:=s;
      for x in s do
         for y in s minus {x} do
            if type(y)="max" then
               if contains({op(y)},x) then s:=s minus {y} end_if
            elif is(0 <= y - x )=TRUE then s:=s minus {y}
            end_if
         end_for
      end_for
   until s=olds or nops(s)=1 end_repeat;
   if nops(s)=1 then op(s) else min(op(s)) end_if
end_proc):
