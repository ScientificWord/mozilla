/* $Date: 2006-05-17 14:19:21 +0200 (Wed, 17 May 2006) $ $Author: stefanw $ $Revision: 39073 $ */


/* solvelib::preImage(eq, x, S)

   determine the set of all C such that subs(eq, x=C) is an
   element of S
   S must *not* depend on x

*/

alias(BOUND = 10):


solvelib::preImage:=
proc(eq, x: DOM_IDENT, S)
local i, opt, v, k, prop;
save MAXEFFORT;

begin
  if testargs() then
    if args(0)<3 then
      error("Wrong number of arguments")
    end_if;
    if contains(freeIndets(S), x) then
      error("Third argument must not depend on variable")
    end_if;
  end_if;

  opt:=solvelib::getOptions(args(4..args(0)));
  
  if type(eq) = piecewise then
    // eq(x) = eq1(x) if cond1(x), eq2(x) if cond2(x) ...
    // then eq(x) in S iff for some k, condk(x) and eqk(x) in S 
    return(solvelib::solve_union
           (solvelib::solve_intersect
            (solve(piecewise::condition(eq, i), x, opt),
             solvelib::preImage(piecewise::expression(eq, i), x, S, opt)
             )
            $i=1..nops(eq)
           )
           )
  end_if;
  


  if opt["Real"] then
    save x;
    assume(x, Type::Real)
  end_if;

  if S::dom::preImage<>FAIL then
    return(S::dom::preImage(args()))
  end_if;


  if eq=x then
    return(S)
  end_if;
  case type(S)
    of DOM_SET do
      if nops(S) = 0 then
        return({})
      end_if;
      if nops(S) <= BOUND then
        MAXEFFORT:= MAXEFFORT/nops(S);
        return(_union(solve(eq=op(S,i), x, opt) $i=1..nops(S)))
      else
        break
      end_if;
    of "_union" do
    of "_intersect" do
    of "_minus" do
      MAXEFFORT:= MAXEFFORT/nops(S);
      return(map(S, u-> solvelib::preImage(eq, x, u, opt)))
    of "Union" do
      MAXEFFORT:= MAXEFFORT/2;
      return(solvelib::Union(solvelib::preImage(eq, x, op(S,1), opt),
                             op(S, 2), op(S, 3)
                             ))
    of Dom::ImageSet do
      // S = { f(y); y \in A }
      // then eq(x) \in S iff eq(x)=f(y) for some y in A
      // but first take care of the alias problem x=y
      if S::dom::nvars(S)=1 then
        v:= S::dom::variables(S)[1];
        if v = x or
          has(eq, v) then
          v:= genident();
          S:= S::dom::setvar(S, v)
        end_if;
        save v;
        prop:= solvelib::set2prop(S::dom::sets(S)[1], Superset);
        if prop = property::Null then
          // we have found out that S = {} !
          return({})
        else  
          assume(v, prop)
        end_if;
        // own effort is roughly 100
        MAXEFFORT:= max(5.0, MAXEFFORT - 100);
        k:= op(S::dom::variables(S), 1);
        return(solvelib::Union(solvelib::avoidAliasProblem
                               (solve(eq=expr(S), x, opt), {k}),
                                       k,
                               op(S::dom::sets(S), 1)
                               ))
      else
        break
      end_if
    of solvelib::BasicSet do
      case S
        of solvelib::BasicSet(Dom::Complex) do
          return(S minus discont(eq, x, undefined))
        of solvelib::BasicSet(Dom::Real) do
          return(solvelib::preImageReal(eq, x, opt))
        of solvelib::BasicSet(Dom::Integer) do
          // we can do very little here
          if type(eq) = "_plus" then
            eq:= select(eq, summand -> is(summand in Z_) <> TRUE)
          end_if;
          break // continue by solving below
          // otherwise
          // fall through
      end_case;
  end_case;

  i:=genident();
  save i;
  prop:= solvelib::set2prop(S, Superset);
  if prop = property::Null then
    return({})
  else  
    assume(i, prop);
  end_if;
  // for each of the following steps, reserve one half of the time
  MAXEFFORT:= MAXEFFORT/2;
  solve(eq=i, x, opt);
  solvelib::Union(%, i, S)
end_proc:


// special case S = R_: determine all x such that f(x) is real

solvelib::preImageReal:=
proc(eq, x, options)
  local zeroes, fac, rf;
  save MAXEFFORT;
begin
  // simple test
  // do not use is(..) because of bugs
  if simplify::simplifyCondition(eq in R_, UseSolver=FALSE) = TRUE then
    if getprop(x) = x then
      return(C_)
    else
      return(property::prop2set(getprop(x)))
    end_if
  end_if;


  case type(eq)
    of  "_power" do
      if type(op(eq, 2)) = DOM_RAT then
        if op(eq, 2) > 0 then
          return(solve(op(eq, 1) >= 0, x) )
        else
          return(solve(op(eq, 1) > 0, x) )
        end_if
      end_if;
      break
    of "ln" do
      // ln(f(z)) in R_ iff f(z) is positive
      return(solve(op(eq, 1) > 0, x))
    of "arcsin" do
    of "arccos" do
      // arcsin(f(z)) in R_ iff f(z) \in [-1, 1], the same for arccos
      return(solvelib::preImage(op(eq, 1), x, Dom::Interval([-1, 1]), options))
    of "exp" do
      if options["Real"] then
        return(solvelib::preImageReal(op(eq, 1), x, options))
      else
        return(solvelib::preImage(Im(op(eq, 1))/PI, x, Z_, options))
      end_if
    of "lambertW" do
      return(
             solve(op(eq, 1) = -1, x, options) intersect
             solvelib::preImage(op(eq, 2), x, Dom::Interval(-1/exp(1), 0),
                                options)
             union
             solve(op(eq, 1), x, options) intersect
             solve(op(eq, 2) >= -1/exp(1), x, options)
             )
    of "_plus" do
      eq:= select(eq, s -> is(s in R_) <> TRUE);
      if type(eq) <> "_plus" then
        return(solvelib::preImageReal(eq, x, options))
      else
        break
      end_if
    of "_mult" do
      zeroes:= split([op(eq)], s -> is(s in R_) <> TRUE);
      assert(nops(zeroes[3]) = 0);
      if nops(zeroes[2]) = 0 then
        // there are no real factors to divide off
        break
      end_if;
      // there are real factors; eq is zero iff the product of the other
      // factors is real or if one of the real factors is zero
      eq:= _mult(op(zeroes[1]));
      MAXEFFORT:= MAXEFFORT/nops(zeroes[2]);
      return(solvelib::preImageReal(eq, x, options) union
             _union(solve(fac, x, options) $fac in zeroes[2]))
  end_case;


  if MAXEFFORT < 2000 then
    return(hold(solve)(Im(eq), x))
  end_if;

  // last resort:
  rf:= rectform(eq);
  if op(rf, 3) <> 0 then
    hold(solve)(Im(eq), x)
  else
    rf:= op(rf, 2);
    // take care that no Re(X) + I*Im(X) remains
    rf:= subsex(rf, Re(fac) + I*Im(fac) = fac $fac in indets(eq));
    solve(rf, x, options)
  end_if
end_proc:


unalias(BOUND):
