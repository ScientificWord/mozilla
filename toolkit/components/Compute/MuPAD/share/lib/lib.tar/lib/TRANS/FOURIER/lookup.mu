
transform::fourier::lookup:=
proc(f : Type::Arithmetical, x : DOM_IDENT)
  save _X;
  local C, F, noX, dummy;
begin
  C:=genident();

  if x <> _X then
    delete _X;
    /* The summation index does not have properties
    if property::hasprop(x) then
      //assume(_X,prop) // doesn't work due to an error in assume
      zip([_X],[getprop(x)],assume);
    end_if;
    */
    if x<>_X then f:=subs(f,[_X=C,x=_X],EvalChanges) end_if;
  elif _X <> hold(_X) then
    delete _X;
  end_if;
  //  remove independent factors
  if type(f)="_mult" then
    [f, noX, dummy] := split([op(f)], has, _X);
    assert(dummy = []);
    f := _mult(op(f));
    noX := _mult(op(noX));
  else
    noX := 1;
  end_if;
  
  F := FAIL;

  if transform::fourier::userpatternsFSA <> FAIL then
      F := matchlib::addpatterns::handle_results(
                  matchlib::evalFSA(f, transform::fourier::userpatternsFSA));
  end_if;

  if F = FAIL then
    if transform::fourier::patternFSA <> FAIL then
        F := matchlib::addpatterns::handle_results(
                    matchlib::evalFSA(f, transform::fourier::patternFSA));
    end_if;
  end_if;
  
  if F<>FAIL then F:=subs(noX * F, [_X=x,C=_X]) end_if;
  F
end_proc:
