//      #

// NegInt -- expression to test for negative integers

Type::NegInt:=
    new(Type,
	"NegInt",
	proc(t,x) 
	  name Type::NegInt;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if domtype(x) = DOM_INT then
		return(bool(x < 0))
	    end_if;
	    FAIL
	end_proc,
	FALSE, FALSE):
