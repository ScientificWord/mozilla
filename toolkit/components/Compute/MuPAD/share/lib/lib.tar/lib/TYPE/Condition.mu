//   


/*
    Type::Condition

    the type of conditions
*/

Type::Condition:= new(Type, "Condition",
  proc(t, x)
    name Type::Condition;
  begin
    if args(0) <> 2 then
      return(FALSE)
    end_if;

    case type(x)
      of DOM_IDENT do
      of "isEmpty" do
        return( TRUE );
      of "_and" do
      of "_or" do
        return( _lazy_and( map( op(x), testtype, Type::Condition ) ) );
      of "_equal" do
      of "_less" do
      of "_leequal" do
      of "_unequal" do
        return( _lazy_and( testtype( op(x,1), Type::Union(Type::Arithmetical,Type::Relation) ) or op(x,1)=undefined,
          testtype( op(x,2), Type::Union(Type::Arithmetical,Type::Relation) )or op(x,2)=undefined ) );
      of "_in" do
        return( _lazy_and( testtype( op(x,1), Type::Arithmetical ),
          testtype( op(x,2),Type::Union(Type::Set, Type::Property ) ) ) );
      of "_not" do
        return( testtype( op(x), Type::Condition ) );
      of "_notsubset" do
      of "_subset" do
        return( _lazy_and( testtype( op(x,1), Type::Set ), testtype( op(x,2), Type::Set ) ) );
      otherwise
        case expr2text(type(x))
          of "piecewise" do
            return(_lazy_and( op(map( [op(x)], X->testtype(op(X,2), Type::Condition ) ) )));
        end_case;
        return(FALSE)
    end_case;
    assert( FALSE );
  end_proc,
  FALSE, FALSE ):
