if traperror(module("xmlprint")) <> 0 then
  xmlprint := FAIL;
end_if:
