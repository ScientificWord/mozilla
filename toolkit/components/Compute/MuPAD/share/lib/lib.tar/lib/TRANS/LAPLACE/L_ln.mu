// Dirk Mueller, olorien, 28/10/96, v1.0 

ln::"transform::laplace":=
  proc(_f, var1, var2) 
    local _a, _g;
  begin
    _g:=expand(op(_f));
    _a:=normal(_g/var1);
    if not has(_a, var1) then
      userinfo(10, "formula from M&P");
      return(ln(_a)/var2-ln(var2)/var2-EULER/var2)
    end_if;
    FAIL;
  end_proc:

// end of file 
