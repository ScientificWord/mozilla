// 

// assorted utilities

proc()
  local fl2tex;
  option escape;
begin
  
  fl2tex := x->x;
//  fl2tex("RD_INF") := "\\tilde{\\infty}";
//  fl2tex("RD_NINF") := "-\\tilde{\\infty}";
  fl2tex("RD_INF") := "\\mathrm{RD\\_INF}";
  fl2tex("RD_NINF") := "\\mathrm{RD\\_NINF}";
  fl2tex("RD_NAN") := "\\mathrm{RD\\_NAN}";

  DOM_INTERVAL::TeX := 
  proc(iv, prio)
  begin
    if op(iv, 0) = hold(_union) then
      generate::TeXoperator(" \\cup ", prio, output::Priority::Union, op(iv));
    elif op(iv, 0) = hold(hull) then
      generate::TeXquote(fl2tex(rdfloat2text(op(iv, 1), DIGITS, -1))
			 . "\\,\\ldots\\,"
			 . fl2tex(rdfloat2text(op(iv, 2), DIGITS, 1)),
			 prio, output::Priority::Interval);
    else
      _plus::TeX(_plus, hold(_plus)(Re(iv), hold(_mult)(I,Im(iv))), prio);
    end_if;
  end_proc:
end_proc():


