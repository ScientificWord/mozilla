//       
// 
// olorien, 04/06/96 

alias(c1=IntTrans::c1):
alias(c2=IntTrans::c2):
alias(c3=IntTrans::c3):
alias(c4=IntTrans::c4):

int:=slot(int, "IntTrans::fourier", 
  proc(_f, var1, var2) 
    local u, v, r, s, arg, iarg, varg, range, ana, _a, _b, _c, _d ;
  begin
  if type(_f)="int" then
    arg:=op(_f,1); iarg:=op(_f,2);
    if type(arg)="_mult" and type(iarg)="_equal" then
      u:=op(arg,1); v:=op(arg,2); range:=op(iarg,2);
      if op(u)=op(iarg,1) and op(range,1)=-infinity and
         op(range,2)=infinity then
        varg:=op(v);
        if type(varg)="_plus" then
          if op(varg,1)=var1 and op(varg,2)=-op(iarg,1) then
            r:=op(u,0)(var1); s:=op(v,0)(var1);
            return((IntTrans::fourier)(r, var1, var2)*
              (IntTrans::fourier)(s, var1, var2));
          end_if;
        end_if;
    
      end_if;

    else
      if nops(arg)=1 and type(iarg)="_equal" then
        u:=op(arg,1); v:=op(arg,2); range:=op(iarg,2);
        if op(arg)=op(iarg,1) then
          if not ((ana:=match(op(range,1), hold(_plus)(c1, var1, c2)))=FAIL) then
            if not ((ana:=match(op(range,2), hold(_plus)(c3, var1, c4)))=FAIL) then
              _a:=level(_plus(ana["c1"],ana["c2"]), 2);
              _b:=level(_plus(ana["c3"],ana["c4"]), 2);
              if _c=-_d then 
                return(1);
              end_if;
            end_if;
          end_if;
        end_if;
      end_if;
    end_if;
  end_if;
  return(FAIL);
  end_proc):

unalias(c1):
unalias(c2):
unalias(c3):
unalias(c4):

// end of file 

