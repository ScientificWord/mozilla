//      #

// Integer -- expression to test for integers

Type::Integer := new(Type,
  "Integer",
  proc(t,x) 
    name Type::Integer;
    option noDebug;
        begin
      if args(0) <> 2 then return(FALSE) end_if;
      if domtype(x) = DOM_INT then
    TRUE
      else
    FAIL
      end_if;
  end_proc,
  FALSE, FALSE):
 