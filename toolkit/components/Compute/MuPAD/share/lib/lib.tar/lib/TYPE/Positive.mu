//      #

// Positive -- expression to test for positive real numbers

Type::Positive:=
    new(Type,
	"Positive",
	proc(t,x)
	  name Type::Positive;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_INT, DOM_RAT, DOM_FLOAT}, domtype(x)) then
		return(bool(x > 0))
	    end_if;
	    FAIL
	end_proc,
	FALSE, FALSE):
