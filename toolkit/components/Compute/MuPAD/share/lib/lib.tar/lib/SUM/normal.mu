// required because normal expands 
sum::normal :=
proc(f)
local num, den;
begin
  [num, den]:= normal(f, Expand = FALSE, List = TRUE):
  sum::factor(num)/sum::factor(den)
end_proc:
