//       
// 
// olorien, 05/06/96 

diff:=slot(diff,"IntTrans::invfourier", 
  proc(_f, var1, var2) 
   local _F, nps;
  begin
  if type(_f)="diff" then
    _F:=op(_f,1); nps:=nops(_f)-1;

    if has(_F, var2) or nops(_F)>1 then return(FAIL) end_if;
    if type(_F)="function" and 
    _and(bool(_equal(op(_f,k), var1)) $ k=2..nps+1) then
       return( (-I*var2)^nps*new((IntTrans::invfourier), _F, var1, var2));
     end_if;
   end_if;  
   return(FAIL);
  end_proc):

// end of file 

  
