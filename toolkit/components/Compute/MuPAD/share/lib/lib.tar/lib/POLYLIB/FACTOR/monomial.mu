//   

/*--
faclib::monomial -- get monomial factors and there multiplication, output is
                    given in form:[x,3,y,2,..],x^3*y^2*...(if the input
                    polynomial has factors x^3, y^2 and etc.

faclib::monomial(p)
p - a polynomial in Z 
--*/

faclib::monomial:=proc(p)
local i, pcont, px, q, x;
begin
    userinfo(3, "faclib::monomial called with ".expr2text(p));
    if degree(nthterm(p,nterms(p)))<>0 then
       if (q:=_intersect({op(op(p,2))}, indets(expr(nthmonomial(p,i)),PolyExpr)$i=1..nterms(p)))\
          <>{} then  
	  userinfo(5, "Variables that appear in every monomial: ".
		   expr2text(q));
          pcont:=[];
          // do it for every variable in q 
          for x in q do
              px:=poly(p,[x]);
              pcont:=append(pcont,poly(x,op(p,2..3)),degree(nthterm(px,nterms(px)))); 
          end_for;
          return(pcont,_mult(_power(expr(op(pcont,2*i-1)),\
                                          op(pcont,2*i))$i=1..nops(q)));
       end_if;
    end_if;
    return([],1);
end_proc:
