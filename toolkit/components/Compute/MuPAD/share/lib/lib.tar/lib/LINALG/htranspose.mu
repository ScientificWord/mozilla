// 

/* htranspose.mu
 *
 * linalg::htranspose -- computes the Hermitian transpose of the matrix M
 */

linalg::htranspose := proc(M)
begin
  if M::dom::htranspose <> FAIL then
   return(M::dom::htranspose(args()))
  end_if;

  if M::dom::hasProp(Cat::Matrix) <> TRUE then
     error("First argument should be a matrix or a vector.")
  end;
  return( conjugate(linalg::transpose(M)) )
end:
