//    
// kg, 19/09/95 

/*++
fp::fold -- create folded function

fp::fold(f, [e...])
f - function
e - expression

fold(f,e) returns the function 
	() +-> e,
	(x1,x2,...,xn) +-> f(xn,...f(x2,f(x1,e))...)
++*/

fp::fold:= proc(f) 
  option escape; 
  local e; 
begin
  if args(0) = 0 then 
    error("Wrong number of arguments");
  end_if;
  e:= args(2..args(0));
  
  proc() 
    local i, r; 
  begin
	  r:= e;
	  for i from 1 to args(0) do
	    r:= f(args(i), r)
	  end_for;
	  r;
  end_proc
end_proc:

// end of file 
