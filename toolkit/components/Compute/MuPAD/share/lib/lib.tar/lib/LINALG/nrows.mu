/*
 linalg::nrows  --  returns the number of rows of a matrix
*/

linalg::nrows := proc(x)
begin
 if testargs() then
   if args(0) <> 1 then error("expecting 1 argument")
   elif x::dom::hasProp( Cat::Matrix ) <> TRUE then
     error("argument is not of 'Cat::Matrix'")
   end_if
 end_if;
 op( x::dom::matdim(x),1 )
end_proc:

