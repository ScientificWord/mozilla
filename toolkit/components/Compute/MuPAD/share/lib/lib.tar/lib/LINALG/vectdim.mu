/*
 linalg::vecdim(v) -- returns the dimension of vector v
*/

linalg::vecdim:= proc(v)
begin
 if testargs() then
   if args(0) <> 1 then error("expecting one argument") 
   elif not testtype( v,linalg::vectorOf(Type::AnyType) ) then
     error("expecting a vector")
   end_if
 end_if;
 v::dom::nops(v)
end_proc:

