//      #

// NegRat -- expression to test for negative rationals

Type::NegRat:=
    new(Type,
	"NegRat",
	proc(t,x)
	  name Type::NegRat;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_INT, DOM_RAT}, domtype(x)) then
		return(bool(x < 0))
	    end_if;
	    FAIL
	end_proc,
	FALSE, FALSE):
