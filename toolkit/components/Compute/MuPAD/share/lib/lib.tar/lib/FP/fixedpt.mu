//    
// kg, 19/09/95 

/*++
fp::fixedpt -- return fixed point of function

fp::fixedpt(f)
f - function

This is the Y combinator. Given a function f it returns the 
fixed point of f:
	Y: f +-> h(f)(h(f))
with
	h: F +-> (g +-> (x +-> F(g(g))(x)))
++*/

fp::fixedpt:= proc(f) 
  option escape; 
begin
  if args(0) = 0 then 
    error("Wrong number of arguments"); 
  end_if;

  proc(F) option escape; begin
	  proc(g) option escape; begin
	    proc(x) begin
		    F(g(g))(x)
	    end_proc
	  end_proc
  end_proc (f);
  %(%)
end_proc:

// end of file 
