//      #

// Rational -- expression to test for rational integers

Type::Rational:=
    new(Type,
	"Rational",
	proc(t,x)
	  name Type::Rational;
	  option noDebug;
	begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_INT, DOM_RAT}, domtype(x)) then
		TRUE
	    else
		FAIL
	    end_if;
	end_proc,
	FALSE, FALSE):
