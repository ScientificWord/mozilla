// 

// the beta function for intervals, implemented via the gamma function
// (which may be a bad idea causing substantial overestimation)

DOM_INTERVAL::beta := proc(x,y)
local xx, yy;
begin
  xx := interval(x);
  yy := interval(y);

  if xx::dom <> DOM_INTERVAL or yy::dom <> DOM_INTERVAL
  then
    if y::dom <> DOM_INTERVAL and y::dom::beta <> FAIL
    then return(y::dom::beta(x, y));
    else return(hold(beta)(x, y));
    end_if;
  end_if;

  DOM_INTERVAL::gamma(xx)*DOM_INTERVAL::gamma(yy)/
      DOM_INTERVAL::gamma(xx+yy);
end_proc:
