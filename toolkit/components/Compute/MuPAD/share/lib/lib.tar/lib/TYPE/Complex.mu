/*++
Complex -- expression to test for complex numbers

Complex
++*/

Type::Complex:=
  new(Type,
      "Complex",
      proc(t,x)
	name Type::Complex;
	option noDebug;
      begin
        if args(0) <> 2 then return(FALSE) end_if;
        if contains({DOM_INT, DOM_RAT, DOM_FLOAT, DOM_COMPLEX}, domtype(x)) then
          TRUE
        else
          FAIL
        end_if;
      end_proc,
      FALSE, FALSE):
