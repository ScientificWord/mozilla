//    
// kg, 19/09/95 

/*++
fp::apply -- apply function

fp::apply(f, [e...])
f - function
e - expression

apply(f,e) returns f(e).
++*/

fp::apply := proc(f)
begin
  if args(0) < 1 then
    error("Wrong number of arguments");
  end_if;
  
  f(args(2..args(0)));
end_proc:

// end of file 
