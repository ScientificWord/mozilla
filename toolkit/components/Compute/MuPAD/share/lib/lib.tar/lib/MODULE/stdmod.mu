if traperror(module("stdmod")) <> 0 then
  stdmod := FAIL;
end_if:
