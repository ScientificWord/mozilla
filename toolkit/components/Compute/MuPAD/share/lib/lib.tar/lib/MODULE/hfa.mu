if traperror(module("hfa")) <> 0 then
  hfa := FAIL;
end_if:
