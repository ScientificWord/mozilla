//    

// kg, 14/09/94 

/*--
gcdlib::norm_modp -- normalize residue class polynomial

gcdlib::norm_modp(a, b)

a,b - residue class polynomials

a is normalized.
--*/

gcdlib::norm_modp:= proc(a/*,b*/)
begin
    multcoeffs(a, 1/lcoeff(a))
end_proc:

// end of file 
