//    

// kg, 14/09/94 

/*--
gcdlib::norm_intp -- normalize integer polynomial

gcdlib::norm_intp(a, b)

a,b - integer polynomials

a divides b over the rationals and is normalized such that it is the
gcd of a and b over the integers.
--*/

gcdlib::norm_intp:= proc(aa, b)
    local a, ca;
begin
    a:=aa;
    if args(0) = 2 then
	ca:= icontent(a);
	a:= multcoeffs(a, igcd(icontent(b), ca) / ca);
    end_if;
    if lcoeff(a) < 0 then -a else a end_if
end_proc:

// end of file 
