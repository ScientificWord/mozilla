
/*
polylib::bezoutResultant(f, g, x)

computes the resultant of f and g via the Bezout matrix

*/

polylib::bezoutResultant:= 
proc(f: DOM_POLY, g: DOM_POLY, x)
  local n;
begin
  n:= degree(f, x);
  (-1)^((n mod 4) div 2) * linalg::det(linalg::bezout(f, g, x))
end_proc:
 
// end of file
