if traperror(module("shell")) <> 0 then
  shell := FAIL;
end_if:
