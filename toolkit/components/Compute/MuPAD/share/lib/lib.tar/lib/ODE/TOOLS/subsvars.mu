// substitutes y(a,z,b,...) by y(z) where l=[a,z,b,...] and z=l[n] 
ode::subsvars:= proc(eq,y,n,l,solveOptions={},odeOptions={}) 
  local m;
begin
  case type(eq)
    of DOM_SET do
    of "_equal" do
    of "_plus" do
    of "_mult" do
    of "_power" do 
      return(map(eq,ode::subsvars,y,n,l,solveOptions,odeOptions));
    of "diff" do 
      if op(eq,1)=y(op(l)) then
        return(subsop(eq,1=y(l[n])));
      else 
        return(eq); 
      end_if;
    of "function" do
      if type(op(eq,0))="D" then
         if op(eq,[0,2])=y then
            m:= op(eq,[0,1]);
            if {op(m)}<>{n} then 
              error("other variables appear"); 
            end_if;
            return(diff(y(l[n]),l[n]$nops(m)));
         end_if;
      elif eq=y(op(l)) then 
         return(y(l[n]));
      end_if;
    otherwise 
      return(eq);
   end_case;
   
end_proc:
