/**
   Allow for overloading support.
**/

polylib::support :=
proc(p: Type::AnyType)
begin
    if domtype(p)=DOM_POLY then
	return(map(poly2list(p), op, 2));
    end_if;
    if p::dom::support<>FAIL then
	return(p::dom::support(p));
    end_if;
    if domtype(extop(p,1))=DOM_POLY then // temporary until support is
	// defined as a method of Dom::UnivariatePolynomial & such
	return(polylib::support(extop(p,1)));
    end_if;
    return(hold(polylib::support)(args()));
end_proc:
