//      #

// IntImaginary -- expression to test for intimaginary numbers

Type::IntImaginary:=
    new(Type,
	"IntImaginary",
	proc(t,x) 
	  name Type::IntImaginary;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if domtype(x) = DOM_COMPLEX then
	        if iszero(Re(x)) then
		    bool(domtype(Im(x)) = DOM_INT)
	        end_if
	    else
		FAIL
	    end_if;
	end_proc,
	FALSE, FALSE):
