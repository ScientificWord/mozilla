//     

//Residue Class -- expression to test for residue class

Type::Residue:=
  proc(RM = 0, CL = 0 : DOM_INT, ST = Type::Integer)
  begin
    if stdlib::hasmsign(CL) then
      CL := -CL;
    end_if;
    if CL <> 0 then
      RM := modp(RM, CL);
    end_if;
    new(Type,
          "Residue",
	  proc(t,x)
	    name Type::Residue;
            option noDebug;
          begin
            if args(0) <> 2 then return(FALSE) end_if;
            if domtype(x) = DOM_INT then
              bool((x mod op(t, 2)) = op(t, 1))
              and testtype(x, op(t, 3))
            else
              FALSE
            end_if
          end_proc,
          [RM, CL, ST], FALSE);
  end_proc:
