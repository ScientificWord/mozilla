
proc()
  save patternFSA, invpatterns ;
begin
  unprotect(patternFSA);
  if traperror(read(pathname("TRANS").pathname("ZTRANS")."patternFSA.mb", Plain)) = 0 then
    transform::ztrans::patternFSA := patternFSA;
  else
    transform::ztrans::patternFSA := FAIL;
  end_if;
  unprotect(invpatterns);
  if traperror(read(pathname("TRANS").pathname("ZTRANS")."invpatterns.mb", Plain)) = 0 then
    transform::invztrans::patterns := invpatterns;
  else
    transform::invztrans::patterns := FAIL;
  end_if;
end():

prog::setcheckglobals(transform::ztrans,
  hold({_X, _Y})):
