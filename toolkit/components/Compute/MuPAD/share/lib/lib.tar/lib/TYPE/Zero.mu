//      #

// Zero -- expression to test for zero numbers

Type::Zero:=
    new(Type,
	"Zero",
	proc(t,x)
	  name Type::Zero;
	  option noDebug;
	begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    iszero(x)
	end_proc,
	FALSE, FALSE):
