/*
 linalg::tr(A) -- returns the trace of a square matrix

 This function uses the method "tr" of Matrix.
 See file 'Matrix.mu' for further details.
*/

linalg::tr:= proc(A)
begin
 if testargs() then
   if args(0) <> 1 then error("expecting 1 argument")
   elif A::dom::hasProp( Cat::Matrix ) <> TRUE then
     error("argument is not of 'Cat::Matrix'")
   end_if
 end_if;
  A::dom::tr( A )
end_proc:

