//    

/*--
	exp/sign -- the function attribut "sign" for exp
--*/

exp::sign:=
  proc(x)
    local a;
  begin
    a := op(x, 1);
    if testtype(a, Type::Real)
      or testtype(sign(a), Type::Real) then
      return(1)
    end_if;
    if domtype(a) = DOM_COMPLEX then
      if domtype(op(a,1)) = DOM_FLOAT
        or domtype(op(a,2)) = DOM_FLOAT then
        return( exp(I*Im(a)) )
      end_if
    end_if;
    if not has(a, infinity) then
      a := Im(a);
      if not has(a,{Im,Re}) then
        return(exp(I*a))
      end_if
    end_if;
    hold(sign)(x)
  end_proc:

// end of file 
