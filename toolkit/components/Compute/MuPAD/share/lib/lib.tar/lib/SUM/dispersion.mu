sum::dispersion :=
proc(q,x) // q is a polynomial 
  local X,r,i,s;
begin
  X:= genident("X"):
  q:=normal(q/content(q,[x]));
  r:=polylib::resultant(q,subs(q,x=x+X),x);
  r:=factor(r);
  s:={};
  for i from 2 to nops(r) step 2 do
    // this is because iroots does not like other variables
    if indets(op(r,i))={X} then
      s:=s union solvelib::iroots(op(r,i))
    end_if;
  end_for;
   // no multiplicity for iroots 
  max(op(s))
end_proc:

