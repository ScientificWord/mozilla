/*++
Type::Even -- type to test for even numbers
++*/

Type::Even:=new(Type,
          "Residue",
	  proc(t,x)
	    name Type::Residue;
            option noDebug;
          begin
            if args(0) <> 2 then return(FALSE) end_if;
            if domtype(x) = DOM_INT then
              bool((x mod op(t, 2)) = op(t, 1))
              and testtype(x, op(t, 3))
            else
              FALSE
            end_if
          end_proc,
        [0, 2, Type::Integer], FALSE):
