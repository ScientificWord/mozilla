// Note:    transform::invfourier(f(s), s, t) 
//    = 1/2/PI*transform::fourier(f(s), s, -t)
// Use the fourier pattern matcher for invfourier, too:

transform::invfourier::addpattern :=
proc(pattern, varin, varout, result, pat_vars, conds)
option hold;
begin
  /*
  pattern := context(pattern);
  varin := context(varin);
  varout := context(varout);
  result := context(hold(matchlib::block)(result));
  result := 1/2/PI * eval(subs(result, varout = -varout));
  */
  context(hold(transform::fourier::addpattern)
	  (pattern, varin, varout,
	   2*PI*hold(subs)(result, varout=-varout),
	   args(5..args(0))));
end_proc:
