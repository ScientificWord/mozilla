// Dirk Mueller, olorien, 28/10/96, v1.0 

cos::"transform::laplace":=
  proc(_f, var1, var2) 
    local ana, _a, _b;
  begin
   _f:= expand(op(_f));
   _a:= normal(_f/var1);
    if not has(_a, var1) then
      userinfo(10, "formula 13 from Heuser");
      return(var2/(var2^2+_a^2) )
    else
      if testtype(_f, Type::RatExpr(var1) ) then
        ana:=transform::IntTrans::anapol(_f, var1);
        case ana[1][1]
          of [1,3] do
            _a:=ana[2][1][2]; _b:=ana[2][1][1];
            userinfo(10, "formula 19 from Heuser");
            return( (var2*cos(_b)-_a*sin(_b))/(var2^2+_a^2) );
        end_case;
      end_if;
    end_if;
    FAIL;

  end_proc:

// end of file 
