alias(Lisp=generate::lisp): 
alias(Seq=generate::lisp_seq):

Lisp := proc(e) 
   option remember;
   local s;
begin
   s:= e::dom::lisp;
   if s <> FAIL then 
     s(args());
   else 
     expr2text(e);
   end_if;
end_proc:

Lisp(arccos):="ARCCOS":

// method "lisp" for other domains 
DOM_INT::lisp:=expr2text:

DOM_EXPR::lisp:=proc(e) 
   local t;
begin
   t:= eval(op(e,0));
   if domtype(t) = DOM_FUNC_ENV then
      t:= slot(t,"lisp");
      if t <> FAIL then 
         return(t(op(args())));
      end_if;
   elif type(e)="function" then 
      return("(".Lisp(op(e,0)).Seq(e," ").")");
   end_if;
   expr2text(e);
end_proc:

// Seq([a,b,c]," ") -> " a", " b", " c" 
Seq:= proc(l,s) 
    local i;
begin
    if nops(l)=0 then 
       "";
    else 
       s.Lisp(op(l,i)) $ i=1..nops(l);
   end_if
end_proc:

// function attributes 
_plus:=slot(_plus,"lisp",(()->("(+".Seq([args()]," ").")"))):

_mult:=slot(_mult,"lisp",(()->("(*".Seq([args()]," ").")"))):

_power:=slot(_power,"lisp",(()->("(EXPT ".Lisp(args(1))." ".Lisp(args(2)).")"))):
