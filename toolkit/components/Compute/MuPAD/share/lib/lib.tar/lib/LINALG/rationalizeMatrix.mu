// linalg::rationalizeMatrix(A, <ReturnType = matrixconstructor>)

linalg::rationalizeMatrix:= proc(A)
local Mat, m, n, subsargs, arg, subst;
begin
  Mat:= A::dom;
  [m, n]:= Mat::matdim(A):
  subsargs:= null();
  for arg in [args(2..args(0))] do
     if has(arg, ReturnType) then
        assert(type(arg) = "_equal"):
        Mat:= op(arg, 2);
     else
        subsargs:= subsargs, arg;
     end_if;
  end_for;

  [A, subst]:= [rationalize([op(A)], subsargs)];
  Mat(m, n, A), subst;
end_proc:
  
