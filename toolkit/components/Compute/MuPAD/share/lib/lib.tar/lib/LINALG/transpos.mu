/*++
  transpos.mu

  linalg::transpose  --  computes the transpose of a matrix
++*/

linalg::transpose := proc(x)
begin
 if testargs() then
   if args(0) <> 1 then error("expecting one argument")
   elif x::dom::hasProp( Cat::Matrix ) <> TRUE then
     error("argument is not of 'Cat::Matrix'")
   end_if
 end_if;
 x::dom::transpose(x)
end_proc:

linalg::transpose := funcenv(linalg::transpose):
linalg::transpose::Content := stdlib::genOutFunc("Ctranspose", 1):

// end of file 
