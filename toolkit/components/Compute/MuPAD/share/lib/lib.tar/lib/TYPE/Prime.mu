//      #

// Prime -- expression to test for prime numbers

Type::Prime:=
new(Type,
    "Prime",
    proc(t,x)
      name Type::Prime;
      option noDebug;
    begin
      if args(0) <> 2 then
        return(FALSE)
      end_if;
      if domtype(x) = DOM_INT then
        isprime(x)
      else
        FAIL
      end_if;
    end_proc,
    FALSE, FALSE):
