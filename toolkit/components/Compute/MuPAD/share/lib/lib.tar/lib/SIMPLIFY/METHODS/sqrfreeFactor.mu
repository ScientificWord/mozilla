// squarefree factorization, using algebraic dependencies


Simplify::sqrfreeFactor:= x -> Factored::convDOM2expr(polylib::sqrfree(x)):
//Simplify::sqrfreeFactor:= x -> Factored::convert_to(polylib::sqrfree(x), DOM_EXPR):