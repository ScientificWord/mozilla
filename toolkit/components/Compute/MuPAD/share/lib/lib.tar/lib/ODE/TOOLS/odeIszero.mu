// Heuristic zero test in order to improve performance before applying 
// symbolic zero test using 'expand', 'normal' etc. that may be costly. 

ode::odeIszero:= 
proc(x)
begin 
  testeq(x, 0, 
         Steps = 0,               
         Seconds = infinity, 
         hold(NumberOfRandomRatTests) = 2,
         // cannot use more random tests here (problem in numeric::isnonzero)
         NumberOfRandomTests = 4,   
         IgnoreProperties = TRUE, 
         hold(ZeroTestMode) = TRUE) 
end_proc:

// end of file
