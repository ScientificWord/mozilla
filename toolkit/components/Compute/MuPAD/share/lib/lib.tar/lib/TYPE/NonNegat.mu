//      #

// NonNegative -- expression to test for non-negative real numbers

Type::NonNegative:=
    new(Type,
	"NonNegative",
	proc(t,x) 
	  name Type::NonNegative;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_INT, DOM_RAT, DOM_FLOAT}, domtype(x)) then
		return(bool(x >= 0))
	    end_if;
	    FAIL
	end_proc,
	FALSE, FALSE):
