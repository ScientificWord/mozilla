

dirac:=slot(dirac, "transform::fourier",
  proc(_f, var1, var2)
  begin
    if op(_f)=var1 then
      userinfo(3, "formula 12 from Foellinger");
      return(1)
    end_if;
    FAIL;
  end_proc):


// end of file 
