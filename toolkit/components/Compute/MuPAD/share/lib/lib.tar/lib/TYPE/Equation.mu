//      

/*++
Equation - returns type expression to test equations

Equation(lS, rS)

++*/

Type::Equation:=
proc(ls = Type::AnyType, rs = Type::AnyType)
  option escape, noDebug;
begin
  if type(ls) = "_equal" and args(0) < 2 then
    rs:= op(ls, 2);
    ls:= op(ls, 1)
  end_if;
  new(Type,
      "Equation",
      (proc(t,x)
	 option noDebug;
	 name Type::Equation;
      begin
         if type(x) = "_equal" then
	   return(testtype(op(x, 1), ls) and testtype(op(x, 2), rs))
	 end_if;
         FALSE
       end_proc),
      [ ls, rs ], FALSE)
end_proc:

// end of file 
