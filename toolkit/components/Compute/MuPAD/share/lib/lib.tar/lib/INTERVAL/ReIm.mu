// 

DOM_INTERVAL::Re := proc(iv)
 local t;
begin
 if iv::dom <> DOM_INTERVAL then
   if iv = {} then return(iv); end_if;
   return(FAIL);
 end_if;

 // union of intervals?
 if op(iv, 0) = hold(_union)
 then
   return(_union(map(op(iv), DOM_INTERVAL::Re)));
 end_if;

 t := op(iv, 1);

 if t::dom = DOM_INTERVAL
 then return(t);
 else return(iv);
 end_if;
end_proc:

DOM_INTERVAL::Im := proc(iv)
 local t;
begin
 if iv::dom <> DOM_INTERVAL then
   if iv = {} then return(iv); end_if;
   return(FAIL);
 end_if;

 // union of intervals?
 if op(iv, 0) = hold(_union)
 then
   return(_union(map(op(iv), DOM_INTERVAL::Im)));
 end_if;

 t := op(iv, 2);

 if t::dom = DOM_INTERVAL
 then return(t);
 else return(0...0);
 end_if;
end_proc:

