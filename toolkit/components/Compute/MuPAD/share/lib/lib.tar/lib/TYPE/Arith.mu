//     


/*

Arithmetical -- the type of all arithmetical expressions
without equations/inequations

*/


Type::Arithmetical :=
newDomain("Type::Arithmetical"):

Type::Arithmetical::non_arith_fns :=
{"_and", "_approx", "_assign", "_break", "_case", "_equal", "_equiv", "_exprseq", "_fconcat", "_fnest", "_for", "_for_down", "_for_in", "_if", "_implies", "_in", 
"_intersect", "_lazy_and", "_lazy_or", "_leequal", "_less", "_minus", "_next", "_not", "_or", "_range", "_repeat", "_seqbegin", 
"_seqgen", "_stmtseq", "_subset", "_unequal", "_union", "_while", "_xor"}:

Type::Arithmetical::arith_fns :=
{DOM_IDENT, DOM_INT, DOM_RAT, "function", DOM_COMPLEX, DOM_FLOAT, DOM_INTERVAL, "_index"}:


Type::Arithmetical::testtype :=
  proc(x, t)
    option noDebug;
  begin
    if args(0) <> 2 or x = Type::Arithmetical then
      return(FAIL)
    end_if;

    findtype(x, 
    // these are arithmetical expressions:
    Type::Arithmetical::arith_fns,
    // these are DOM_EXPR but not arithmetical:
    Type::Arithmetical::non_arith_fns,
    // recursion needed
    {DOM_EXPR},
    // default
    FALSE,
    "testtype",
    t
    )
    
  end_proc:


null():

// end of file

