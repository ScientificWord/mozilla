

sign:=slot(sign,"transform::fourier",
  proc(_f, var1, var2)
  begin
    if op(_f)=var1 then
      userinfo(3, "formula 17 from Foellinger");
      return(2/I/var2);
    end_if;
    FAIL;
  end_proc):



// end of file 
