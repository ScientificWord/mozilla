//      #

// PosRat -- expression to test for positive rationals

Type::PosRat:=
    new(Type,
	"PosRat",
	proc(t,x)
	  name Type::PosRat;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_INT, DOM_RAT}, domtype(x)) then
		return(bool(x > 0))
	    end_if;
	    FAIL
	end_proc,
	FALSE, FALSE):
