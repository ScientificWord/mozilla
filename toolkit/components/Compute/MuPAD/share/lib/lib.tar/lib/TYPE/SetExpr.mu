//   


/*

    Type::Set

    the type of set-theoretic formulas



*/

Type::Set:= 
newDomain("Type::Set"):

Type::Set::testtype:=
proc(x, t)
     option noDebug;
begin
      if args(0) <> 2 then
        return(FALSE)
      end_if;

      findtype(x, 
      // these are sets
      // DOM_IDENT is not quite accurate: we would need to exclude PI, CATALAN, ...
      {DOM_IDENT, DOM_SET, DOM_INTERVAL, "cartesianProduct"},
      // need not enumerate all non-sets since FALSE is the default
      {},
      // recurse:
      {"_union", "_minus", "_intersect"},
      // default:
      FALSE,
      "testtype",
      t
      )

end_proc:

