//   

/*--
faclib::getprime -- get a prime number that is larger than p and does not
                    divide a, output is a prime number.

faclib::getprime(a,p) 
a -an integer number
p -a positive integer number
--*/

faclib::getprime:=proc(a,pp)
local p;
begin
    p:=pp;
    repeat p:=nextprime(p+1); 
    until a mod p<>0 end_repeat;
end_proc:

