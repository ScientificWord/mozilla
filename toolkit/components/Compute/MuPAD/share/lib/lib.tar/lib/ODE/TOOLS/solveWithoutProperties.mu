/*
 
  This function is a wrapper for using 'solve' on its arguments 
  ignoring all properties set for variables or expressions in 
  the equation(s) to be solved. 

*/

ode::solveWithoutProperties:= proc() 
begin
  unassume(args(1));
  return(solve(args()));
end_proc: