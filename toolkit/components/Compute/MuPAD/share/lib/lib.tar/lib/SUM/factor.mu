sum::factor :=
proc(f)
  local i,l;
begin
  l:=factor(f);
  // Anpassung an Aenderung von Factored::_index (Walter 29.12.04)
  l:= coerce(l, DOM_LIST):
  _mult(l[1],l[2*i]^l[2*i+1]$i=1..nops(l) div 2)
end_proc:

