// 
//       
// 
// olorien, 2/06/96 

alias ( IntTrans= transform::IntTrans);

sin:=slot(sin,"transform::fourier",
  proc(_f, var1, var2) 
    local _a;
  begin
    _a:=op(_f)/var1;
    if not has(_a, var1) then
      userinfo(3, "formula 15 from Foellinger");
      return(I*PI*(dirac(var2+_a)-dirac(var2-_a)) )
    end_if;
    FAIL;
  end_proc):

unalias(IntTrans):
// end of file 
