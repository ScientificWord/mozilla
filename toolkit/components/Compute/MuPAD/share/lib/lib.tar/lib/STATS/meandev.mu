//this procedure returns the meandeviation
// stats::meandev(d1,..,dn)=1/n*(abs(d1-x)+..+abs(d.n-x))
// where x is the mean of the data d1, .., d.n

stats::meandev:=proc()
local data, n, X;
begin
  if args(0)<1 then 
     error("expecting at least one argument")
  end_if:
  data:= stats::getdata(testargs(), "all_data", 1, args(1..args(0))):
  if domtype(data) = DOM_STRING then
     error(data) 
  end_if:
  n:= nops(data):
  X:= _plus(op(data))/n;
  data :=map(data, abs@_subtract, X):
  return(_plus(op(data))/n);
end_proc:
