numeric::startHardwareFloats:= proc(string)
option remember;
begin
   if domtype(hfa) <> DOM_DOMAIN then
         module("hfa");
   end_if:
   if args(0) = 0 then
      bool(domtype(hfa) = DOM_DOMAIN);
   else
      bool(domtype(hfa) = DOM_DOMAIN and slot(hfa, string) <> FAIL);
   end_if;
end_proc;
