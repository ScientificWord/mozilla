//       

/*--
usage:
sample2list(s)

converts type stats::sample to DOM_LIST using (stats::sample)::convert_to
--*/
/*--
parameters:
s  stats::sample
--*/

stats::sample2list := proc()
begin
  if testargs() then
    if args(0) <> 1 then
      error("Wrong number of arguments")
    end_if;
    if domtype(args(1)) <> stats::sample then
      error("stats::sample expected")
    end_if;
  end_if;
  (stats::sample)::convert_to(args(1), DOM_LIST)
end_proc:


// end of file 
 
