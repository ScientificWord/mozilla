//      #

// NonZero -- expression to test for numbers <> zero

Type::NonZero:=
    new(Type,
	"NonZero",
	proc(t,x) 
	  name Type::NonZero;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    not iszero(x)
	end_proc,
	FALSE, FALSE):
