// 
//       
// 
// olorien, 04/06/96 


dirac:=slot(dirac, "IntTrans::invfourier",
  proc(_f, var1, var2) 
  begin
    if op(_f)=var1 then
      return(1/(2*PI));
    end_if;
    FAIL;
  end_proc):


// end of file 
