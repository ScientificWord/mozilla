// Dirk Mueller, olorien, 28/10/96, v1.0 

diff::"transform::laplace":=
  proc(_f, var1, var2) 
   local k, _F, nps;
  begin
   if type(_f)="diff" then
     _F:=op(_f,1); nps:=nops(_f)-1;

     if has(_F, var2) or nops(_F)>1 then return(FAIL) end_if;

     if type(_F)="function" and 
    _and(bool(_equal(op(_f,k), var1)) $ k=2..nps+1) then
       return( var2^(nps)*transform::laplace(_F, var1, var2)+
               _plus(-var2^(nps-k)*fp::nest(D,k-1)(op(_F,0))(0)
                  $ k=1..nps));
     end_if;
   end_if;
   return(FAIL);
  end_proc:

// end of file 

