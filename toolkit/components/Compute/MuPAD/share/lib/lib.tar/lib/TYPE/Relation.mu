/*++

Relation -- expression to test for a relation

Relation

++*/

Type::Relation:=
      new(Type,
	  "Relation",
	  proc(t,x)
	    name Type::Relation;
	    option noDebug;
	  begin
	      if args(0) <> 2 then return(FALSE) end_if;
	      if contains( {"_equal", "_unequal", "_leequal", "_less"}, type(x) ) then
		  TRUE
	      else
		  FAIL
	      end_if
	  end_proc,
	  FALSE, FALSE
	  ):

// end of file
