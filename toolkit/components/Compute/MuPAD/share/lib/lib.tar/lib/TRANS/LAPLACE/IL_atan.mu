// Dirk Mueller, olorien, 28/10/96, v1.0 

alias( IntTrans = transform::IntTrans ):

arctan::"transform::invlaplace":=
  proc(_f, var1, var2) 
     local _c;
  begin
    _c:=op(_f)*var1;
    if not has(_c, var1) then
      userinfo(10, "formula 66 from Heuser");
      return(sin(_c*var2)/var2)    
    end_if;
    FAIL
  end_proc:

unalias( IntTrans ):

// end of file 

