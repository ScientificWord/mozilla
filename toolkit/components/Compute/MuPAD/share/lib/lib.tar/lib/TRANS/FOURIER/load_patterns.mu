
proc()
  save patternFSA, invpatternFSA ;
begin
  unprotect(patternFSA);
  if traperror(read(pathname("TRANS").pathname("FOURIER")."patternFSA.mb", Plain)) = 0 then
    transform::fourier::patternFSA := patternFSA;
  else
    transform::fourier::patternFSA := FAIL;
  end_if;
end():
