//      #

//Real -- expression to test for real numbers

Type::Real:=
    new(Type,
	"Real",
	proc(t,x)
	  name Type::Real;
	  option noDebug;
	begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_INT, DOM_RAT, DOM_FLOAT}, domtype(x)) then
		TRUE
	    else
		FAIL
	    end_if;
	end_proc,
	FALSE, FALSE):
