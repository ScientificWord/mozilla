/*++
  nnz.mu

	linalg::nonZeros -- returns the no of non-zeros of a matrix
++*/

linalg::nonZeros:= proc(x)
begin
    if testargs() then
        if args(0) <> 1 then error("expecting 1 argument")
        elif x::dom::hasProp( Cat::Matrix ) <> TRUE then
            error("argument is not of 'Cat::Matrix'")
        end_if
    end_if;
    return(x::dom::nonZeros(x))
end_proc:

// end of file 
