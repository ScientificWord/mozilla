
proc()
  save patternFSA, invpatternFSA ;
begin
  unprotect(patternFSA);
  if traperror(read(pathname("TRANS").pathname("LAPLACE")."patternFSA.mb", Plain)) = 0 then
    transform::laplace::patternFSA := patternFSA;
  else
    transform::laplace::patternFSA := FAIL;
  end_if;
  if traperror(read(pathname("TRANS").pathname("LAPLACE")."invpatternFSA.mb", Plain)) = 0 then
    transform::invlaplace::patternFSA := invpatternFSA;
  else
    transform::invlaplace::patternFSA := FAIL;
  end_if;
end():
