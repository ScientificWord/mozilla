
  proc()
    save vcam;
  begin
    if traperror(module("vcam")) <> 0 then
      stdlib::vcam := FAIL;
    else
      stdlib::vcam := vcam;
    end_if:
  end_proc():
  
  null():

