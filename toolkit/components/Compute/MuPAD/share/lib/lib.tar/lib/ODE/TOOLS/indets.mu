// gives all the terms of the form y(...) or diff(y(...),...) or D(D(...))(...)
// y is a set of names 

ode::odeIndets:= proc(eq,y={})
  local i,solveOptions,odeOptions;
begin
  if args(0) > 2 then 
    solveOptions:= args(args(0)-1);
    odeOptions:= args(args(0));
    if type(solveOptions) <> DOM_SET or type(odeOptions) <> DOM_SET then 
      error("wrong type of additional arguments");
    end_if;
  end_if;
  case type(eq)
    of DOM_IDENT do return({});
    of "_plus" do
    of "_mult" do
    of "_power" do
    of "_equal" do return(_union(ode::odeIndets(op(eq,i),y,solveOptions,odeOptions) $ i=1..nops(eq)))
    of "diff" do if contains(y,op(eq,[1,0])) then {eq} else {} end_if; break
    otherwise 
      if not has(eq,y) then 
        return({});
      elif contains(y,op(eq,0)) then 
        return({eq});
      elif type(op(eq,0))="D" then
        if ode::indets2(op(eq,0),y,solveOptions,odeOptions) then 
          return({eq})
        else 
          return({})
        end_if
      elif nops(eq)=1 then 
        return(ode::odeIndets(op(eq),y,solveOptions,odeOptions));
      else 
        return(_union(map(op(eq),ode::odeIndets,y,solveOptions,odeOptions))); 
      end_if;
    end_case;
    
end_proc:

// returns true iff eq=(D@@k)(f) for f in y 
ode::indets2 := proc(eq,y,solveOptions,odeOptions)
begin
   if type(eq)="D" then 
     return(ode::indets2(op(eq),y,solveOptions,odeOptions));
   else 
     return(contains(y,eq));
   end_if;
end_proc:

