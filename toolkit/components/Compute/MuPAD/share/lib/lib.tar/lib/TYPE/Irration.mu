//     

// Irrational -- expression to test for irrationals

Type::Irrational:=
    new(Type,
	"Irrational",
	proc(t,x) 
	  name Type::Irrational;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    //if domtype(x) = DOM_FLOAT then
		//TRUE
	    //else
		FAIL
	    //end_if;
	end_proc,
	FALSE, FALSE):
