
proc()
  save patternFSA;
begin
  unprotect(patternFSA);
  if traperror(read(pathname("SUM")."patternFSA.mb", Plain)) = 0 then
    sum::patternFSA := patternFSA;
  else
    sum::patternFSA := FAIL;
  end_if;
end():
