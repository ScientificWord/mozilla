//      #

//
// Property -- type to identify properties
//

Type::Property:=
    new(Type,
	"Property",
	proc(t, x)
	  name Type::Property;
	  option noDebug;
	begin
	  if args(0) <> 2 then return(FAIL); end_if;
          if domtype(x) = DOM_EXPR then
            bool(_lazy_and(op(map([op(x)], testtype, Type::Property))) = TRUE)
          elif contains({"Interval", "Residue"}, type(x)) then
            TRUE
          else
            contains({Type::Integer, Type::Zero, Type::Negative, Type::Rational,
              Type::NegInt, Type::NonZero, Type::Imaginary, Type::Positive,
              Type::NonNegInt, Type::IntImaginary, Type::NonNegative,
              Type::NonNegRat, Type::NegRat, Type::PosRat, Type::Irrational,
              Type::Complex, Type::Real, Type::PosInt}, x) or contains(x::dom, "prop")
          end_if
	end_proc,
	FALSE, FALSE):

