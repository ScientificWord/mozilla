
  proc()
    save uspensky;
  begin
    if traperror(module("uspensky")) <> 0 then
      stdlib::uspensky := FAIL;
    else
      stdlib::uspensky := uspensky;
    end_if:
  end_proc():
  
  null():

