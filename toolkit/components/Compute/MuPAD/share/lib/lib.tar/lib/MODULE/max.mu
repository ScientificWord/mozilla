//    

// andi, 13.05.94 

/*++
max  - Set/Get the max. number of simultaneously loadable moduls

max( num )
max( )

num - Integer in the range of 1..256

The function allways returns the current maximum number  of simul-
taneously loadable modules. If 'num' is given, then the maximum is
set to 'num'.  If 'num' modules are loaded, a new modules replaces
an old one.

For more information, refer to the help-document of module 'stdmod'.
++*/

module::max:= proc()
begin
	external("stdmod","max")( args() );
end_proc:

// end of file 
