alias( IntTrans= (transform::IntTrans)):

heaviside:=slot(heaviside, "transform::fourier",
  proc(_f, var1, var2)
    local ana, this_op;
  begin
    this_op:=op(_f);
    if this_op=var1 then
      userinfo(3, "formula 18 from Heuser");
      return(1/I/var2+PI*dirac(var2) )
    end_if;
    if testtype(this_op, Type::RatExpr(var1) ) then
      ana:=IntTrans::anapol(this_op, var1);
      case ana[1][1]
      of [1,3] do
        _a:=ana[2][1][2]; _b:=ana[2][1][1];
        if IntTrans::Minus(_a) then
          return(  PI*dirac(var2)+I*exp(_b/_a*I*var2)/var2   );
        end_if;
        return( PI*dirac(var2)-I*exp(_b/_a*I*var2)/var2  );
      end_case:
    end_if;
    FAIL;

  end_proc):

unalias(IntTrans):
// end of file 
