// Dirk Mueller, olorien, 28/10/96, v1.0 

abs::"transform::laplace":=
  proc(_f, var1, var2) 
    local _g, _a;
  begin
    _g:=op(_f);
    if type(_g)="sin" then
      _a:=op(_g)/var1;
      if not has(_a, var1) then
        userinfo(10, "formula 5.3 from R&K");
        return(_a/(var2^2+_a^2)*coth(PI*var2/(2*_a)))
        //abs(sin(a*t)), Saunders S27, 3
      end_if;
    end_if;  
    FAIL;
  end_proc:

// end of file 
