//    


/*  Type::Boolean

    the type of logical formulas
*/


Type::Boolean :=
new(Type, "Boolean",
    proc(t,x)
      name Type::Boolean;
      option noDebug;
    begin
      if args(0) <> 2 then return(FALSE) end_if;
    
      case domtype(x)
        of DOM_BOOL do
          return(TRUE)
        of DOM_IDENT do
          return(not contains(Type::ConstantIdents, x))
        of DOM_EXPR do
          case type(x)
            of "_less" do
            of "_leequal" do
            of "_equal" do
            of "_unequal" do
            of "_approx" do  
            of "_in" do
            of "isEmpty" do
            of "_subset" do
            of "_notsubset" do  
              return(TRUE)
            of "_and" do
            of "_or" do
            of "_xor" do  
            of  "_not" do
            of "_implies" do
            of "_equiv" do  
              t:= map([op(x)], testtype, Type::Boolean);
              if contains(t, FALSE) > 0 then
                return(FALSE)
              elif contains(t, FAIL) > 0 then
                return(FAIL)
              else
                return(TRUE)
              end_if;
            otherwise
              return(FALSE)
            end_case
          end_case;
      FALSE
    end_proc,
    FALSE, FALSE
):