faclib::powermod_poly := proc(a,n,p) // a^n mod p where p is a polynom (iterative version) 
local y,l,i;
begin
   y:=divide(a,p,Rem);
   l:=numlib::g_adic(n,2);
   for i from nops(l)-1 downto 1 do
      y:=divide(y*y,p,Rem);
      if l[i] = 1 then y:=divide(a*y,p,Rem) end_if
   end_for;
   y
end_proc:


