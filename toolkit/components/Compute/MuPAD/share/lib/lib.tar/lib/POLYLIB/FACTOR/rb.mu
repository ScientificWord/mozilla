/*-- 
faclib::rb -- generate a global form of random number in -b..b, output is an
              integer number.

faclib::rb(b)
b - a positive integer number

faclib::rb may be called by faclib::set_b many times with the same input number, so set "option remember", the form may also be used by faclib::set_b many times, so faclib::Rb is a global variable
--*/

faclib::rb:=proc(b)
option remember;
begin
   sysassign(faclib::Rb, random(-b..b));
end_proc:
