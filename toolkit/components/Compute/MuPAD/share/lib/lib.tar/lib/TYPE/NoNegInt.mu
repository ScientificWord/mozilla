//      #

// NonNegInt -- expression to test for non-negative integers

Type::NonNegInt:=
    new(Type,
	"NonNegInt",
	proc(t,x)
	  name Type::NonNegInt;
	  option noDebug;
         begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if domtype(x) = DOM_INT then
		return(bool(x >= 0))
	    end_if;
	    FAIL
	end_proc,
	FALSE, FALSE):
