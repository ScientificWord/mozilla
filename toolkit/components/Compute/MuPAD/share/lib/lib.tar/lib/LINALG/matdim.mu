/*
    linalg::matdim(A) -- returns the dimension of matrix A in form of
    a list [nrows,ncols].
*/

linalg::matdim:= proc(A)
begin
    if testargs() then
      if args(0) <> 1 then error("expecting one argument")
      elif A::dom::hasProp( Cat::Matrix ) <> TRUE then
        error("argument is not of 'Cat::Matrix'")
      end_if
    end_if;
    return( A::dom::matdim(A) )
end_proc:

