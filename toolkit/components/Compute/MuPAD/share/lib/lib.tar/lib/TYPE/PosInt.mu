//      #

// PosInt -- expression to test for positive integers

Type::PosInt:=
    new(Type,
	"PosInt",
	proc(t,x)
	  name Type::PosInt;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if domtype(x) = DOM_INT then
		return(bool(x > 0))
	    end_if;
	    FAIL
	end_proc,
	FALSE, FALSE):
