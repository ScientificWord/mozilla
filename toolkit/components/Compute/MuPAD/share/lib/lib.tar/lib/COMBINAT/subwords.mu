
/*
combinat::subwords(l)

return a list consisting of all lists that can be obtained by leaving out
some (zero or more) elements of l
*/

combinat::subwords:=
proc(l: DOM_LIST)
  local i, res;
begin
  if nops(l) = 0 then
    return([[]])
  end_if;
  res := [[]];
  for i in l do
    res := res . map(res, append,  i);
  end_for;
  res;
end_proc:
  