/*
combinat::catalan reimplementation
*/

combinat::catalan:=
proc(n:Type::NonNegInt)
begin
  binomial(2*n,n) / (n+1)
end_proc: