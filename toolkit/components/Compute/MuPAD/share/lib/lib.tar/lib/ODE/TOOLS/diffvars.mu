// computes the set of differential variables of eq for function y 

ode::diffvars:= proc(eq,y,solveOptions={},odeOptions={}) 
  local i,l;
begin
  case type(eq)
    of DOM_SET do
    of "_equal" do
    of "_plus" do
    of "_mult" do
    of "_power" do 
      return(_union(ode::diffvars(op(eq,i),y,solveOptions,odeOptions) $ i=1..nops(eq)));
    of "diff" do 
      if op(eq,[1,0])=y then 
        return({op(eq,2..nops(eq))});
      else 
        return({}); 
      end_if;
    of "function" do
      if type(op(eq,0))="D" then
        if op(eq,[0,2])=y then
          l:= op(eq,[0,1]);
          return(map({op(l)},proc() begin op(args(2),args(1)) end_proc ,eq));
          end_if;
       end_if;
    otherwise 
      return({});
  end_case;
end_proc:

