//
// light-weight blockTransparent/unblock

matchlib::block :=
proc(ex)
  option hold;
  local vars;
begin
  ex := context(hold(hold)(ex));
  vars := indets(ex);
  vars := map(vars, v -> if matchlib::isBlock(eval(v)) then 
                           v=eval(v) else null() end);
  ex := subs(ex, vars, Unsimplified);
  ex := misc::maprec(ex,
          matchlib::isBlock = (x -> x[2]),
          Unsimplified);

  array(1..2, [`#matchlib::block`, ex]);
end:

matchlib::isBlock :=
(ex) -> _lazy_and(domtype(ex) = DOM_ARRAY,
                  op(ex, 0) = (1,1..2),
                  ex[1] = `#matchlib::block`):

matchlib::unblock :=
ex -> if matchlib::isBlock(ex) then ex[2] else ex end:
