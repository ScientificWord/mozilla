//    

// andi, 13.05.94 

/*++
age - Set/Get the maximum age for modules (aging control)

age( maxage, interval )
age( maxage )
age( )

maxage   - Integer in the range of 0..3600
interval - Integer in the range of 1..60

The module-aging algorithm unloads all modules,which were not 
used for 'maxage' seconds.   This time is called the age of a
module. If 'maxage' is zero (0),then module-aging is inactive.

'age' always returns the current maximum age.    If the value
'maxage' is given,then the maximum age for all modules is set 
to 'maxage'. If the value 'interval' is also given,  then the
minimum number  of seconds  between  two calls of the  aging-
algorithmis is set to 'interval'.

For more information, refer to the help-document of module
'stdmod'.
++*/

/*--
'module::age' uses the function 'stdmod::age' to (de)activate 
the aging-algorithm. This feature may be used for future ex-
tension (to support interval-timer,to control the calling of
the aging-algorithm ...)
--*/

module::age:= proc()
begin
	external("stdmod","age")( args() );
end_proc:

// end of file 
