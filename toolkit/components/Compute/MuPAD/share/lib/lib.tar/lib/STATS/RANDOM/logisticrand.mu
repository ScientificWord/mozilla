// this procedure computes logistic deviates with parameters a real, b>0
// (the standard deviation)
// according to the distribution function
// 1/2*(1+(tanh(1/2*(x-a)*PI/b/sqrt(3)))) ;
// for given a,b,  f:=logisticRandom(a,b) calls the generator;
// f() returns the
// random numbers

/* ----------------------------------------------------
Walter Oevel, 27.8.01
  - ueberarbeitet, sollte ok sein
  - Todo: - a bit more internal documentation (comments
            in the header) would be nice
          - Apart from this: OK
---------------------------------------------------- */

stats::logisticRandom:=proc(m, s)
local y, fm, fs;
option escape;
begin
  if args(0)<2 then
     error("expecting at least two arguments")
  end_if:
  if args(0)>3 then 
     error("expecting no more than three arguments")
  end_if:

  // ------------- check m -------------
  fm:= float(m):
  if domtype(fm) = DOM_COMPLEX then
     error("the mean must be real");
  end_if;

  // ------------- check s -------------
  fs:= float(s):
  if domtype(fs) = DOM_FLOAT and fs <= 0 then
     error("the standard deviation must be positive"):
  end_if;
  if domtype(fs) = DOM_COMPLEX then
     error("the standard deviation must be real");
  end_if;

  // -----------  check option Seed = s ---------------
  if args(0)=3 then
    if type(args(3))<>"_equal" then
       error("the 3rd argument must be of the form 'Seed = integer' or 'Seed = CurrentTime'"):
    end_if:
    if op(args(3),1)<>Seed then
       error("the 3rd argument must be of the form 'Seed = integer' or 'Seed = CurrentTime'"):
    end_if:
    if domtype(op(args(3),2))<>DOM_INT and op(args(3),2)<>CurrentTime then
       error("the 3rd argument must be of the form 'Seed = integer' or 'Seed = CurrentTime'"):
    end_if:
  end_if:
  // ------ unevaluated return ? --------
  if domtype(fm) <> DOM_FLOAT or
     domtype(fs) <> DOM_FLOAT
  then
    if args(0) = 2 then
         return(procname(args()));
    else // do not accept symbolic a and/or b in conjunction
         // with Seed = s, because otherwise the following would
         // happen:
         // delete a, b: f:= stats::XXXRandom(a, b, Seed = 1):
         // a:= 1: b:= 2: f(), f(), f()
         //     -1.506518279, -1.506518279, -1.506518279
         error("all parameters must be numerical ".
               "if 'Seed = ...' is specified"):
    end_if;
  end_if:

  //produce an uc(0,1) random generator: 
  if args(0)=3 then
       y:= frandom(op(args(3),2)):
  else y:= frandom:
  end_if:

  //-------------------------------
  // return the following procedure
  //-------------------------------
  proc()
  local z;
  begin:
     z:= y():
     if iszero(z) or iszero(1 - z) then
        return(fm);
     end_if:
     fm + float(3)^(1/2)/float(PI)*fs*ln::float(z/(1-z));
  end_proc:
end_proc:
