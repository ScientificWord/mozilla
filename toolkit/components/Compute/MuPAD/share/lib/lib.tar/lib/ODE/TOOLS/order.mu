// eq is an equation, l a set of names 
ode::order:=
proc(eq,l,solveOptions,odeOptions)
  local s;
begin
   if type(eq)=DOM_SET then
     max(ode::order(op(eq,s),l,solveOptions,odeOptions) $ s=1..nops(eq))
   else
     s:= ode::odeIndets(eq,l,solveOptions,odeOptions);
     if s={} then
       -1 // no name(..)
     else
       max(op(map(s,ode::order_term,l,solveOptions,odeOptions)))
     end_if;
   end_if;
   
end_proc:


ode::order_term:=
proc(f,l,solveOptions={},odeOptions={}) // f=y(t) or diff(y(t),t,...) or D(...)(t) 
begin
   case type(f)
   of "function" do 
     if contains(l,op(f,0)) then
       return(0);
     elif type(op(f,0))="D" then
		   return(1+ode::order_term(op(op(f,0))(op(f)),l,solveOptions,odeOptions));
     else 
       return(max(op(map([op(f)],ode::order_term,l,solveOptions,odeOptions))));
     end_if;
   of "diff" do 
     return(nops(f)-1);
   otherwise 
     error("invalid argument");
   end_case;
   
end_proc:


