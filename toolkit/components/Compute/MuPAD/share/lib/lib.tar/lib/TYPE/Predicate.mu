// f should be a function returning TRUE, FALSE or FAIL.
// x is of type Type::Predicate(f <, arg1, ...>) if f(x, arg1, ...) is TRUE.
Type::Predicate :=
proc(p)
    option escape;
    local typeName, typeOptions, options;
begin
    if domtype(p) = DOM_STRING then
	typeName := p;
	p := args(2);
	options := args(3..args(0));
	if args(0)>2 then
	    typeOptions := [options];
	else
	    typeOptions := FALSE;
	end_if;
    else
	typeName := "Predicate";
	options := args(2..args(0));
	typeOptions := [p, options];
    end_if;
    // This construction depends on undocumented features of the
    // Type library, and might be broken in future versions of MuPAD>=2.5

    new(Type, typeName,
	proc(F,x) name Type::Predicate; option noDebug; begin p(x, options) end,
	typeOptions, FALSE);
end_proc:
