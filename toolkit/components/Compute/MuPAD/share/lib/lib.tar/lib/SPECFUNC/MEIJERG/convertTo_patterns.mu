proc()
  save patterns, LEVEL;
begin
  patterns := read( "SPECFUNC".stdlib::PathSep."MEIJERG".stdlib::PathSep."toMeijerGPatterns.mb" );
  specfunc::MeijerG::convertTo_patterns := patterns:
end():
