//      #

// Imaginary -- expression to test for imaginary numbers

Type::Imaginary:=
    new(Type,
	"Imaginary",
	proc(t,x)
	  name Type::Imaginary;
          option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if domtype(x) = DOM_COMPLEX then
		iszero(Re(x))
            elif iszero(x) then
                TRUE
	    else
		FAIL
	    end_if;
	end_proc,
	FALSE, FALSE):
