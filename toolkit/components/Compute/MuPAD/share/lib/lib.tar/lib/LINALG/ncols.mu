/*
 linalg::ncols  -- returns the number of columns of a matrix
*/

linalg::ncols:= proc(x)
begin
 if testargs() then
   if args(0) <> 1 then error("expecting 1 argument") end_if;
   if x::dom::hasProp( Cat::Matrix ) <> TRUE then
     error("argument is not of 'Cat::Matrix'")
   end_if
 end_if;
 op( x::dom::matdim(x),2 )
end_proc:

