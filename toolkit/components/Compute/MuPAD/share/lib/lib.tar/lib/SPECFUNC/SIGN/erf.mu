//    

/*--
	erf/sign -- the function attribut "sign" for erf
--*/

erf::sign:=
  proc(x)
    local op1;
  begin 
    op1 := sign(op(x, 1));
    if contains({-1, 0, 1, I, -I}, op1) then
      op1
    else
      hold(sign)(x)
    end_if
  end_proc:

// end of file 
