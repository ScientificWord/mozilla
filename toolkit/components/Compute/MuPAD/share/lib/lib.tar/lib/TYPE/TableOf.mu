Type::TableOf :=
proc(Tindex=Type::AnyType, Tentries=Type::AnyType)
    option noDebug;
begin
    new(Type, "TableOf",
	proc(T,t)
	  name Type::TableOf;
	  option noDebug;
	  local res, eq;
	begin
	    if _lazy_or(args(0)<>2, domtype(t)<>DOM_TABLE) then
		return(FALSE);
	    end_if;
	    for eq in t do
		if (res:=testtype(lhs(eq), op(T,1))) <> TRUE then
		    return(res);
		end_if;
		if (res:=testtype(rhs(eq), op(T,2))) <> TRUE then
		    return(res);
		end_if;
	    end_for;
	    return(TRUE);
	end_proc,
	[Tindex, Tentries], FALSE);
end_proc:
