//    

// andi, 30.06.97 

/*++
unload  - Unload a MuPAD modul

Still available to be compatible with MuPAD 1.3. Refer to
'module::displace'.

++*/

module::unload:= module::displace:

// end of file 
