//      #

// NonNegRat -- expression to test for non-negative rationals

Type::NonNegRat:=
    new(Type,
	"NonNegRat",
	proc(t,x) 
	  name Type::NonNegRat;
	  option noDebug;
        begin
	    if args(0) <> 2 then return(FALSE) end_if;
	    if contains({DOM_INT, DOM_RAT}, domtype(x)) then
		return(bool(x >= 0))
	    end_if;
	    FAIL
	end_proc,
	FALSE, FALSE):
