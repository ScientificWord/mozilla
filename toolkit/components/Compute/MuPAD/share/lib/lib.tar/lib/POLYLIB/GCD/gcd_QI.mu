
/* 
   gcdlib::gcd_QI(a, b)

   a, b - polynomials over Expr, both in the same variable(s), whose coefficients are of one of the types DOM_INT, DOM_RAT, DOM_COMPLEX

   returns the gcd of a and b

*/

gcdlib::gcd_QI:=
proc(a, b)
  local result;
begin
 result:= gcdlib::heu_gcd_QI(a, b);
 if result = FAIL or result = FALSE then
    result:= gcdlib::mod_gcd_QI(a, b)
 end_if;

 result
end_proc:

// end of file
