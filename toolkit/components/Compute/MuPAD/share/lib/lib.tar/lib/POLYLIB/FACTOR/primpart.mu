/*--
faclib::primpart -- return the primitive polynomial of input polynomial, output
                    is a polynomial.

faclib::primpart(a)
a - a polynomial in Z
--*/

faclib::primpart:=proc(a)
local icont;
begin
    if (icont:=icontent(a))=1 then 
       a;
    else multcoeffs(a,1/icont); 
    end_if;
end_proc:

