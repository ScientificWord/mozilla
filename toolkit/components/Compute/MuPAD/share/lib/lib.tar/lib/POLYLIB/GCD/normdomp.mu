//    

// kg, 14/09/94 

/*--
gcdlib::norm_domp -- normalize polynomial over domain

gcdlib::norm_domp(a, b)

a,b - polynomials over domain
--*/

gcdlib::norm_domp:= proc(aa, b)
    local T, ca, x, a;
begin
    a:=aa;
    T:= op(a,3);

    if args(0) = 2 then
        ca:= content(a);
	a:= multcoeffs(mapcoeffs(a, T::_divide, ca), T::gcd(ca, content(b)))
    end_if;
    
    if T::unitNormalRep <> FAIL then
	x:= T::unitNormalRep(lcoeff(a));
	a:= multcoeffs(a, x[2]);
    end_if;
    a
end_proc:

// end of file 
